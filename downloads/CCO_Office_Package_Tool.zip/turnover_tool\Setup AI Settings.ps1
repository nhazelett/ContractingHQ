$ErrorActionPreference = "Stop"

$settingsPath = Join-Path $PSScriptRoot "settings.env"

Write-Host "CCO Office Package Tool - AI Settings"
Write-Host ""
Write-Host "This writes settings.env next to the dashboard files."
Write-Host "Keep that file private; it contains the user's API key."
Write-Host ""

$secureKey = Read-Host "Paste the user's OpenAI API key" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
}
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

if ([string]::IsNullOrWhiteSpace($apiKey)) {
    throw "No API key was entered."
}

$model = Read-Host "Model to use for AI assist [gpt-4.1-mini]"
if ([string]::IsNullOrWhiteSpace($model)) {
    $model = "gpt-4.1-mini"
}

$lines = @(
    "# Local AI settings for the CCO Office Package Tool",
    "# Do not email or upload this file.",
    "CCO_AI_PROVIDER=api",
    "OPENAI_API_KEY=$apiKey",
    "OPENAI_MODEL=$model",
    "# OPENAI_RESPONSES_URL=https://api.openai.com/v1/responses"
)

Set-Content -LiteralPath $settingsPath -Value $lines -Encoding UTF8

Write-Host ""
Write-Host "Wrote $settingsPath"
Write-Host "Restart the dashboard if it was already open."
