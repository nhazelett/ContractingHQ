#!/usr/bin/env python3
"""
Generate mock CCO turnover contract action folders.

The generator is intentionally "20XX safe": exercise-facing documents use
20XX, FYXX, and FA4867XX-style identifiers so the same kit can be reused.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import random
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import date, timedelta
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, RGBColor
except ImportError:
    Document = None
    WD_ALIGN_PARAGRAPH = None
    Inches = None
    RGBColor = None
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch, mm
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


GENERIC_YEAR = "20XX"
GENERIC_YEAR_PREV = "20XW"
GENERIC_YEAR_PREV2 = "20XV"
GENERIC_FY = "FYXX"
EXERCISE_BANNER = "//EXERCISE//EXERCISE//EXERCISE//"

# Active year token used by the date formatters. Normally the current exercise
# year (20XX). Inject-bearing historical files (for example an expired BPA
# master that was awarded "last year") temporarily switch this to a prior-year
# token so the whole file reads as an older record.
_ACTIVE_YEAR_TOKEN = GENERIC_YEAR


def set_active_year_token(token: str) -> None:
    global _ACTIVE_YEAR_TOKEN
    _ACTIVE_YEAR_TOKEN = token or GENERIC_YEAR


def active_year_token() -> str:
    return _ACTIVE_YEAR_TOKEN
CONSTRUCTION_AWARD_CAP = 1_999_000
TASK_ORDER_AWARD_CAP = 999_000
MAX_PACKAGE_NAME_CHARS = 32
MAX_ACTION_LABEL_CHARS = 20
MAX_DOCUMENT_NAME_CHARS = 36
MAX_OFFICE_RELATIVE_PATH_CHARS = 115
MAX_CONTROLLED_RELATIVE_PATH_CHARS = 145
PIID_PATTERN = re.compile(r"FA4867XX[A-Z]\d{4}", re.I)
SEQUENCE_STATE_FILE = "_sequence_state.json"
SEQUENCE_LOCK_FILE = "_sequence_state.lock"
AI_PROVIDER_CHOICES = ["codex-cli", "codex", "local", "api", "auto", "none"]

DEFAULT_OFFICE_NAME = "Mock Office Drive"
OFFICE_ADMIN_DIRNAME = "00. Office Admin"
OFFICE_FILES_DIRNAME = "01. Contract Files"
OFFICE_CONTROLLER_DIRNAME = "_controller"
PARENT_ADMIN_DIRNAME = "9. Admin"
PARENT_ADMIN_DIR_ALIASES = ["9. Administration"]


def office_admin_dir(office_dir: Path) -> Path:
    return office_dir / OFFICE_ADMIN_DIRNAME


def office_files_dir(office_dir: Path) -> Path:
    return office_dir / OFFICE_FILES_DIRNAME


def office_controller_dir(office_dir: Path) -> Path:
    return office_dir / OFFICE_CONTROLLER_DIRNAME


def stage_folder_name(stage: int) -> str:
    for stage_num, stage_name in STAGE_FOLDERS:
        if stage_num == stage:
            return stage_name
    raise ValueError(stage)


def stage_folder_names(stage: int) -> list[str]:
    return [stage_folder_name(stage), *STAGE_FOLDER_ALIASES.get(stage, [])]


def parent_admin_dir(folder: Path) -> Path:
    default = folder / PARENT_ADMIN_DIRNAME
    if default.exists():
        return default
    for alias in PARENT_ADMIN_DIR_ALIASES:
        candidate = folder / alias
        if candidate.exists():
            return candidate
    return default


def load_local_settings() -> None:
    settings_path = Path(__file__).resolve().with_name("settings.env")
    if not settings_path.exists():
        return
    try:
        lines = settings_path.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


load_local_settings()


STAGE_FOLDERS = [
    (1, "1. Initial"),
    (2, "2. Funding"),
    (3, "3. Market Research"),
    (4, "4. Solicitation"),
    (5, "5. Quotes"),
    (6, "6. Evaluation"),
    (7, "7. Award"),
    (8, "8. Delivery"),
]

STAGE_FOLDER_ALIASES = {
    1: ["1. Initial Documents & IGE"],
    2: ["2. Funding Documents"],
    3: ["3. Market"],
    4: ["4. Solicit"],
    5: ["5. Quotes or Proposals"],
    6: ["6. Eval"],
    8: ["8. Delivery Confirmation"],
}

MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
]


@dataclass
class Scenario:
    index: int
    archetype: dict[str, Any]
    customer: dict[str, Any]
    requester: str
    approver: str
    certifier: str
    co: dict[str, str]
    contractors: list[dict[str, str]]
    winner: dict[str, str]
    base_amount: int
    line_items: list[dict[str, Any]]
    quote_rows: list[dict[str, Any]]
    stage: int
    timeline: dict[str, date]
    delivery_address: str
    contract_number: str
    piid_sequence: int
    parent_contract_number: str
    parent_instrument_label: str
    parent_vehicle: dict[str, Any]
    solicitation_number: str
    pr_number: str
    file_number: str
    loa: str
    accounting_data: str
    funding_label: str
    folder_name: str
    category: str
    requirement_category: str
    solicitation_style: str


def load_data() -> dict[str, Any]:
    data_path = Path(__file__).with_name("scenario_data.json")
    return json.loads(data_path.read_text(encoding="utf-8"))


def ai_api_key() -> str:
    return os.environ.get("OPENAI_API_KEY", "").strip() or os.environ.get("AI_API_KEY", "").strip()


def ai_model_name(requested: str = "") -> str:
    return (
        requested.strip()
        or os.environ.get("OPENAI_MODEL", "").strip()
        or os.environ.get("AI_MODEL", "").strip()
        or "gpt-4.1-mini"
    )


def ai_endpoint() -> str:
    return (
        os.environ.get("OPENAI_RESPONSES_URL", "").strip()
        or os.environ.get("AI_API_URL", "").strip()
        or "https://api.openai.com/v1/responses"
    )


def normalize_ai_provider(value: str = "") -> str:
    cleaned = (value or "codex-cli").strip().lower().replace("_", "-")
    aliases = {
        "codex": "codex-cli",
        "cli": "codex-cli",
        "local": "codex-cli",
        "openai": "api",
        "openai-api": "api",
        "off": "none",
        "false": "none",
    }
    return aliases.get(cleaned, cleaned)


def default_ai_provider() -> str:
    provider = normalize_ai_provider(os.environ.get("CCO_AI_PROVIDER", "codex-cli"))
    return provider if provider in AI_PROVIDER_CHOICES else "codex-cli"


def codex_command() -> str | None:
    found = shutil.which("codex")
    if found:
        return found
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        Path(local_app_data) / "OpenAI" / "Codex" / "bin" / "codex.exe",
        Path(local_app_data) / "Microsoft" / "WindowsApps" / "codex.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def codex_model_args(model: str = "") -> list[str]:
    model = model.strip()
    return ["--model", model] if model else []


def codex_env() -> dict[str, str]:
    env = dict(os.environ)
    # Force the local logged-in Codex path instead of surprise API-key billing.
    for key in ["OPENAI_API_KEY", "AI_API_KEY", "ANTHROPIC_API_KEY", "CLAUDE_API_KEY", "CODEX_API_KEY"]:
        env.pop(key, None)
    return env


def response_text_from_payload(payload: Any) -> str:
    if isinstance(payload, str):
        return payload
    if isinstance(payload, list):
        parts = [response_text_from_payload(item) for item in payload]
        return "\n".join(part for part in parts if part)
    if not isinstance(payload, dict):
        return ""
    if isinstance(payload.get("output_text"), str):
        return payload["output_text"]
    if payload.get("type") == "output_text" and isinstance(payload.get("text"), str):
        return payload["text"]
    if isinstance(payload.get("text"), str):
        return payload["text"]
    if isinstance(payload.get("message"), dict):
        text = response_text_from_payload(payload["message"])
        if text:
            return text
    for key in ["output", "content", "choices"]:
        text = response_text_from_payload(payload.get(key))
        if text:
            return text
    return ""


def parse_json_object(text: str) -> dict[str, Any] | None:
    text = text.strip()
    if not text:
        return None
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            return None
        try:
            value = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return value if isinstance(value, dict) else None


def call_codex_cli_json(system_prompt: str, user_prompt: str, model: str = "") -> tuple[dict[str, Any] | None, str]:
    command = codex_command()
    if not command:
        return None, "Codex assist skipped because the local codex CLI was not found."
    prompt = (
        f"{system_prompt}\n\n"
        f"{user_prompt}\n\n"
        "Return only one valid JSON object. Do not write markdown fences, commentary, or a preface."
    )
    with tempfile.TemporaryDirectory(prefix="cco_codex_assist_") as tmp:
        output_path = Path(tmp) / "last-message.txt"
        args = [
            command,
            "exec",
            "--skip-git-repo-check",
            "--ephemeral",
            "--sandbox",
            "read-only",
            "-C",
            str(package_root()),
            "--output-last-message",
            str(output_path),
            "-c",
            'model_reasoning_effort="low"',
            *codex_model_args(model),
            "-",
        ]
        try:
            result = subprocess.run(
                args,
                input=prompt,
                capture_output=True,
                text=True,
                timeout=300,
                env=codex_env(),
            )
        except subprocess.TimeoutExpired:
            return None, "Codex assist timed out after 5 minutes."
        except Exception as exc:
            return None, f"Codex assist failed to start: {exc}"
        text = output_path.read_text(encoding="utf-8", errors="replace") if output_path.exists() else result.stdout
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or text).strip()[:800]
            return None, f"Codex assist exited with code {result.returncode}: {detail}"
        parsed = parse_json_object(text)
        if parsed is None:
            return None, "Codex assist did not return a parseable JSON object."
        return parsed, "Codex assist used the local codex CLI."


def call_api_json(system_prompt: str, user_prompt: str, model: str = "") -> tuple[dict[str, Any] | None, str]:
    key = ai_api_key()
    if not key:
        return None, "AI assist skipped because OPENAI_API_KEY or AI_API_KEY is not set."
    request_payload = {
        "model": ai_model_name(model),
        "input": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "text": {"format": {"type": "json_object"}},
        "temperature": 0.55,
    }
    request = urllib.request.Request(
        ai_endpoint(),
        data=json.dumps(request_payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:600]
        return None, f"AI assist request failed with HTTP {exc.code}: {detail}"
    except Exception as exc:
        return None, f"AI assist request failed: {exc}"
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return None, "AI assist response was not valid JSON."
    content = response_text_from_payload(payload)
    parsed = parse_json_object(content)
    if parsed is None:
        return None, "AI assist did not return a parseable JSON object."
    return parsed, f"AI assist used model {ai_model_name(model)}."


def call_ai_json(
    system_prompt: str,
    user_prompt: str,
    model: str = "",
    provider: str = "codex-cli",
) -> tuple[dict[str, Any] | None, str]:
    provider = normalize_ai_provider(provider)
    if provider == "none":
        return None, "AI assist skipped because provider is set to none."
    if provider == "api":
        return call_api_json(system_prompt, user_prompt, model)
    if provider == "auto":
        if codex_command():
            return call_codex_cli_json(system_prompt, user_prompt, model)
        return call_api_json(system_prompt, user_prompt, model)
    return call_codex_cli_json(system_prompt, user_prompt, model)


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def sanitize_filename(value: str, fallback: str = "untitled") -> str:
    value = re.sub(r'[<>:"/\\|?*]+', " ", value)
    value = re.sub(r"\s+", " ", value).strip().rstrip(".")
    return value or fallback


def truncate_filename(value: str, max_chars: int, fallback: str = "untitled") -> str:
    value = sanitize_filename(value, fallback)
    if len(value) <= max_chars:
        return value
    value = value[:max_chars].rstrip(" ._-")
    return value or fallback


def slugify(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")
    return value or "Requirement"


def compact_doc_name_for_number(contract_number: str, label: str, ext: str = "pdf") -> str:
    ext = ext.lstrip(".") or "pdf"
    label_slug = slugify(label)
    contract_number = sanitize_filename(str(contract_number or "")).replace(" ", "")
    stem = f"{contract_number}_{label_slug}" if contract_number else label_slug
    max_stem = max(8, MAX_DOCUMENT_NAME_CHARS - len(ext) - 1)
    return f"{truncate_filename(stem, max_stem, contract_number or label_slug)}.{ext}"


def compact_doc_name_for_label(label: str, ext: str = "pdf") -> str:
    ext = ext.lstrip(".") or "pdf"
    stem = sanitize_filename(str(label or "Doc"), "Doc")
    max_stem = max(3, MAX_DOCUMENT_NAME_CHARS - len(ext) - 1)
    return f"{truncate_filename(stem, max_stem, 'Doc')}.{ext}"


def compact_doc_name(s: Scenario, label: str, ext: str = "pdf") -> str:
    return compact_doc_name_for_label(label, ext)


def money(value: float | int) -> str:
    return f"${value:,.2f}"


def quantity_display(value: Any) -> str:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    if numeric.is_integer():
        return str(int(numeric))
    return f"{numeric:g}"


def numeric_quantity(value: Any) -> float:
    try:
        quantity = float(value)
    except (TypeError, ValueError):
        return 1.0
    return quantity if quantity > 0 else 1.0


def apply_quantity_override(archetype: dict[str, Any], quantity: int | None) -> None:
    if not quantity:
        return
    archetype["quantity"] = quantity
    if archetype.get("line_items"):
        # The first CLIN normally carries the main quantity from the scenario prompt.
        archetype["line_items"][0]["quantity"] = quantity


def prompt_quantity_scale(prompt: str) -> str:
    lower = prompt.lower()
    if any(term in lower for term in ["minor", "small", "limited", "temporary", "supplemental", "additional", "add-on", "addon"]):
        return "low"
    if any(term in lower for term in ["large", "major", "base expansion", "perimeter", "new ecp", "expansion", "multiple", "several"]):
        return "high"
    return "normal"


def random_quantity_from_range(archetype: dict[str, Any], rng: random.Random, prompt: str = "") -> int | None:
    quantity_range = archetype.get("quantity_range")
    if not isinstance(quantity_range, list) or len(quantity_range) < 2:
        return None
    low = int(quantity_range[0])
    high = int(quantity_range[1])
    if high < low:
        low, high = high, low
    scale = prompt_quantity_scale(prompt)
    midpoint = (low + high) // 2
    if scale == "low":
        high = max(low, midpoint)
    elif scale == "high":
        low = min(high, midpoint)
    step = max(1, int(archetype.get("quantity_step") or 1))
    values = list(range(low, high + 1, step))
    if not values or values[-1] != high:
        values.append(high)
    return rng.choice(values)


def random_int_from_range(value: Any, rng: random.Random, fallback: int, minimum: int = 1, maximum: int = 9999, step: int = 1) -> int:
    quantity_range = clean_ai_range(value, [fallback, fallback], minimum, maximum, step)
    low, high = int(quantity_range[0]), int(quantity_range[1])
    if high < low:
        low, high = high, low
    step = max(1, int(step or 1))
    values = list(range(low, high + 1, step))
    if not values or values[-1] != high:
        values.append(high)
    return rng.choice(values)


def apply_line_item_quantity_ranges(archetype: dict[str, Any], rng: random.Random, preserve_first_quantity: bool = False) -> None:
    for idx, item in enumerate(archetype.get("line_items", [])):
        if preserve_first_quantity and idx == 0:
            continue
        if not isinstance(item, dict) or "quantity_range" not in item:
            continue
        fallback = clean_ai_int(item.get("quantity"), int(archetype.get("quantity") or 1), 1, 9999)
        step = clean_ai_int(item.get("quantity_step"), 1, 1, 1000)
        item["quantity"] = random_int_from_range(item.get("quantity_range"), rng, fallback, 1, 9999, step)


def enforce_service_period(archetype: dict[str, Any], category: str) -> None:
    if category != "service":
        return
    if is_master_vehicle_category(str(archetype.get("category") or "")):
        return
    if str(archetype.get("unit", "")).upper() == "MO":
        archetype["quantity"] = 12
    for item in archetype.get("line_items", []):
        if str(item.get("unit", "")).upper() == "MO":
            item["quantity"] = 12


def line_items_for_amount(archetype: dict[str, Any], total_amount: float | int) -> list[dict[str, Any]]:
    source_items = archetype.get("line_items") or [
        {
            "description": archetype["clin_description"],
            "quantity": archetype["quantity"],
            "unit": archetype["unit"],
            "share": 1,
        }
    ]
    total = float(total_amount)
    weights = [float(item.get("share", item.get("weight", 1))) for item in source_items]
    total_weight = sum(weights) or 1.0
    line_items: list[dict[str, Any]] = []
    allocated = 0.0
    for idx, item in enumerate(source_items):
        if idx == len(source_items) - 1:
            amount = round(total - allocated, 2)
        else:
            amount = round(total * (weights[idx] / total_weight), 2)
            allocated += amount
        quantity = numeric_quantity(item.get("quantity", 1))
        line_items.append(
            {
                "clin": str(item.get("clin", f"{idx + 1:04d}")),
                "description": str(item.get("description", archetype["clin_description"])),
                "vehicle_class": str(item.get("vehicle_class", "")),
                "price_note": str(item.get("price_note", "")),
                "quantity": quantity_display(item.get("quantity", 1)),
                "unit": str(item.get("unit", archetype["unit"])),
                "unit_price": amount / quantity,
                "amount": amount,
            }
        )
    return line_items


def money_from_range(value: Any, rng: random.Random, step: int = 10) -> float:
    if isinstance(value, (list, tuple)) and len(value) >= 2:
        low = float(value[0])
        high = float(value[1])
        if high < low:
            low, high = high, low
        amount = rng.uniform(low, high)
    else:
        amount = float(value)
    if step > 1:
        amount = round(amount / step) * step
    return round(amount, 2)


def quantity_priced_amount(archetype: dict[str, Any], rng: random.Random) -> float | None:
    if is_master_vehicle_category(str(archetype.get("category") or "")):
        return None
    source_items = archetype.get("line_items") or []
    if not source_items:
        return None
    priced_amounts: list[float] = []
    for item in source_items:
        quantity = numeric_quantity(item.get("quantity", 1))
        if "unit_price_range" in item:
            unit_price = money_from_range(item["unit_price_range"], rng, step=5)
            amount = round(unit_price * quantity / 10) * 10
        elif "unit_price" in item:
            amount = round(float(item["unit_price"]) * quantity, 2)
        elif "fixed_price_range" in item:
            amount = money_from_range(item["fixed_price_range"], rng, step=10)
        elif "fixed_amount" in item:
            amount = round(float(item["fixed_amount"]), 2)
        else:
            return None
        priced_amounts.append(round(float(amount), 2))
    total = round(sum(priced_amounts), 2)
    if total <= 0:
        return None
    for item, amount in zip(source_items, priced_amounts):
        item["share"] = amount / total
    return total


def line_item_total(line_items: list[dict[str, Any]]) -> float:
    return round(sum(float(item["amount"]) for item in line_items), 2)


def line_item_table(
    line_items: list[dict[str, Any]],
    include_unit_price: bool = False,
    include_amount: bool = True,
    include_total: bool = True,
) -> list[list[str]]:
    header = ["CLIN", "Description", "Qty", "Unit"]
    if include_unit_price:
        header.append("Unit Price")
    if include_amount:
        header.append("Amount")
    rows = [header]
    for item in line_items:
        row = [item["clin"], item["description"], item["quantity"], item["unit"]]
        if include_unit_price:
            row.append(money(item["unit_price"]))
        if include_amount:
            row.append(money(item["amount"]))
        rows.append(row)
    if include_amount and include_total and len(line_items) > 1:
        total_row = ["", "Total", "", ""]
        if include_unit_price:
            total_row.append("")
        total_row.append(money(line_item_total(line_items)))
        rows.append(total_row)
    return rows


def evaluation_factors_from_focus(focus: str) -> list[str]:
    return ["Price", "Past Performance", "Technical"]


def clean_technical_consideration(value: str) -> str:
    text = re.sub(r"\s+", " ", value or "").strip(" .;:")
    cleanup_patterns = [
        (r"^technical\s+acceptability\s+(?:should\s+)?(?:consider|address|include)\s+", ""),
        (r"^technical\s+acceptability\s+of\s+", ""),
        (r"^technical\s+acceptability$", ""),
        (r"^technical\s+approach\s+(?:for|to)\s+", ""),
        (r"^technical\s+repair\s+plan$", "repair plan"),
        (r"^technical\s+capability$", "vendor capability"),
        (r"^technical\s+(?:will\s+|should\s+)?(?:consist\s+of|include|address)\s+", ""),
        (r"^ability\s+to\s+meet\s+(?:required\s+)?", ""),
        (r"^compliance\s+with\s+(?:stated\s+)?", ""),
        (r"^completeness\s+of\s+(?:the\s+)?", ""),
    ]
    for pattern, replacement in cleanup_patterns:
        text = re.sub(pattern, replacement, text, count=1, flags=re.I).strip(" .;:")
    replacements = {
        "material specifications": "material specifications",
        "proposed bill of materials": "bill of materials",
    }
    return replacements.get(text.lower(), text)


def technical_considerations_from_focus(focus: str) -> list[str]:
    focus = str(focus).replace(", and ", ", ")
    focus = re.sub(r";\s*(?:price|cost|past performance)\b.*$", "", focus, flags=re.I)
    focus = re.sub(r"\.\s*(?:Price|Past Performance)\b.*$", "", focus, flags=re.I)
    considerations: list[str] = []
    for item in [factor.strip(" .") for factor in focus.split(",") if factor.strip()]:
        item = clean_technical_consideration(item)
        if not item:
            continue
        lower = item.lower()
        if "price" in lower or "cost" in lower or "past performance" in lower:
            continue
        if item.lower() in {existing.lower() for existing in considerations}:
            continue
        considerations.append(item)
    for fallback in ["technical approach", "delivery or performance schedule", "quality control or capability"]:
        if len(considerations) >= 3:
            break
        if fallback.lower() not in {existing.lower() for existing in considerations}:
            considerations.append(fallback)
    return considerations[:3]


def technical_factor_list_from_archetype(archetype: dict[str, Any]) -> list[str]:
    factors = technical_considerations_from_focus(archetype.get("evaluation_focus", ""))
    existing = {factor.lower() for factor in factors}
    profile = archetype.get("_requirement_profile")
    profile = profile if isinstance(profile, dict) else {}
    if profile_text_list(profile.get("salient_characteristics"), 10) and "salient characteristics" not in existing:
        factors.insert(0, "salient characteristics")
        existing.add("salient characteristics")
    if (
        profile_text_list(profile.get("acceptance_criteria"), 8)
        and "inspection and acceptance approach" not in existing
        and len(factors) < 5
    ):
        factors.append("inspection and acceptance approach")
    return factors[:5]


def technical_consideration_summary(s: "Scenario") -> str:
    items = [factor_title(item) for item in technical_factor_list(s)]
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return ", ".join(items[:-1]) + f", and {items[-1]}"


def evaluation_strategy_summary(s: "Scenario") -> str:
    return (
        "Price, Past Performance, and Technical. "
        f"Technical will consist of {technical_consideration_summary(s)}."
    )


def factor_title(factor: str) -> str:
    return factor[:1].upper() + factor[1:]


def quote_factor_response(
    archetype: dict[str, Any],
    category: str,
    factor: str,
    amount: float | int,
    contractor: dict[str, str],
) -> str:
    lower = factor.lower()
    vendor = contractor["name"]
    profile = archetype.get("_requirement_profile") if isinstance(archetype.get("_requirement_profile"), dict) else {}
    salient = profile_text_list(profile.get("salient_characteristics"), 4)
    acceptance = profile_text_list(profile.get("acceptance_criteria"), 3)
    if "price" in lower or "cost" in lower:
        return f"Firm-fixed-price total is {money(amount)}. Pricing is valid for 30 calendar days and includes the CLINs shown in the quote."
    if "salient" in lower or "specification" in lower or "characteristic" in lower:
        if salient:
            return f"{vendor} confirms the offered solution addresses the required characteristics, including: {'; '.join(salient)}."
        return f"{vendor} confirms the offered solution meets the stated technical characteristics without exception."
    if "acceptance" in lower or "inspection" in lower:
        if acceptance:
            return f"{vendor} will support Government inspection and acceptance using these criteria: {'; '.join(acceptance)}."
        return f"{vendor} will support Government inspection, receiving, and acceptance at the required delivery or performance location."
    if "delivery" in lower or "schedule" in lower or "timeline" in lower or "start" in lower:
        return f"{archetype['delivery_note']} {vendor} will coordinate access, staging, and delivery notices through the Government POC."
    if "maintenance" in lower or "response" in lower:
        return "Routine support will be handled during normal duty hours with emergency call-back available through the vendor dispatch phone."
    if "service" in lower or "sanitary" in lower or "quality" in lower:
        return "The proposed approach uses a dedicated lead, recurring quality checks, and same-day correction of customer-identified service issues when materials are available."
    if "staff" in lower or "labor" in lower:
        return "Staffing will be sourced from the current deployed labor pool with a designated site lead for daily coordination and accountability."
    if "safety" in lower or "site" in lower or "construction" in lower:
        return "The crew will conduct a site walk before work begins, maintain a daily safety brief, and follow base access and work-control procedures."
    if "past performance" in lower or "experience" in lower:
        return "The vendor reports recent similar base-support work for logistics, sustainment, and expeditionary facility requirements."
    if "warranty" in lower or "support" in lower:
        return "Quoted materials and workmanship include standard commercial warranty support, with defective items corrected or replaced after Government notice."
    if "technical" in lower or "acceptable" in lower or "capacity" in lower:
        return f"The quoted solution meets the stated requirement for {lowercase_display_phrase(archetype['clin_description'])} and is available within the required performance window."
    return f"{vendor} confirms its proposed approach can meet this technical consideration for the stated deployed requirement."


def quote_response_flaw(
    factors: list[str],
    idx: int,
    rng: random.Random,
) -> list[str]:
    if idx == 0 or not factors:
        return []
    non_price_factors = [factor for factor in factors if "price" not in factor.lower() and "cost" not in factor.lower()]
    if not non_price_factors:
        return []
    if rng.random() > 0.34:
        return []
    missing_count = 1 if len(non_price_factors) < 4 or rng.random() > 0.2 else 2
    return rng.sample(non_price_factors, min(missing_count, len(non_price_factors)))


def quote_technical_status(non_response: bool, missing_factors: list[str], rng: random.Random) -> str:
    if non_response:
        return "No Response"
    if not missing_factors:
        return "Acceptable"
    if len(missing_factors) > 1:
        return "Unacceptable"
    factor = missing_factors[0].lower()
    if any(word in factor for word in ["technical", "capacity", "delivery", "schedule", "safety", "staff", "service"]):
        return "Unacceptable" if rng.random() < 0.7 else "Acceptable with clarification"
    return "Acceptable with clarification"


def quote_deficiency_note(quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "No quote received by the stated deadline."
    missing = quote.get("missing_factors") or []
    if missing:
        return "Did not clearly address: " + "; ".join(factor_title(factor) for factor in missing) + "."
    if quote.get("technical") == "Acceptable with clarification":
        return "Technically reviewable; clarification may be needed."
    return "No material exception identified."


def build_quote_row(
    archetype: dict[str, Any],
    category: str,
    contractor: dict[str, str],
    amount: float | int,
    idx: int,
    factors: list[str],
    rng: random.Random,
    allow_non_response: bool = True,
    allow_technical_flaws: bool = True,
) -> dict[str, Any]:
    non_response = allow_non_response and idx > 0 and rng.random() < 0.14
    missing_factors = quote_response_flaw(factors, idx, rng) if allow_technical_flaws else []
    factor_responses = {
        factor: quote_factor_response(archetype, category, factor, amount, contractor)
        for factor in factors
        if factor not in missing_factors and not non_response
    }
    technical = quote_technical_status(non_response, missing_factors, rng)
    quote_suffix = re.sub(r"[^A-Z0-9]", "", contractor["code"])[-4:]
    return {
        "vendor": contractor["name"],
        "uei": contractor["code"],
        "amount": None if non_response else amount,
        "line_items": [] if non_response else line_items_for_amount(archetype, amount),
        "technical": technical,
        "delivery": archetype["delivery_note"],
        "quote_format": "no_quote" if non_response else "email",
        "non_response": non_response,
        "missing_factors": missing_factors,
        "factor_responses": factor_responses,
        "quote_number": f"Q-XX-{quote_suffix}-{idx + 1:02d}",
        "validity_days": rng.choice([15, 30, 30, 45]),
        "response_order": idx,
        "deficiency_note": quote_deficiency_note({"non_response": non_response, "missing_factors": missing_factors, "technical": technical}),
    }


def ensure_quote_variance(quote_rows: list[dict[str, Any]], factors: list[str], rng: random.Random) -> None:
    if len(quote_rows) < 3 or any(row.get("non_response") or row.get("missing_factors") for row in quote_rows):
        return
    eligible = [row for row in quote_rows if row.get("response_order", 0) != 0 and row.get("amount") is not None]
    non_price_factors = [factor for factor in factors if "price" not in factor.lower() and "cost" not in factor.lower()]
    if not eligible or not non_price_factors:
        return
    row = rng.choice(eligible)
    missing = rng.choice(non_price_factors)
    row["missing_factors"] = [missing]
    row["factor_responses"].pop(missing, None)
    row["technical"] = quote_technical_status(False, row["missing_factors"], rng)
    row["deficiency_note"] = quote_deficiency_note(row)


def fmt_date(value: date, short_month: bool = False) -> str:
    month = MONTHS[value.month - 1]
    if short_month:
        month = month[:3]
    return f"{value.day} {month} {active_year_token()}"


def fmt_form9_date(value: date) -> str:
    return f"{active_year_token()}{value.month:02d}{value.day:02d}"


def fmt_sf1449_date(value: date) -> str:
    return f"{value.month:02d}/{value.day:02d}/{active_year_token()}"


def following_year_suffix(start: date, end: date) -> str:
    return " (following year)" if end.year > start.year else ""


def fmt_period_range(start: date, end: date, sf_style: bool = False) -> str:
    formatter = fmt_sf1449_date if sf_style else fmt_date
    return f"{formatter(start)} through {formatter(end)}{following_year_suffix(start, end)}"


def fmt_email_time(hour: int, minute: int) -> str:
    return f"{hour:02d}{minute:02d}L"


def email_time(s: "Scenario", key: str, hour: int, minute: int) -> str:
    """Seeded jitter so identical document types do not all send at the same minute."""
    jitter_rng = random.Random(f"{s.contract_number}|time|{key}")
    total = hour * 60 + minute + jitter_rng.randint(-30, 110)
    total = max(6 * 60 + 5, min(19 * 60 + 45, total))
    return fmt_email_time(total // 60, total % 60)


def form9_number(index: int, rng: random.Random) -> str:
    chars = "ABCDEFGHJKLMNPRTUWXY0123456789"
    suffix = "".join(rng.choice(chars) for _ in range(5)) + f"{index % 100:02d}"
    return f"F2D3J{suffix}"


def person_display(person: str) -> str:
    return person.split(",", 1)[0].strip()


def person_email(person: str) -> str:
    name = person_display(person).replace('"', "")
    parts = re.findall(r"[A-Za-z]+", name)
    if len(parts) >= 2:
        return f"{parts[0].lower()}.{parts[-1].lower()}.{len(parts) + len(name)}@us.af.mil"
    return "exercise.user@us.af.mil"


def split_ranked_person(person: str) -> tuple[str, str, str]:
    clean = re.sub(r"\s+", " ", person.replace('"', "")).strip()
    if "," in clean:
        pieces = [piece.strip() for piece in clean.split(",")]
        return pieces[0], pieces[1] if len(pieces) > 1 else "", pieces[2] if len(pieces) > 2 else "USAF"
    match = re.match(r"^(Amn|A1C|SrA|SSgt|TSgt|MSgt|SMSgt|CMSgt|Lt|Capt|Maj|Lt Col|Col|GS-\d+)\s+(.+)$", clean, re.I)
    if match:
        return match.group(2), match.group(1), "USAF"
    return clean, "", "USAF"


def outlook_name(person: str, office: str = "", email: str | None = None) -> str:
    name, rank, service = split_ranked_person(person)
    parts = name.replace(".", "").split()
    if len(parts) > 1:
        display = f"{parts[-1].upper()}, {' '.join(part.upper() for part in parts[:-1])}"
    else:
        display = name.upper()
    rank_service = " ".join(part for part in [rank, service, office] if part)
    address = email or person_email(person)
    return f"{display} {rank_service} <{address}>".strip()


def signature_name(person: str) -> str:
    name, rank, service = split_ranked_person(person)
    parts = [name.upper()]
    if rank:
        parts.append(rank)
    if service:
        parts.append(service)
    return ", ".join(parts)


def customer_office_symbol(unit: str) -> str:
    suffixes = {
        "XXX ECES": "CEO",
        "XXX ESFS": "S4",
        "XXX EFSS": "FSR",
        "XXX ECS": "SCX",
        "XXX ELRS": "LGR",
        "XXX EMXS": "MXOO",
        "XXX EMDG": "SGSL",
        "XXX AEW": "A4C",
    }
    return f"{unit}/{suffixes.get(unit, 'CC')}"


def requester_title(s: Scenario) -> str:
    _, rank, _ = split_ranked_person(s.requester)
    if rank.startswith("GS-"):
        return stable_pick(s.requester, ["Program Manager", "Facility Manager", "Logistics Specialist"])
    if rank in {"Lt", "Capt", "Maj", "Lt Col", "Col"}:
        return stable_pick(s.requester + s.customer["unit"], ["OIC, Requirements", "Flight Commander", "Operations Officer"])
    unit_titles = {
        "XXX ECES": ["NCOIC, Operations Engineering", "NCOIC, Requirements", "Project NCOIC"],
        "XXX ESFS": ["NCOIC, S4", "Flight Chief", "NCOIC, Plans and Programs"],
        "XXX EFSS": ["NCOIC, Sustainment Services", "NCOIC, Services Operations", "Flight Chief"],
        "XXX ECS": ["NCOIC, Plans and Programs", "NCOIC, Systems Support", "Network Operations NCOIC"],
        "XXX ELRS": ["NCOIC, Vehicle Support", "NCOIC, Materiel Management", "Logistics Support NCOIC"],
        "XXX EMXS": ["NCOIC, Production Support", "Section Chief", "Maintenance Support NCOIC"],
        "XXX EMDG": ["NCOIC, Medical Logistics", "NCOIC, Clinic Support", "Section Chief"],
        "XXX AEW": ["NCOIC, A4C", "Wing Staff NCOIC", "Logistics Planner"],
    }
    return stable_pick(s.requester + s.customer["unit"], unit_titles.get(s.customer["unit"], ["NCOIC", "Flight Chief", "Section Chief"]))


def stable_pick(seed: str, options: list[str]) -> str:
    if not options:
        return ""
    return options[sum(ord(char) for char in seed) % len(options)]


def approver_title(s: Scenario) -> str:
    if "Resource Advisor" in s.approver:
        return "Resource Advisor"
    _, rank, _ = split_ranked_person(s.approver)
    if rank in {"Lt Col", "Col"}:
        return "Commander"
    if rank in {"Capt", "Maj"}:
        return stable_pick(s.approver + s.customer["unit"], ["Director of Operations", "Flight Commander", "OIC"])
    if rank in {"MSgt", "SMSgt", "CMSgt"}:
        return stable_pick(s.approver + s.customer["unit"], ["Superintendent", "Flight Chief", "Section Chief"])
    return stable_pick(s.approver + s.customer["unit"], ["Flight Chief", "NCOIC", "Section Chief"])


def approver_office_symbol(s: Scenario) -> str:
    title = approver_title(s)
    suffix = {
        "Commander": "CC",
        "Director of Operations": "DO",
        "Flight Commander": "CC",
        "OIC": "OIC",
        "Resource Advisor": "RA",
        "Superintendent": "CCC",
        "Flight Chief": "CCF",
        "Section Chief": "CCF",
    }.get(title, "CC")
    return f"{s.customer['unit']}/{suffix}"


def co_title(_: Scenario) -> str:
    return "Contingency Contracting Officer"


def email_signature(person: str, title: str, office: str, phone: str = "DSN: 318-XXX-2204", email: str | None = None) -> list[str]:
    lines = [signature_name(person), title, office, phone]
    if email:
        lines.append(email)
    return lines


def requester_header(s: Scenario) -> str:
    return outlook_name(s.requester, customer_office_symbol(s.customer["unit"]), person_email(s.requester))


def approver_header(s: Scenario) -> str:
    return outlook_name(s.approver, approver_office_symbol(s), person_email(s.approver))


def co_header(s: Scenario, data: dict[str, Any] | None = None) -> str:
    office = data["contracting_office"]["office_symbol"] if data else "XXX ECONS/LGCA"
    return outlook_name(s.co["name"], office, s.co["email"])


def requester_signature(s: Scenario) -> list[str]:
    return email_signature(
        s.requester,
        requester_title(s),
        s.customer["display_name"],
        "DSN: 318-XXX-3317",
        person_email(s.requester),
    )


def approver_signature(s: Scenario) -> list[str]:
    return email_signature(
        s.approver,
        approver_title(s),
        s.customer["display_name"],
        "DSN: 318-XXX-4410",
        person_email(s.approver),
    )


def co_signature(s: Scenario, data: dict[str, Any] | None = None) -> list[str]:
    office_name = data["contracting_office"]["office_name"] if data else "XXX Expeditionary Contracting Squadron"
    return email_signature(s.co["name"], co_title(s), office_name, f"DSN: {s.co['phone'].replace('DSN ', '')}", s.co["email"])


def vendor_email(vendor: dict[str, str]) -> str:
    slug = re.sub(r"[^a-z0-9]+", "", vendor["name"].lower().replace("llc", ""))
    return f"quotes@{slug or 'vendor'}.example"


def vendor_header(vendor: dict[str, str]) -> str:
    signer = vendor.get("signer", "Authorized Representative").split(",", 1)[0]
    return f"{signer} <{vendor_email(vendor)}>"


def pick_customer(data: dict[str, Any], archetype: dict[str, Any], rng: random.Random) -> dict[str, Any]:
    hint = archetype.get("customer_hint")
    for customer in data["customers"]:
        if customer["unit"] == hint:
            return deepcopy(customer)
    return deepcopy(rng.choice(data["customers"]))


def build_delivery_address(data: dict[str, Any], rng: random.Random) -> str:
    seed = rng.choice(data["delivery_addresses"])
    return f"Bldg {seed['building']}, {seed['street']}\nUndisclosed Location, Overseas"


def create_timeline(rng: random.Random) -> dict[str, date]:
    # Use a leap-year anchor only for arithmetic. The printed year is always 20XX.
    base = date(2000, rng.choice([2, 3, 4, 5, 6, 7, 8, 9]), rng.randint(3, 18))
    timeline = {
        "requirement": base,
        "ige": base + timedelta(days=rng.randint(1, 2)),
        "funding": base + timedelta(days=rng.randint(2, 5)),
    }
    timeline["market_research"] = timeline["funding"] + timedelta(days=rng.randint(1, 3))
    timeline["solicitation"] = timeline["market_research"] + timedelta(days=rng.randint(1, 3))
    timeline["questions_due"] = timeline["solicitation"] + timedelta(days=rng.randint(2, 4))
    timeline["quotes_due"] = timeline["solicitation"] + timedelta(days=rng.randint(5, 8))
    timeline["tech_eval_request"] = timeline["quotes_due"] + timedelta(days=1)
    timeline["tech_eval"] = timeline["tech_eval_request"] + timedelta(days=rng.randint(1, 2))
    timeline["decision"] = timeline["tech_eval"] + timedelta(days=1)
    timeline["award"] = timeline["decision"] + timedelta(days=rng.randint(1, 2))
    timeline["delivery"] = timeline["award"] + timedelta(days=rng.randint(5, 14))
    timeline["pop_end"] = timeline["delivery"] + timedelta(days=rng.choice([60, 90, 120, 180]))
    return timeline


def set_category_timeline(timeline: dict[str, date], category: str) -> None:
    if category == "service":
        timeline["pop_end"] = timeline["delivery"] + timedelta(days=364)
    elif category in {"bpa", "idiq"}:
        timeline["pop_end"] = timeline["award"] + timedelta(days=364)


def performance_period_label(s: Scenario) -> str:
    if is_service_requirement(s):
        return f"12-month base period beginning {fmt_date(s.timeline['delivery'])}"
    return fmt_period_range(s.timeline["delivery"], s.timeline["pop_end"])


def funding_seed(data: dict[str, Any], fund_type: str, rng: random.Random) -> tuple[str, str, str]:
    profile = data["funding_profiles"][fund_type]
    acrn = rng.choice("ABCDEFGHJKLMNPQRSTUVWXYZ")
    loa_parts = [
        profile["tas"],
        rng.choice(profile["budget_activity_options"]),
        rng.choice(profile["subhead_options"]),
        rng.choice(profile["eeic_options"]),
        rng.choice(data["organization_codes"]),
        rng.choice(data["cost_centers"]),
        rng.choice(data["project_codes"]),
        "000000",
        "503000",
    ]
    loa = " ".join(loa_parts)
    return acrn, loa, profile["label"]


def weighted_stage(rng: random.Random, max_stage: int) -> int:
    candidates = [stage for stage in [3, 4, 5, 6, 7, 8] if stage <= max_stage]
    if not candidates:
        return max(1, max_stage)
    weights = {3: 1, 4: 2, 5: 2, 6: 3, 7: 4, 8: 5}
    return rng.choices(candidates, weights=[weights[s] for s in candidates], k=1)[0]


def normalize_scenario_type(value: str | None) -> str:
    cleaned = (value or "auto").strip().lower().replace("_", "-")
    aliases = {
        "bpa-call": "bpa_call",
        "bpa call": "bpa_call",
        "call": "bpa_call",
        "idiq-order": "idiq_order",
        "idiq order": "idiq_order",
        "task-order": "idiq_order",
        "task order": "idiq_order",
        "delivery-order": "idiq_order",
        "delivery order": "idiq_order",
    }
    return aliases.get(cleaned, cleaned)


def contract_letter_for_category(category: str, archetype: dict[str, Any]) -> str:
    if category == "construction":
        return "C"
    if category == "bpa":
        return "A"
    if category == "idiq":
        return "D"
    if category in {"bpa_call", "idiq_order"}:
        return "F"
    if category in {"supply", "service"}:
        return "P"
    return str(archetype.get("instrument", "P")).upper()[:1] or "P"


def is_ordering_action_category(category: str) -> bool:
    return category in {"bpa_call", "idiq_order"}


def is_master_vehicle_category(category: str) -> bool:
    return category in {"bpa", "idiq"}


def prompt_explicitly_requests_master_vehicle(prompt: str, scenario_type: str = "auto") -> bool:
    requested_type = normalize_scenario_type(scenario_type)
    if requested_type in {"bpa", "idiq"}:
        return True
    lower = (prompt or "").lower()
    explicit_patterns = [
        r"\b(?:idiq|indefinite[- ]delivery|bpa|blanket\s+purchase\s+agreement)\b",
        r"\bmaster\s+(?:vehicle|contract|agreement)\b",
        r"\bordering\s+vehicle\b",
        r"\b(?:establish|set\s+up|create|build)\s+(?:an?\s+)?(?:master|ordering|idiq|indefinite[- ]delivery|bpa|blanket\s+purchase\s+agreement)\b",
    ]
    return any(re.search(pattern, lower) for pattern in explicit_patterns)


def is_master_vehicle(s: "Scenario") -> bool:
    return is_master_vehicle_category(s.category)


def master_vehicle_label(category: str) -> str:
    if category == "bpa":
        return "BPA"
    if category == "idiq":
        return "IDIQ"
    return "Ordering Vehicle"


def parent_instrument_label_for_category(category: str) -> str:
    if category == "bpa_call":
        return "BPA"
    if category == "idiq_order":
        return "IDIQ"
    return ""


def parent_contract_letter_for_category(category: str) -> str:
    if category == "bpa_call":
        return "A"
    if category == "idiq_order":
        return "D"
    return ""


def parent_contract_number_for_order(
    category: str,
    activity: str,
    piid_sequence: int,
    rng: random.Random,
    override: str = "",
    vehicle_registry: list[dict[str, Any]] | None = None,
    preferred_requirement_category: str = "",
) -> tuple[str, dict[str, Any]]:
    if not is_ordering_action_category(category):
        return "", {}
    vehicle_registry = vehicle_registry or []
    if override.strip():
        parent_number = override.strip().upper()
        return parent_number, find_vehicle_record(vehicle_registry, parent_number)
    candidates = active_parent_vehicle_candidates(vehicle_registry, category)
    preferred = str(preferred_requirement_category or "").lower()
    if preferred and candidates:
        matching = [
            record
            for record in candidates
            if str(record.get("requirement_category") or record.get("category") or "").lower() == preferred
        ]
        if matching:
            candidates = matching
    if candidates:
        selected = rng.choice(candidates)
        return str(selected.get("vehicle_number", "")).upper(), deepcopy(selected)
    parent_letter = parent_contract_letter_for_category(category)
    parent_sequence = rng.randint(1, max(1, min(piid_sequence, 5)))
    return f"{activity}XX{parent_letter}{parent_sequence:04d}", {}


def find_vehicle_record(vehicle_registry: list[dict[str, Any]], vehicle_number: str) -> dict[str, Any]:
    target = vehicle_number.strip().upper()
    for record in vehicle_registry:
        if str(record.get("vehicle_number", "")).upper() == target:
            return deepcopy(record)
    return {}


def active_parent_vehicle_candidates(vehicle_registry: list[dict[str, Any]], category: str) -> list[dict[str, Any]]:
    instrument = parent_instrument_label_for_category(category)
    candidates = [
        deepcopy(record)
        for record in vehicle_registry
        if str(record.get("instrument", "")).upper() == instrument
        and str(record.get("status", "")).lower() in {"", "active"}
        and record.get("vehicle_number")
    ]
    return candidates


def parent_lookup_registry_for_category(
    category: str,
    global_registry: list[dict[str, Any]],
    package_registry: list[dict[str, Any]],
    parent_override: str = "",
) -> list[dict[str, Any]]:
    if parent_override.strip():
        return merge_vehicle_records(global_registry, package_registry)
    if is_ordering_action_category(category) and active_parent_vehicle_candidates(package_registry, category):
        return package_registry
    return merge_vehicle_records(global_registry, package_registry)


def contractor_from_vehicle_record(data: dict[str, Any], vehicle: dict[str, Any]) -> dict[str, str] | None:
    if not vehicle:
        return None
    vendor_name = str(vehicle.get("vendor", ""))
    vendor_code = str(vehicle.get("vendor_code", ""))
    for contractor in data.get("contractors", []):
        if contractor.get("name") == vendor_name or contractor.get("code") == vendor_code:
            return deepcopy(contractor)
    if vendor_name and vendor_code:
        return {
            "name": vendor_name,
            "code": vendor_code,
            "address": str(vehicle.get("vendor_address", "Undisclosed Location, Overseas")),
            "phone": str(vehicle.get("vendor_phone", "DSN 318-555-02XX")),
            "facility_code": "",
            "signer": str(vehicle.get("vendor_signer", "Authorized Representative")),
        }
    return None


def piid_sequence_numbers(count: int, rng: random.Random) -> list[int]:
    numbers: list[int] = []
    next_number = 1
    forced_skip_after = rng.randrange(0, count - 1) if count >= 4 else None
    for idx in range(count):
        numbers.append(next_number)
        next_number += 1
        if idx >= count - 1:
            continue
        if rng.random() < 0.22 or idx == forced_skip_after:
            next_number += 1
    return numbers


def piid_sequence_numbers_after(count: int, rng: random.Random, start_after: int = 0) -> list[int]:
    return [start_after + number for number in piid_sequence_numbers(count, rng)]


def infer_category(archetype: dict[str, Any], scenario_type: str = "auto") -> str:
    scenario_type = normalize_scenario_type(scenario_type)
    if scenario_type and scenario_type != "auto":
        return scenario_type
    if archetype.get("category"):
        return str(archetype["category"]).lower()
    text = " ".join(
        str(archetype.get(key, ""))
        for key in ["key", "folder_label", "title", "requirement", "clin_description"]
    ).lower()
    if archetype.get("instrument") == "C" or any(word in text for word in ["construction", "renovation", "site work", "pad repair"]):
        return "construction"
    if any(word in text for word in ["service", "services", "maintenance", "cleaning", "removal", "inspection", "recurring"]):
        return "service"
    return "supply"


def archetype_haystack(archetype: dict[str, Any]) -> str:
    parts = [
        str(archetype.get(key, ""))
        for key in [
            "key",
            "folder_label",
            "title",
            "category",
            "requirement",
            "clin_description",
            "market_note",
            "evaluation_focus",
        ]
    ]
    parts.extend(str(alias) for alias in archetype.get("aliases", []))
    return " ".join(parts).lower()


def prompt_words(prompt: str) -> set[str]:
    words = {w.lower() for w in re.findall(r"[A-Za-z0-9]+", prompt) if len(w) > 2}
    if "t-wall" in prompt.lower() or "t wall" in prompt.lower():
        words.update({"t-wall", "barrier"})
    return words


def prompt_looks_like_bulk_material_supply(prompt: str) -> bool:
    lower = prompt.lower()
    material_terms = [
        "sand",
        "concrete mix",
        "cement",
        "ready mix",
        "ready-mix",
        "mortar",
        "asphalt",
        "aggregate",
        "fill dirt",
        "topsoil",
        "riprap",
        "crushed stone",
    ]
    excluded_terms = ["t-wall", "t wall", "barrier", "hesco", "concrete pad", "foundation", "construct", "construction"]
    return any(term in lower for term in material_terms) and not any(term in lower for term in excluded_terms)


def prompt_looks_like_unmodeled_supply(prompt: str) -> bool:
    lower = prompt.lower()
    supply_terms = [
        "refrigerator",
        "refrigerators",
        "freezer",
        "freezers",
        "ice machine",
        "dishwasher",
        "oven",
        "stove",
        "kitchen equipment",
        "appliance",
        "appliances",
    ]
    service_terms = ["repair", "maintenance", "service", "install", "installation"]
    return any(term in lower for term in supply_terms) and not any(term in lower for term in service_terms)


def prompt_looks_like_office_supply(prompt: str) -> bool:
    lower = prompt.lower()
    supply_patterns = [
        r"\boffice\s+(?:supplies|consumables)\b",
        r"\bcopy\s+paper\b",
        r"\bprinter\s+paper\b",
        r"\bpaper\s+(?:and|/)\s+toner\b",
        r"\btoner\b",
        r"\bink\s+cartridges?\b",
        r"\bprinter\s+cartridges?\b",
    ]
    excluded_patterns = [
        r"\b(?:repair|maintenance|service|install|installation|managed\s+print|shredding)\b",
    ]
    office_paper = bool(re.search(r"\boffice\b", lower) and re.search(r"\bpaper\b", lower))
    looks_supply = office_paper or any(re.search(pattern, lower) for pattern in supply_patterns)
    return looks_supply and not any(re.search(pattern, lower) for pattern in excluded_patterns)


def prompt_looks_like_generator_supply(prompt: str) -> bool:
    lower = prompt.lower()
    generator_terms = [
        r"\bgenerators?\b",
        r"\bgensets?\b",
        r"\bpower\s+units?\b",
        r"\blight\s+towers?\b",
    ]
    excluded_terms = [
        r"\bmaintenance\b",
        r"\brepair\b",
        r"\bservice\b",
        r"\bservices\b",
        r"\binspection\b",
        r"\brental\b",
        r"\brent\b",
        r"\blease\b",
        r"\bleased\b",
        r"\bleasing\b",
    ]
    purchase_terms = [
        r"\bpurchase\b",
        r"\bbuy\b",
        r"\bprocure\b",
        r"\bacquire\b",
        r"\bdeliver(?:y|ed)?\b",
        r"\bprovide\b",
    ]
    has_generator = any(re.search(pattern, lower) for pattern in generator_terms)
    is_excluded = any(re.search(pattern, lower) for pattern in excluded_terms)
    has_purchase_intent = any(re.search(pattern, lower) for pattern in purchase_terms)
    return has_generator and has_purchase_intent and not is_excluded


def prompt_looks_like_comm_supply(prompt: str) -> bool:
    lower = prompt.lower()
    comm_terms = [
        r"\bradios?\b",
        r"\bhandheld\s+radios?\b",
        r"\bsatellite\s+phones?\b",
        r"\bcomm(?:unications?)?\s+gear\b",
        r"\bnetwork\s+(?:switches?|routers?|equipment|cable|cabling)\b",
        r"\bethernet\s+(?:switches?|cable|cabling)\b",
        r"\bfiber\s+(?:cable|cabling|patch)\b",
    ]
    excluded_terms = [r"\binstall(?:ation)?\b", r"\bmaintenance\b", r"\brepair\b", r"\bservice\b", r"\bservices\b"]
    return any(re.search(pattern, lower) for pattern in comm_terms) and not any(re.search(pattern, lower) for pattern in excluded_terms)


def prompt_looks_like_medical_supply(prompt: str) -> bool:
    lower = prompt.lower()
    medical_terms = [
        r"\bmedical\s+(?:equipment|supplies|kits?)\b",
        r"\btrauma\s+(?:kits?|bags?)\b",
        r"\bfirst[- ]aid\s+(?:kits?|supplies)\b",
        r"\baeds?\b",
        r"\bdefibrillators?\b",
        r"\bstretchers?\b",
        r"\blitters?\b",
        r"\bclinic\s+supplies\b",
    ]
    excluded_terms = [r"\bmedical\s+services?\b", r"\bclinic\s+staff(?:ing)?\b", r"\bdoctor\b", r"\bnurse\b", r"\btreatment\s+service\b"]
    return any(re.search(pattern, lower) for pattern in medical_terms) and not any(re.search(pattern, lower) for pattern in excluded_terms)


def prompt_looks_like_aircraft_supply(prompt: str) -> bool:
    lower = prompt.lower()
    aircraft_terms = [
        r"\bf-?35\b",
        r"\bfighter\s+aircraft\b",
        r"\baircraft\s+(?:support\s+equipment|equipment|parts?|components?)\b",
        r"\bground\s+support\s+equipment\b",
        r"\bgse\b",
        r"\bengine\s+module\b",
    ]
    excluded_terms = [r"\bmaintenance\b", r"\brepair\b", r"\boverhaul\b", r"\bservice\b", r"\bservices\b"]
    return any(re.search(pattern, lower) for pattern in aircraft_terms) and not any(re.search(pattern, lower) for pattern in excluded_terms)


def simple_quantity_hint(prompt: str) -> int | None:
    match = re.search(
        r"\b(\d{1,4})\s+(?:[A-Za-z-]+\s+){0,3}"
        r"(?:refrigerators?|freezers?|ice\s+machines?|dishwashers?|ovens?|stoves?|appliances?|"
        r"generators?|gensets?|power\s+units?|light\s+towers?|radios?|satellite\s+phones?|aeds?|defibrillators?|"
        r"stretchers?|litters?|aircraft|components?|t[- ]?walls?|barriers?|units?|ea|each)\b",
        prompt,
        re.I,
    )
    if match:
        value = int(match.group(1))
        return value if value > 0 else None
    return None


def appliance_supply_label(prompt: str) -> str:
    lower = prompt.lower()
    labels = [
        ("commercial refrigerators", ["refrigerator", "refrigerators"]),
        ("commercial freezers", ["freezer", "freezers"]),
        ("ice machines", ["ice machine", "ice machines"]),
        ("dishwashers", ["dishwasher", "dishwashers"]),
        ("commercial ovens", ["oven", "ovens"]),
        ("commercial stoves", ["stove", "stoves"]),
        ("commercial kitchen appliances", ["kitchen equipment", "appliance", "appliances"]),
    ]
    for label, terms in labels:
        if any(term in lower for term in terms):
            return label
    return "commercial equipment"


def custom_construction_requirement(prompt: str) -> str:
    text = re.sub(r"\s+", " ", prompt.strip()).strip(". ")
    text = re.sub(r"\bunder\s+\$?\s*2m\b", "", text, flags=re.I).strip(" -,.")
    replacements = [
        (r"^construct(?:ing)?\s+", "construction of "),
        (r"^renovat(?:e|ing)\s+", "renovation of "),
        (r"^repair(?:ing)?\s+", "repair of "),
        (r"^build(?:ing)?\s+", "construction of "),
    ]
    for pattern, replacement in replacements:
        new_text = re.sub(pattern, replacement, text, count=1, flags=re.I)
        if new_text != text:
            return new_text[:1].lower() + new_text[1:]
    return text[:1].lower() + text[1:] if text else "minor construction work"


def bulk_material_unit(prompt: str) -> str:
    lower = prompt.lower()
    if any(term in lower for term in ["ready mix", "ready-mix", "concrete mix", "cement", "mortar"]):
        return "CY"
    return "TON"


def prompt_mentions_vehicle(prompt: str) -> bool:
    lower = prompt.lower()
    vehicle_terms = [
        "non-tactical vehicle",
        "non tactical vehicle",
        "nontactical vehicle",
        "ntv",
        "vehicle",
        "vehicles",
        "van",
        "vans",
        "suv",
        "suvs",
        "pickup",
        "pickups",
        "sedan",
        "sedans",
        "shuttle bus",
    ]
    return any(re.search(rf"\b{re.escape(term)}\b", lower) for term in vehicle_terms)


VEHICLE_SUPPLY_CONTEXT_TERMS = ["parts", "tires", "batteries", "filters", "oil", "consumables", "repair parts"]


def prompt_requests_vehicle_supply_context(prompt: str) -> bool:
    lower = prompt.lower()
    return any(term in lower for term in VEHICLE_SUPPLY_CONTEXT_TERMS) or prompt_explicitly_requests_vehicle_purchase(prompt)


def prompt_vehicle_master_should_use_lease_profile(prompt: str, category: str) -> bool:
    return category == "idiq" and prompt_mentions_vehicle(prompt) and not prompt_requests_vehicle_supply_context(prompt)


def prompt_explicitly_requests_vehicle_lease(prompt: str) -> bool:
    lower = prompt.lower()
    return bool(
        prompt_mentions_vehicle(prompt)
        and (
            re.search(r"\b(?:lease|leased|leasing|rental|rentals|renting|rented|rent)\b", lower)
            or re.search(r"\b(?:for|over)\s+\d{1,2}\s*(?:mo|mos|month|months)\b", lower)
        )
    )


def prompt_explicitly_requests_vehicle_purchase(prompt: str) -> bool:
    lower = prompt.lower()
    return bool(
        prompt_mentions_vehicle(prompt)
        and re.search(r"\b(?:purchase|buy|procure|acquire|ordered?|open\s+market|delivered?|new)\b", lower)
        and not prompt_explicitly_requests_vehicle_lease(prompt)
    )


def prompt_mentions_construction(prompt: str) -> bool:
    lower = prompt.lower()
    construction_patterns = [
        r"\b(?:macc|multiple[- ]award\s+construction)\b",
        r"\bconstruct(?:ion|ing)?\b",
        r"\bnew\b.{0,35}\bbuilding\b",
        r"\bmwr\b.{0,35}\bbuilding\b",
        r"\brenovat(?:e|ion|ing)\b",
        r"\bfoundation\b",
        r"\bsite work\b",
        r"\bconcrete pad\b",
        r"\broof replacement\b",
        r"\bfacilit(?:y|ies)\s+(?:repair|maintenance|sustainment)\b",
        r"\b(?:repair|replace|replacement|install|installation)\b.{0,50}\b(?:doors?|walkways?|lighting|trench drains?|concrete|apron|paving|pavement|electrical|plumbing|roof|shade structure)\b",
        r"\b(?:doors?|walkways?|lighting|trench drains?|concrete|apron|paving|pavement|electrical|plumbing|roof|shade structure)\b.{0,50}\b(?:repair|replace|replacement|install|installation)\b",
    ]
    return any(re.search(pattern, lower) for pattern in construction_patterns)


def prompt_looks_like_order_supply(prompt: str) -> bool:
    lower = prompt.lower()
    if any(
        checker(prompt)
        for checker in [
            prompt_looks_like_office_supply,
            prompt_looks_like_generator_supply,
            prompt_looks_like_comm_supply,
            prompt_looks_like_medical_supply,
            prompt_looks_like_aircraft_supply,
            prompt_looks_like_bulk_material_supply,
            prompt_looks_like_unmodeled_supply,
        ]
    ):
        return True
    supply_patterns = [
        r"\bsupplies?\b",
        r"\bconsumables?\b",
        r"\bbatteries?\b",
        r"\btoner\b",
        r"\bpaper\b",
        r"\bcartridges?\b",
        r"\bsmall\s+tools?\b",
        r"\bparts?\b",
        r"\bfilters?\b",
        r"\bkits?\b",
        r"\bcleaning\s+supplies?\b",
        r"\bfacility\s+consumables?\b",
    ]
    return any(re.search(pattern, lower) for pattern in supply_patterns)


def prompt_order_requirement_category(prompt: str) -> str:
    lower = prompt.lower()
    if prompt_looks_like_order_supply(prompt):
        return "supply"
    if prompt_mentions_construction(prompt):
        return "construction"
    if prompt_explicitly_requests_vehicle_lease(prompt):
        return "service"
    if any(word in lower for word in ["service", "services", "maintenance", "repair", "cleaning", "janitorial", "recurring", "lease", "leased", "rental", "rent"]):
        return "service"
    return "supply"


def prompt_requests_multiple_award(prompt: str) -> bool:
    lower = prompt.lower()
    return bool(re.search(r"\b(?:multiple[- ]award|multi[- ]award|macc|several\s+awardees|awardees)\b", lower))


def custom_category_from_prompt(prompt: str, scenario_type: str = "auto") -> str:
    scenario_type = normalize_scenario_type(scenario_type)
    if scenario_type != "auto":
        return scenario_type
    lower = prompt.lower()
    if any(term in lower for term in ["bpa call", "call off bpa", "call against bpa"]):
        return "bpa_call"
    if any(term in lower for term in ["idiq order", "task order", "delivery order", "order off idiq", "order against idiq"]):
        return "idiq_order"
    if lower.strip() == "bpa" or any(term in lower for term in ["blanket purchase agreement", " bpa", "bpa "]):
        return "bpa"
    if lower.strip() == "idiq" or any(term in lower for term in ["idiq", "indefinite delivery", "indefinite-delivery"]):
        return "idiq"
    if prompt_requests_multiple_award(prompt) and prompt_mentions_construction(prompt):
        return "idiq"
    if prompt_mentions_construction(prompt):
        return "construction"
    if prompt_explicitly_requests_vehicle_lease(prompt):
        return "service"
    if any(word in lower for word in ["service", "services", "janitorial", "custodial", "cleaning", "maintenance", "recurring", "lease", "leased", "rental", "rent"]):
        return "service"
    if prompt_explicitly_requests_vehicle_purchase(prompt):
        return "supply"
    if prompt_mentions_vehicle(prompt) and not prompt_requests_vehicle_supply_context(prompt):
        return "supply"
    return "supply"


def custom_archetype_from_prompt(prompt: str, scenario_type: str = "auto") -> dict[str, Any]:
    clean = re.sub(r"\s+", " ", prompt.strip()).strip(". ") or "Custom Requirement"
    title = clean[:1].upper() + clean[1:]
    category = custom_category_from_prompt(prompt, scenario_type)
    if category == "bpa":
        unit, quantity, amount_range = "LOT", 1, [50000, 750000]
        delivery_note = "Calls may be placed during the BPA period by authorized callers. Each call will specify the actual requirement, quantity, funding, and delivery or performance location."
        evaluation_focus = "supplier capability, ordering procedures, purchase limitations, price list, delivery responsiveness, and administrative terms"
    elif category == "idiq":
        unit, quantity, amount_range = "LOT", 1, [250000, 1900000]
        delivery_note = "Task or delivery orders will specify the actual requirement, quantity, funding, delivery location, and performance schedule."
        evaluation_focus = "technical capability, ordering procedures, minimum guarantee, ceiling, delivery responsiveness, past performance, and price"
    elif category in {"bpa_call", "idiq_order"}:
        lower = prompt.lower()
        requirement_category = prompt_order_requirement_category(prompt)
        if requirement_category == "construction":
            title = "Facility Repair Order" if category == "idiq_order" else "Facility Repair Call"
            requirement_category = "construction"
            unit, quantity, amount_range = "LOT", 1, [50000, 750000]
        elif any(word in lower for word in ["vehicle", "vehicles", "ntv", "vans", "suv", "suvs", "pickup", "pickups", "sedan", "sedans", "shuttle bus"]):
            title = "Vehicle Lease Order" if category == "idiq_order" else "Vehicle Lease Call"
            requirement_category = "service"
            months_match = re.search(r"\b(\d{1,2})\s*(?:mo|mos|month|months)\b", prompt, re.I)
            months = int(months_match.group(1)) if months_match else 12
            unit, quantity, amount_range = "MO", max(1, min(12, months)), [25000, 175000]
        elif requirement_category == "supply":
            title = "Recurring Supply Call" if category == "bpa_call" else "Supply Order"
            requirement_category = "supply"
            unit, quantity, amount_range = "LOT", 1, [15000, 150000]
        else:
            title = "Service Call" if category == "bpa_call" else "Service Order"
            requirement_category = "service"
            unit, quantity, amount_range = "MO", 6, [15000, 150000]
        delivery_note = "Delivery or performance timing will be specified in the call or order and coordinated through the requiring activity."
        evaluation_focus = "technical acceptability, delivery or performance schedule, vendor capability, and price"
    elif category == "service":
        unit, quantity, amount_range = "MO", 6, [30000, 120000]
        delivery_note = "Service start required within seven calendar days of award."
        evaluation_focus = "staffing approach, performance schedule, quality control, and price"
    elif category == "construction":
        unit, quantity, amount_range = "LOT", 1, [250000, 1850000]
        delivery_note = "Work shall begin after notice to proceed and site access coordination."
        evaluation_focus = "technical approach, safety controls, schedule, relevant experience, and price"
    elif prompt_looks_like_office_supply(prompt):
        unit, quantity, amount_range = "LOT", 1, [5000, 45000]
        delivery_note = "Delivery required within fourteen calendar days of award."
        evaluation_focus = "item compatibility, manufacturer or part numbers, substitution controls, delivery schedule, and price"
    elif prompt_looks_like_bulk_material_supply(prompt):
        unit, quantity, amount_range = bulk_material_unit(prompt), 80, [12000, 95000]
        delivery_note = "Delivery may be phased over the period coordinated with the requiring activity and receiving point."
        evaluation_focus = "material specification, delivery schedule, haul capacity, unloading coordination, and price"
    else:
        unit, quantity, amount_range = "LOT", 1, [15000, 90000]
        delivery_note = "Delivery required within fourteen calendar days of award."
        evaluation_focus = "technical acceptability, delivery schedule, warranty or support terms, and price"
    archetype = {
        "key": slugify(clean).lower(),
        "folder_label": title[:60],
        "title": title[:80],
        "category": category,
        "requirement_category": requirement_category if category in {"bpa_call", "idiq_order"} else category,
        "customer_hint": "XXX AEW",
        "instrument": contract_letter_for_category(category, {}),
        "fund_type": "om",
        "amount_range": amount_range,
        "unit": unit,
        "quantity": quantity,
        "requirement": clean,
        "clin_description": clean,
        "evaluation_focus": evaluation_focus,
        "market_note": "Market research should confirm capable commercial sources and realistic delivery or performance timing for this custom scenario.",
        "delivery_note": delivery_note,
        "_custom_prompt_archetype": True,
    }
    if category == "idiq" and prompt_mentions_construction(prompt):
        archetype.update(
            {
                "key": "multiple_award_construction_idiq" if prompt_requests_multiple_award(prompt) else archetype["key"],
                "folder_label": "Multiple Award Construction IDIQ",
                "title": "Multiple Award Construction Contract" if prompt_requests_multiple_award(prompt) else "Construction IDIQ",
                "requirement_category": "construction",
                "fund_type": "om",
                "amount_range": [750000, 1900000],
                "requirement": "multiple award construction indefinite-delivery contract for minor facility repair, alteration, site work, and sustainment projects ordered by separate task orders",
                "clin_description": "IDIQ ordering vehicle for recurring minor construction and facility repair task orders. Orders will specify scope, drawings, funding, schedule, and place of performance.",
                "evaluation_focus": "construction capability, safety program, quality control plan, task order management, relevant experience, past performance, and price",
                "market_note": "Market research should identify local construction contractors capable of base access coordination, site safety controls, material procurement, quality control, and performance under task-order procedures.",
                "delivery_note": "Task orders will specify the actual scope, drawings or sketches, performance location, safety submittals, schedule, and closeout documentation.",
                "_multiple_award": True if prompt_requests_multiple_award(prompt) else False,
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Minor facility repair and alteration task order category.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.34,
                        "price_note": "Task orders define actual scope, quantities, drawings, and funding.",
                    },
                    {
                        "clin": "0002",
                        "description": "Civil/site work and concrete task order category.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.28,
                        "price_note": "Task orders define actual site constraints, material requirements, and schedule.",
                    },
                    {
                        "clin": "0003",
                        "description": "Electrical, HVAC, plumbing, and utility support task order category.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.24,
                        "price_note": "Task orders define trade-specific work, outage coordination, and acceptance criteria.",
                    },
                    {
                        "clin": "0004",
                        "description": "Mobilization, submittals, safety controls, and closeout documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.14,
                        "price_note": "Included when required by the individual task order.",
                    },
                ],
            }
        )
    if category == "construction":
        construction_req = custom_construction_requirement(prompt)
        archetype.update(
            {
                "fund_type": "om",
                "_ai_category_locked": True,
                "requirement": construction_req,
                "clin_description": f"Designated construction work for {construction_req}.",
                "evaluation_focus": "technical approach, safety controls, schedule, relevant construction experience, quality control, past performance, and price",
                "market_note": "Market research should identify local construction and base support contractors capable of performing site coordination, safety controls, material procurement, construction execution, and closeout documentation.",
                "delivery_note": "Work shall begin after notice to proceed, site access coordination, safety submittal review, and required pre-construction coordination.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Mobilization, submittals, safety plan, and site coordination.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.12,
                    },
                    {
                        "clin": "0002",
                        "description": f"Construction work - {construction_req}.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.78,
                    },
                    {
                        "clin": "0003",
                        "description": "Punch list correction, cleanup, as-built documentation, and closeout.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.10,
                    },
                ],
            }
        )
    if category == "bpa_call" and "bottled water" in clean.lower():
        archetype.update(
            {
                "requirement_category": "supply",
                "folder_label": "Bottled Water BPA Call",
                "title": "Bottled Water BPA Call",
                "unit": "CS",
                "quantity": 160,
                "quantity_range": [80, 420],
                "quantity_step": 20,
                "amount_range": [6000, 45000],
                "requirement": "bottled water delivery under the referenced BPA for deployed mission support",
                "clin_description": "Bottled water cases delivered to the Government-designated receiving point.",
                "evaluation_focus": "BPA scope, delivery schedule, product availability, acceptance coordination, and price",
                "market_note": "Market research should confirm the referenced BPA covers bottled water or recurring consumable deliveries, and that the call quantity and delivery location are within the agreement scope.",
                "delivery_note": "Delivery shall be coordinated with the requiring activity. The call shall identify quantity, receiving point, acceptance POC, and funding citation.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Bottled water cases delivered under BPA call.",
                        "unit": "CS",
                        "quantity": 160,
                        "unit_price_range": [18, 42],
                        "share": 0.94,
                    },
                    {
                        "clin": "0002",
                        "description": "Delivery coordination and pallet handling.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [500, 2500],
                        "share": 0.06,
                    },
                ],
            }
        )
    if category == "supply" and prompt_looks_like_office_supply(prompt):
        archetype.update(
            {
                "fund_type": "om",
                "_ai_category_locked": True,
                "unit": "LOT",
                "quantity": 1,
                "amount_range": [5000, 45000],
                "clin_description": "Office paper, toner, printer cartridges, and related consumables delivered to the Government-designated location.",
                "evaluation_focus": "item compatibility, manufacturer or part numbers, substitution controls, delivery schedule, past performance, and price",
                "market_note": "Market research should identify commercial office supply distributors able to provide conforming paper and printer consumables, identify part numbers or equal items, and deliver without damaged packaging.",
                "delivery_note": "Delivery shall be coordinated with the requiring activity and receiving point. Contractor shall provide packing slips showing quantities, part numbers, and any substitutions.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Copy paper, commercially packaged, standard office size and weight.",
                        "unit": "CS",
                        "quantity": 40,
                        "quantity_range": [20, 120],
                        "quantity_step": 10,
                        "unit_price_range": [35, 75],
                        "share": 0.35,
                    },
                    {
                        "clin": "0002",
                        "description": "Printer toner or ink cartridges compatible with listed office printer models.",
                        "unit": "EA",
                        "quantity": 24,
                        "quantity_range": [10, 80],
                        "quantity_step": 5,
                        "unit_price_range": [85, 220],
                        "share": 0.55,
                    },
                    {
                        "clin": "0003",
                        "description": "Delivery coordination, packing slips, and substitution documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [500, 2500],
                        "share": 0.10,
                    },
                ],
            }
        )
    if category == "supply" and prompt_looks_like_generator_supply(prompt):
        quantity_hint = simple_quantity_hint(prompt) or int(quantity or 1)
        archetype.update(
            {
                "fund_type": "procurement",
                "_ai_category_locked": True,
                "unit": "EA",
                "quantity": quantity_hint,
                "amount_range": [max(25000, quantity_hint * 35000), max(90000, quantity_hint * 125000 + 10000)],
                "folder_label": "Portable Generator Purchase",
                "title": "Portable Generator Purchase",
                "requirement": "portable generator sets, accessories, delivery, startup check, and basic operator familiarization for deployed facility power support",
                "clin_description": "Portable generator sets with required accessories and delivery/startup support.",
                "evaluation_focus": "generator output rating, voltage and phase compatibility, accessories, delivery and startup support, warranty terms, past performance, and price",
                "market_note": "Market research should identify generator distributors or power equipment vendors with available commercial units, compatible accessories, delivery/offload capability, startup support, and warranty documentation.",
                "delivery_note": "Delivery shall be coordinated with the requiring activity and receiving point. Contractor shall provide required accessories, manuals, warranty documentation, startup check, and basic operator familiarization at delivery.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Portable diesel generator set, weather-resistant enclosure, voltage/phase compatible with supported facility load.",
                        "unit": "EA",
                        "quantity": quantity_hint,
                        "unit_price_range": [35000, 125000],
                        "share": 0.86,
                    },
                    {
                        "clin": "0002",
                        "description": "Required cables, grounding kit, drip pan, manuals, and startup/functional check.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [2500, 9500],
                        "share": 0.10,
                    },
                    {
                        "clin": "0003",
                        "description": "Delivery coordination, offload support, warranty documentation, and operator familiarization.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [1500, 6500],
                        "share": 0.04,
                    },
                ],
            }
        )
    if category == "supply" and prompt_looks_like_comm_supply(prompt):
        quantity_hint = simple_quantity_hint(prompt) or 1
        archetype.update(
            {
                "fund_type": "procurement",
                "_ai_category_locked": True,
                "unit": "LOT",
                "quantity": 1,
                "amount_range": [max(12000, quantity_hint * 1200), max(125000, quantity_hint * 8500 + 20000)],
                "folder_label": "Communications Equipment Purchase",
                "title": "Communications Equipment Purchase",
                "requirement": "commercial communications or network equipment, accessories, delivery documentation, and warranty support for deployed mission support use",
                "clin_description": "Communications/network equipment package with required accessories and documentation.",
                "evaluation_focus": "equipment compatibility, included accessories, commercial warranty, delivery schedule, past performance, and price",
                "market_note": "Market research should identify commercial communications or network equipment vendors able to provide compatible hardware, accessories, documentation, delivery, and warranty support without relying on classified or sensitive configuration details.",
                "delivery_note": "Delivery shall be coordinated with the receiving point. Contractor shall provide equipment list, serial numbers when applicable, commercial manuals, warranty documentation, and packing slips.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Communications or network equipment package meeting the stated commercial compatibility requirements.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [15000, 95000],
                        "share": 0.78,
                    },
                    {
                        "clin": "0002",
                        "description": "Accessories, chargers, mounting hardware, patch cables, batteries, or peripheral items required for delivered equipment.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [2500, 18000],
                        "share": 0.16,
                    },
                    {
                        "clin": "0003",
                        "description": "Delivery documentation, warranty information, serial-number list, and packing slips.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [500, 3500],
                        "share": 0.06,
                    },
                ],
            }
        )
    if category == "supply" and prompt_looks_like_medical_supply(prompt):
        quantity_hint = simple_quantity_hint(prompt) or 1
        archetype.update(
            {
                "fund_type": "om",
                "_ai_category_locked": True,
                "unit": "LOT",
                "quantity": 1,
                "amount_range": [max(8000, quantity_hint * 750), max(85000, quantity_hint * 4500 + 12000)],
                "folder_label": "Medical Supply Package",
                "title": "Medical Supply Package",
                "requirement": "commercial medical supply items or equipment kits, delivery documentation, expiration-date visibility, and warranty/support information for deployed clinic or emergency response use",
                "clin_description": "Commercial medical supply/equipment package delivered with documentation and acceptance support.",
                "evaluation_focus": "commercial item specifications, shelf-life or expiration controls, included accessories, delivery schedule, past performance, and price",
                "market_note": "Market research should identify commercial medical supply distributors able to provide new items, shelf-life or expiration-date information where applicable, manufacturer documentation, and delivery to the receiving point.",
                "delivery_note": "Delivery shall be coordinated with the receiving point. Contractor shall provide packing slips, manufacturer documentation, expiration-date or lot information when applicable, and warranty/support information.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Commercial medical supplies or equipment kits in new condition with manufacturer documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [8000, 60000],
                        "share": 0.82,
                    },
                    {
                        "clin": "0002",
                        "description": "Consumables, replacement accessories, batteries, or supporting items required for initial use.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [1000, 12000],
                        "share": 0.12,
                    },
                    {
                        "clin": "0003",
                        "description": "Delivery, packing slips, shelf-life/lot information, and warranty or support documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [500, 3000],
                        "share": 0.06,
                    },
                ],
            }
        )
    if category == "supply" and prompt_looks_like_aircraft_supply(prompt):
        title = "F-35 Support Equipment Purchase" if re.search(r"\bf-?35\b", prompt, re.I) else "Aircraft Support Equipment Purchase"
        archetype.update(
            {
                "fund_type": "procurement",
                "_ai_category_locked": True,
                "unit": "LOT",
                "quantity": 1,
                "amount_range": [250000, 4500000],
                "folder_label": title,
                "title": title,
                "requirement": "aircraft support equipment, component support items, delivery documentation, warranty information, and acceptance support for mission aircraft sustainment training purposes",
                "clin_description": "Aircraft support equipment or component support package delivered with documentation.",
                "evaluation_focus": "part or equipment compatibility, manufacturer documentation, warranty or support terms, delivery schedule, past performance, and price",
                "market_note": "Market research should identify authorized commercial suppliers or support-equipment vendors able to provide conforming items, traceability documentation, warranty/support information, and delivery coordination for aircraft support use.",
                "delivery_note": "Delivery shall be coordinated with the receiving point. Contractor shall provide part numbers, serial numbers when applicable, traceability or manufacturer documentation, warranty/support information, and packing slips.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": "Aircraft support equipment or component support package with applicable commercial documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [225000, 4000000],
                        "share": 0.90,
                    },
                    {
                        "clin": "0002",
                        "description": "Accessories, manuals, support documentation, inspection/acceptance support, and delivery coordination.",
                        "unit": "LOT",
                        "quantity": 1,
                        "fixed_price_range": [10000, 175000],
                        "share": 0.10,
                    },
                ],
            }
        )
    if category == "supply" and prompt_explicitly_requests_vehicle_purchase(prompt):
        vehicle_items = vehicle_count_items_from_prompt(prompt)
        if not vehicle_items:
            vehicle_items = [{"count": simple_quantity_hint(prompt) or int(quantity or 1), "label": vehicle_lease_label_from_prompt(prompt)}]
        total_vehicles = max(1, sum(int(item["count"]) for item in vehicle_items))
        vehicle_summary = phrase_join([f"{item['count']} {item['label']}" for item in vehicle_items])
        line_items = []
        for idx, item in enumerate(vehicle_items, start=1):
            count = max(1, int(item["count"]))
            label = str(item["label"])
            line_items.append(
                {
                    "clin": f"{idx:04d}",
                    "description": f"{label.title()} with standard safety equipment and delivery documentation.",
                    "unit": "EA",
                    "quantity": count,
                    "unit_price_range": [45000, 90000],
                    "share": 1,
                }
            )
        if len(line_items) > 1:
            line_items.append(
                {
                    "clin": f"{len(line_items) + 1:04d}",
                    "description": "Delivery coordination, acceptance support, and vehicle documentation.",
                    "unit": "LOT",
                    "quantity": 1,
                    "fixed_price_range": [1500, 6500],
                    "share": 0.04,
                }
            )
        archetype.update(
            {
                "fund_type": "procurement",
                "_ai_category_locked": True,
                "unit": "EA",
                "quantity": total_vehicles,
                "amount_range": [max(25000, total_vehicles * 45000), max(65000, total_vehicles * 90000 + 6500)],
                "requirement": f"{vehicle_summary} purchased for deployed mission transportation support",
                "clin_description": f"{vehicle_summary.title()} with standard safety equipment and delivery documentation.",
                "evaluation_focus": "vehicle configuration, seating or cargo capacity, warranty and support documentation, delivery schedule, past performance, and price",
                "market_note": "Market research should identify commercial vehicle dealers or fleet vendors with available stock, delivery capability, warranty support, and documentation needed for Government acceptance.",
                "delivery_note": "Delivery shall be coordinated with the requiring activity and receiving point. Contractor shall provide vehicle documentation, warranty information, keys, and acceptance support at delivery.",
                "line_items": line_items,
            }
        )
    if category == "supply" and prompt_looks_like_bulk_material_supply(prompt):
        archetype.update(
            {
                "fund_type": "om",
                "_ai_category_locked": True,
                "quantity_range": [20, 240] if unit == "TON" else [10, 120],
                "quantity_step": 10 if unit == "TON" else 5,
                "clin_description": f"{clean}, delivered to the Government-designated laydown area.",
                "market_note": "Bulk construction materials are available through local material suppliers, batch plants, quarry sources, and hauling firms with delivery and offload coordination capability.",
                "line_items": [
                    {
                        "description": f"{clean}, delivered.",
                        "unit": unit,
                        "quantity": quantity,
                        "share": 0.88,
                        "unit_price_range": [65, 145] if unit == "TON" else [125, 220],
                    },
                    {
                        "description": "Freight, delivery scheduling, and offload coordination.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.12,
                        "fixed_price_range": [2500, 9000],
                    },
                ],
            }
        )
    elif category == "supply" and prompt_looks_like_unmodeled_supply(prompt):
        quantity_hint = simple_quantity_hint(prompt) or 1
        supply_label = appliance_supply_label(prompt)
        unit_low = 1800 if "refrigerator" not in supply_label and "freezer" not in supply_label else 3500
        unit_high = 6500 if "refrigerator" not in supply_label and "freezer" not in supply_label else 12000
        archetype.update(
            {
                "fund_type": "om",
                "_ai_category_locked": True,
                "unit": "EA",
                "quantity": quantity_hint,
                "amount_range": [max(2500, quantity_hint * unit_low), max(7500, quantity_hint * unit_high + 3500)],
                "clin_description": f"{supply_label.title()} delivered to the Government-designated location.",
                "evaluation_focus": "technical acceptability, commercial specifications, delivery schedule, warranty or support terms, past performance, and price",
                "market_note": "Market research should identify commercial suppliers or local support contractors able to provide conforming equipment, delivery, basic placement coordination, warranty support, and any required startup documentation.",
                "delivery_note": "Delivery shall be coordinated with the requiring activity and receiving point. Contractor shall provide commercial documentation, warranty information, and basic placement coordination.",
                "line_items": [
                    {
                        "clin": "0001",
                        "description": f"{supply_label.title()}, delivered.",
                        "unit": "EA",
                        "quantity": quantity_hint,
                        "share": 0.92,
                        "unit_price_range": [unit_low, unit_high],
                    },
                    {
                        "clin": "0002",
                        "description": "Delivery coordination, placement support, and warranty documentation.",
                        "unit": "LOT",
                        "quantity": 1,
                        "share": 0.08,
                        "fixed_price_range": [500, 3500],
                    },
                ],
            }
        )
    return archetype


def clean_ai_text(value: Any, limit: int = 500) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\bFY\d{2,4}\b", GENERIC_FY, text, flags=re.I)
    text = re.sub(r"\b20\d{2}\b", GENERIC_YEAR, text)
    return text[:limit].strip()


AI_META_PATTERNS = [
    r"\bcontrolled\s+training\s+exercise\b",
    r"\btraining\s+package\b",
    r"\btraining\s+kit\b",
    r"\bexercise\s+(?:package|generator|tool|file|scenario)\b",
    r"\bgenerator(?:-controlled)?\b",
    r"\btool(?:ing)?\b",
    r"\bmetadata\b",
    r"\bscenario\s+plan\b",
    r"\bprompt\b",
    r"\bAI\b",
    r"\bacquisition\s+package\s+should\b",
    r"\bshould\s+support\s+(?:a\s+)?(?:controlled\s+)?training\b",
    r"\bshould\s+not\s+include\b",
    r"\bdo\s+not\s+include\b",
    r"\bavoid\s+real\b",
    r"\breal\s+(?:calendar\s+)?dates?\b",
    r"\blive\s+vendor\s+data\b",
    r"\bPIIDs?\b",
    r"\bfunding\s+(?:math|calculations?)\b",
    r"\bForm\s+9\s+(?:numbers?|data)\b",
    r"\bfolder\s+structure\b",
    r"\bfinal\s+award\s+determinations?\b",
    r"\bvendor\s+selection\b",
    r"\baward\s+forms?\b",
    r"\bfictitious\b",
    r"\breusable\s+exercise\s+language\b",
]


def normalize_document_text_punctuation(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    text = re.sub(r"([.!?]){2,}", r"\1", text)
    return text.strip(" \t\r\n,;:")


def remove_ai_meta_instructions(text: str) -> str:
    if not text:
        return ""
    parts = re.split(r"(?<=[.!?])\s+", text)
    kept: list[str] = []
    for part in parts:
        stripped = part.strip()
        if not stripped:
            continue
        if any(re.search(pattern, stripped, re.I) for pattern in AI_META_PATTERNS):
            continue
        kept.append(stripped)
    return normalize_document_text_punctuation(" ".join(kept))


def lowercase_sentence_fragment(text: str) -> str:
    match = re.match(r"([A-Za-z][A-Za-z-]*)", text or "")
    if not match:
        return text
    first_word = match.group(1)
    if len(first_word) > 1 and first_word[1:].islower():
        return first_word[:1].lower() + text[1:]
    return text


DISPLAY_TERM_CASE_PATTERNS = [
    (re.compile(r"\bf-?35\b", re.I), "F-35"),
    (re.compile(r"\bpsab\b", re.I), "PSAB"),
    (re.compile(r"\bidiq\b", re.I), "IDIQ"),
    (re.compile(r"\bbpa\b", re.I), "BPA"),
    (re.compile(r"\bpws\b", re.I), "PWS"),
    (re.compile(r"\bsow\b", re.I), "SOW"),
    (re.compile(r"\bsor\b", re.I), "SOR"),
    (re.compile(r"\bpiid\b", re.I), "PIID"),
    (re.compile(r"\bgpc\b", re.I), "GPC"),
    (re.compile(r"\bsf\s*1449\b", re.I), "SF 1449"),
    (re.compile(r"\bsf\s*1442\b", re.I), "SF 1442"),
]


def restore_display_term_case(text: str) -> str:
    restored = str(text or "")
    for pattern, replacement in DISPLAY_TERM_CASE_PATTERNS:
        restored = pattern.sub(replacement, restored)
    return restored


def lowercase_display_phrase(text: str) -> str:
    return restore_display_term_case(str(text or "").lower())


def normalize_requirement_phrase(text: str) -> str:
    original = normalize_document_text_punctuation(text).strip(". ")
    if not original:
        return ""
    lead_in_patterns = [
        r"^(?:the\s+)?(?:requiring\s+activity|customer|unit|mission\s+partner|end\s+user|requesting\s+unit)\s+(?:needs|requires|requested|requests)\s+",
        r"^(?:there\s+is|there's)\s+a\s+need\s+for\s+",
        r"^(?:the\s+)?request\s+is\s+for\s+",
        r"^(?:the|this)\s+requirement\s+is\s+for\s+",
        r"^(?:provide|purchase|procure|acquire)\s+",
    ]
    text = original
    removed_lead_in = False
    for pattern in lead_in_patterns:
        new_text = re.sub(pattern, "", text, count=1, flags=re.I).strip()
        if new_text != text:
            text = new_text
            removed_lead_in = True
            break
    if removed_lead_in:
        text = lowercase_sentence_fragment(text)
    return normalize_document_text_punctuation(text).strip(". ")


def clean_ai_document_field(value: Any, limit: int = 500, field: str = "") -> str:
    text = remove_ai_meta_instructions(clean_ai_text(value, limit))
    if field == "requirement":
        text = normalize_requirement_phrase(text)
    elif field in {"clin_description", "line_item_description"}:
        text = normalize_document_text_punctuation(text).strip(". ")
    return text[:limit].strip()


def clean_ai_unit(value: Any, fallback: str = "LOT") -> str:
    text = re.sub(r"[^A-Za-z0-9-]+", "", str(value or "").upper()).strip()
    return (text or fallback.upper())[:12]


def clean_ai_int(value: Any, fallback: int = 1, minimum: int = 1, maximum: int = 9999) -> int:
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        return fallback
    return max(minimum, min(maximum, number))


def clean_ai_range(value: Any, fallback: list[int], minimum: int, maximum: int, step: int = 1) -> list[int]:
    if isinstance(value, dict):
        value = [
            value.get("min", value.get("low", value.get("minimum"))),
            value.get("max", value.get("high", value.get("maximum"))),
        ]
    if not isinstance(value, list) or len(value) < 2:
        return fallback
    low = clean_ai_int(value[0], fallback[0], minimum, maximum)
    high = clean_ai_int(value[1], fallback[1], minimum, maximum)
    if high < low:
        low, high = high, low
    if step > 1:
        low = max(minimum, round(low / step) * step)
        high = max(low, round(high / step) * step)
    return [low, high]


def clean_ai_money_range(value: Any, fallback: list[int], category: str) -> list[int]:
    cap = CONSTRUCTION_AWARD_CAP if category == "construction" else 2_000_000
    result = clean_ai_range(value, fallback, 500, cap, 250)
    if category == "construction":
        result[1] = min(result[1], CONSTRUCTION_AWARD_CAP)
        result[0] = min(result[0], result[1])
    return result


def clean_ai_line_items(value: Any, fallback_unit: str, fallback_quantity: int) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    line_items: list[dict[str, Any]] = []
    for idx, raw_item in enumerate(value[:6]):
        if not isinstance(raw_item, dict):
            continue
        description = clean_ai_document_field(raw_item.get("description"), 180, "line_item_description")
        if not description:
            continue
        item: dict[str, Any] = {
            "clin": clean_ai_text(raw_item.get("clin") or f"{idx + 1:04d}", 8),
            "description": description,
            "unit": clean_ai_unit(raw_item.get("unit"), fallback_unit),
            "quantity": clean_ai_int(raw_item.get("quantity"), fallback_quantity, 1, 9999),
        }
        if isinstance(raw_item.get("quantity_range"), (list, dict)):
            item["quantity_range"] = clean_ai_range(raw_item.get("quantity_range"), [item["quantity"], item["quantity"]], 1, 9999)
            item["quantity_step"] = clean_ai_int(raw_item.get("quantity_step"), 1, 1, 1000)
        if "unit_price_range" in raw_item:
            item["unit_price_range"] = clean_ai_range(raw_item.get("unit_price_range"), [100, 500], 1, 250000, 5)
        elif "fixed_price_range" in raw_item:
            item["fixed_price_range"] = clean_ai_range(raw_item.get("fixed_price_range"), [1000, 5000], 1, 500000, 10)
        else:
            try:
                item["share"] = max(0.01, float(raw_item.get("share", 1)))
            except (TypeError, ValueError):
                item["share"] = 1
        line_items.append(item)
    return line_items


DEFAULT_VARIATION_PROFILES = [
    {
        "email_style": "concise",
        "customer_posture": "routine",
        "file_texture": "clean but brief",
        "requirement_note": "Customer kept the package short because the requirement is familiar to the unit.",
        "evaluation_note": "Mission partner wants a simple technical check and no extra evaluation machinery.",
        "qa_focus": "Check that the file does not over-document a routine buy.",
    },
    {
        "email_style": "coordination-heavy",
        "customer_posture": "cautious",
        "file_texture": "complete with some coordination chatter",
        "requirement_note": "Customer is trying to avoid a rework after vendors ask questions.",
        "evaluation_note": "Mission partner wants the technical review to stay tied to practical performance risk.",
        "qa_focus": "Check that technical factors, quotes, evaluation, and decision line up.",
    },
    {
        "email_style": "field pressure",
        "customer_posture": "urgent but controlled",
        "file_texture": "slightly rushed but usable",
        "requirement_note": "The file shows operational pressure, but the requirement is still documented well enough to compete.",
        "evaluation_note": "Mission partner cares most about whether the vendor can perform on the needed timeline.",
        "qa_focus": "Check that urgency does not accidentally create a sole-source or false inject.",
    },
    {
        "email_style": "terse turnover",
        "customer_posture": "busy",
        "file_texture": "thin in a few realistic places",
        "requirement_note": "The package has the essentials, but some background stayed in email instead of a polished memo.",
        "evaluation_note": "Mission partner is willing to review quotes but does not want to own price or award judgment.",
        "qa_focus": "Check that missing polish does not become missing required evaluation support.",
    },
]


def clean_ai_variation_profile(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    allowed = {
        "email_style": 60,
        "customer_posture": 80,
        "file_texture": 100,
        "requirement_note": 240,
        "evaluation_note": 240,
        "qa_focus": 240,
    }
    profile: dict[str, str] = {}
    for key, limit in allowed.items():
        text = clean_ai_document_field(value.get(key), limit, key)
        if key in {"requirement_note", "evaluation_note"}:
            text = remove_customer_instrument_determination(text)
        if text:
            profile[key] = text
    return profile


def remove_customer_instrument_determination(text: str) -> str:
    if not text:
        return ""
    forbidden = [
        r"\btreat(?:ed)?\s+(?:this|the requirement|it)\s+as\s+a?\s*(?:supply|service|construction)\s+(?:buy|action|requirement|purchase|contract)\b",
        r"\bclassif(?:y|ied|ication)\s+(?:this|the requirement|it)\s+as\s+(?:supply|service|construction)\b",
        r"\brequirement type\s+is\s+(?:supply|service|construction)\b",
        r"\b(?:supply|service|construction)\s+(?:buy|action|purchase|contract)\b",
        r"\bnot\s+a\s+(?:supply|service|construction)\s+(?:buy|action|purchase|contract)\b",
    ]
    parts = re.split(r"(?<=[.!?])\s+", text)
    kept = []
    for part in parts:
        if any(re.search(pattern, part, re.I) for pattern in forbidden):
            continue
        kept.append(part)
    return " ".join(kept).strip()


def ensure_variation_profile(archetype: dict[str, Any], rng: random.Random, scenario_prompt: str = "") -> None:
    existing = clean_ai_variation_profile(archetype.get("_variation_profile"))
    if existing:
        archetype["_variation_profile"] = existing
        return
    profile = deepcopy(rng.choice(DEFAULT_VARIATION_PROFILES))
    lower = scenario_prompt.lower()
    if any(term in lower for term in ["urgent", "asap", "immediate", "critical", "mission"]):
        profile = deepcopy(DEFAULT_VARIATION_PROFILES[2])
    elif any(term in lower for term in ["follow-on", "additional", "repeat", "another"]):
        profile = deepcopy(DEFAULT_VARIATION_PROFILES[3])
    archetype["_variation_profile"] = profile


def variation_text(s: "Scenario", key: str, fallback: str = "") -> str:
    profile = s.archetype.get("_variation_profile")
    if isinstance(profile, dict):
        return clean_ai_document_field(profile.get(key), 300, key) or fallback
    return fallback


# ---------------------------------------------------------------------------
# Author personas and phrase banks
#
# Every scenario assigns one persona to the CO and one to the customer side
# (requester/approver share the customer persona). Personas control email
# greetings, closings, verbosity, and low-rate benign typos so different
# action files read like they were worked by different people. All choices
# are seeded from the contract number, so a given action is stable across
# re-renders within a run.
# ---------------------------------------------------------------------------

CO_PERSONAS = [
    {
        "key": "precise",
        "closing": "V/r,",
        "greeting_style": "name",
        "verbosity": "standard",
        "typo_rate": 0.0,
        "double_space_rate": 0.0,
    },
    {
        "key": "terse",
        "closing": "Vr,",
        "greeting_style": "none",
        "verbosity": "terse",
        "typo_rate": 0.012,
        "double_space_rate": 0.05,
    },
    {
        "key": "wordy",
        "closing": "Respectfully,",
        "greeting_style": "time_of_day",
        "verbosity": "verbose",
        "typo_rate": 0.0,
        "double_space_rate": 0.0,
    },
    {
        "key": "hurried",
        "closing": "Thanks,",
        "greeting_style": "short",
        "verbosity": "terse",
        "typo_rate": 0.02,
        "double_space_rate": 0.08,
    },
    {
        "key": "formal",
        "closing": "Very respectfully,",
        "greeting_style": "rank_name",
        "verbosity": "verbose",
        "typo_rate": 0.0,
        "double_space_rate": 0.0,
    },
]

CUSTOMER_PERSONAS = [
    {
        "key": "by_the_book",
        "closing": "V/r,",
        "greeting_style": "rank_name",
        "verbosity": "standard",
        "typo_rate": 0.0,
        "double_space_rate": 0.0,
    },
    {
        "key": "field_busy",
        "closing": "Thanks,",
        "greeting_style": "short",
        "verbosity": "terse",
        "typo_rate": 0.025,
        "double_space_rate": 0.06,
    },
    {
        "key": "thorough",
        "closing": "Respectfully,",
        "greeting_style": "time_of_day",
        "verbosity": "verbose",
        "typo_rate": 0.0,
        "double_space_rate": 0.0,
    },
    {
        "key": "informal",
        "closing": "Thank you,",
        "greeting_style": "name",
        "verbosity": "standard",
        "typo_rate": 0.015,
        "double_space_rate": 0.04,
    },
]

# Benign, common misspellings only. Never applied to numbers, identifiers,
# or formal award documents - email bodies only.
TYPO_MAP = {
    "received": "recieved",
    "government": "goverment",
    "coordinate": "coordiante",
    "separate": "seperate",
    "maintenance": "maintenence",
    "until": "untill",
    "questions": "quesitons",
    "tomorrow": "tommorow",
    "occurred": "occured",
}


def ensure_personas(archetype: dict[str, Any], rng: random.Random) -> None:
    if isinstance(archetype.get("_personas"), dict):
        return
    archetype["_personas"] = {
        "co": deepcopy(rng.choice(CO_PERSONAS)),
        "customer": deepcopy(rng.choice(CUSTOMER_PERSONAS)),
    }


def persona(s: "Scenario", role: str) -> dict[str, Any]:
    personas = s.archetype.get("_personas")
    if isinstance(personas, dict):
        lookup = "co" if role == "co" else "customer"
        found = personas.get(lookup)
        if isinstance(found, dict):
            return found
    return CO_PERSONAS[0] if role == "co" else CUSTOMER_PERSONAS[0]


def scenario_rng(s: "Scenario", key: str) -> random.Random:
    return random.Random(f"{s.contract_number}|{key}")


def pick_phrase(s: "Scenario", key: str, options: list[str]) -> str:
    if not options:
        return ""
    return scenario_rng(s, key).choice(options)


def persona_closing(s: "Scenario", role: str) -> str:
    return str(persona(s, role).get("closing") or "V/r,")


def persona_greeting(s: "Scenario", role: str, recipient: str = "", key: str = "greeting") -> str:
    style = str(persona(s, role).get("greeting_style") or "name")
    first = recipient.split()[0].rstrip(",") if recipient else ""
    if style == "none":
        return ""
    if style == "short":
        return f"{first}," if first else "All,"
    if style == "time_of_day":
        return pick_phrase(s, f"{key}|tod", ["Good morning,", "Good afternoon,"])
    if style == "rank_name":
        return f"{recipient}," if recipient else "Sir/Ma'am,"
    return f"{first}," if first else "Team,"


def apply_persona_texture(s: "Scenario", role: str, text: str, key: str = "texture") -> str:
    """Apply low-rate benign typos and spacing quirks to an email body."""
    profile = persona(s, role)
    typo_rate = float(profile.get("typo_rate") or 0.0)
    double_space_rate = float(profile.get("double_space_rate") or 0.0)
    if typo_rate <= 0 and double_space_rate <= 0:
        return text
    rng = scenario_rng(s, f"{key}|{role}")
    if typo_rate > 0:
        for correct, typo in TYPO_MAP.items():
            if correct in text and rng.random() < typo_rate * 8:
                text = text.replace(correct, typo, 1)
                break  # at most one misspelling per body
    if double_space_rate > 0:
        sentences = text.split(". ")
        for idx in range(len(sentences) - 1):
            if rng.random() < double_space_rate:
                sentences[idx] = sentences[idx] + " "
        text = ". ".join(sentences)
    return text


def with_greeting(s: "Scenario", role: str, recipient: str, body: str, key: str = "greeting") -> str:
    greeting = persona_greeting(s, role, recipient, key)
    body = apply_persona_texture(s, role, body, key)
    if greeting:
        return f"{greeting}\n\n{body}"
    return body


# ---------------------------------------------------------------------------
# Inject definitions
#
# Injects are deliberate, catchable problems planted in an otherwise normal
# record. Each inject writes a controller-only answer key at the package root
# (_inject_key.json / _inject_key.md) describing what the trainee should
# catch and where the evidence lives. Trainee-facing documents never announce
# the inject.
# ---------------------------------------------------------------------------

INJECT_DEFINITIONS: dict[str, dict[str, Any]] = {
    "expired-parent": {
        "label": "Expired parent vehicle",
        "difficulty": "moderate",
        "applies_to": ["bpa_call", "idiq_order"],
        "summary": "The call/order file references a parent BPA/IDIQ whose ordering period ended last fiscal year.",
        "expected_find": (
            "Before writing the call/order, the CCO should pull the parent vehicle file and verify the ordering "
            "period. The parent period ended in {prev_year}, so no new calls/orders may be placed against it "
            "without re-establishing or extending the vehicle."
        ),
        "evidence": [
            "The parent master file's Award folder contains renewal-decision email traffic documenting the decision NOT to renew and that no further calls/orders are authorized.",
            "Contract Workload Tracker.xlsx - Vehicles sheet shows the parent status Expired.",
            "The continuity binder warns against placing new calls/orders on the expired vehicle.",
        ],
    },
    "near-ceiling-parent": {
        "label": "Parent vehicle near ceiling",
        "difficulty": "subtle",
        "applies_to": ["idiq_order"],
        "summary": "The parent BPA/IDIQ has nearly exhausted its ceiling; this call/order would exceed the remaining headroom.",
        "expected_find": (
            "The CCO should compare the parent ceiling against cumulative obligations before placing the order. "
            "Remaining headroom is less than this action's estimated value, so the order cannot be placed "
            "without ceiling relief or a new vehicle."
        ),
        "evidence": [
            "Contract Workload Tracker.xlsx - Vehicles sheet shows obligated amount within a few percent of the ceiling.",
            "_vehicle_registry.json (controller copy) carries the same obligated/ceiling figures.",
        ],
    },
    "expired-vehicle": {
        "label": "Expired master vehicle",
        "difficulty": "moderate",
        "applies_to": ["bpa", "idiq"],
        "summary": "The BPA/IDIQ master file in the office is expired - awarded and ended in prior years.",
        "expected_find": (
            "A CCO asked to use this vehicle (or reviewing the office files) should notice the ordering period "
            "ended in {prev_year}. Any new call/order request against it should be challenged."
        ),
        "evidence": [
            "The master file's Award folder contains renewal-decision email traffic explicitly documenting that the vehicle was not renewed and no further calls/orders are authorized.",
            "Contract Workload Tracker.xlsx - Vehicles sheet shows status Expired.",
            "The continuity binder warns against using the expired vehicle.",
            "The award packet period and {prev_year}-era dates corroborate, but the email traffic is the decisive evidence.",
        ],
    },
    "wrong-appropriation": {
        "label": "Wrong appropriation",
        "difficulty": "moderate",
        "applies_to": ["supply", "service", "construction", "bpa_call", "idiq_order"],
        "summary": "The Form 9 cites the wrong appropriation for the requirement type (O&M vs procurement funds).",
        "expected_find": (
            "The CCO should check the line of accounting against the nature of the requirement. The cited "
            "appropriation does not match the requirement type, so the action cannot proceed without a corrected "
            "funding document."
        ),
        "evidence": [
            "Form 9 accounting classification cites the wrong appropriation/TAS for this requirement type.",
            "The funding label in the file's accounting data block names the mismatched fund type.",
        ],
    },
    "funding-shortfall": {
        "label": "Certified funding below award",
        "difficulty": "subtle",
        "applies_to": ["supply", "service", "construction", "bpa_call", "idiq_order"],
        "summary": "The Form 9 certifies less funding than the award amount; no updated certification is in the file.",
        "expected_find": (
            "The CCO should compare the certified amount on the Form 9 against the award total. The certification "
            "is short, and the CLIN amounts on the same form do not sum to the certified total."
        ),
        "evidence": [
            "Form 9 estimated total cost and certified amount are below the award amount.",
            "The CLIN line amounts on the Form 9 sum to more than the certified grand total.",
        ],
    },
    "missing-certification": {
        "label": "Missing funds certification",
        "difficulty": "obvious",
        "applies_to": ["supply", "service", "construction", "bpa_call", "idiq_order"],
        "summary": "The Form 9 certifying official block is blank - funds were never certified.",
        "expected_find": (
            "The CCO should notice the certification block on the Form 9 is unsigned with no certifying official "
            "named. The action proceeded without certified funds."
        ),
        "evidence": [
            "Form 9 certifying official name, date, and signature blocks are blank.",
        ],
    },
    "unjustified-award": {
        "label": "Award not to lowest acceptable",
        "difficulty": "moderate",
        "applies_to": ["supply", "service", "construction"],
        "summary": "Award went to a higher-priced quote while a cheaper technically-acceptable quote received no documented discriminator.",
        "expected_find": (
            "The CCO should compare the quote abstract against the award decision. A lower-priced acceptable quote "
            "was passed over and the decision document never explains why the premium was worth paying."
        ),
        "evidence": [
            "Quote abstract in the Decision Document shows a cheaper technically-acceptable quote than the awardee's.",
            "The best-value rationale does not address the price difference or document a discriminator.",
        ],
    },
    "late-quote": {
        "label": "Late quote accepted",
        "difficulty": "subtle",
        "applies_to": ["supply", "service", "construction"],
        "summary": "The winning quote was received after the quotes-due deadline with no CO note in the file.",
        "expected_find": (
            "The CCO should check quote receipt dates against the solicitation deadline. The awardee's quote came "
            "in after quotes were due and was evaluated anyway without documentation."
        ),
        "evidence": [
            "Quote Receipt log shows the awardee's received date after the quotes-due date.",
            "The solicitation states the quotes-due deadline; no late-quote determination is in the file.",
        ],
    },
    "missing-tech-eval": {
        "label": "Missing technical evaluation",
        "difficulty": "obvious",
        "applies_to": ["supply", "service", "construction"],
        "summary": "The file is awarded but contains no technical evaluation request or response.",
        "expected_find": (
            "The CCO should notice folder 6 has no technical evaluation request or technical evaluation, while the Decision Document "
            "cites awardee technical findings that have no source documentation."
        ),
        "evidence": [
            "Evaluation folder is missing the technical evaluation request and technical evaluation.",
            "Decision Document references technical findings with no supporting evaluation in the file.",
        ],
    },
    "entity-mismatch": {
        "label": "Vendor entity mismatch",
        "difficulty": "subtle",
        "applies_to": ["supply", "service"],
        "summary": "The award document carries a vendor code that does not match the code on the quote and market research.",
        "expected_find": (
            "The CCO should verify the awardee's unique entity identifier across the file. The code on the award "
            "face page differs from the code on the vendor's quote - the award may name the wrong entity."
        ),
        "evidence": [
            "Award face page block 17a vendor code differs from the UEI recorded in the MRR vendor survey table (and on the winning quote where shown).",
        ],
    },
    "call-limit-breach": {
        "label": "BPA call exceeds call limit",
        "difficulty": "moderate",
        "applies_to": ["bpa_call"],
        "summary": "The call amount exceeds the per-call purchase limitation on the parent BPA.",
        "expected_find": (
            "The CCO should check the parent BPA's call limit before placing the call. This call's value exceeds "
            "the authorized per-call limit recorded for the parent vehicle."
        ),
        "evidence": [
            "Contract Workload Tracker.xlsx - Vehicles sheet shows the parent's call limit below this call's amount.",
            "_vehicle_registry.json (controller copy) carries the same call limit.",
        ],
    },
    "out-of-scope-order": {
        "label": "Order outside parent scope",
        "difficulty": "moderate",
        "applies_to": ["bpa_call", "idiq_order"],
        "summary": "The call/order requirement does not fall within the parent vehicle's scope.",
        "expected_find": (
            "The CCO should compare the order requirement against the parent vehicle's scope statement. The "
            "requirement is outside scope, even though the MRR claims alignment."
        ),
        "evidence": [
            "Parent vehicle scope in the tracker Vehicles sheet/registry covers a different commodity or service.",
            "The MRR's 'order appears within scope' finding quotes a parent scope that plainly does not match.",
        ],
    },
    "pop-clin-mismatch": {
        "label": "PWS period vs CLIN mismatch",
        "difficulty": "moderate",
        "applies_to": ["service"],
        "summary": "The PWS describes a 12-month base period but the CLIN is priced for 6 months.",
        "expected_find": (
            "The CCO should reconcile the PWS performance period against the CLIN schedule. The file prices half "
            "the period the PWS requires."
        ),
        "evidence": [
            "PWS and service documents describe a 12-month base period.",
            "CLIN schedule on the IGE, solicitation, and award shows quantity 6 MO.",
        ],
    },
    "unsigned-award": {
        "label": "Unsigned award",
        "difficulty": "obvious",
        "applies_to": ["supply", "service", "construction"],
        "summary": "The contracting officer signature block on the award is blank.",
        "expected_find": (
            "The CCO should notice the award document was never signed by the contracting officer - the contract "
            "is not validly awarded despite the file showing post-award activity."
        ),
        "evidence": [
            "Award face page CO signature block is blank (no //SIGNED//).",
        ],
    },
    "tracker-mismatch": {
        "label": "Tracker disagrees with file",
        "difficulty": "moderate",
        "applies_to": ["supply", "service", "construction", "bpa_call", "idiq_order"],
        "summary": "The workload tracker reports a later stage than the action folder actually supports.",
        "expected_find": (
            "The CCO should validate tracker status against the actual file. The tracker claims a stage the folder "
            "does not contain - turnover documentation cannot be trusted without verification."
        ),
        "evidence": [
            "Contract Workload Tracker.xlsx status/stage for this action is ahead of the folders that exist.",
            "The action folder's highest stage folder contradicts the tracker row.",
        ],
    },
    "phantom-master": {
        "label": "Registry vehicle missing from drive",
        "difficulty": "moderate",
        "applies_to": ["supply", "service", "construction", "bpa", "idiq", "bpa_call", "idiq_order"],
        "summary": "The tracker/registry lists an active master vehicle whose contract file does not exist on the drive.",
        "expected_find": (
            "The CCO should attempt to pull the master file for every active vehicle in the tracker. One active "
            "vehicle has no folder anywhere in the office records."
        ),
        "evidence": [
            "Contract Workload Tracker.xlsx - Vehicles sheet lists an Active vehicle with no folder reference.",
            "No action folder for that vehicle number exists in the package.",
        ],
    },
    "sam-inactive": {
        "label": "Awardee SAM registration inactive",
        "difficulty": "moderate",
        "applies_to": ["supply", "service", "construction"],
        "summary": "The vendor responsibility screening shows the awardee's SAM registration lapsed, but award proceeded with no resolution.",
        "expected_find": (
            "The CCO should read the responsibility screening in the Evaluation folder. The awardee's registration is "
            "shown INACTIVE and nothing in the file documents a correction before award - the award decision is defective."
        ),
        "evidence": [
            "Vendor Responsibility Screening.pdf in the Evaluation folder shows the awardee's SAM status as inactive/lapsed.",
            "The Decision Document and award proceed without addressing the registration problem.",
        ],
    },
    "adverse-past-performance": {
        "label": "Adverse past performance ignored",
        "difficulty": "subtle",
        "applies_to": ["supply", "service", "construction"],
        "summary": "A prior action with the same vendor ended in documented delivery problems, but this file's past performance evaluation says 'no adverse information.'",
        "expected_find": (
            "The CCO should check office records on the awardee before relying on the past performance evaluation. "
            "A prior contract file on the drive documents late/partial delivery and a CO memo flagging the record for "
            "future evaluations - which this file ignored."
        ),
        "evidence": [
            "An archived prior action folder for the same vendor contains delivery discrepancy email traffic and a CO past performance memo.",
            "This action's Past Performance Evaluation.pdf reports 'no adverse information' for the awardee.",
        ],
    },
    "wrong-piid-letter": {
        "label": "Wrong PIID instrument letter",
        "difficulty": "obvious",
        "applies_to": ["supply", "service"],
        "summary": "The contract number uses the wrong instrument letter for the action type (e.g. F on a standalone purchase).",
        "expected_find": (
            "The CCO should recognize the PIID instrument letter does not match the action: an F (call/order) "
            "letter on a standalone purchase with no parent vehicle in the file."
        ),
        "evidence": [
            "Contract number on every document uses an instrument letter inconsistent with the action type.",
            "No parent BPA/IDIQ is referenced anywhere in the file.",
        ],
    },
}


def inject_choices() -> list[str]:
    return sorted(INJECT_DEFINITIONS.keys()) + ["random"]


def resolve_injects(requested: list[str], category: str, rng: random.Random) -> tuple[list[str], list[str]]:
    """Resolve requested inject keys against the action category.

    Returns (applied_keys, messages). 'random' picks one applicable inject.
    Requested injects that do not apply to the category are dropped with a message.
    """
    applied: list[str] = []
    messages: list[str] = []
    applicable = [key for key, definition in INJECT_DEFINITIONS.items() if category in definition["applies_to"]]
    for key in requested:
        if key == "random":
            pool = [candidate for candidate in applicable if candidate not in applied]
            if pool:
                applied.append(rng.choice(pool))
            else:
                messages.append(f"Random inject skipped: no inject applies to category '{category}'.")
            continue
        if key not in INJECT_DEFINITIONS:
            messages.append(f"Unknown inject '{key}' skipped.")
            continue
        if category not in INJECT_DEFINITIONS[key]["applies_to"]:
            messages.append(
                f"Inject '{key}' skipped: applies to {', '.join(INJECT_DEFINITIONS[key]['applies_to'])}, not '{category}'."
            )
            continue
        if key not in applied:
            applied.append(key)
    return applied, messages


def synthetic_parent_vehicle_record(
    parent_number: str,
    category: str,
    vendor: dict[str, str],
    archetype: dict[str, Any],
    rng: random.Random,
) -> dict[str, Any]:
    """Build a parent vehicle record for injects when no real master exists in the registry."""
    instrument = "BPA" if category == "bpa_call" else "IDIQ"
    if instrument == "BPA":
        ceiling: Any = ""
        call_limit: Any = float(rng.choice([10000, 15000, 25000, 50000]))
        minimum: Any = ""
    else:
        ceiling = float(rng.randrange(500000, 2000000, 250000))
        call_limit = ""
        minimum = float(rng.choice([5000, 10000, 25000]))
    return {
        "vehicle_number": parent_number,
        "instrument": instrument,
        "title": str(archetype.get("title") or "Recurring support requirement"),
        "scope": str(archetype.get("requirement") or "recurring base support requirements"),
        "requirement_category": str(archetype.get("requirement_category") or "supply"),
        "status": "Active",
        "vendor": vendor["name"],
        "vendor_code": vendor.get("code", ""),
        "vendor_address": vendor.get("address", ""),
        "vendor_phone": vendor.get("phone", ""),
        "vendor_signer": vendor.get("signer", ""),
        "customer": "",
        "contracting_officer": "",
        "ceiling": ceiling,
        "call_limit": call_limit,
        "minimum_guarantee": minimum,
        "obligated_amount": 0.0,
        "period_start": f"1 October {GENERIC_YEAR_PREV}",
        "period_end": f"30 September {GENERIC_YEAR}",
        "award_date": f"1 October {GENERIC_YEAR_PREV}",
        "package": "",
        "folder": "",
        "folder_path": "",
        "price_list_title": "",
        "price_list": [],
        "_synthetic": True,
    }


def apply_parent_vehicle_injects(
    inject_keys: list[str],
    parent_vehicle: dict[str, Any],
    estimated_amount: float,
    rng: random.Random,
) -> list[dict[str, Any]]:
    """Mutate the parent vehicle record for parent-side injects. Returns inject detail dicts."""
    details: list[dict[str, Any]] = []
    if "expired-parent" in inject_keys and parent_vehicle:
        parent_vehicle["status"] = "Expired"
        parent_vehicle["period_start"] = f"1 October {GENERIC_YEAR_PREV2}"
        parent_vehicle["period_end"] = f"30 September {GENERIC_YEAR_PREV}"
        parent_vehicle["award_date"] = f"1 October {GENERIC_YEAR_PREV2}"
        details.append(
            {
                "key": "expired-parent",
                "parent_number": parent_vehicle.get("vehicle_number", ""),
                "parent_period_end": parent_vehicle["period_end"],
            }
        )
    if "call-limit-breach" in inject_keys and parent_vehicle:
        existing_limit = float(parent_vehicle.get("call_limit") or 0)
        if existing_limit and existing_limit < estimated_amount:
            call_limit = existing_limit
        else:
            call_limit = max(2500.0, round(estimated_amount * rng.uniform(0.45, 0.75) / 500) * 500)
        parent_vehicle["call_limit"] = call_limit
        details.append(
            {
                "key": "call-limit-breach",
                "parent_number": parent_vehicle.get("vehicle_number", ""),
                "call_limit": call_limit,
                "call_amount": estimated_amount,
                "overage": round(estimated_amount - call_limit, 2),
            }
        )
    if "out-of-scope-order" in inject_keys and parent_vehicle:
        unrelated_scopes = [
            "recurring grounds maintenance, mowing, and vegetation control for cantonment areas",
            "bulk fuel handling support equipment and fuel bladder repair parts",
            "medical and dental consumable resupply for the expeditionary medical group",
            "airfield lighting spares and runway distance marker replacements",
        ]
        original_scope = str(parent_vehicle.get("scope") or "")
        replacement = rng.choice([scope for scope in unrelated_scopes if scope != original_scope])
        parent_vehicle["scope"] = replacement
        details.append(
            {
                "key": "out-of-scope-order",
                "parent_number": parent_vehicle.get("vehicle_number", ""),
                "parent_scope": replacement,
                "order_requirement": "see action requirement; does not match parent scope",
            }
        )
    if "near-ceiling-parent" in inject_keys and parent_vehicle:
        ceiling = float(parent_vehicle.get("ceiling") or 0)
        floor_needed = estimated_amount * 1.5
        if ceiling < floor_needed:
            ceiling = round(floor_needed / 5000) * 5000 + 5000
            parent_vehicle["ceiling"] = ceiling
        # Leave less headroom than this action's estimate.
        headroom = estimated_amount * rng.uniform(0.25, 0.7)
        obligated = max(0.0, round((ceiling - headroom) / 100) * 100)
        parent_vehicle["obligated_amount"] = obligated
        parent_vehicle["status"] = parent_vehicle.get("status") or "Active"
        details.append(
            {
                "key": "near-ceiling-parent",
                "parent_number": parent_vehicle.get("vehicle_number", ""),
                "ceiling": ceiling,
                "obligated": obligated,
                "remaining": round(ceiling - obligated, 2),
                "action_estimate": estimated_amount,
            }
        )
    return details


def inject_answer_key_entry(s: "Scenario", action_root: Path) -> dict[str, Any] | None:
    inject_keys = list(s.archetype.get("_injects") or [])
    if not inject_keys:
        return None
    details_by_key = {str(detail.get("key")): detail for detail in (s.archetype.get("_inject_details") or [])}
    tokens = {"prev_year": GENERIC_YEAR_PREV, "prev_year2": GENERIC_YEAR_PREV2}
    injects = []
    for key in inject_keys:
        definition = INJECT_DEFINITIONS.get(key, {})
        injects.append(
            {
                "key": key,
                "label": definition.get("label", key),
                "difficulty": definition.get("difficulty", "moderate"),
                "summary": str(definition.get("summary", "")).format(**tokens),
                "expected_find": str(definition.get("expected_find", "")).format(**tokens),
                "evidence": [str(item).format(**tokens) for item in definition.get("evidence", [])],
                "details": details_by_key.get(key, {}),
            }
        )
    return {
        "contract_number": s.contract_number,
        "folder": str(action_root.name),
        "title": s.archetype["title"],
        "category": s.category,
        "parent_contract_number": s.parent_contract_number,
        "injects": injects,
    }


def load_inject_key(package_dir: Path) -> list[dict[str, Any]]:
    path = office_controller_dir(package_dir) / "_inject_key.json"
    if not path.exists():
        path = package_dir / "_inject_key.json"
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    entries = payload.get("actions") if isinstance(payload, dict) else payload
    if isinstance(entries, list):
        return [entry for entry in entries if isinstance(entry, dict)]
    return []


def write_inject_key(package_dir: Path, entries: list[dict[str, Any]]) -> Path | None:
    if not entries:
        return None
    merged: dict[str, dict[str, Any]] = {}
    for entry in entries:
        merged[str(entry.get("contract_number", ""))] = entry
    ordered = sorted(merged.values(), key=lambda item: str(item.get("contract_number", "")))
    controller = office_controller_dir(package_dir)
    controller.mkdir(parents=True, exist_ok=True)
    (package_dir / "_inject_key.json").unlink(missing_ok=True)
    (package_dir / "_inject_key.md").unlink(missing_ok=True)
    json_path = controller / "_inject_key.json"
    json_path.write_text(
        json.dumps({"generated_at": current_controller_timestamp(), "actions": ordered}, indent=2),
        encoding="utf-8",
    )
    lines = [
        "# Inject Answer Key (Controller Only)",
        "",
        "Do not place this file in the trainee's mock office drive.",
        "",
    ]
    for entry in ordered:
        lines.append(f"## {entry.get('contract_number', '')} - {entry.get('title', '')}")
        lines.append("")
        lines.append(f"Folder: `{entry.get('folder', '')}`")
        if entry.get("parent_contract_number"):
            lines.append(f"Parent: {entry['parent_contract_number']}")
        lines.append("")
        for inject in entry.get("injects", []):
            lines.append(f"### {inject.get('label', '')} (`{inject.get('key', '')}`)")
            lines.append("")
            lines.append(f"Difficulty: **{inject.get('difficulty', 'moderate')}**")
            lines.append("")
            lines.append(str(inject.get("summary", "")))
            lines.append("")
            lines.append(f"**What the CCO should catch:** {inject.get('expected_find', '')}")
            lines.append("")
            lines.append("**Evidence:**")
            for item in inject.get("evidence", []):
                lines.append(f"- {item}")
            details = inject.get("details") or {}
            interesting = {k: v for k, v in details.items() if k != "key" and v not in ("", None)}
            if interesting:
                lines.append("")
                lines.append("**Planted values:**")
                for field, value in interesting.items():
                    if isinstance(value, float):
                        value = f"${value:,.2f}" if field in {"ceiling", "obligated", "remaining", "action_estimate"} else value
                    lines.append(f"- {field}: {value}")
            lines.append("")
    (controller / "_inject_key.md").write_text("\n".join(lines), encoding="utf-8")
    return json_path


def technical_review_context_note(text: str) -> str:
    text = remove_customer_instrument_determination(text or "")
    text = re.sub(
        r",?\s*(?:and\s+)?(?:overall\s+)?(?:price|cost)\s+(?:reasonableness|realism|fairness|analysis|evaluation)",
        "",
        text,
        flags=re.I,
    )
    text = re.sub(r"\b(?:price|cost)\s+and\s+", "", text, flags=re.I)
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*(?:and\s*)?\.", ".", text)
    text = re.sub(r"\s+", " ", text).strip(" ,.;")
    if not text:
        return ""
    parts = re.split(r"(?<=[.!?])\s+", text)
    kept = [
        part.strip()
        for part in parts
        if part.strip()
        and not re.search(r"\b(?:price|cost|funding|funds|award\s+(?:decision|judgment)|recommend\s+award)\b", part, re.I)
    ]
    return " ".join(kept).strip()


def build_ai_plan_prompt(prompt: str, scenario_type: str, solicitation_style: str) -> str:
    return f"""
Scenario prompt: {prompt}
Requested action type: {scenario_type}
Requested solicitation style: {solicitation_style}

Return one JSON object for a controlled CCO training package plan. Do not write finished documents.
Use reusable exercise language only: no real calendar years, no weekday/date commitments, no real-world personal data.
The generator will control PIIDs, Form 9 numbers, dates, funding math, vendor selection, award forms, and folder structure.
Document-facing fields must read as if written inside the mock contract file. Do not put generator/tool instructions,
training-package instructions, controlled-exercise caveats, real-date/PIID/funding warnings, metadata notes, or
package construction guidance in title, folder_label, requirement, clin_description, market_note, delivery_note,
evaluation_focus, line_items, or variation_profile. Put controller-only reasoning in rationale only.

Fields:
title, folder_label, category, requirement, clin_description, unit, quantity, quantity_range,
quantity_step, amount_range, fund_type, evaluation_focus, market_note, delivery_note,
solicitation_style, line_items, variation_profile, rationale.

Rules:
- category is supply, service, construction, bpa, idiq, bpa_call, or idiq_order.
- requirement must be a noun phrase that fits after "need for", for example "additional precast concrete T-Walls delivered to a deployed operating location", not "The requiring activity needs additional precast concrete T-Walls".
- T-Walls, Hescos, gravel, sand, concrete mix, material delivery, and similar commodity delivery/placement buys are normally supply actions. Do not classify them as construction unless the prompt clearly asks for construction of a new facility, foundation, roadway, pad, or other real property work.
- Construction means actual construction, alteration, or repair of real property. Incidental delivery, placement, setup, offload, staging, or installation support does not by itself make a requirement construction.
- Vehicle purchases on the open market are supply actions unless the prompt clearly asks for lease, rental, or recurring fleet support.
- Vehicle IDIQ masters for NTVs, sedans, vans, SUVs, pickups, buses, or fleet support are normally lease/rental/fleet-support service vehicles with class-specific monthly rates unless the prompt clearly asks for vehicle purchase, repair parts, tires, batteries, filters, oil, or other vehicle consumables.
- fund_type is om or procurement.
- services should be one year, normally unit MO and quantity 12.
- construction must stay under 1999000.
- IDIQ/BPA masters should describe ordering scope rather than funded delivery.
- evaluation_focus should contain only technical considerations plus price/past performance if helpful; Technical should naturally roll up to about three considerations.
- line_items are optional but useful when CLINs need realism. Use unit_price_range or fixed_price_range when quantity drives price.
- variation_profile should be subtle. Include email_style, customer_posture, file_texture, requirement_note, evaluation_note, and qa_focus. Do not create injects or material contradictions.
"""


def request_ai_scenario_plan(
    prompt: str,
    scenario_type: str,
    solicitation_style: str,
    model: str = "",
    provider: str = "codex-cli",
) -> tuple[dict[str, Any] | None, str]:
    system_prompt = (
        "You are a CCO training scenario planner. Return only JSON. "
        "Create realistic but fictitious acquisition scenario metadata for a deployed contracting exercise. "
        "Preserve controlled training rails; do not invent PIIDs, real dates, or final award decisions."
    )
    return call_ai_json(system_prompt, build_ai_plan_prompt(prompt, scenario_type, solicitation_style), model, provider)


def apply_ai_plan_to_archetype(
    archetype: dict[str, Any],
    plan: dict[str, Any],
    scenario_type: str = "auto",
    scenario_prompt: str = "",
) -> dict[str, Any]:
    updated = deepcopy(archetype)
    requested_type = normalize_scenario_type(scenario_type)
    planned_category = normalize_scenario_type(str(plan.get("category") or "auto"))
    base_category = infer_category(updated, "auto")
    prompt_requests_master = prompt_explicitly_requests_master_vehicle(scenario_prompt, scenario_type)
    category_locked = bool(updated.get("_ai_category_locked")) or not bool(updated.get("_custom_prompt_archetype"))
    master_promotion_without_request = (
        requested_type == "auto"
        and not prompt_requests_master
        and is_master_vehicle_category(planned_category)
        and planned_category != base_category
    )
    base_master_without_request = requested_type == "auto" and not prompt_requests_master and is_master_vehicle_category(base_category)
    guarded_category_mismatch = (
        requested_type == "auto"
        and category_locked
        and planned_category not in {"auto", "", base_category}
        and not base_master_without_request
    ) or master_promotion_without_request
    if requested_type != "auto":
        category = requested_type
    elif base_master_without_request and planned_category not in {"auto", "", base_category}:
        category = planned_category
    elif category_locked or master_promotion_without_request:
        category = base_category
    else:
        category = planned_category
    if category == "auto":
        category = base_category
    if category in {"bpa-call", "idiq-order"}:
        category = category.replace("-", "_")
    if category in {"supply", "service", "construction", "bpa", "idiq", "bpa_call", "idiq_order"}:
        updated["category"] = category
        updated["instrument"] = contract_letter_for_category(category, updated)
    requirement_category = category
    if category in {"bpa_call", "idiq_order"}:
        requirement_category = normalize_scenario_type(str(plan.get("requirement_category") or infer_category(updated, "auto")))
        if requirement_category in {"auto", "bpa", "idiq", "bpa_call", "idiq_order"}:
            requirement_category = "supply"
        updated["requirement_category"] = requirement_category

    preserve_master_price_list = (
        is_master_vehicle_category(category)
        and any(isinstance(item, dict) and item.get("vehicle_class") for item in updated.get("line_items", []))
    )
    vehicle_master_plan_guarded = bool(
        preserve_master_price_list
        and prompt_mentions_vehicle(scenario_prompt)
        and planned_category == "supply"
        and not prompt_requests_vehicle_supply_context(scenario_prompt)
    )
    core_plan_allowed = not guarded_category_mismatch and not vehicle_master_plan_guarded
    text_fields = {
        "title": 80,
        "folder_label": 60,
        "requirement": 450,
        "clin_description": 220,
        "evaluation_focus": 260,
        "market_note": 450,
        "delivery_note": 300,
    }
    if core_plan_allowed:
        for field, limit in text_fields.items():
            text = clean_ai_document_field(plan.get(field), limit, field)
            if text:
                updated[field] = text
        customer_hint = clean_ai_document_field(plan.get("customer_hint"), 40, "customer_hint")
        if customer_hint:
            updated["customer_hint"] = customer_hint
        if str(plan.get("fund_type", "")).lower() in {"om", "procurement"}:
            updated["fund_type"] = str(plan["fund_type"]).lower()
        if not preserve_master_price_list and clean_ai_unit(plan.get("unit"), ""):
            updated["unit"] = clean_ai_unit(plan.get("unit"), str(updated.get("unit") or "LOT"))
        if not preserve_master_price_list and plan.get("quantity") not in (None, ""):
            updated["quantity"] = clean_ai_int(plan.get("quantity"), int(updated.get("quantity") or 1))
        if not preserve_master_price_list and isinstance(plan.get("quantity_range"), (list, dict)):
            updated["quantity_range"] = clean_ai_range(plan.get("quantity_range"), list(updated.get("quantity_range") or [1, 12]), 1, 9999)
        if not preserve_master_price_list and plan.get("quantity_step") not in (None, ""):
            updated["quantity_step"] = clean_ai_int(plan.get("quantity_step"), int(updated.get("quantity_step") or 1), 1, 1000)
        if not preserve_master_price_list and isinstance(plan.get("amount_range"), (list, dict)):
            updated["amount_range"] = clean_ai_money_range(
                plan.get("amount_range"),
                list(updated.get("amount_range") or [15000, 90000]),
                str(updated.get("category") or "supply"),
            )
        line_items = clean_ai_line_items(plan.get("line_items"), str(updated.get("unit") or "LOT"), int(updated.get("quantity") or 1))
        if line_items and not preserve_master_price_list:
            updated["line_items"] = line_items
    variation_profile = clean_ai_variation_profile(plan.get("variation_profile"))
    if variation_profile:
        updated["_variation_profile"] = variation_profile
    style = str(plan.get("solicitation_style") or "").strip().lower()
    style_aliases = {
        "rfq": "rfq-email",
        "request_for_quotation": "rfq-email",
        "request-for-quotation": "rfq-email",
        "email_rfq": "rfq-email",
        "email-rfq": "rfq-email",
        "combined_synopsis_solicitation": "combined",
        "combined-synopsis-solicitation": "combined",
        "combined synopsis/solicitation": "combined",
        "combined synopsis solicitation": "combined",
        "combined solicitation": "combined",
    }
    style = style_aliases.get(style, style)
    if core_plan_allowed and style in {"auto", "rfq-email", "combined"}:
        updated["_ai_solicitation_style"] = style
    rationale = clean_ai_text(plan.get("rationale"), 500)
    if guarded_category_mismatch:
        guard = f"AI category '{planned_category}' ignored; generator kept protected archetype category '{base_category}'."
        rationale = f"{guard} {rationale}".strip()
        updated["_ai_plan_guardrail"] = guard
    elif vehicle_master_plan_guarded:
        guard = "AI supply-oriented rewrite ignored; vehicle IDIQ master kept the lease/fleet-support price schedule."
        rationale = f"{guard} {rationale}".strip()
        updated["_ai_plan_guardrail"] = guard
    elif base_master_without_request and category != base_category:
        guard = f"Base master-vehicle template '{base_category}' ignored because the prompt did not ask for a BPA/IDIQ master."
        rationale = f"{guard} {rationale}".strip()
        updated["_ai_plan_guardrail"] = guard
    updated["_ai_plan_used"] = True
    updated["_ai_plan_rationale"] = rationale
    updated["_ai_plan"] = plan
    if category == "service":
        enforce_service_period(updated, "service")
    return updated


def matching_archetypes(
    data: dict[str, Any],
    prompt: str | None,
    scenario_type: str = "auto",
) -> list[dict[str, Any]]:
    scenario_type = normalize_scenario_type(scenario_type)
    archetypes = data["archetypes"]
    prompt_category = custom_category_from_prompt(prompt, scenario_type) if prompt else scenario_type
    if prompt and prompt_category == "idiq" and prompt_mentions_construction(prompt):
        return [custom_archetype_from_prompt(prompt, "idiq")]
    if prompt and prompt_vehicle_master_should_use_lease_profile(prompt, prompt_category):
        vehicle_master = [archetype for archetype in archetypes if archetype.get("key") == "vehicle_lease_idiq"]
        if vehicle_master:
            return vehicle_master
    if prompt and scenario_type == "construction":
        return [custom_archetype_from_prompt(prompt, "construction")]
    if prompt and scenario_type in {"bpa_call", "idiq_order"} and prompt_order_requirement_category(prompt) in {"supply", "construction"}:
        return [custom_archetype_from_prompt(prompt, scenario_type)]
    if scenario_type in {"bpa_call", "idiq_order"}:
        archetypes = [
            archetype
            for archetype in archetypes
            if infer_category(archetype, "auto") not in {"bpa", "idiq", "bpa_call", "idiq_order"}
        ] or archetypes
    elif scenario_type != "auto":
        typed = [archetype for archetype in archetypes if infer_category(archetype, "auto") == scenario_type]
        archetypes = typed or archetypes
    elif prompt:
        prompt_category = custom_category_from_prompt(prompt, "auto")
        if prompt_category != "supply":
            typed = [archetype for archetype in archetypes if infer_category(archetype, "auto") == prompt_category]
            if typed:
                archetypes = typed
            else:
                return [custom_archetype_from_prompt(prompt, prompt_category)]
        else:
            typed = [archetype for archetype in archetypes if infer_category(archetype, "auto") == "supply"]
            if typed:
                archetypes = typed
    if not prompt:
        return archetypes
    prompt_category = custom_category_from_prompt(prompt, scenario_type)
    if prompt_category == "supply" and prompt_looks_like_office_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_category == "supply" and prompt_looks_like_generator_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_category == "supply" and prompt_looks_like_comm_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_category == "supply" and prompt_looks_like_medical_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_category == "supply" and prompt_looks_like_aircraft_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_category == "supply" and prompt_looks_like_unmodeled_supply(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if scenario_type == "auto" and not prompt_explicitly_requests_master_vehicle(prompt, scenario_type):
        non_master_archetypes = [
            archetype
            for archetype in archetypes
            if not is_master_vehicle_category(infer_category(archetype, "auto"))
        ]
        if non_master_archetypes:
            archetypes = non_master_archetypes
    if prompt_category == "supply" and prompt_mentions_vehicle(prompt) and not prompt_explicitly_requests_vehicle_lease(prompt):
        return [custom_archetype_from_prompt(prompt, "supply")]
    if prompt_looks_like_bulk_material_supply(prompt):
        return [custom_archetype_from_prompt(prompt, scenario_type)]
    words = prompt_words(prompt)
    scored: list[tuple[int, bool, dict[str, Any]]] = []
    prompt_lower = prompt.lower()
    for archetype in archetypes:
        haystack = archetype_haystack(archetype)
        score = sum(1 for word in words if word in haystack)
        alias_hit = False
        for alias in archetype.get("aliases", []):
            alias_text = str(alias).strip().lower()
            if alias_text and re.search(rf"\b{re.escape(alias_text)}\b", prompt_lower):
                score += 8 + len(alias_text.split())
                alias_hit = True
        if score:
            scored.append((score, alias_hit, archetype))
    if not scored:
        return [custom_archetype_from_prompt(prompt, scenario_type)]
    scored.sort(key=lambda item: item[0], reverse=True)
    top_score, top_alias_hit, _ = scored[0]
    if top_score < 2 and not top_alias_hit:
        return [custom_archetype_from_prompt(prompt, scenario_type)]
    return [item[2] for item in scored]


def vehicle_lease_label_from_prompt(prompt: str) -> str:
    lower = (prompt or "").lower()
    if re.search(r"\b(?:vans?|passenger\s+vans?)\b", lower):
        return "passenger vans"
    if re.search(r"\b(?:suvs?|sport\s+utility)\b", lower):
        return "sport utility vehicles"
    if re.search(r"\b(?:pickups?|pickup\s+trucks?)\b", lower):
        return "pickup trucks"
    if re.search(r"\b(?:sedans?)\b", lower):
        return "sedans"
    if re.search(r"\b(?:buses?|shuttles?)\b", lower):
        return "shuttle buses"
    return "non-tactical vehicles"


def vehicle_count_items_from_prompt(prompt: str) -> list[dict[str, Any]]:
    lower = (prompt or "").lower()
    patterns = [
        ("passenger vans", r"(?:passenger\s+)?vans?"),
        ("sport utility vehicles", r"(?:sport\s+utility\s+vehicles?|suvs?)"),
        ("pickup trucks", r"(?:pickup\s+trucks?|pickups?)"),
        ("sedans", r"sedans?"),
        ("cargo trucks", r"(?:cargo|box)\s+trucks?"),
        ("shuttle buses", r"(?:shuttle\s+)?buses?"),
        ("non-tactical vehicles", r"(?:non[- ]tactical\s+vehicles?|ntvs?|vehicles?)"),
    ]
    matches: list[tuple[int, dict[str, Any]]] = []
    used_spans: list[tuple[int, int]] = []
    for label, term_pattern in patterns:
        pattern = rf"\b(\d{{1,4}})\s+(?:[A-Za-z-]+\s+){{0,3}}({term_pattern})\b"
        for match in re.finditer(pattern, lower, flags=re.I):
            span = match.span()
            if any(max(span[0], used[0]) < min(span[1], used[1]) for used in used_spans):
                continue
            count = int(match.group(1))
            if count <= 0:
                continue
            matches.append((span[0], {"count": count, "label": label}))
            used_spans.append(span)
    return [item for _, item in sorted(matches, key=lambda pair: pair[0])]


def extract_quantity_from_prompt(prompt: str) -> int | None:
    # Only parse numeric quantities; words like "one T-Wall requirement" mean
    # one contract action, not necessarily one barrier.
    vehicle_items = vehicle_count_items_from_prompt(prompt)
    if vehicle_items:
        return sum(int(item["count"]) for item in vehicle_items)
    patterns = [
        r"\b(\d{1,4})\s+(?:[A-Za-z-]+\s+){0,3}(?:t[- ]?walls?|barriers?)\b",
        r"\b(\d{1,4})\s+(?:[A-Za-z-]+\s+){0,3}(?:rolls?|coils?)\b",
        r"\b(\d{1,4})\s+(?:[A-Za-z-]+\s+){0,3}(?:refrigerators?|freezers?|ice\s+machines?|dishwashers?|ovens?|stoves?|appliances?)\b",
        r"\b(\d{1,4})\s*(?:ea|each|units?|tons?|ton|mo|months?)\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, prompt, re.I)
        if match:
            value = int(match.group(1))
            return value if value > 0 else None
    return None


def phrase_join(items: list[str]) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return ", ".join(items[:-1]) + f", and {items[-1]}"


def vehicle_short_label(label: str) -> str:
    return {
        "passenger vans": "Vans",
        "sport utility vehicles": "SUVs",
        "pickup trucks": "Pickups",
        "sedans": "Sedans",
        "cargo trucks": "Cargo Trucks",
        "shuttle buses": "Shuttle Buses",
        "non-tactical vehicles": "Non-Tactical Vehicles",
    }.get(label, label.title())


def apply_direct_vehicle_lease_prompt_details(archetype: dict[str, Any], prompt: str, quantity_override: int | None) -> None:
    if archetype.get("key") != "vehicle_lease_order" or infer_category(archetype, "auto") != "service":
        return
    vehicle_items = vehicle_count_items_from_prompt(prompt)
    vehicle_count = quantity_override or sum(int(item["count"]) for item in vehicle_items) or extract_quantity_from_prompt(prompt)
    if not vehicle_items and vehicle_count:
        vehicle_items = [{"count": vehicle_count, "label": vehicle_lease_label_from_prompt(prompt)}]
    vehicle_summary = phrase_join([f"{item['count']} {item['label']}" for item in vehicle_items])
    vehicle_label = phrase_join(sorted({str(item["label"]) for item in vehicle_items})) or vehicle_lease_label_from_prompt(prompt)
    short_labels = phrase_join([vehicle_short_label(str(item["label"])) for item in vehicle_items])
    archetype["title"] = "Non-Tactical Vehicle Lease"
    archetype["folder_label"] = f"Vehicle Lease - {short_labels}" if short_labels and short_labels != "Non-Tactical Vehicles" else "Non-Tactical Vehicle Lease"
    archetype["requirement"] = (
        f"{vehicle_summary} leased for a 12-month period, including preventive maintenance, "
        "replacement vehicle support, delivery, and end-of-lease recovery"
        if vehicle_summary
        else f"leased {vehicle_label}, including preventive maintenance, replacement vehicle support, delivery, and end-of-lease recovery"
    )
    archetype["clin_description"] = (
        f"{vehicle_summary} leased for a 12-month period with maintenance and replacement support."
        if vehicle_summary
        else f"{vehicle_label.title()} lease with maintenance and replacement support."
    )
    archetype["delivery_note"] = (
        "Delivery and pickup will be coordinated with the requiring activity. "
        "The contractor shall provide required operating documentation, routine servicing, and replacement support."
    )
    archetype["unit"] = "MO"
    archetype["quantity"] = 12
    if vehicle_count:
        low_monthly = max(2500, int(vehicle_count) * 850)
        high_monthly = min(175000, int(vehicle_count) * 2400)
        archetype["amount_range"] = [low_monthly * 12, high_monthly * 12]
        line_items = []
        for idx, item in enumerate(vehicle_items or [{"count": vehicle_count, "label": vehicle_label}], start=1):
            count = int(item["count"])
            label = str(item["label"])
            line_items.append(
                {
                    "clin": f"{idx:04d}",
                    "description": f"{count} {label} leased for a 12-month period with maintenance and replacement support.",
                    "unit": "MO",
                    "quantity": 12,
                    "unit_price_range": [max(2500, count * 850), min(175000, count * 2400)],
                    "price_note": f"Monthly price covers {count} leased {label}.",
                }
            )
        archetype["line_items"] = line_items


def parent_vehicle_price_list(parent_vehicle: dict[str, Any]) -> list[dict[str, Any]]:
    rows = parent_vehicle.get("price_list") if parent_vehicle else []
    if not isinstance(rows, list):
        return []
    return [deepcopy(row) for row in rows if isinstance(row, dict) and row.get("clin")]


def vehicle_price_list_record(s: Scenario, awardee: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    if not has_price_list(s):
        return []
    source = master_price_list_for_awardee(s, awardee) if awardee else master_price_list(s)
    if source:
        return deepcopy(source)
    rows: list[dict[str, Any]] = []
    for item in s.line_items:
        rows.append(
            {
                "clin": item["clin"],
                "vehicle_class": item.get("vehicle_class", ""),
                "description": item["description"],
                "unit": item["unit"],
                "unit_price": round(float(item["unit_price"]), 2),
                "price_note": item.get("price_note", ""),
            }
        )
    return rows


def vehicle_class_terms(row: dict[str, Any]) -> set[str]:
    vehicle_class = str(row.get("vehicle_class") or row.get("description") or "").lower()
    terms = {vehicle_class}
    if "van" in vehicle_class:
        terms.update({"van", "vans"})
    if "sport utility" in vehicle_class or "suv" in vehicle_class:
        terms.update({"suv", "suvs", "sport utility vehicle", "sport utility vehicles"})
    if "pickup" in vehicle_class:
        terms.update({"pickup", "pickups", "pickup truck", "pickup trucks"})
    if "sedan" in vehicle_class:
        terms.update({"sedan", "sedans"})
    if "cargo truck" in vehicle_class:
        terms.update({"cargo truck", "cargo trucks", "box truck", "box trucks"})
    if "shuttle" in vehicle_class or "bus" in vehicle_class:
        terms.update({"shuttle bus", "shuttle buses", "bus", "buses"})
    return {term for term in terms if term}


def select_vehicle_price_row(prompt: str, price_list: list[dict[str, Any]]) -> dict[str, Any]:
    prompt_lower = prompt.lower()
    for row in price_list:
        if any(re.search(rf"\b{re.escape(term)}\b", prompt_lower) for term in vehicle_class_terms(row)):
            return row
    return price_list[0] if price_list else {}


def extract_vehicle_order_months(prompt: str) -> int:
    match = re.search(r"\b(\d{1,2})\s*(?:mo|mos|month|months)\b", prompt, re.I)
    if not match:
        return 12
    return max(1, min(12, int(match.group(1))))


def extract_vehicle_order_count(prompt: str, selected_row: dict[str, Any]) -> int:
    prompt_lower = prompt.lower()
    vehicle_terms = sorted(vehicle_class_terms(selected_row), key=len, reverse=True)
    for term in vehicle_terms:
        match = re.search(rf"\b(\d{{1,3}})\s+{re.escape(term)}\b", prompt_lower)
        if match:
            return max(1, int(match.group(1)))
    match = re.search(r"\b(\d{1,3})\s+(?:vehicles?|ntvs?)\b", prompt_lower)
    if match:
        return max(1, int(match.group(1)))
    return 4


def apply_parent_price_list_order(
    archetype: dict[str, Any],
    category: str,
    parent_vehicle: dict[str, Any],
    prompt: str,
) -> None:
    if category != "idiq_order":
        return
    price_list = parent_vehicle_price_list(parent_vehicle)
    if not price_list:
        return
    if not any(row.get("vehicle_class") for row in price_list):
        return
    selected = select_vehicle_price_row(prompt, price_list)
    if not selected:
        return
    unit_price = float(selected.get("unit_price") or 0)
    if unit_price <= 0:
        return
    vehicle_class = str(selected.get("vehicle_class") or selected.get("description") or "Vehicles").split("-", 1)[0].strip()
    months = extract_vehicle_order_months(prompt)
    vehicle_count = extract_vehicle_order_count(prompt, selected)
    order_quantity = vehicle_count * months
    order_amount = round(unit_price * order_quantity, 2)
    parent_number = str(parent_vehicle.get("vehicle_number") or "the parent IDIQ")

    archetype["folder_label"] = "Vehicle Lease Order"
    archetype["title"] = "Vehicle Lease Order"
    archetype["requirement_category"] = "service"
    archetype["unit"] = str(selected.get("unit") or "MO")
    archetype["quantity"] = order_quantity
    archetype["clin_description"] = "Vehicle lease in accordance with the attached price list."
    archetype["requirement"] = (
        f"{vehicle_count} {vehicle_class.lower()} for a {months}-month lease period under {parent_number}, "
        "including vehicle delivery, preventive maintenance, replacement vehicle support, and end-of-lease recovery"
    )
    archetype["delivery_note"] = (
        f"Order is for {vehicle_count} {vehicle_class.lower()} for {months} months. "
        "Contractor shall coordinate delivery, preventive maintenance, and replacement support with the requiring activity."
    )
    archetype["evaluation_focus"] = "vehicle availability, maintenance and replacement support, delivery schedule, past performance, and price"
    archetype["line_items"] = [
        {
            "clin": str(selected.get("clin") or "0001"),
            "vehicle_class": vehicle_class,
            "description": f"{vehicle_class} - vehicle lease in accordance with the attached price list.",
            "unit": str(selected.get("unit") or "MO"),
            "quantity": order_quantity,
            "share": 1,
            "price_note": f"{vehicle_count} vehicle(s) x {months} months at {money(unit_price)} per vehicle-month.",
        }
    ]
    archetype["_fixed_award_amount"] = order_amount
    archetype["_parent_price_list_order"] = True


def apply_standalone_vehicle_order_prompt_details(
    archetype: dict[str, Any],
    category: str,
    parent_contract_number: str,
    prompt: str,
    quantity_override: int | None,
) -> None:
    if category != "idiq_order" or archetype.get("_parent_price_list_order"):
        return
    vehicle_items = vehicle_count_items_from_prompt(prompt)
    if not vehicle_items and quantity_override:
        vehicle_items = [{"count": quantity_override, "label": vehicle_lease_label_from_prompt(prompt)}]
    if not vehicle_items:
        return
    months = extract_vehicle_order_months(prompt)
    vehicle_summary = phrase_join([f"{item['count']} {item['label']}" for item in vehicle_items])
    short_labels = phrase_join([vehicle_short_label(str(item["label"])) for item in vehicle_items])
    parent_text = parent_contract_number or "the referenced parent IDIQ"
    archetype["folder_label"] = f"Vehicle Lease Order - {short_labels}" if short_labels else "Vehicle Lease Order"
    archetype["title"] = "Vehicle Lease Order"
    archetype["requirement_category"] = "service"
    archetype["unit"] = "MO"
    archetype["quantity"] = months
    archetype["requirement"] = (
        f"{vehicle_summary} for a {months}-month lease period under {parent_text}, including vehicle delivery, "
        "preventive maintenance, replacement vehicle support, and end-of-lease recovery"
    )
    archetype["clin_description"] = f"{vehicle_summary} leased for {months} months with maintenance and replacement support."
    archetype["delivery_note"] = (
        f"Order is for {vehicle_summary} for {months} months. Contractor shall coordinate delivery, "
        "preventive maintenance, replacement support, and end-of-lease recovery with the requiring activity."
    )
    archetype["market_note"] = (
        "Market research should confirm the parent IDIQ scope, available vehicle classes, commercial lease support, "
        "and whether the proposed order is within the ordering vehicle terms."
    )
    archetype["evaluation_focus"] = "vehicle availability, vehicle condition, maintenance and replacement support, delivery schedule, past performance, and price"
    line_items = []
    for idx, item in enumerate(vehicle_items, start=1):
        count = int(item["count"])
        label = str(item["label"])
        line_items.append(
            {
                "clin": f"{idx:04d}",
                "vehicle_class": vehicle_short_label(label),
                "description": f"{count} {label} leased for {months} months with maintenance and replacement support.",
                "unit": "MO",
                "quantity": months,
                "unit_price_range": [max(2500, count * 850), min(175000, count * 2400)],
                "price_note": f"Monthly price covers {count} leased {label} for {months} months.",
            }
        )
    archetype["line_items"] = line_items
    archetype["_standalone_parent_order"] = True


GENERIC_SERVICE_PRICE_LINES = [
    ("General support labor", "HR", (38, 65)),
    ("Skilled trade labor", "HR", (55, 95)),
    ("Recurring service visit", "EA", (180, 450)),
    ("Emergency call-out", "EA", (250, 600)),
    ("Consumables and materials", "LOT", None),
]

GENERIC_SUPPLY_PRICE_LINES = [
    ("Copy paper, white, letter size, 10-ream case", "CS", (38, 68)),
    ("Printer toner cartridge, standard office printer class", "EA", (85, 240)),
    ("AA/AAA battery pack, alkaline, bulk package", "PK", (18, 55)),
    ("Cleaning supply bundle, general facility use", "KIT", (45, 125)),
    ("Small hand tool or facility consumable item", "EA", (12, 95)),
    ("Standard delivery to installation receiving point", "EA", (75, 220)),
]

GENERIC_CONSTRUCTION_PRICE_LINES = [
    ("Minor facility repair or alteration task order", "LOT", (25000, 250000)),
    ("Civil/site work and concrete task order", "LOT", (30000, 350000)),
    ("Electrical, HVAC, plumbing, or utility task order", "LOT", (20000, 300000)),
    ("Mobilization, submittals, safety, and closeout", "LOT", (5000, 50000)),
    ("Emergency repair response task order", "LOT", (15000, 150000)),
]


def price_list_quantity_basis(item: dict[str, Any]) -> str:
    unit = str(item.get("unit") or "").upper()
    if item.get("vehicle_class"):
        return "1 EA / MO" if unit == "MO" else f"1 EA / {unit or 'ORDER'}"
    return str(item.get("unit") or "")


def awardee_price_factor(awardee: dict[str, Any], base_total: float) -> float:
    if base_total <= 0:
        return 1.0
    try:
        amount = float(awardee.get("amount") or 0)
    except (TypeError, ValueError):
        return 1.0
    return max(0.55, min(1.75, amount / base_total)) if amount > 0 else 1.0


def line_items_priced_total(line_items: list[dict[str, Any]]) -> float:
    total = 0.0
    for item in line_items:
        if item.get("amount") not in (None, ""):
            total += float(item.get("amount") or 0)
        else:
            total += float(item.get("unit_price") or 0) * numeric_quantity(item.get("quantity", 1))
    return round(total, 2)


def expand_master_price_list_for_awardees(
    rows: list[dict[str, Any]],
    awardees: list[dict[str, Any]] | None,
    base_total: float,
    default_note: str,
) -> list[dict[str, Any]]:
    awardee_rows = [row for row in (awardees or []) if isinstance(row, dict) and row.get("name")]
    if not awardee_rows:
        return rows
    expanded: list[dict[str, Any]] = []
    for awardee in awardee_rows:
        factor = awardee_price_factor(awardee, base_total)
        for row in rows:
            item = dict(row)
            item["awardee"] = str(awardee.get("name") or "")
            item["contract_number"] = str(awardee.get("contract_number") or "")
            unit_price = float(item.get("unit_price") or 0)
            if unit_price > 0:
                item["unit_price"] = round(unit_price * factor, 2)
            item["price_note"] = str(item.get("price_note") or default_note)
            expanded.append(item)
    return expanded


def build_master_price_list(
    line_items: list[dict[str, Any]],
    requirement_category: str,
    rng: random.Random,
    awardees: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Ordering support lines for a master vehicle. Quantities live on calls/orders, never here."""
    if any(item.get("vehicle_class") for item in line_items):
        base_total = line_items_priced_total(line_items)
        rows = [
            {
                "clin": item["clin"],
                "vehicle_class": item.get("vehicle_class", ""),
                "description": item["description"],
                "quantity_basis": price_list_quantity_basis(item),
                "unit": item["unit"],
                "unit_price": round(float(item["unit_price"]), 2),
                "price_note": item.get("price_note", "Orders will specify actual quantity, period, delivery location, and funding."),
            }
            for item in line_items
        ]
        return expand_master_price_list_for_awardees(
            rows,
            awardees,
            base_total,
            "Orders cite the selected awardee IDIQ PIID, vehicle class, quantity, lease months, delivery point, and funding.",
        )
    if requirement_category == "construction":
        bank = GENERIC_CONSTRUCTION_PRICE_LINES
    elif requirement_category == "service":
        bank = GENERIC_SERVICE_PRICE_LINES
    else:
        bank = GENERIC_SUPPLY_PRICE_LINES
    rows: list[dict[str, Any]] = []
    for idx, (label, unit, price_range) in enumerate(bank, start=1):
        if requirement_category == "construction":
            unit_price = 0.0
            note = "Project price established by competed task order proposal; no standard MACC price list."
        elif price_range is None:
            unit_price = 0.0
            note = "At cost per contractor catalog/invoice; supported by call/order documentation."
        else:
            unit_price = float(round(rng.uniform(*price_range)))
            note = "Quantities ordered on individual calls/orders only."
        rows.append(
            {
                "clin": f"{idx:04d}",
                "vehicle_class": "",
                "description": label,
                "unit": unit,
                "unit_price": unit_price,
                "price_note": note,
            }
        )
    if requirement_category == "construction":
        return rows
    return expand_master_price_list_for_awardees(
        rows,
        awardees,
        line_items_priced_total(line_items),
        "Calls/orders cite the selected awardee parent PIID, CLIN, quantity, delivery or performance location, funding, and required date.",
    )


def master_price_list(s: "Scenario") -> list[dict[str, Any]]:
    rows = s.archetype.get("_master_price_list")
    return rows if isinstance(rows, list) else []


def master_awardees(s: "Scenario") -> list[dict[str, Any]]:
    rows = s.archetype.get("_master_awardees")
    return [row for row in rows if isinstance(row, dict) and row.get("name")] if isinstance(rows, list) else []


def is_multiple_award_master(s: "Scenario") -> bool:
    return bool(is_master_vehicle(s) and master_awardees(s))


def master_awardee_summary(s: "Scenario") -> str:
    awardees = master_awardees(s)
    if not awardees:
        return s.winner["name"]
    return f"Multiple awardees ({len(awardees)})"


def master_awardee_names(s: "Scenario") -> str:
    awardees = master_awardees(s)
    return "; ".join(str(row.get("name", "")) for row in awardees) if awardees else s.winner["name"]


def master_awardee_contract_numbers(s: "Scenario") -> list[str]:
    numbers: list[str] = []
    for row in master_awardees(s):
        number = str(row.get("contract_number") or "").strip().upper()
        if number:
            numbers.append(number)
    return numbers


def master_awardee_contract_numbers_text(s: "Scenario") -> str:
    return "; ".join(master_awardee_contract_numbers(s))


def master_awardee_display_names(s: "Scenario") -> str:
    awardees = master_awardees(s)
    if not awardees:
        return s.winner["name"]
    parts = []
    for row in awardees:
        number = str(row.get("contract_number") or "").strip().upper()
        name = str(row.get("name", ""))
        parts.append(f"{number} - {name}" if number else name)
    return "; ".join(parts)


def master_awardee_rows(s: "Scenario") -> list[list[str]]:
    rows = [["Contract", "Awardee", "UEI", "Evaluated Price", "Technical", "Quote"]]
    for row in master_awardees(s):
        rows.append(
            [
                str(row.get("contract_number", "")),
                str(row.get("name", "")),
                str(row.get("uei", "")),
                money(float(row.get("amount") or 0)),
                str(row.get("technical") or "Acceptable"),
                str(row.get("quote_number", "")),
            ]
        )
    return rows


def master_awardee_name_set(s: "Scenario") -> set[str]:
    return {str(row.get("name", "")) for row in master_awardees(s) if row.get("name")}


def is_master_awardee_vendor(s: "Scenario", vendor_name: str) -> bool:
    return vendor_name in master_awardee_name_set(s)


def master_awardee_for_vendor(s: "Scenario", vendor_name: str) -> dict[str, Any]:
    return next((row for row in master_awardees(s) if str(row.get("name", "")) == vendor_name), {})


def master_awardee_quote_rows(s: "Scenario") -> list[dict[str, Any]]:
    awardee_names = master_awardee_name_set(s)
    return [quote for quote in s.quote_rows if quote.get("vendor") in awardee_names]


def assign_master_awardee_contract_numbers(
    s: "Scenario",
    data: dict[str, Any],
    additional_sequences: list[int] | None = None,
) -> None:
    if not is_multiple_award_master(s):
        return
    awardees = master_awardees(s)
    if not awardees:
        return
    letter, base_sequence = piid_parts_from_contract_number(s.contract_number)
    letter = letter or contract_letter_for_category(s.category, s.archetype)
    activity = data["contracting_office"]["piid_activity"]
    sequences = [base_sequence or s.piid_sequence, *(additional_sequences or [])]
    updated: list[dict[str, Any]] = []
    for idx, awardee in enumerate(awardees):
        row = dict(awardee)
        sequence = sequences[idx] if idx < len(sequences) else (sequences[-1] + idx)
        row["piid_sequence"] = sequence
        row["contract_number"] = f"{activity}XX{letter}{sequence:04d}"
        updated.append(row)
    s.archetype["_master_awardees"] = updated
    sync_master_price_list_awardee_contract_numbers(s)


def sync_master_price_list_awardee_contract_numbers(s: "Scenario") -> None:
    rows = master_price_list(s)
    if not rows:
        return
    awardee_numbers = {str(row.get("name") or ""): str(row.get("contract_number") or "") for row in master_awardees(s)}
    if not awardee_numbers:
        return
    updated: list[dict[str, Any]] = []
    changed = False
    for row in rows:
        item = dict(row)
        awardee_name = str(item.get("awardee") or "")
        if awardee_name and not item.get("contract_number") and awardee_numbers.get(awardee_name):
            item["contract_number"] = awardee_numbers[awardee_name]
            changed = True
        updated.append(item)
    if changed:
        s.archetype["_master_price_list"] = updated


def contractor_for_master_awardee(s: "Scenario", awardee: dict[str, Any]) -> dict[str, str]:
    name = str(awardee.get("name", ""))
    uei = str(awardee.get("uei", ""))
    for contractor in s.contractors:
        if contractor.get("name") == name or contractor.get("code") == uei:
            return deepcopy(contractor)
    return {
        "name": name,
        "code": uei,
        "address": str(awardee.get("address", "")),
        "phone": str(awardee.get("phone", "")),
        "facility_code": "",
        "signer": str(awardee.get("signer", "Authorized Representative")),
    }


def master_price_list_for_awardee(s: "Scenario", awardee: dict[str, Any]) -> list[dict[str, Any]]:
    rows = [deepcopy(row) for row in master_price_list(s)]
    if not rows:
        return []
    target_contract = str(awardee.get("contract_number") or "").strip().upper()
    target_name = str(awardee.get("name") or "").strip()
    awardee_rows = [
        row
        for row in rows
        if (target_contract and str(row.get("contract_number") or "").strip().upper() == target_contract)
        or (target_name and str(row.get("awardee") or "").strip() == target_name)
    ]
    return awardee_rows or rows


def scenario_for_master_awardee(s: "Scenario", awardee: dict[str, Any]) -> "Scenario":
    archetype = deepcopy(s.archetype)
    archetype.pop("_master_awardees", None)
    filtered_price_list = master_price_list_for_awardee(s, awardee)
    if filtered_price_list:
        archetype["_master_price_list"] = filtered_price_list
    archetype["_multiple_award_source_contract"] = s.contract_number
    contract_number = str(awardee.get("contract_number") or s.contract_number)
    return replace(
        s,
        archetype=archetype,
        winner=contractor_for_master_awardee(s, awardee),
        base_amount=round(float(awardee.get("amount") or s.base_amount), 2),
        contract_number=contract_number,
        piid_sequence=int(awardee.get("piid_sequence") or piid_sequence_from_contract_number(contract_number) or s.piid_sequence),
    )


def multiple_award_pool_folder_name(s: "Scenario") -> str:
    vehicle_label = master_vehicle_label(s.category)
    label = truncate_filename(str(s.archetype.get("folder_label") or s.archetype.get("title") or "Award Pool"), MAX_ACTION_LABEL_CHARS, "Award Pool")
    return sanitize_filename(f"MA {vehicle_label} - {label}")


def bpa_call_limit_value(s: "Scenario") -> float:
    return float(s.archetype.get("_bpa_call_limit") or 25000.0)


def idiq_ceiling_value(s: "Scenario") -> float:
    return float(s.archetype.get("_idiq_ceiling") or 0.0) or float(s.base_amount)


def idiq_minimum_value(s: "Scenario") -> float:
    return float(s.archetype.get("_idiq_minimum") or 10000.0)


def build_scenario(
    index: int,
    data: dict[str, Any],
    archetype: dict[str, Any],
    rng: random.Random,
    max_stage: int,
    piid_sequence: int | None = None,
    stage_override: int | None = None,
    quantity_override: int | None = None,
    scenario_type: str = "auto",
    solicitation_style: str = "auto",
    parent_number_override: str = "",
    vehicle_registry: list[dict[str, Any]] | None = None,
    scenario_prompt: str = "",
    awardee_count_override: int | None = None,
    injects: list[str] | None = None,
    inject_messages: list[str] | None = None,
) -> Scenario:
    archetype = deepcopy(archetype)
    source_category = infer_category(archetype, "auto")
    category = infer_category(archetype, scenario_type)
    requirement_category = str(archetype.get("requirement_category") or source_category).lower()
    if category not in {"bpa_call", "idiq_order"}:
        requirement_category = str(archetype.get("requirement_category") or category).lower() if is_master_vehicle_category(category) else category
    if requirement_category in {"bpa", "idiq", "bpa_call", "idiq_order", "auto", ""}:
        requirement_category = "supply"
    archetype["category"] = category
    archetype["instrument"] = contract_letter_for_category(category, archetype)
    if quantity_override:
        apply_quantity_override(archetype, quantity_override)
    else:
        apply_quantity_override(archetype, random_quantity_from_range(archetype, rng, scenario_prompt))
    ensure_variation_profile(archetype, rng, scenario_prompt)
    ensure_personas(archetype, rng)
    enforce_service_period(archetype, requirement_category)
    apply_direct_vehicle_lease_prompt_details(archetype, scenario_prompt, quantity_override)
    apply_line_item_quantity_ranges(archetype, rng, bool(quantity_override))
    if category in {"bpa_call", "idiq_order"} and scenario_prompt:
        requirement_category = prompt_order_requirement_category(scenario_prompt)
        archetype["requirement_category"] = requirement_category
    piid_sequence = piid_sequence if piid_sequence is not None else index
    parent_contract_number, parent_vehicle = parent_contract_number_for_order(
        category,
        data["contracting_office"]["piid_activity"],
        piid_sequence,
        rng,
        parent_number_override,
        vehicle_registry,
        requirement_category,
    )
    parent_instrument_label = parent_instrument_label_for_category(category)
    apply_parent_price_list_order(archetype, category, parent_vehicle, scenario_prompt)
    apply_standalone_vehicle_order_prompt_details(archetype, category, parent_contract_number, scenario_prompt, quantity_override)
    if category in {"bpa_call", "idiq_order"} or is_master_vehicle_category(category):
        requirement_category = str(archetype.get("requirement_category") or requirement_category).lower()
    else:
        requirement_category = category
    if requirement_category in {"bpa", "idiq", "bpa_call", "idiq_order", "auto", ""}:
        requirement_category = "supply"
    archetype["requirement_category"] = requirement_category
    requested_awardee_count = max(1, min(8, int(awardee_count_override))) if awardee_count_override is not None else None
    auto_multiple_award_master = bool(
        category == "idiq"
        and (
            archetype.get("_multiple_award")
            or prompt_requests_multiple_award(scenario_prompt)
            or requirement_category == "construction"
        )
    )
    multiple_award_master = bool(
        is_master_vehicle_category(category)
        and ((requested_awardee_count is not None and requested_awardee_count > 1) or (requested_awardee_count is None and auto_multiple_award_master))
    )
    if multiple_award_master:
        archetype["_multiple_award"] = True
    ensure_requirement_profile(archetype, category, requirement_category, scenario_prompt, rng)

    inject_keys, inject_notes = resolve_injects(list(injects or []), category, rng)
    if inject_messages is not None:
        inject_messages.extend(inject_notes)
    archetype["_injects"] = inject_keys
    parent_inject_keys = [
        key for key in inject_keys if key in {"expired-parent", "near-ceiling-parent", "call-limit-breach", "out-of-scope-order"}
    ]
    if parent_inject_keys and parent_contract_number and not parent_vehicle:
        # No real master exists in the registry; synthesize one so the
        # tracker/registry carry the evidence the trainee must find.
        synthetic_vendor = rng.choice(data["contractors"])
        parent_vehicle = synthetic_parent_vehicle_record(parent_contract_number, category, synthetic_vendor, archetype, rng)
    if "expired-vehicle" in inject_keys:
        archetype["_inject_expired_vehicle"] = True
    if "wrong-appropriation" in inject_keys:
        correct_fund = str(archetype.get("fund_type") or "om")
        archetype["_inject_correct_fund_type"] = correct_fund
        archetype["fund_type"] = "procurement" if correct_fund == "om" else "om"
    if "wrong-piid-letter" in inject_keys:
        archetype["_inject_wrong_piid_letter"] = True
    if "missing-certification" in inject_keys:
        archetype["_inject_missing_certification"] = True
    if "missing-tech-eval" in inject_keys:
        archetype["_inject_missing_tech_eval"] = True
    if "unsigned-award" in inject_keys:
        archetype["_inject_unsigned_award"] = True
    if "late-quote" in inject_keys:
        archetype["_inject_late_quote"] = True
    if "tracker-mismatch" in inject_keys:
        archetype["_inject_tracker_mismatch"] = True
    if "pop-clin-mismatch" in inject_keys:
        archetype["quantity"] = 6
        line_items_spec = archetype.get("line_items")
        if isinstance(line_items_spec, list) and line_items_spec:
            line_items_spec[0]["quantity"] = 6
        archetype["_inject_pop_clin_mismatch"] = True

    customer = pick_customer(data, archetype, rng)
    requester = rng.choice(customer["requesters"])
    approver = rng.choice(customer["approvers"])
    certifier = rng.choice(data["certifying_officials"])
    co = deepcopy(rng.choice(data["contracting_office"]["contacts"]))

    parent_vendor = contractor_from_vehicle_record(data, parent_vehicle)
    if parent_vendor:
        contractors = [parent_vendor]
    else:
        if multiple_award_master:
            contractor_count = min(requested_awardee_count or rng.randint(4, min(8, len(data["contractors"]))), len(data["contractors"]))
        else:
            contractor_count = rng.randint(3, min(5, len(data["contractors"])))
        contractors = rng.sample(data["contractors"], contractor_count)
    base_low, base_high = archetype["amount_range"]
    # Organic BPA calls must respect the parent's per-call purchase limitation,
    # unless a call-limit-breach inject is deliberately planted.
    if category == "bpa_call" and parent_vehicle and parent_vehicle.get("call_limit") and "call-limit-breach" not in inject_keys:
        parent_call_limit = float(parent_vehicle["call_limit"])
        capped_high = int(parent_call_limit * 0.78)
        if capped_high > 2000:
            base_high = min(int(base_high), capped_high)
            base_low = min(int(base_low), max(1000, base_high - 500))
        fixed_existing = archetype.get("_fixed_award_amount")
        if fixed_existing and float(fixed_existing) > parent_call_limit * 0.95:
            archetype["_fixed_award_amount"] = round(parent_call_limit * rng.uniform(0.55, 0.85), 2)
    if requirement_category == "construction":
        base_high = min(int(base_high), CONSTRUCTION_AWARD_CAP)
        base_low = min(int(base_low), base_high - 250)
        base_low = max(25000, base_low)
    if category == "idiq_order":
        base_high = min(int(base_high), TASK_ORDER_AWARD_CAP)
        base_low = min(int(base_low), max(250, base_high - 250))
    if int(base_high) <= int(base_low):
        base_high = int(base_low) + 250
    fixed_award_amount = archetype.get("_fixed_award_amount")
    quantity_based_amount = quantity_priced_amount(archetype, rng)
    if quantity_based_amount is not None:
        fixed_award_amount = quantity_based_amount
    if category == "idiq_order" and fixed_award_amount:
        fixed_award_amount = min(float(fixed_award_amount), TASK_ORDER_AWARD_CAP)
    if fixed_award_amount:
        base_amount = round(float(fixed_award_amount), 2)
    else:
        base_amount = rng.randrange(base_low, base_high, 250)
    winner = contractors[0]
    quote_rows: list[dict[str, Any]] = []
    technical_considerations = technical_factor_list_from_archetype(archetype)
    quote_format_cycle = ["email", "letterhead", "estimate", "technical", "simple"]
    rng.shuffle(quote_format_cycle)
    for idx, contractor in enumerate(contractors):
        multiplier = 1.0 if idx == 0 else rng.uniform(0.90, 1.22)
        if fixed_award_amount and idx == 0:
            amount = round(float(base_amount), 2)
        else:
            amount = round(base_amount * multiplier / 10) * 10
        if requirement_category == "construction":
            amount = min(amount, CONSTRUCTION_AWARD_CAP)
        if category == "idiq_order":
            amount = min(amount, TASK_ORDER_AWARD_CAP)
        quote_row = build_quote_row(
            archetype,
            requirement_category,
            contractor,
            amount,
            idx,
            technical_considerations,
            rng,
            allow_non_response=not multiple_award_master,
            allow_technical_flaws=not multiple_award_master,
        )
        if not quote_row["non_response"]:
            quote_row["quote_format"] = quote_format_cycle[idx % len(quote_format_cycle)]
        quote_rows.append(quote_row)

    if not multiple_award_master:
        ensure_quote_variance(quote_rows, technical_considerations, rng)
    rng.shuffle(quote_rows)
    quote_rows.sort(
        key=lambda row: (
            row.get("non_response", False),
            row["technical"] != "Acceptable",
            float(row["amount"]) if row.get("amount") is not None else 999999999.0,
        )
    )
    winner_name = quote_rows[0]["vendor"]
    winner = next(contractor for contractor in contractors if contractor["name"] == winner_name)
    base_amount = round(float(quote_rows[0]["amount"]), 2)
    line_items = line_items_for_amount(archetype, base_amount)
    if multiple_award_master:
        awardees = []
        for quote in quote_rows:
            contractor = next((item for item in contractors if item["name"] == quote["vendor"]), {})
            awardees.append(
                {
                    "name": quote["vendor"],
                    "uei": quote.get("uei", contractor.get("code", "")),
                    "amount": round(float(quote.get("amount") or 0), 2),
                    "technical": quote.get("technical", "Acceptable"),
                    "quote_number": quote.get("quote_number", ""),
                    "signer": contractor.get("signer", ""),
                    "address": contractor.get("address", ""),
                    "phone": contractor.get("phone", ""),
                }
            )
        archetype["_master_awardees"] = sorted(awardees, key=lambda item: item["name"])

    if is_master_vehicle_category(category):
        archetype["_master_price_list"] = build_master_price_list(
            line_items,
            requirement_category,
            rng,
            archetype.get("_master_awardees") if isinstance(archetype.get("_master_awardees"), list) else None,
        )
        if category == "bpa":
            archetype["_bpa_call_limit"] = float(rng.choice([10000, 15000, 25000, 50000]))
            archetype["_master_estimated_value"] = float(max(50000, round(base_amount / 25000) * 25000))
        else:
            ceiling = max(500000, ((int(base_amount) + 249999) // 250000) * 250000)
            archetype["_idiq_ceiling"] = float(ceiling)
            archetype["_idiq_minimum"] = float(rng.choice([5000, 10000, 25000]))

    inject_details: list[dict[str, Any]] = []
    if "unjustified-award" in inject_keys:
        acceptable = [row for row in quote_rows if not row.get("non_response") and row["technical"] == "Acceptable"]
        if len(acceptable) >= 2 and float(acceptable[1]["amount"]) > float(acceptable[0]["amount"]):
            passed_over = acceptable[0]
            awarded_row = acceptable[1]
            winner_name = awarded_row["vendor"]
            winner = next(contractor for contractor in contractors if contractor["name"] == winner_name)
            base_amount = round(float(awarded_row["amount"]), 2)
            line_items = line_items_for_amount(archetype, base_amount)
            inject_details.append(
                {
                    "key": "unjustified-award",
                    "awarded_vendor": winner_name,
                    "awarded_price": base_amount,
                    "passed_over_vendor": passed_over["vendor"],
                    "passed_over_price": round(float(passed_over["amount"]), 2),
                    "premium": round(base_amount - float(passed_over["amount"]), 2),
                }
            )
        else:
            inject_keys = [key for key in inject_keys if key != "unjustified-award"]
            archetype["_injects"] = inject_keys
            if inject_messages is not None:
                inject_messages.append("Inject 'unjustified-award' skipped: quote pool lacked two distinct acceptable prices.")
    if "funding-shortfall" in inject_keys:
        shortfall = round(base_amount * rng.uniform(0.72, 0.90) / 100) * 100
        archetype["_inject_funding_shortfall_amount"] = float(shortfall)
        inject_details.append(
            {
                "key": "funding-shortfall",
                "certified_amount": float(shortfall),
                "award_amount": float(base_amount),
                "shortfall": round(float(base_amount) - shortfall, 2),
            }
        )
    if "wrong-appropriation" in inject_keys:
        inject_details.append(
            {
                "key": "wrong-appropriation",
                "cited_fund_type": str(archetype.get("fund_type")),
                "correct_fund_type": str(archetype.get("_inject_correct_fund_type")),
            }
        )
    if "missing-certification" in inject_keys:
        inject_details.append({"key": "missing-certification", "form9": "certifying official block left blank"})
    if "missing-tech-eval" in inject_keys:
        inject_details.append({"key": "missing-tech-eval", "suppressed": "technical evaluation request and technical evaluation"})
    if "unsigned-award" in inject_keys:
        inject_details.append({"key": "unsigned-award", "blank_block": "CO signature on award face page"})
    if "late-quote" in inject_keys:
        inject_details.append({"key": "late-quote", "vendor": winner_name, "note": "awardee receipt date falls after quotes-due"})
    if "entity-mismatch" in inject_keys:
        true_code = str(winner.get("code", ""))
        mismatched = true_code
        if len(true_code) >= 4:
            chars = list(true_code)
            chars[1], chars[2] = chars[2], chars[1]
            mismatched = "".join(chars)
        archetype["_inject_award_vendor_code"] = mismatched
        inject_details.append(
            {"key": "entity-mismatch", "quote_code": true_code, "award_code": mismatched, "vendor": winner_name}
        )
    if "pop-clin-mismatch" in inject_keys:
        inject_details.append({"key": "pop-clin-mismatch", "pws_period": "12-month base period", "clin_quantity": "6 MO"})
    if "sam-inactive" in inject_keys:
        archetype["_inject_sam_inactive"] = True
        inject_details.append({"key": "sam-inactive", "vendor": winner_name, "screening_shows": "Registration INACTIVE - lapsed"})
    if "adverse-past-performance" in inject_keys:
        prior_number = f"{data['contracting_office']['piid_activity']}XXP{rng.randint(80, 95):04d}"
        archetype["_inject_prior_performance_record"] = {
            "prior_number": prior_number,
            "vendor": winner_name,
            "title": str(archetype.get("title") or "Prior requirement"),
            "folder_label": str(archetype.get("folder_label") or "Prior Requirement"),
        }
        inject_details.append(
            {
                "key": "adverse-past-performance",
                "vendor": winner_name,
                "prior_contract": prior_number,
                "prior_folder": "",  # filled after archive folder is written
            }
        )
    if parent_inject_keys and parent_vehicle:
        inject_details.extend(apply_parent_vehicle_injects(parent_inject_keys, parent_vehicle, float(base_amount), rng))
    if "expired-vehicle" in inject_keys:
        inject_details.append(
            {
                "key": "expired-vehicle",
                "vehicle_number": "",  # filled in below once the contract number exists
                "period_note": f"Awarded {GENERIC_YEAR_PREV2}-era, period ended {GENERIC_YEAR_PREV}.",
            }
        )
    archetype["_inject_details"] = inject_details

    timeline = create_timeline(rng)
    set_category_timeline(timeline, requirement_category if category in {"bpa_call", "idiq_order"} else category)
    contract_letter = contract_letter_for_category(category, archetype)
    if archetype.get("_inject_wrong_piid_letter"):
        wrong_letter = "F" if contract_letter == "P" else "P"
        inject_details.append(
            {"key": "wrong-piid-letter", "correct_letter": contract_letter, "used_letter": wrong_letter}
        )
        contract_letter = wrong_letter
    contract_number = f"{data['contracting_office']['piid_activity']}XX{contract_letter}{piid_sequence:04d}"
    solicitation_number = f"{data['contracting_office']['piid_activity']}XXQ{piid_sequence:04d}"
    pr_number = form9_number(index, rng)
    file_number = f"{GENERIC_FY}-XXAEW-LGCA-{index:04d}"
    acrn, loa, funding_label = funding_seed(data, archetype["fund_type"], rng)
    if is_master_vehicle_category(category):
        vehicle_label = master_vehicle_label(category)
        if category == "bpa":
            limits_line = (
                f"Funding will be cited on individual BPA calls. Per-call purchase limitation: {money(float(archetype.get('_bpa_call_limit') or 25000))}. "
                f"Estimated annual usage for planning only (not a ceiling): {money(float(archetype.get('_master_estimated_value') or base_amount))}."
            )
        else:
            limits_line = (
                f"Funding will be cited on individual task or delivery orders. IDIQ ceiling: {money(float(archetype.get('_idiq_ceiling') or base_amount))}. "
                f"Guaranteed minimum: {money(float(archetype.get('_idiq_minimum') or 10000))}, tracked in the funding folder and satisfied through funded orders."
            )
        accounting_data = (
            f"Master {vehicle_label} only - no ACRN or LOA cited on the agreement.\n"
            f"{limits_line}\n"
            f"Funding Document: N/A - {vehicle_label} MASTER  Obligation: $0.00"
        )
    else:
        accounting_data = (
            f"ACRN {acrn}: {loa}\n"
            f"Fund Type: {funding_label} ({data['funding_profiles'][archetype['fund_type']]['appn']})\n"
            f"Funding Document: {pr_number}  Obligation: {money(base_amount)}"
        )
        if parent_contract_number:
            accounting_data += f"\nParent {parent_instrument_label}: {parent_contract_number}  Call/Order: {contract_number}"

    if "phantom-master" in inject_keys:
        phantom_letter = rng.choice(["A", "D"])
        phantom_number = f"{data['contracting_office']['piid_activity']}XX{phantom_letter}{rng.randint(90, 99):04d}"
        phantom_vendor = rng.choice(data["contractors"])
        phantom_is_bpa = phantom_letter == "A"
        archetype["_inject_phantom_master_record"] = {
            "vehicle_number": phantom_number,
            "instrument": "BPA" if phantom_is_bpa else "IDIQ",
            "title": rng.choice(
                ["Base Operations Support Agreement", "Incidental Services Agreement", "Regional Supply Support Vehicle"]
            ),
            "scope": "recurring base support supplies and incidental services",
            "requirement_category": "supply",
            "status": "Active",
            "vendor": phantom_vendor["name"],
            "vendor_code": phantom_vendor.get("code", ""),
            "customer": "",
            "contracting_officer": "",
            "ceiling": "" if phantom_is_bpa else float(rng.randrange(500000, 2000000, 250000)),
            "call_limit": float(rng.choice([10000, 25000, 50000])) if phantom_is_bpa else "",
            "obligated_amount": 0.0 if phantom_is_bpa else float(rng.randrange(20000, 150000, 1000)),
            "period_start": f"1 October {GENERIC_YEAR_PREV}",
            "period_end": f"30 September {GENERIC_YEAR}",
            "award_date": f"1 October {GENERIC_YEAR_PREV}",
            "package": "",
            "folder": "",
            "folder_path": "",
        }
        inject_details.append(
            {
                "key": "phantom-master",
                "vehicle_number": phantom_number,
                "note": "registry/tracker row exists; no folder anywhere on the drive",
            }
        )
    for detail in inject_details:
        if detail.get("key") == "expired-vehicle":
            detail["vehicle_number"] = contract_number

    action_label = truncate_filename(str(archetype["folder_label"]), MAX_ACTION_LABEL_CHARS, "Requirement")
    folder_name = sanitize_filename(f"{contract_number} - {action_label}")
    stage = stage_override if stage_override is not None else weighted_stage(rng, max_stage)
    if is_master_vehicle_category(category) and stage > 7:
        stage = 7
    if "expired-vehicle" in inject_keys and stage < 7:
        stage = 7  # an expired master must show its award and closeout record
    if "tracker-mismatch" in inject_keys:
        if stage >= 7:
            stage = 6  # keep the folder one stage behind what the tracker will claim
        claimed_stage = 7 if stage < 7 else 8
        archetype["_inject_tracker_claimed_stage"] = claimed_stage
        inject_details.append(
            {
                "key": "tracker-mismatch",
                "actual_stage": stage,
                "tracker_claims_stage": claimed_stage,
                "tracker_claims": STAGE_FOLDERS[claimed_stage - 1][1],
            }
        )
    if solicitation_style == "auto":
        resolved_solicitation_style = "rfq-email" if category == "supply" and base_amount <= 75000 else "combined"
    else:
        resolved_solicitation_style = solicitation_style
    return Scenario(
        index=index,
        archetype=deepcopy(archetype),
        customer=customer,
        requester=requester,
        approver=approver,
        certifier=certifier,
        co=co,
        contractors=deepcopy(contractors),
        winner=deepcopy(winner),
        base_amount=base_amount,
        line_items=line_items,
        quote_rows=quote_rows,
        stage=stage,
        timeline=timeline,
        delivery_address=build_delivery_address(data, rng),
        contract_number=contract_number,
        piid_sequence=piid_sequence,
        parent_contract_number=parent_contract_number,
        parent_instrument_label=parent_instrument_label,
        parent_vehicle=parent_vehicle,
        solicitation_number=solicitation_number,
        pr_number=pr_number,
        file_number=file_number,
        loa=loa,
        accounting_data=accounting_data,
        funding_label=funding_label,
        folder_name=folder_name,
        category=category,
        requirement_category=requirement_category,
        solicitation_style=resolved_solicitation_style,
    )


def pdf_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="DocTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=20,
            alignment=TA_CENTER,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Subtitle",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=9,
            leading=12,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#555555"),
            spaceAfter=12,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SectionHeading",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            spaceBefore=8,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Small",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Mono",
            parent=styles["Normal"],
            fontName="Courier",
            fontSize=8.5,
            leading=11,
        )
    )
    return styles


def p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(escape(str(text)).replace("\n", "<br/>"), style)


def add_table(story: list[Any], rows: list[list[Any]], widths: list[float] | None = None) -> None:
    if not rows:
        return
    styles = pdf_styles()
    styles.add(ParagraphStyle(name="TableHeader", parent=styles["Small"], fontName="Helvetica-Bold", textColor=colors.HexColor("#1B3A5C")))
    converted = [
        [p(cell, styles["TableHeader"] if row_idx == 0 else styles["Small"]) for cell in row]
        for row_idx, row in enumerate(rows)
    ]
    table = Table(converted, colWidths=widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EEF7")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#1B3A5C")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#888888")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.12 * inch))


def footer(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(colors.HexColor("#B00000"))
    canvas.drawCentredString(letter[0] / 2, letter[1] - 0.28 * inch, EXERCISE_BANNER)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawRightString(7.85 * inch, 0.38 * inch, f"Page {doc.page}")
    canvas.restoreState()


def email_page_marks(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 8.5)
    canvas.setFillColor(colors.HexColor("#B00000"))
    canvas.drawCentredString(letter[0] / 2, letter[1] - 0.36 * inch, EXERCISE_BANNER)
    canvas.drawCentredString(letter[0] / 2, 0.35 * inch, EXERCISE_BANNER)
    canvas.restoreState()


def add_email_body(story: list[Any], body: str, styles: dict[str, ParagraphStyle]) -> None:
    for block in body.split("\n\n"):
        lines = [line.rstrip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        bullet_lines = [re.sub(r"^\s*[-*•]\s*", "", line) for line in lines if re.match(r"^\s*[-*•]\s+", line)]
        if bullet_lines and len(bullet_lines) == len(lines):
            for line in bullet_lines:
                story.append(Paragraph(escape(line), styles["OutlookBullet"], bulletText="•"))
            story.append(Spacer(1, 0.04 * inch))
            continue
        story.append(p("\n".join(lines), styles["OutlookBody"]))
        story.append(Spacer(1, 0.045 * inch))


def add_email_table(story: list[Any], rows: list[list[Any]], widths: list[float] | None = None) -> None:
    if not rows:
        return
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="EmailTableCell", parent=styles["Normal"], fontName="Helvetica", fontSize=7.8, leading=9.4))
    styles.add(ParagraphStyle(name="EmailTableHeader", parent=styles["EmailTableCell"], fontName="Helvetica-Bold", textColor=colors.white))
    converted = [
        [p(cell, styles["EmailTableHeader"] if row_idx == 0 else styles["EmailTableCell"]) for cell in row]
        for row_idx, row in enumerate(rows)
    ]
    table = Table(converted, colWidths=widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#153B5C")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7B7B7")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    story.append(Spacer(1, 0.05 * inch))
    story.append(table)
    story.append(Spacer(1, 0.10 * inch))


def add_attachment_bar(story: list[Any], attachments: list[str], styles: dict[str, ParagraphStyle]) -> None:
    label = "   ".join(f"[PDF]  {name}" for name in attachments)
    table = Table([[p(label, styles["OutlookSmall"])]], colWidths=[6.7 * inch], hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F2F2F2")),
                ("BOX", (0, 0), (-1, -1), 0.35, colors.HexColor("#C7C7C7")),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story.append(Spacer(1, 0.05 * inch))
    story.append(table)
    story.append(Spacer(1, 0.04 * inch))


def mrr_page_marks(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 8.5)
    canvas.setFillColor(colors.HexColor("#B00000"))
    canvas.drawCentredString(letter[0] / 2, letter[1] - 0.32 * inch, EXERCISE_BANNER)
    canvas.restoreState()


def write_pdf(
    path: Path,
    title: str,
    subtitle: str,
    sections: list[dict[str, Any]],
    first_page_notice: str | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    styles = pdf_styles()
    story: list[Any] = [p(title, styles["DocTitle"]), p(subtitle, styles["Subtitle"])]
    if first_page_notice:
        story.append(p(first_page_notice, styles["Small"]))
        story.append(Spacer(1, 0.12 * inch))
    for section in sections:
        heading = section.get("heading")
        if heading:
            story.append(p(heading, styles["SectionHeading"]))
        for paragraph in section.get("paragraphs", []):
            style = styles["Mono"] if section.get("mono") else styles["Normal"]
            story.append(p(paragraph, style))
            story.append(Spacer(1, 0.07 * inch))
        if "table" in section:
            add_table(story, section["table"], section.get("widths"))
        if section.get("page_break"):
            story.append(PageBreak())
    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        rightMargin=0.65 * inch,
        leftMargin=0.65 * inch,
        topMargin=0.6 * inch,
        bottomMargin=0.65 * inch,
        title=title,
    )
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def sf1449_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="SFFormTitle", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=9.2, leading=10.4, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="SFFormNote", parent=styles["Normal"], fontName="Helvetica", fontSize=5.8, leading=6.4, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="SFLabel", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=5.8, leading=6.6))
    styles.add(ParagraphStyle(name="SFValue", parent=styles["Normal"], fontName="Helvetica", fontSize=7.0, leading=8.0))
    styles.add(ParagraphStyle(name="SFValueBold", parent=styles["SFValue"], fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="SFTiny", parent=styles["Normal"], fontName="Helvetica", fontSize=5.7, leading=6.2))
    styles.add(ParagraphStyle(name="UCFTitle", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=10.5, leading=12, textColor=colors.white))
    styles.add(ParagraphStyle(name="UCFMeta", parent=styles["Normal"], fontName="Helvetica", fontSize=6.7, leading=7.8, textColor=colors.white))
    styles.add(ParagraphStyle(name="UCFHeading", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=8.8, leading=10.4, textColor=colors.white))
    styles.add(ParagraphStyle(name="UCFBody", parent=styles["Normal"], fontName="Helvetica", fontSize=8.2, leading=10.2))
    styles.add(ParagraphStyle(name="UCFSmall", parent=styles["Normal"], fontName="Helvetica", fontSize=7.2, leading=8.8))
    return styles


def sf1449_page_marks(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(colors.HexColor("#B00000"))
    canvas.drawCentredString(letter[0] / 2, letter[1] - 0.25 * inch, EXERCISE_BANNER)
    canvas.setFont("Helvetica", 6.5)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawRightString(8.05 * inch, 0.25 * inch, f"Page {doc.page}")
    canvas.restoreState()


def sf1449_cell(label: str, value: Any = "", styles: dict[str, ParagraphStyle] | None = None) -> list[Any]:
    styles = styles or sf1449_styles()
    return [p(label, styles["SFLabel"]), p(value if str(value).strip() else " ", styles["SFValue"])]


def sf1449_check_line(options: list[tuple[str, bool]]) -> str:
    return "    ".join(f"[{'X' if checked else ' '}] {label}" for label, checked in options)


def sf1449_grid(
    rows: list[list[Any]],
    widths: list[float],
    styles: dict[str, ParagraphStyle],
    row_heights: list[float] | None = None,
    header_rows: int = 0,
) -> Table:
    converted: list[list[Any]] = []
    for row in rows:
        converted_row: list[Any] = []
        for cell in row:
            if isinstance(cell, list) or isinstance(cell, Paragraph):
                converted_row.append(cell)
            else:
                converted_row.append(p(cell, styles["SFValue"]))
        converted.append(converted_row)
    table = Table(converted, colWidths=widths, rowHeights=row_heights, hAlign="LEFT", repeatRows=header_rows)
    commands: list[tuple[Any, ...]] = [
        ("GRID", (0, 0), (-1, -1), 0.45, colors.black),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]
    if header_rows:
        commands.extend(
            [
                ("BACKGROUND", (0, 0), (-1, header_rows - 1), colors.HexColor("#E6E6E6")),
                ("FONTNAME", (0, 0), (-1, header_rows - 1), "Helvetica-Bold"),
            ]
        )
    table.setStyle(TableStyle(commands))
    return table


def sf1449_ucf_header(story: list[Any], s: Scenario, title: str, page_label: str, styles: dict[str, ParagraphStyle]) -> None:
    meta = f"Contract: {s.contract_number}\nSolicitation: {s.solicitation_number}\nContractor: {s.winner['name']}\n{page_label}"
    table = Table([[p(title, styles["UCFTitle"]), p(meta, styles["UCFMeta"])]], colWidths=[4.85 * inch, 2.60 * inch], hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#1B1F24")),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#1B1F24")),
                ("LEFTPADDING", (0, 0), (-1, -1), 7),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.10 * inch))


def sf1449_section_bar(story: list[Any], title: str, styles: dict[str, ParagraphStyle]) -> None:
    table = Table([[p(title, styles["UCFHeading"])]], colWidths=[7.45 * inch], hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#2F3D4C")),
                ("BOX", (0, 0), (-1, -1), 0.4, colors.HexColor("#2F3D4C")),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.05 * inch))


def sf1449_ucf_table(story: list[Any], rows: list[list[Any]], widths: list[float], styles: dict[str, ParagraphStyle]) -> None:
    converted = [[p(cell, styles["UCFSmall"]) for cell in row] for row in rows]
    table = Table(converted, colWidths=widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DDE4EC")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#1B1F24")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#6E7881")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.10 * inch))


def sf1449_paragraphs(story: list[Any], paragraphs: list[str], styles: dict[str, ParagraphStyle]) -> None:
    for paragraph in paragraphs:
        story.append(p(paragraph, styles["UCFBody"]))
        story.append(Spacer(1, 0.045 * inch))


def has_price_list(s: Scenario) -> bool:
    if effective_requirement_category(s) == "construction" and not price_list_has_vehicle_classes(s):
        return False
    if is_master_vehicle(s) and master_price_list(s):
        return True
    return s.category == "idiq" and any(item.get("vehicle_class") for item in s.line_items)


def has_macc_ordering_procedures(s: Scenario) -> bool:
    return bool(s.category == "idiq" and effective_requirement_category(s) == "construction" and is_multiple_award_master(s))


def price_list_attachment_title(s: Scenario) -> str:
    if price_list_has_vehicle_classes(s) or "vehicle" in s.archetype["title"].lower():
        return "Vehicle Lease Price List"
    if effective_requirement_category(s) == "construction":
        return "Task Order Price List"
    if s.category == "bpa":
        return "BPA Price List"
    return "Price List"


def price_list_has_vehicle_classes(s: Scenario) -> bool:
    rows = master_price_list(s) or s.line_items
    return any(row.get("vehicle_class") for row in rows)


def price_list_has_awardee_rates(s: Scenario) -> bool:
    return any(row.get("awardee") for row in master_price_list(s))


def price_list_item_label(s: Scenario) -> str:
    if price_list_has_vehicle_classes(s):
        return "Vehicle Class"
    if effective_requirement_category(s) == "construction":
        return "Ordering Category"
    if effective_requirement_category(s) == "supply":
        return "Item / Supply"
    return "Item / Service"


def price_list_intro_paragraphs(s: Scenario, solicitation_template: bool = False) -> list[str]:
    if solicitation_template and price_list_has_awardee_rates(s):
        if price_list_has_vehicle_classes(s):
            return [
                "Offerors shall propose monthly rates for each vehicle class listed below.",
                "Awarded rates will be incorporated into each awardee's IDIQ and used when future orders cite that awardee's parent PIID, CLIN, vehicle class, quantity, lease period, delivery location, and funding.",
            ]
        return [
            "Offerors shall propose unit prices for each ordering category listed below.",
            "Awarded rates will be incorporated into each awardee's BPA/IDIQ and used when future calls or orders cite that awardee's parent PIID, CLIN, quantity, delivery or performance location, funding, and required date.",
        ]
    if price_list_has_awardee_rates(s):
        if price_list_has_vehicle_classes(s):
            return [
                "Prices establish awardee-specific vehicle classes available for future task or delivery orders.",
                "Orders shall cite the selected awardee's parent IDIQ PIID, CLIN, vehicle class, quantity, lease period, delivery location, funding, and any mission-specific support requirements.",
            ]
        return [
            "Prices establish awardee-specific ordering categories available for future calls or orders.",
            "Calls or orders shall cite the selected awardee's parent PIID, CLIN, quantity, delivery or performance location, funding, required date, and any mission-specific support requirements.",
        ]
    if price_list_has_vehicle_classes(s):
        return [
            "Prices establish the vehicle classes available for future task or delivery orders.",
            "Individual orders will identify the CLIN, vehicle class, quantity, lease period, delivery location, funding, and any mission-specific support requirements.",
        ]
    if effective_requirement_category(s) == "construction":
        return [
            "Prices establish representative ordering categories for future construction task orders.",
            "Individual task orders will identify the scope, drawings or sketches, quantities, schedule, location, funding, safety controls, and closeout requirements.",
        ]
    if effective_requirement_category(s) == "supply":
        return [
            "Prices establish representative catalog items or supply categories available for future calls or orders.",
            "Individual calls or orders will identify the CLIN, item description, quantity, delivery location, funding, and any order-specific documentation or substitution controls.",
        ]
    return [
        "Prices establish representative service or support categories available for future calls or orders.",
        "Individual calls or orders will identify the CLIN, performance period, location, funding, required deliverables, and any mission-specific support requirements.",
    ]


def price_list_unit_price_text(item: dict[str, Any]) -> str:
    unit_price = float(item.get("unit_price") or 0)
    if unit_price <= 0:
        return "At cost"
    if item.get("vehicle_class") and str(item.get("unit") or "").upper() == "MO":
        return f"{money(unit_price)} / month"
    return money(unit_price)


def price_list_solicitation_template_rows(s: Scenario) -> list[list[str]]:
    source = master_price_list(s)
    item_label = price_list_item_label(s)
    rows = [["CLIN", item_label, "Qty Basis", "Offeror Unit Price", "Notes"]]
    seen: set[tuple[str, str]] = set()
    for item in source:
        clin = str(item.get("clin", ""))
        item_description = str(item.get("vehicle_class") or item.get("description", ""))
        key = (clin, item_description)
        if key in seen:
            continue
        seen.add(key)
        unit = str(item.get("unit") or "").upper()
        is_vehicle_month = bool(item.get("vehicle_class")) and unit == "MO"
        rows.append(
            [
                clin,
                item_description,
                str(item.get("quantity_basis") or price_list_quantity_basis(item)),
                "Proposed monthly rate" if is_vehicle_month else "Proposed unit price",
                "Offeror shall state the rate for one vehicle-month; orders will state actual quantity and months."
                if is_vehicle_month
                else "Offeror shall state the unit price; calls/orders will state actual quantity and required date.",
            ]
        )
    return rows


def price_list_rows(s: Scenario, solicitation_template: bool = False) -> list[list[str]]:
    source = master_price_list(s)
    if source:
        if solicitation_template and any(item.get("awardee") for item in source):
            return price_list_solicitation_template_rows(s)
        if any(item.get("awardee") for item in source):
            rows = [["Awardee", "CLIN", price_list_item_label(s), "Qty Basis", "Unit Price", "Notes"]]
            for item in source:
                awardee_label = str(item.get("awardee") or "")
                contract_number = str(item.get("contract_number") or "")
                if contract_number:
                    awardee_label = f"{contract_number} - {awardee_label}"
                rows.append(
                    [
                        awardee_label,
                        str(item.get("clin", "")),
                        str(item.get("vehicle_class") or item.get("description", "")),
                        str(item.get("quantity_basis") or price_list_quantity_basis(item)),
                        price_list_unit_price_text(item),
                        str(item.get("price_note") or "Orders will specify actual quantity, lease period, delivery location, and funding."),
                    ]
                )
            return rows
        if price_list_has_vehicle_classes(s):
            rows = [["CLIN", "Vehicle Class", "Qty Basis", "Unit Price", "Notes"]]
            for item in source:
                rows.append(
                    [
                        str(item.get("clin", "")),
                        str(item.get("vehicle_class") or item.get("description", "")),
                        str(item.get("quantity_basis") or price_list_quantity_basis(item)),
                        price_list_unit_price_text(item),
                        str(item.get("price_note") or "Orders will specify actual quantity, lease period, delivery location, and funding."),
                    ]
                )
            return rows
        label = price_list_item_label(s)
        rows = [["CLIN", label, "Unit", "Unit Price", "Notes"]]
        for item in source:
            rows.append(
                [
                    str(item.get("clin", "")),
                    str(item.get("vehicle_class") or item.get("description", "")),
                    str(item.get("unit", "")),
                    price_list_unit_price_text(item),
                    str(item.get("price_note") or "Quantities ordered on individual calls/orders only."),
                ]
            )
        return rows
    rows = [["CLIN", "Vehicle Class", "Qty Basis", "Unit Price", "Notes"]]
    for item in s.line_items:
        vehicle_class = str(item.get("vehicle_class") or item["description"].split("-", 1)[0]).strip()
        rows.append(
            [
                item["clin"],
                vehicle_class,
                str(item.get("quantity_basis") or price_list_quantity_basis(item)),
                price_list_unit_price_text(item),
                str(item.get("price_note") or "Orders will specify actual quantity, lease period, delivery location, and funding."),
            ]
        )
    return rows


def price_list_widths(s: Scenario, solicitation_template: bool = False) -> list[float]:
    if price_list_has_awardee_rates(s) and not solicitation_template:
        return [1.30 * inch, 0.45 * inch, 1.05 * inch, 0.72 * inch, 0.78 * inch, 2.20 * inch]
    return [0.55 * inch, 1.35 * inch, 0.85 * inch, 0.90 * inch, 2.85 * inch]


def sf1449_attachment_rows(s: Scenario) -> list[list[str]]:
    quote_label = "Awardee Quote / Proposal"
    if is_multiple_award_master(s):
        quote_label = "Awardee Quotes / Proposals"
    elif s.winner.get("name"):
        quote_label = f"{s.winner['name']} Quote / Proposal"
    rows = [["", "Statement of Requirement / Requirement Routing"]]
    support_name = requirement_support_doc_name(s)
    if support_name:
        rows.append(["", f"{requirement_support_doc_type(s)} - {support_name}"])
    if has_macc_ordering_procedures(s):
        rows.append(["", "Fair Opportunity Ordering Procedures"])
    elif has_price_list(s):
        rows.append(["", price_list_attachment_title(s)])
    rows.extend([["", "Market Research Report"], ["", quote_label]])
    renumbered = [["Attachment", "Title"]]
    for idx, row in enumerate(rows, start=1):
        renumbered.append([str(idx), row[1]])
    return renumbered


def sf1449_total_pages() -> int:
    return 11


def sf1449_naics(s: Scenario) -> str:
    title = s.archetype["title"].lower()
    requirement = s.archetype["requirement"].lower()
    if is_construction_requirement(s):
        text = f"{title} {requirement}"
        if any(term in text for term in ["electrical", "power", "utility", "utilities"]):
            return "238210"
        if any(term in text for term in ["hvac", "plumbing", "mechanical"]):
            return "238220"
        if any(term in text for term in ["concrete", "drainage", "site work", "civil", "road", "apron", "pad"]):
            return "237990"
        return "236220"
    if "vehicle lease" in title or "leased non-tactical vehicles" in requirement or "vehicle rental" in requirement:
        return "532111"
    if is_service_requirement(s) and ("janitorial" in title or "clean" in requirement):
        return "561720"
    if is_service_requirement(s):
        return "561210"
    if "barrier" in title or "t-wall" in title or "hesco" in requirement:
        return "332999"
    return "339999"


def sf1449_clause_entries(s: Scenario) -> list[dict[str, str]]:
    entries = [
        {"clause": "52.204-7", "title": "System for Award Management", "date": "OCT 20XX", "method": "Reference"},
        {"clause": "52.204-13", "title": "System for Award Management Maintenance", "date": "OCT 20XX", "method": "Reference"},
        {"clause": "52.204-21", "title": "Basic Safeguarding of Covered Contractor Information Systems", "date": "NOV 20XX", "method": "Reference"},
        {"clause": "52.212-1", "title": "Instructions to Offerors - Commercial Products and Commercial Services", "date": "SEP 20XX", "method": "Reference"},
        {"clause": "52.212-4", "title": "Contract Terms and Conditions - Commercial Products and Commercial Services", "date": "NOV 20XX", "method": "Reference"},
        {"clause": "52.232-33", "title": "Payment by Electronic Funds Transfer - System for Award Management", "date": "OCT 20XX", "method": "Reference"},
    ]
    if is_construction_requirement(s):
        entries.extend(
            [
                {"clause": "52.236-2", "title": "Differing Site Conditions", "date": "APR 20XX", "method": "Reference"},
                {"clause": "52.236-3", "title": "Site Investigation and Conditions Affecting the Work", "date": "APR 20XX", "method": "Reference"},
                {"clause": "52.236-7", "title": "Permits and Responsibilities", "date": "NOV 20XX", "method": "Reference"},
                {"clause": "52.236-13", "title": "Accident Prevention", "date": "NOV 20XX", "method": "Full text"},
                {"clause": "52.243-4", "title": "Changes", "date": "JUN 20XX", "method": "Reference"},
            ]
        )
        if s.category in {"idiq", "idiq_order"}:
            entries.extend(
                [
                    {"clause": "52.216-18", "title": "Ordering", "date": "AUG 20XX", "method": "Full text"},
                    {"clause": "52.216-19", "title": "Order Limitations", "date": "OCT 20XX", "method": "Reference"},
                    {"clause": "52.216-22", "title": "Indefinite Quantity", "date": "OCT 20XX", "method": "Full text"},
                ]
            )
    elif is_service_requirement(s) and not is_ordering_action(s):
        entries.extend(
            [
                {"clause": "52.217-8", "title": "Option to Extend Services", "date": "NOV 20XX", "method": "Full text"},
                {"clause": "52.217-9", "title": "Option to Extend the Term of the Contract", "date": "MAR 20XX", "method": "Full text"},
                {"clause": "52.237-3", "title": "Continuity of Services", "date": "JAN 20XX", "method": "Full text"},
                {"clause": "52.246-4", "title": "Inspection of Services - Fixed-Price", "date": "AUG 20XX", "method": "Full text"},
            ]
        )
    elif s.category in {"idiq", "idiq_order"}:
        entries.extend(
            [
                {"clause": "52.216-18", "title": "Ordering", "date": "AUG 20XX", "method": "Full text"},
                {"clause": "52.216-19", "title": "Order Limitations", "date": "OCT 20XX", "method": "Reference"},
                {"clause": "52.216-22", "title": "Indefinite Quantity", "date": "OCT 20XX", "method": "Full text"},
            ]
        )
    elif s.category == "bpa_call":
        entries.extend(
            [
                {"clause": "Parent BPA", "title": "Authorized call issued within parent BPA scope and limitations", "date": "20XX", "method": "Reference"},
                {"clause": "52.246-2", "title": "Inspection of Supplies - Fixed-Price", "date": "AUG 20XX", "method": "Full text"},
            ]
        )
    else:
        entries.extend(
            [
                {"clause": "52.211-6", "title": "Brand Name or Equal", "date": "AUG 20XX", "method": "Reference"},
                {"clause": "52.246-2", "title": "Inspection of Supplies - Fixed-Price", "date": "AUG 20XX", "method": "Full text"},
            ]
        )
    return entries


def sf1449_full_text_blocks(s: Scenario) -> list[list[tuple[str, list[str]]]]:
    common = [
        (
            "52.204-7 SYSTEM FOR AWARD MANAGEMENT (OCT 20XX)",
            [
                "The offeror shall be registered in the System for Award Management at the time an offer is submitted and shall maintain active registration during performance.",
                "The Contractor is responsible for the accuracy and completeness of information entered in SAM. Failure to maintain required registration may affect payment, award, or performance actions.",
            ],
        ),
        (
            "52.204-13 SYSTEM FOR AWARD MANAGEMENT MAINTENANCE (OCT 20XX)",
            [
                "The Contractor shall maintain registration in SAM during contract performance and through final payment.",
                "The Contractor shall notify the Contracting Officer of changes that could affect payment, representations, certifications, or responsibility determinations.",
            ],
        ),
        (
            "52.204-21 BASIC SAFEGUARDING OF COVERED CONTRACTOR INFORMATION SYSTEMS (NOV 20XX)",
            [
                "The Contractor shall apply basic safeguarding requirements and procedures to protect covered contractor information systems.",
                "This clause applies to systems owned or operated by the Contractor that process, store, or transmit Federal contract information.",
            ],
        ),
        (
            "52.212-1 INSTRUCTIONS TO OFFERORS - COMMERCIAL PRODUCTS AND COMMERCIAL SERVICES (SEP 20XX)",
            [
                "North American Industry Classification System code and small business size standard are stated on the face page.",
                "Offerors shall submit offers in the form and quantity specified in the solicitation. Offers shall include prices, technical information, representations, and other information required by the solicitation.",
                "The Government may reject any or all offers if such action is in the public interest.",
            ],
        ),
        (
            "52.212-4 CONTRACT TERMS AND CONDITIONS - COMMERCIAL PRODUCTS AND COMMERCIAL SERVICES (NOV 20XX)",
            [
                "The Contractor shall comply with the terms and conditions of this contract and shall provide the supplies or services described in the schedule.",
                "The Government will inspect and accept supplies or services as stated in Section E. Payment will be made in accordance with the payment office identified on the SF 1449.",
                "Changes may be made only by written agreement of the parties unless otherwise authorized by the contract.",
            ],
        ),
        (
            "52.232-33 PAYMENT BY ELECTRONIC FUNDS TRANSFER - SYSTEM FOR AWARD MANAGEMENT (OCT 20XX)",
            [
                "The Government shall make payment by electronic funds transfer using information contained in SAM.",
                "The Contractor is responsible for maintaining current EFT information. Payment may be delayed if banking information is incomplete, inaccurate, or inactive.",
            ],
        ),
    ]
    if is_construction_requirement(s):
        construction = [
            (
                "52.236-2 DIFFERING SITE CONDITIONS (APR 20XX)",
                [
                    "The Contractor shall notify the Contracting Officer before disturbing site conditions that differ materially from those indicated in the contract or from conditions ordinarily encountered.",
                    "The parties will address any resulting adjustment by written direction or contract modification, as applicable.",
                ],
            ),
            (
                "52.236-3 SITE INVESTIGATION AND CONDITIONS AFFECTING THE WORK (APR 20XX)",
                [
                    "The Contractor acknowledges that site conditions, access, laydown, utilities, and base operating constraints may affect the work.",
                    "The Contractor shall coordinate work sequencing, safety controls, and site access with the Government before mobilization.",
                ],
            ),
            (
                "52.236-13 ACCIDENT PREVENTION (NOV 20XX)",
                [
                    "The Contractor shall provide and maintain work environments and procedures that safeguard the public, Government personnel, contractor personnel, property, materials, supplies, and equipment exposed to contractor operations.",
                    "The Contractor shall coordinate safety submittals, daily controls, and incident reporting with the Government representative identified for the work.",
                ],
            ),
            (
                "52.243-4 CHANGES (JUN 20XX)",
                [
                    "The Contracting Officer may make changes within the general scope of the contract by written order.",
                    "No field direction, customer request, or contractor assumption changes the contract unless incorporated by the Contracting Officer.",
                ],
            ),
        ]
        if s.category in {"idiq", "idiq_order"}:
            construction.extend(
                [
                    (
                        "52.216-18 ORDERING (AUG 20XX)",
                        [
                            "Construction or site-work efforts shall be ordered by issuance of task or delivery orders by authorized ordering officials.",
                            "Each order will identify the applicable scope, funding, place of performance, performance period, and order-specific requirements.",
                        ],
                    ),
                    (
                        "52.216-22 INDEFINITE QUANTITY (OCT 20XX)",
                        [
                            "Performance shall be made only as authorized by orders issued in accordance with the ordering clause.",
                            "The ordering vehicle establishes the general scope and limits; individual orders control actual work authorization and payment.",
                        ],
                    ),
                ]
            )
        blocks = common + construction
    elif s.category == "service":
        service = [
            (
                "52.217-8 OPTION TO EXTEND SERVICES (NOV 20XX)",
                [
                    "The Government may require continued performance of any services within the limits and at the rates specified in the contract.",
                    "The option provision may be exercised more than once, but total extension of performance shall not exceed 6 months. The Contracting Officer may exercise the option by written notice to the Contractor within 30 days.",
                ],
            ),
            (
                "52.217-9 OPTION TO EXTEND THE TERM OF THE CONTRACT (MAR 20XX)",
                [
                    "The Government may extend the term of this contract by written notice to the Contractor within 30 days, provided that preliminary notice is given before the contract expires.",
                    "If the Government exercises this option, the extended contract shall be considered to include this option clause.",
                    "The total duration of this contract, including options, shall not exceed five years.",
                ],
            ),
            (
                "52.237-3 CONTINUITY OF SERVICES (JAN 20XX)",
                [
                    "The Contractor recognizes that services under this contract are vital to the Government and must be continued without interruption.",
                    "The Contractor shall cooperate with successor contractors and Government personnel to ensure orderly transition of services.",
                ],
            ),
            (
                "52.246-4 INSPECTION OF SERVICES - FIXED-PRICE (AUG 20XX)",
                [
                    "The Contractor shall provide and maintain an inspection system acceptable to the Government.",
                    "The Government has the right to inspect and test all services called for by the contract, to the extent practicable, at all places and times during performance.",
                ],
            ),
        ]
        blocks = common + service
    elif s.category in {"idiq", "idiq_order"}:
        idiq = [
            (
                "52.216-18 ORDERING (AUG 20XX)",
                [
                    "Supplies and services to be furnished under this contract shall be ordered by issuance of task or delivery orders by the individuals or activities designated in the contract.",
                    "Orders may be issued during the ordering period stated in the schedule. All orders are subject to the terms and conditions of the contract.",
                ],
            ),
            (
                "52.216-19 ORDER LIMITATIONS (OCT 20XX)",
                [
                    "The Contractor is not obligated to honor an order exceeding the maximum order limitation stated in the schedule unless it accepts the order.",
                    "The Government may issue multiple orders, but each order must remain within scope, funding, and ordering authority.",
                ],
            ),
            (
                "52.216-22 INDEFINITE QUANTITY (OCT 20XX)",
                [
                    "The Government shall order at least the minimum quantity or amount stated in the schedule, if any.",
                    "Delivery or performance shall be made only as authorized by orders issued in accordance with the ordering clause.",
                ],
            ),
        ]
        blocks = common + idiq
    else:
        supply = [
            (
                "52.211-6 BRAND NAME OR EQUAL (AUG 20XX)",
                [
                    "If an item is identified by brand name or equal, the Contractor shall furnish supplies that meet the salient characteristics stated in the contract.",
                    "The Government may evaluate equal products based on descriptive literature, specifications, and other information submitted with the quote.",
                ],
            ),
            (
                "52.246-2 INSPECTION OF SUPPLIES - FIXED-PRICE (AUG 20XX)",
                [
                    "The Contractor shall provide and maintain an inspection system acceptable to the Government.",
                    "The Government has the right to inspect and test all supplies called for by the contract, to the extent practicable, at all places and times including the period of manufacture.",
                ],
            ),
        ]
        blocks = common + supply
    return [blocks[:4], blocks[4:8], blocks[8:]]


def sf1449_draw_wrapped(
    c: Any,
    text: Any,
    x: float,
    y: float,
    max_width: float,
    font: str = "Helvetica",
    size: float = 8,
    leading: float | None = None,
    max_lines: int | None = None,
) -> float:
    leading = leading or size + 2
    c.setFont(font, size)
    lines_drawn = 0
    for raw_line in str(text).splitlines() or [""]:
        words = raw_line.split()
        if not words:
            y -= leading
            continue
        line = ""
        for word in words:
            test = f"{line} {word}".strip()
            if not line or c.stringWidth(test, font, size) <= max_width:
                line = test
                continue
            if max_lines is not None and lines_drawn >= max_lines:
                return y
            c.drawString(x, y, line)
            y -= leading
            lines_drawn += 1
            line = word
        if line:
            if max_lines is not None and lines_drawn >= max_lines:
                return y
            c.drawString(x, y, line)
            y -= leading
            lines_drawn += 1
    return y


def sf1449_draw_training_marks(c: Any, page: int, total_pages: int, continuation: bool) -> None:
    c.saveState()
    c.setFillColor(colors.HexColor("#F2DADA"))
    c.translate(letter[0] / 2, letter[1] / 2 - 20)
    c.rotate(35)
    c.setFont("Helvetica-Bold", 34)
    c.drawCentredString(0, 0, "EXERCISE DOCUMENT")
    c.restoreState()
    c.saveState()
    c.setFillColor(colors.HexColor("#B00000"))
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(letter[0] / 2, 780, EXERCISE_BANNER)
    c.restoreState()
    if continuation:
        c.setStrokeColor(colors.black)
        c.setLineWidth(0.8)
        c.line(25, 30, 587, 30)
        c.setFont("Helvetica", 7)
        c.setFillColor(colors.black)
        c.drawString(25, 20, "SF 1449 Continuation / Uniform Contract Format")
        c.drawRightString(587, 20, f"Page {page} of {total_pages}")


def sf1449_draw_cell(c: Any, x: float, y: float, w: float, h: float, label: str, value: Any = "", max_lines: int | None = None) -> None:
    c.setStrokeColor(colors.black)
    c.setLineWidth(0.8)
    c.rect(x, y - h, w, h, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 6.5)
    c.setFillColor(colors.black)
    label_text = label.upper()
    if c.stringWidth(label_text, "Helvetica-Bold", 6.5) <= w - 6:
        c.drawString(x + 3, y - 8, label_text)
        value_y = y - 18
    else:
        value_y = sf1449_draw_wrapped(c, label_text, x + 3, y - 8, w - 6, font="Helvetica-Bold", size=6.1, leading=6.6, max_lines=2) - 1
    if str(value).strip():
        sf1449_draw_wrapped(c, value, x + 3, value_y, w - 6, size=7.2, leading=8.2, max_lines=max_lines)


def sf1449_draw_table(
    c: Any,
    x: float,
    y: float,
    widths: list[float],
    rows: list[list[Any]],
    row_heights: list[float],
    header_rows: int = 1,
    right_align_cols: set[int] | None = None,
) -> float:
    right_align_cols = right_align_cols or set()
    for row_idx, row in enumerate(rows):
        h = row_heights[row_idx]
        cursor = x
        for col_idx, width in enumerate(widths):
            c.setStrokeColor(colors.black)
            c.setLineWidth(0.8)
            c.rect(cursor, y - h, width, h, stroke=1, fill=0)
            value = row[col_idx] if col_idx < len(row) else ""
            font = "Helvetica-Bold" if row_idx < header_rows else "Helvetica"
            size = 6.7 if row_idx < header_rows else 7.4
            if row_idx < header_rows:
                c.setFont(font, size)
                c.drawCentredString(cursor + width / 2, y - 12, str(value).upper())
            elif col_idx in right_align_cols:
                c.setFont(font, size)
                c.drawRightString(cursor + width - 4, y - 12, str(value))
            else:
                sf1449_draw_wrapped(c, value, cursor + 4, y - 12, width - 8, font=font, size=size, leading=size + 2, max_lines=max(1, int((h - 5) // (size + 2))))
            cursor += width
        y -= h
    return y


def sf1449_section_heading(c: Any, title: str, y: float) -> float:
    c.setFont("Helvetica-Bold", 11)
    c.setFillColor(colors.black)
    c.drawString(25, y, title.upper())
    c.line(25, y - 5, 587, y - 5)
    return y - 18


def sf1449_draw_paragraphs(c: Any, paragraphs: list[str], y: float, size: float = 8.2) -> float:
    for paragraph in paragraphs:
        y = sf1449_draw_wrapped(c, paragraph, 25, y, 562, size=size, leading=size + 3)
        y -= 7
    return y


def sf1449_draw_header(c: Any, s: Scenario, title: str, page: int, total_pages: int) -> float:
    sf1449_draw_training_marks(c, page, total_pages, continuation=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(25, 750, title.upper())
    c.setFont("Helvetica", 8.2)
    header_contract = f"{call_or_order_label(s).upper()} {s.contract_number}" if is_ordering_action(s) else f"CONTRACT {s.contract_number}"
    c.drawString(25, 738, header_contract)
    c.setFont("Helvetica", 8)
    c.drawRightString(587, 752, f"Solicitation: {s.solicitation_number}")
    contractor_label = master_awardee_summary(s) if is_multiple_award_master(s) else s.winner["name"]
    c.drawRightString(587, 740, f"Parent: {parent_reference_label(s)}" if is_ordering_action(s) else f"Contractor: {contractor_label}")
    c.drawRightString(587, 728, f"Page {page} of {total_pages}")
    c.setLineWidth(0.8)
    c.line(25, 716, 587, 716)
    return 695


def award_co_signature_value(s: Scenario) -> str:
    return "" if s.archetype.get("_inject_unsigned_award") else "//SIGNED//"


def award_co_sign_date_value(s: Scenario) -> str:
    return "" if s.archetype.get("_inject_unsigned_award") else fmt_sf1449_date(s.timeline["award"])


def award_vendor_code(s: Scenario) -> str:
    return str(s.archetype.get("_inject_award_vendor_code") or s.winner["code"])


def sf1449_face_contract_label(s: Scenario) -> str:
    if s.category == "bpa_call":
        return "2. BPA Number"
    if s.category == "idiq_order":
        return "2. Contract Number"
    return "2. Contract Number"


def sf1449_face_contract_value(s: Scenario) -> str:
    return s.parent_contract_number if is_ordering_action(s) else s.contract_number


def sf1449_face_order_label(s: Scenario) -> str:
    if s.category == "bpa_call":
        return "4. Call Number"
    if s.category == "idiq_order":
        return "4. Order Number"
    return "4. Order Number"


def sf1449_face_order_value(s: Scenario) -> str:
    return s.contract_number if is_ordering_action(s) else ""


def sf1449_draw_cover(c: Any, s: Scenario, data: dict[str, Any], total_pages: int) -> None:
    office = data["contracting_office"]
    payment = office["payment_office"]
    x = 25
    y = 760
    w = 562
    sf1449_draw_training_marks(c, 1, total_pages, continuation=False)

    title_w, req_w, page_w = 350, 140, 72
    c.rect(x, y - 42, title_w, 42, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 10.5)
    c.drawCentredString(x + title_w / 2, y - 13, "SOLICITATION/CONTRACT/ORDER FOR COMMERCIAL PRODUCTS")
    c.drawCentredString(x + title_w / 2, y - 25, "AND COMMERCIAL SERVICES")
    c.setFont("Helvetica-Bold", 5.5)
    c.drawCentredString(x + title_w / 2, y - 36, "OFFEROR TO COMPLETE BLOCKS 12, 17, 23, 24, AND 30 AS APPLICABLE.")
    sf1449_draw_cell(c, x + title_w, y, req_w, 42, "1. Requisition Number", funding_reference_label(s))
    sf1449_draw_cell(c, x + title_w + req_w, y, page_w, 42, "Page 1 of", str(total_pages))
    y -= 42

    widths = [110, 130, 95, 135, 92]
    labels = [sf1449_face_contract_label(s), "3. Award/Effective Date", sf1449_face_order_label(s), "5. Solicitation Number", "6. Solicitation Issue Date"]
    values = [sf1449_face_contract_value(s), fmt_sf1449_date(s.timeline["award"]), sf1449_face_order_value(s), s.solicitation_number, fmt_sf1449_date(s.timeline["solicitation"])]
    cursor = x
    for width, label, value in zip(widths, labels, values):
        sf1449_draw_cell(c, cursor, y, width, 38, label, value)
        cursor += width
    y -= 38

    sf1449_draw_cell(c, x, y, 190, 36, "7. For Solicitation Information Call", f"a. Name: {s.co['name']}\nb. Telephone Number: {s.co['phone']}")
    sf1449_draw_cell(c, x + 190, y, 220, 36, "8. Offer Due Date / Local Time", f"{fmt_sf1449_date(s.timeline['quotes_due'])} 12:00 PM ET")
    sf1449_draw_cell(c, x + 410, y, 152, 36, "14. Method of Solicitation", "[ ] IFB   [ ] RFP   [X] RFQ")
    y -= 36

    admin_office = f"{office['piid_activity']}\n{office['office_name']}\n{office['office_address']}"
    sf1449_draw_cell(c, x, y, 150, 58, "9. Issued By Code " + office["piid_activity"], admin_office, max_lines=5)
    acquisition_text = f"[X] Unrestricted   [ ] Set aside:\nNAICS: {sf1449_naics(s)}\nSize Standard: N/A"
    if is_ordering_action(s):
        acquisition_text += f"\nIssued under {parent_reference_label(s)}"
    sf1449_draw_cell(c, x + 150, y, 273, 58, "10. This Acquisition Is", acquisition_text, max_lines=4)
    sf1449_draw_cell(c, x + 423, y, 139, 58, "11. Delivery for FOB Destination Unless Block Is Marked", "[ ] See Schedule\n13a. DPAS Rated Order\n[ ] Yes    13b. Rating:")
    y -= 58

    sf1449_draw_cell(c, x, y, 170, 54, "12. Discount Terms", "Net 30")
    sf1449_draw_cell(c, x + 170, y, 180, 54, "15. Deliver To Code F2D3JC", f"{s.customer['display_name']}\n{s.delivery_address}", max_lines=4)
    sf1449_draw_cell(c, x + 350, y, 212, 54, "16. Administered By Code " + office["piid_activity"], admin_office, max_lines=4)
    y -= 54

    if is_multiple_award_master(s):
        contractor_block = f"{master_awardee_summary(s)}\nSee Section H awardee roster for contractor names, identifiers, and evaluated prices.\nIndividual task orders identify the awardee selected for that order."
        contractor_code = "MULTIPLE"
    else:
        contractor_block = f"{s.winner['name']}\n{s.winner['address']}\nTelephone Number: {s.winner.get('phone', 'DSN 318-555-02XX')}\n[ ] 17b. Check if remittance is different and put such address in offer"
        contractor_code = award_vendor_code(s)
    payment_block = f"{payment['name']}\n{payment.get('address', payment['name'])}\n[ ] 18b. Submit invoices to address shown unless checked: See addendum"
    sf1449_draw_cell(c, x, y, 337, 72, "17a. Contractor / Offeror Code " + contractor_code + " Facility Code", contractor_block, max_lines=6)
    sf1449_draw_cell(c, x + 337, y, 225, 72, "18a. Payment Will Be Made By Code " + payment["code"], payment_block, max_lines=5)
    y -= 72

    schedule_widths = [74, 268, 57, 50, 58, 55]
    header_h, body_h, helper_h = 26, 226, 11
    sf1449_draw_table(c, x, y, schedule_widths, [["19. Item Number", "20. Schedule of Supplies/Services", "21. Quantity", "22. Unit", "23. Unit Price", "24. Amount"]], [header_h], header_rows=1)
    body_top = y - header_h
    cursor = x
    for width in schedule_widths:
        c.rect(cursor, body_top - body_h, width, body_h, stroke=1, fill=0)
        cursor += width
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(x + schedule_widths[0] + schedule_widths[1] / 2, body_top - body_h / 2, "SEE CONTINUATION")
    c.rect(x, body_top - body_h - helper_h, w, helper_h, stroke=1, fill=0)
    c.setFont("Helvetica", 5.5)
    c.drawCentredString(x + w / 2, body_top - body_h - 8, "(Use Reverse and/or Attach Additional Sheets as Necessary)")
    y = body_top - body_h - helper_h

    sf1449_draw_cell(c, x, y, 430, 38, "25. Accounting and Appropriation Data", "SEE CONTINUATION")
    block26_value = "SEE SECTION B - MIN/MAX" if is_master_vehicle(s) else money(line_item_total(s.line_items))
    sf1449_draw_cell(c, x + 430, y, 132, 38, "26. Total Award Amount (For Government Use Only)", block26_value)
    y -= 38
    if is_construction_requirement(s):
        block27_label = "27a/27b. Solicitation/Contract Incorporates Commercial Construction Clauses"
        block27_text = "[X] FAR 52.212-series provisions/clauses are incorporated as applicable.   [X] Construction/site-work addenda and clauses are attached."
    else:
        block27_label = "27a/27b. Solicitation/Contract Incorporates Commercial Item Clauses"
        block27_text = "[X] FAR 52.212-4 and FAR 52.212-1 are incorporated as applicable.   [X] Addenda are attached."
    sf1449_draw_cell(c, x, y, w, 25, block27_label, block27_text)
    y -= 25

    accepted_items = "ALL CLINS" if len(s.line_items) > 1 else s.line_items[0]["clin"]
    award_text = f"Reference offer dated {fmt_sf1449_date(s.timeline['quotes_due'])}. Your offer on solicitation {s.solicitation_number}, including any additions or changes set forth herein, is accepted as to items: {accepted_items}."
    if is_ordering_action(s):
        award_text = f"{call_or_order_label(s)} {s.contract_number} is issued under {parent_reference_label(s)}. " + award_text
    if is_multiple_award_master(s):
        award_text = f"Multiple awards are established under solicitation {s.solicitation_number}. See Section H for the awardee roster. Future task orders will identify the selected awardee, scope, funding, and price."
    sf1449_draw_cell(c, x, y, 280, 40, "28. Contractor Is Required To Sign This Document And Return Copies", "Contractor agrees to furnish and deliver all items set forth or otherwise identified above and on any continuation sheets subject to the terms and conditions specified herein.", max_lines=3)
    sf1449_draw_cell(c, x + 280, y, 282, 40, "29. Award of Contract", award_text, max_lines=4)
    y -= 40

    sf1449_draw_cell(c, x, y, 281, 28, "30a. Signature of Offeror/Contractor", "//SIGNED//")
    sf1449_draw_cell(c, x + 281, y, 281, 28, "31a. United States of America (Signature of Contracting Officer)", award_co_signature_value(s))
    y -= 28
    sf1449_draw_cell(c, x, y, 210, 27, "30b. Name and Title of Signer", "See awardee roster" if is_multiple_award_master(s) else s.winner["signer"], max_lines=2)
    sf1449_draw_cell(c, x + 210, y, 71, 27, "30c. Date Signed", fmt_sf1449_date(s.timeline["award"]))
    sf1449_draw_cell(c, x + 281, y, 210, 27, "31b. Name of Contracting Officer", s.co["name"])
    sf1449_draw_cell(c, x + 491, y, 71, 27, "31c. Date Signed", award_co_sign_date_value(s))

    c.setFont("Helvetica", 5.8)
    c.drawString(x, 35, "AUTHORIZED FOR LOCAL REPRODUCTION - PREVIOUS EDITION IS NOT USABLE")
    c.setFont("Helvetica-Bold", 6.2)
    c.drawRightString(x + w, 35, "STANDARD FORM 1449 (REV. 11/20XX)")


def award_packet_file_name(s: Scenario) -> str:
    if s.archetype.get("_multiple_award_source_contract") and s.category in {"bpa", "idiq"}:
        label = truncate_filename(str(s.winner.get("name") or "Awardee"), 22, "Awardee")
        return compact_doc_name_for_number(s.contract_number, label)
    return compact_doc_name(s, "Award")


def sf1449_render_award_packet(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    path = folder / award_packet_file_name(s)
    path.parent.mkdir(parents=True, exist_ok=True)
    total_pages = sf1449_total_pages()
    c = pdf_canvas.Canvas(str(path), pagesize=letter)

    sf1449_draw_cover(c, s, data, total_pages)
    c.showPage()

    y = sf1449_draw_header(c, s, "Continuation Sheet - Table of Contents", 2, total_pages)
    y = sf1449_section_heading(c, "Uniform Contract Format", y)
    toc_rows = [
        ["Section", "Title", "Use in This Package"],
        ["A", "Solicitation/Contract Form", "SF 1449 cover page"],
        ["B", "Supplies or Services and Prices/Costs", "CLIN schedule and pricing"],
        ["C", "Description/Specifications/Work Statement", "Statement of work or PWS narrative"],
        ["D", "Packaging and Marking", "Delivery packaging and marking instructions"],
        ["E", "Inspection and Acceptance", "Inspection, acceptance, and QA terms"],
        ["F", "Deliveries or Performance", "Period, place, and schedule of performance"],
        ["G", "Contract Administration Data", "Payment, COR, invoicing, and administration"],
        ["H", "Special Contract Requirements", "Special terms not covered elsewhere"],
        ["I", "Contract Clauses", "FAR and supplemental clauses"],
        ["J", "List of Attachments", "Attachments and exhibits"],
    ]
    y = sf1449_draw_table(c, 25, y, [68, 250, 244], toc_rows, [16] + [18] * 10, header_rows=1)
    y -= 25
    y = sf1449_section_heading(c, "Document Control", y)
    sf1449_draw_table(
        c,
        25,
        y,
        [140, 140, 140, 142],
        [
            ["Instrument", "Contract", "Profile", category_label(s)],
            ["Solicitation", s.solicitation_number, "Contract", s.contract_number],
            *([["Parent Instrument", parent_reference_label(s), call_or_order_label(s), s.contract_number]] if is_ordering_action(s) else []),
            ["Issued By", data["contracting_office"]["piid_activity"], "Contractor", master_awardee_summary(s) if is_multiple_award_master(s) else s.winner["name"]],
        ],
        [18] * (3 + (1 if is_ordering_action(s) else 0)),
        header_rows=0,
    )
    c.showPage()

    y = sf1449_draw_header(c, s, "Section B - Supplies or Services", 3, total_pages)
    y = sf1449_section_heading(c, "Section B - Supplies or Services and Prices/Costs", y)
    section_b_paragraphs = ["This section continues SF 1449 Blocks 19 through 24. The CLIN schedule below controls the item numbers, supplies or services, quantities, units, unit prices, and amounts."]
    if is_ordering_action(s):
        section_b_paragraphs.append(ordering_relationship_sentence(s))
    if s.category == "idiq":
        if is_construction_requirement(s) and not price_list_has_vehicle_classes(s):
            section_b_paragraphs = [
                "The CLIN schedule below establishes broad construction ordering categories for the MACC/IDIQ master. Estimated order counts are for planning and evaluation context only; they are not delivery requirements.",
                "The master contract does not establish a standard construction price list. Each funded task order will include a project-specific scope, drawings or sketches when needed, schedule, location, funding, and task-order price.",
                "For multiple-award MACC orders, the Contracting Officer will provide fair opportunity to all eligible awardees unless a documented exception applies.",
            ]
        else:
            section_b_paragraphs = [
                "The CLIN schedule below establishes unit-priced ordering categories for the IDIQ master. Quantities shown are Government estimates for evaluation purposes only and are not delivery requirements.",
                f"Individual task or delivery orders will identify actual quantities, period, delivery location, and funding. Unit prices are contained in the attached {price_list_attachment_title(s)}." if has_price_list(s) else "Individual task or delivery orders will identify actual quantities, period, delivery location, and funding.",
            ]
    y = sf1449_draw_paragraphs(c, section_b_paragraphs, y)
    if s.category == "idiq":
        price_rows = master_price_list(s) or [
            {
                "clin": item["clin"],
                "description": item["description"],
                "unit": item["unit"],
                "unit_price": float(item["unit_price"]),
            }
            for item in s.line_items
        ]
        construction_master = is_construction_requirement(s) and not price_list_has_vehicle_classes(s)
        clin_rows = [["CLIN", "Ordering Category" if construction_master else "Description", "Unit", "Pricing Method" if construction_master else "Unit Price", "Est Orders" if construction_master else "Est Qty"]]
        est_rng = random.Random(f"{s.contract_number}|idiq_est_qty")
        for row in price_rows:
            unit_price = float(row.get("unit_price") or 0)
            clin_rows.append(
                [
                    str(row.get("clin", "")),
                    str(row.get("vehicle_class") or row.get("description", "")),
                    str(row.get("unit", "")),
                    "Competed per task order" if construction_master else (money(unit_price) if unit_price > 0 else "At cost"),
                    str(est_rng.randint(2, 60)),
                ]
            )
        y = sf1449_draw_table(c, 25, y, [50, 282, 72, 98, 60], clin_rows, [17] + [30] * (len(clin_rows) - 1), header_rows=1, right_align_cols={3, 4})
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(25, y - 18, f"IDIQ Ceiling (Maximum): {money(idiq_ceiling_value(s))}")
        c.drawString(25, y - 30, f"Guaranteed Minimum: {money(idiq_minimum_value(s))}")
        y -= 54
    else:
        clin_rows = [["CLIN", "Description", "Qty", "Unit", "Unit Price", "Amount"]]
        for item in s.line_items:
            clin_rows.append([item["clin"], item["description"], item["quantity"], item["unit"], money(item["unit_price"]), money(item["amount"])])
        y = sf1449_draw_table(c, 25, y, [68, 225, 56, 56, 80, 77], clin_rows, [17] + [33] * len(s.line_items), header_rows=1, right_align_cols={4, 5})
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(25, y - 18, f"Total Evaluated / Award Amount: {money(line_item_total(s.line_items))}")
        y -= 42
    if s.category == "idiq" and is_construction_requirement(s) and not price_list_has_vehicle_classes(s):
        sf1449_draw_paragraphs(c, ["Task order prices will be established in the task order award and will include all labor, materials, equipment, supervision, overhead, general and administrative expense, profit, bonds when required, and project-specific requirements unless otherwise stated."], y)
    else:
        sf1449_draw_paragraphs(c, ["Prices include all labor, materials, overhead, general and administrative expense, and profit unless otherwise stated in the schedule."], y)
    c.showPage()

    y = sf1449_draw_header(c, s, "Sections C and D", 4, total_pages)
    y = sf1449_section_heading(c, "Section C - Description / Specifications / Work Statement", y)
    y = sf1449_draw_paragraphs(
        c,
        [
            f"C.1 Scope. The Contractor shall provide {s.archetype['requirement']} in accordance with its quote submitted in response to solicitation number {s.solicitation_number}.",
            *([f"C.1.1 Ordering Vehicle. {ordering_relationship_sentence(s)} The order/call incorporates the parent instrument terms to the extent they apply to this requirement."] if is_ordering_action(s) else []),
            *[f"C.1.{idx + 1} Required Characteristic. {item}." for idx, item in enumerate(profile_characteristics(s), start=1)],
            "C.2 Requirements. Specific tasks, deliverables, performance standards, quantities, and other requirements are contained in the Contractor's quote and any attachments incorporated into this contract.",
            "C.3 Order of Precedence. In the event of conflict, the terms and conditions of this contract take precedence over the quote unless otherwise stated in writing by the Contracting Officer.",
        ],
        y,
    )
    y = sf1449_section_heading(c, "Section D - Packaging and Marking", y)
    packaging = "Services and deliverables shall be documented electronically unless otherwise directed by the Contracting Officer." if is_service_requirement(s) else "Supplies shall be packaged, protected, and marked for FOB destination delivery to the Government location shown in this contract."
    sf1449_draw_paragraphs(
        c,
        [
            f"D.1 Packaging. {packaging}",
            "D.2 Marking. Each deliverable, shipment, packing slip, and invoice shall identify the contract number, CLIN, deliverable title, and date of submission or delivery.",
        ],
        y,
    )
    c.showPage()

    y = sf1449_draw_header(c, s, "Sections E and F", 5, total_pages)
    y = sf1449_section_heading(c, "Section E - Inspection and Acceptance", y)
    inspection = "Services and deliverables will be inspected by the Contracting Officer's Representative for conformance with Section C." if is_service_requirement(s) else "Supplies will be inspected by the requiring activity at destination for quantity, condition, and conformance with Section C."
    y = sf1449_draw_paragraphs(
        c,
        [
            f"E.1 Inspection. {inspection}",
            "E.2 Acceptance. Acceptance occurs upon written confirmation by the Government or ten business days after receipt absent written rejection.",
            *[f"E.2.{idx} Acceptance Criterion. {item}." for idx, item in enumerate(profile_acceptance_criteria(s), start=1)],
        ],
        y,
    )
    y = sf1449_section_heading(c, "Section F - Deliveries or Performance", y)
    y = sf1449_draw_paragraphs(
        c,
        [
            f"F.1 Period of Performance. {performance_period_label(s)}.",
            f"F.2 Place of Performance. Performance or delivery will occur at {s.delivery_address.replace(chr(10), ', ')}.",
            "F.3 Schedule. The Contractor shall coordinate access, delivery notices, and performance sequencing with the Government point of contact identified in the contract file.",
        ],
        y,
    )
    c.showPage()

    y = sf1449_draw_header(c, s, "Sections G and H", 6, total_pages)
    y = sf1449_section_heading(c, "Section G - Contract Administration Data", y)
    y = sf1449_draw_paragraphs(
        c,
        [
            "G.1 Contracting Officer. Only the Contracting Officer may change the terms and conditions of this contract.",
            "G.2 COR. A Contracting Officer's Representative may be designated in writing after award.",
            "G.3 Invoices. Invoices shall reference the contract number, CLIN, period of performance or delivery date, and amount billed.",
            *([f"G.4 Parent Instrument. Invoices and receiving reports shall reference both {s.contract_number} and parent {parent_reference_label(s)} when required by payment office routing."] if is_ordering_action(s) else []),
        ],
        y,
    )
    y = sf1449_section_heading(c, "Continuation of SF 1449 Blocks 25 and 26", y)
    y = sf1449_draw_table(
        c,
        25,
        y,
        [170, 392],
        [
            ["Accounting and Appropriation Data", s.accounting_data],
            ["Total Award Amount", "SEE SECTION B - MIN/MAX" if is_master_vehicle(s) else money(line_item_total(s.line_items))],
            ["Payment Office", f"{data['contracting_office']['payment_office']['name']}\n{data['contracting_office']['payment_office'].get('address', data['contracting_office']['payment_office']['name'])}"],
        ],
        [32, 20, 28],
        header_rows=0,
    )
    y -= 25
    y = sf1449_section_heading(c, "Section H - Special Contract Requirements", y)
    section_h_paragraphs = [
        "H.1 Key Personnel. The Contractor shall provide sufficient management and supervision to coordinate performance with the Government.",
        "H.2 Organizational Conflict of Interest. The Contractor shall disclose any actual or potential OCI that may affect impartial performance.",
        "H.3 Training Data. Exercise data and artifacts are for instructional use only and shall not be represented as official procurement actions.",
    ]
    if has_macc_ordering_procedures(s):
        section_h_paragraphs.extend(
            [
                "H.4 Fair Opportunity. The Contracting Officer will provide each eligible MACC awardee a fair opportunity to be considered for each task order unless an authorized exception is documented in the task order file.",
                "H.5 Task Order RFPs. Each task order request will identify the project-specific SOW, drawings or sketches when applicable, site constraints, schedule, evaluation approach, funding, and proposal due date.",
                "H.6 Task Order Pricing. The MACC master does not use a standard construction price list. Price reasonableness and best value are documented at the task order level based on the competed responses or approved exception.",
            ]
        )
    y = sf1449_draw_paragraphs(c, section_h_paragraphs, y)
    if is_multiple_award_master(s):
        awardee_rows = master_awardee_rows(s)
        roster_heading = "H.7 Multiple Awardee Roster" if has_macc_ordering_procedures(s) else "H.4 Multiple Awardee Roster"
        y = sf1449_section_heading(c, roster_heading, y)
        y = sf1449_draw_table(
            c,
            25,
            y,
            [82, 146, 82, 86, 68, 98],
            awardee_rows,
            [16] + [24] * (len(awardee_rows) - 1),
            header_rows=1,
            right_align_cols={3},
        )
        sf1449_draw_paragraphs(
            c,
            [
                "Task orders will be competed among eligible MACC awardees using the fair-opportunity procedures unless a documented exception applies. Each task order will identify the selected awardee, project scope, funding citation, performance location, schedule, and order price. The master IDIQ does not authorize performance or payment by itself. The guaranteed minimum is tracked in the funding folder and must be satisfied through funded orders under the vehicle."
                if has_macc_ordering_procedures(s)
                else "Task orders will identify the selected awardee, task-order scope, funding citation, performance location, schedule, and order price. The master IDIQ does not authorize performance or payment by itself. The guaranteed minimum is tracked in the funding folder and must be satisfied through funded orders under the vehicle.",
            ],
            y - 10,
            size=7.8,
        )
    c.showPage()

    y = sf1449_draw_header(c, s, "Section I - Contract Clauses", 7, total_pages)
    y = sf1449_section_heading(c, "Section I - Contract Clauses", y)
    clause_rows = [["Clause", "Title", "Date", "Method"]]
    clause_rows.extend([[entry["clause"], entry["title"], entry["date"], entry["method"]] for entry in sf1449_clause_entries(s)])
    y = sf1449_draw_table(c, 25, y, [100, 282, 78, 102], clause_rows, [18] + [18] * (len(clause_rows) - 1), header_rows=1)
    y -= 28
    if is_construction_requirement(s):
        addendum_heading = "Commercial Construction / Site-Work Addendum"
        addendum_paragraph = (
            "The clauses listed above are incorporated by reference or set forth in full text. "
            "FAR 52.212-series commercial terms are used with construction/site-work addenda, ordering limitations, "
            "site coordination, safety, inspection, and change-control requirements stated in the applicable UCF sections."
        )
    else:
        addendum_heading = "Commercial Addendum"
        addendum_paragraph = "The clauses listed above are incorporated by reference or set forth in full text. Fill-ins, ordering limitations, option notice periods, and other addenda are stated in the applicable UCF sections."
    y = sf1449_section_heading(c, addendum_heading, y)
    sf1449_draw_paragraphs(c, [addendum_paragraph], y)
    c.showPage()

    full_text_pages = sf1449_full_text_blocks(s)
    for offset, blocks in enumerate(full_text_pages, start=8):
        title = "Section I - Full Text Clauses" if offset == 8 else "Section I - Full Text Clauses Continued"
        y = sf1449_draw_header(c, s, title, offset, total_pages)
        y = sf1449_section_heading(c, title, y)
        for clause_title, paragraphs in blocks:
            c.setFont("Helvetica-Bold", 8.5)
            c.drawString(25, y, clause_title.upper())
            y -= 13
            for idx, paragraph in enumerate(paragraphs):
                prefix = f"({chr(97 + idx)}) "
                y = sf1449_draw_wrapped(c, prefix + paragraph, 25, y, 562, size=7.8, leading=10)
                y -= 7
            y -= 2
        c.showPage()

    y = sf1449_draw_header(c, s, "Section J - Attachments", 11, total_pages)
    y = sf1449_section_heading(c, "Section J - List of Attachments", y)
    attachment_rows = sf1449_attachment_rows(s)
    if len(attachment_rows) > 1:
        sf1449_draw_table(c, 25, y, [90, 472], attachment_rows, [18] + [22] * (len(attachment_rows) - 1), header_rows=1)
    else:
        sf1449_draw_paragraphs(c, ["No attachments are included."], y)
    c.save()


def sf1449_write_award(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    if is_multiple_award_master(s):
        for awardee in master_awardees(s):
            sf1449_render_award_packet(folder, scenario_for_master_awardee(s, awardee), data)
        write_multiple_award_roster_pdf(folder, s)
        return
    sf1449_render_award_packet(folder, s, data)


def write_multiple_award_roster_pdf(folder: Path, s: Scenario) -> None:
    vehicle_label = master_vehicle_label(s.category)
    write_pdf(
        folder / compact_doc_name(s, "Awardee Roster"),
        f"Multiple Award {vehicle_label} Awardee Roster",
        f"{s.solicitation_number} | {s.archetype['title']}",
        [
            {
                "heading": "Awardee Contracts",
                "paragraphs": [
                    f"This roster summarizes the individual {vehicle_label} instruments awarded from the same solicitation. Each awardee has its own contract PIID and award form; future calls or task orders should cite the selected awardee's parent instrument number.",
                ],
                "table": master_awardee_rows(s),
                "widths": [0.85 * inch, 1.45 * inch, 0.95 * inch, 0.95 * inch, 0.75 * inch, 1.20 * inch],
            },
            {
                "heading": "Ordering Note",
                "paragraphs": [
                    f"The solicitation and evaluation file are shared for the multiple-award pool. Funding, actual scope, and order price are established on individual calls or task orders, not on the master {vehicle_label} awards. For IDIQs, the stated minimum guarantee is tracked in the funding folder and satisfied through funded orders under the vehicle.",
                ],
            },
        ],
    )


def sf1442_total_pages() -> int:
    return 18


def sf1442_project_number(s: Scenario) -> str:
    return f"VGLZ {GENERIC_YEAR}-{s.index:03d}"


def sf1442_completion_days(s: Scenario) -> int:
    if s.base_amount >= 1_000_000:
        return 240
    if s.base_amount >= 500_000:
        return 180
    return 120


def sf1442_clause_entries() -> list[dict[str, str]]:
    clauses = [
        ("52.204-7", "System for Award Management", "OCT 20XX", "Reference"),
        ("52.204-13", "System for Award Management Maintenance", "OCT 20XX", "Reference"),
        ("52.204-21", "Basic Safeguarding of Covered Contractor Information Systems", "NOV 20XX", "Reference"),
        ("52.212-1", "Instructions to Offerors - Commercial Products and Commercial Services", "SEP 20XX", "Reference"),
        ("52.212-4", "Contract Terms and Conditions - Commercial Products and Commercial Services", "NOV 20XX", "Reference"),
        ("52.236-1", "Performance of Work by the Contractor", "APR 20XX", "Reference"),
        ("52.236-2", "Differing Site Conditions", "APR 20XX", "Reference"),
        ("52.236-3", "Site Investigation and Conditions Affecting the Work", "APR 20XX", "Reference"),
        ("52.236-4", "Physical Data", "APR 20XX", "Reference"),
        ("52.236-5", "Material and Workmanship", "APR 20XX", "Reference"),
        ("52.236-6", "Superintendence by the Contractor", "APR 20XX", "Reference"),
        ("52.236-7", "Permits and Responsibilities", "NOV 20XX", "Reference"),
        ("52.236-8", "Other Contracts", "APR 20XX", "Reference"),
        ("52.236-9", "Protection of Existing Vegetation, Structures, Equipment, Utilities, and Improvements", "APR 20XX", "Reference"),
        ("52.236-10", "Operations and Storage Areas", "APR 20XX", "Reference"),
        ("52.236-11", "Use and Possession Prior to Completion", "APR 20XX", "Reference"),
        ("52.236-12", "Cleaning Up", "APR 20XX", "Reference"),
        ("52.236-13", "Accident Prevention", "NOV 20XX", "Reference"),
        ("52.236-14", "Availability and Use of Utility Services", "APR 20XX", "Reference"),
        ("52.236-15", "Schedules for Construction Contracts", "APR 20XX", "Reference"),
        ("52.236-16", "Quantity Surveys", "APR 20XX", "Reference"),
        ("52.236-17", "Layout of Work", "APR 20XX", "Reference"),
        ("52.236-19", "Organization and Direction of the Work", "APR 20XX", "Reference"),
        ("52.236-21", "Specifications and Drawings for Construction", "FEB 20XX", "Reference"),
        ("52.236-22", "Design Within Funding Limitations", "APR 20XX", "Reference"),
        ("52.236-23", "Responsibility of the Architect-Engineer Contractor", "APR 20XX", "Reference"),
        ("52.236-24", "Work Oversight in Architect-Engineer Contracts", "APR 20XX", "Reference"),
        ("52.236-25", "Requirements for Registration of Designers", "JUN 20XX", "Reference"),
        ("52.236-26", "Preconstruction Conference", "FEB 20XX", "Reference"),
        ("52.236-27", "Site Visit (Construction)", "FEB 20XX", "Reference"),
        ("52.236-28", "Preparation of Proposals - Construction", "OCT 20XX", "Reference"),
        ("52.228-15", "Performance and Payment Bonds - Construction", "JUN 20XX", "Reference"),
        ("52.243-4", "Changes", "JUN 20XX", "Full text"),
        ("52.246-12", "Inspection of Construction", "AUG 20XX", "Reference"),
        ("52.232-33", "Payment by Electronic Funds Transfer - System for Award Management", "OCT 20XX", "Reference"),
        ("252.232-7003", "Electronic Submission of Payment Requests and Receiving Reports", "DEC 20XX", "Reference"),
        ("252.232-7006", "Wide Area WorkFlow Payment Instructions", "JAN 20XX", "Reference"),
    ]
    return [{"clause": clause, "title": title, "date": date_text, "method": method} for clause, title, date_text, method in clauses]


def sf1442_full_text_pages() -> list[list[tuple[str, list[str]]]]:
    blocks: list[tuple[str, list[str]]] = []
    for entry in sf1442_clause_entries():
        title = f"{entry['clause']} {entry['title']} ({entry['date']})"
        if entry["clause"] == "52.243-4":
            paragraphs = [
                "The Contracting Officer may make changes within the general scope of the contract by written order.",
                "If any change causes an increase or decrease in the cost of, or time required for, performance, the Contracting Officer shall make an equitable adjustment.",
                "The Contractor shall proceed with the work as changed, except that no change shall be performed without written direction from the Contracting Officer.",
            ]
        elif entry["clause"] == "52.228-15":
            paragraphs = [
                "The Contractor shall furnish performance and payment bonds when required by the award and before starting work.",
                "Bonds shall remain in effect for the period required by the contract and applicable law.",
            ]
        else:
            paragraphs = [
                f"Incorporated by reference. See FAR {entry['clause']}, {entry['title']}. Verify prescription, alternates, and fill-ins against the current FAR before using outside this training simulator."
            ]
        blocks.append((title, paragraphs))
    pages: list[list[tuple[str, list[str]]]] = []
    for idx in range(0, 36, 4):
        pages.append(blocks[idx : idx + 4])
    return pages[:9]


def sf1442_draw_training_marks(c: Any, page: int, total_pages: int, continuation: bool) -> None:
    c.saveState()
    c.setFillColor(colors.HexColor("#F2DADA"))
    c.translate(letter[0] / 2, letter[1] / 2 - 20)
    c.rotate(35)
    c.setFont("Helvetica-Bold", 34)
    c.drawCentredString(0, 0, "EXERCISE DOCUMENT")
    c.restoreState()
    c.saveState()
    c.setFillColor(colors.HexColor("#B00000"))
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(letter[0] / 2, 780, EXERCISE_BANNER)
    c.restoreState()
    if continuation:
        c.setStrokeColor(colors.black)
        c.setLineWidth(0.8)
        c.line(25, 30, 587, 30)
        c.setFont("Helvetica", 7)
        c.setFillColor(colors.black)
        c.drawString(25, 20, "SF 1442 Continuation / Uniform Contract Format")
        c.drawRightString(587, 20, f"Page {page} of {total_pages}")


def sf1442_draw_header(c: Any, s: Scenario, title: str, page: int, total_pages: int) -> float:
    sf1442_draw_training_marks(c, page, total_pages, continuation=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(25, 750, title.upper())
    c.setFont("Helvetica", 8.2)
    c.drawString(25, 738, f"CONTRACT {s.contract_number}")
    c.setFont("Helvetica", 8)
    c.drawRightString(587, 752, f"Solicitation: {s.solicitation_number}")
    c.drawRightString(587, 740, f"Contractor: {s.winner['name']}")
    c.drawRightString(587, 728, f"Page {page} of {total_pages}")
    c.setLineWidth(0.8)
    c.line(25, 716, 587, 716)
    return 695


def sf1442_draw_page_one(c: Any, s: Scenario, data: dict[str, Any], total_pages: int) -> None:
    office = data["contracting_office"]
    x = 25
    y = 760
    w = 562
    sf1442_draw_training_marks(c, 1, total_pages, continuation=False)

    c.rect(x, y - 58, 225, 58, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(x + 112.5, y - 16, "SOLICITATION, OFFER, AND AWARD")
    c.setFont("Helvetica-Bold", 6)
    c.drawCentredString(x + 112.5, y - 31, "(Construction, Alteration, or Repair)")
    sf1449_draw_cell(c, x + 225, y, 125, 58, "1. Solicitation Number", s.solicitation_number)
    sf1449_draw_cell(c, x + 350, y, 130, 58, "2. Type of Solicitation", "[ ] Sealed Bid (IFB)   [ ] Negotiated (RFP)\n[X] RFQ")
    sf1449_draw_cell(c, x + 480, y, 82, 58, "3. Date Issued / Page", f"{fmt_sf1449_date(s.timeline['solicitation'])}\n1 of {total_pages}")
    y -= 58

    sf1449_draw_cell(c, x, y, 205, 32, "4. Contract Number", s.contract_number)
    sf1449_draw_cell(c, x + 205, y, 205, 32, "5. Requisition/Purchase Request Number", s.pr_number)
    sf1449_draw_cell(c, x + 410, y, 152, 32, "6. Project Number", sf1442_project_number(s))
    y -= 32

    office_block = f"{office['piid_activity']}\n{office['office_name']}\n{office['office_address']}"
    sf1449_draw_cell(c, x, y, 281, 58, "7. Issued By Code " + office["piid_activity"], office_block, max_lines=5)
    sf1449_draw_cell(c, x + 281, y, 281, 58, "8. Address Offer To", office_block, max_lines=5)
    y -= 58

    sf1449_draw_cell(c, x, y, 281, 40, "9. For Information Call", f"a. Name: {s.co['name']}\nb. Telephone Number: {s.co['phone']}")
    sf1449_draw_cell(c, x + 281, y, 281, 40, "Solicitation", 'NOTE: In sealed bid solicitations "offer" and "offeror" mean "bid" and "bidder."')
    y -= 40

    sf1449_draw_cell(c, x, y, w, 38, "10. The Government Requires Performance of the Work Described in These Documents", f"Construction, alteration, or repair work at an undisclosed overseas location, including labor, materials, supervision, safety controls, and all work described in the specifications and drawings.", max_lines=3)
    y -= 38

    sf1449_draw_cell(c, x, y, 280, 54, "11. Performance Period", f"The contractor shall begin performance within 10 calendar days after receiving notice to proceed and complete it within {sf1442_completion_days(s)} calendar days after receiving notice to proceed.\n[X] Mandatory   [ ] Negotiable", max_lines=4)
    sf1449_draw_cell(c, x + 280, y, 282, 54, "12a. Performance and Payment Bonds / 12b. Calendar Days", "[X] Yes   [ ] No\n10")
    y -= 54

    due_date = fmt_sf1449_date(s.timeline["quotes_due"])
    sf1449_draw_cell(
        c,
        x,
        y,
        w,
        76,
        "13. Additional Solicitation Requirements",
        (
            f"a. Offers in original and 1 copy to perform the work required are due at the place specified in Item 8 by 2:00 PM ET local on {due_date}.\n"
            "b. An offer guarantee is [ ] required, [X] is not required.\n"
            "c. All offers are subject to the work requirements and other provisions and clauses incorporated in this solicitation.\n"
            "d. Offers providing less than 60 calendar days for Government acceptance will be rejected.\n"
            "e. See continuation pages for Section B prices, Section C specifications/work requirements, Section I clauses, Section J attachments, and completed WAWF payment instructions."
        ),
        max_lines=7,
    )
    y -= 76

    remarks_h = y - 46
    c.rect(x, 46, w, remarks_h, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 7)
    c.drawString(x + 3, y - 9, "CONTINUATION / REMARKS")
    c.setFont("Helvetica", 7)
    remarks = [
        "CONTINUATION OF SOLICITATION REQUIREMENTS:",
        f"The Contractor shall furnish all labor, supervision, management, materials, equipment, tools, transportation, quality control, safety controls, cleanup, coordination, and incidentals necessary to complete {s.archetype['requirement']}.",
        "Offers shall be based on the complete solicitation package, including Section B prices, Section C specifications/work requirements, applicable drawings and technical data, site conditions made available by the Government, clauses, attachments, amendments, and all instructions provided by the Contracting Officer.",
        "Questions, site access, work hours, security requirements, utility outages, submittals, and performance coordination shall be handled through the Contracting Officer or designated Government representative. The Government may issue a written notice to proceed after award when required by the contract.",
    ]
    sf1449_draw_paragraphs(c, remarks, y - 21, size=6.8)
    c.setFont("Helvetica", 5.8)
    c.drawString(x, 35, "IMPORTANT - The offer section on the reverse must be fully completed by offeror.")
    c.setFont("Helvetica-Bold", 6.2)
    c.drawRightString(x + w, 35, "STANDARD FORM 1442 (REV. 12/20XX)")


def sf1442_draw_page_two(c: Any, s: Scenario, data: dict[str, Any], total_pages: int) -> None:
    office = data["contracting_office"]
    payment = office["payment_office"]
    x = 25
    y = 760
    w = 562
    sf1442_draw_training_marks(c, 2, total_pages, continuation=False)

    c.rect(x, y - 30, 330, 30, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(x + 165, y - 18, "OFFER")
    sf1449_draw_cell(c, x + 330, y, 232, 30, "Page", f"2 of {total_pages}")
    y -= 30

    offeror = f"{s.winner['name']}\n{s.winner['address']}\nTelephone Number: {s.winner.get('phone', 'DSN 318-555-02XX')}"
    sf1449_draw_cell(c, x, y, 330, 58, "14. Name and Address of Offeror Code " + award_vendor_code(s) + " Facility Code", offeror, max_lines=5)
    sf1449_draw_cell(c, x + 330, y, 232, 58, "15. Telephone Number / 16. Remittance Address", f"{s.winner.get('phone', 'DSN 318-555-02XX')}\n[ ] Check if remittance address is different")
    y -= 58
    sf1449_draw_cell(c, x, y, w, 34, "17. The Offeror Agrees to Perform the Work Required at the Prices Specified Below", f"See Section B continuation pages for CLIN schedule and prices. Total offer/award amount: {money(line_item_total(s.line_items))}.")
    y -= 34
    sf1449_draw_cell(c, x, y, 375, 34, "18. Accounting and Appropriation Data", "SEE CONTINUATION")
    sf1449_draw_cell(c, x + 375, y, 187, 34, "19. Award Amount", money(line_item_total(s.line_items)))
    y -= 34
    sf1449_draw_cell(c, x, y, 275, 38, "20a. Name and Title of Offeror", s.winner["signer"])
    sf1449_draw_cell(c, x + 275, y, 180, 38, "20b. Signature", "//SIGNED//")
    sf1449_draw_cell(c, x + 455, y, 107, 38, "20c. Offer Date", fmt_sf1449_date(s.timeline["quotes_due"]))
    y -= 38

    c.rect(x, y - 30, w, 30, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(x + w / 2, y - 19, "AWARD")
    y -= 30
    sf1449_draw_cell(c, x, y, 281, 58, "21. Items Accepted", f"ALL CLINS. Reference offer dated {fmt_sf1449_date(s.timeline['quotes_due'])} under solicitation {s.solicitation_number}.")
    office_block = f"{office['piid_activity']}\n{office['office_name']}\n{office['office_address']}"
    sf1449_draw_cell(c, x + 281, y, 281, 58, "22. Administered By Code " + office["piid_activity"], office_block, max_lines=5)
    y -= 58
    sf1449_draw_cell(c, x, y, 281, 40, "23. Payment Will Be Made By Code " + payment["code"], f"{payment['name']}\n{payment.get('address', payment['name'])}")
    sf1449_draw_cell(c, x + 281, y, 281, 40, "24. Submit Invoices to Address Shown in Item 23 Unless Block Is Checked", "[ ] See addendum")
    y -= 40
    sf1449_draw_cell(c, x, y, 275, 38, "25. Name of Contracting Officer", s.co["name"])
    sf1449_draw_cell(c, x + 275, y, 180, 38, "26. United States of America", award_co_signature_value(s))
    sf1449_draw_cell(c, x + 455, y, 107, 38, "27. Award Date", fmt_sf1449_date(s.timeline["award"]))
    y -= 38

    remarks_h = y - 46
    c.rect(x, 46, w, remarks_h, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 7)
    c.drawString(x + 3, y - 9, "CONTINUATION / REMARKS")
    remarks = [
        "CONTINUATION OF AWARD AND ADMINISTRATION:",
        f"This award accepts the item(s) stated in Block 21 and incorporates this SF 1442, the continuation pages, specifications, drawings, attachments, clauses, and the Contractor's accepted offer under solicitation {s.solicitation_number} to the extent not inconsistent with the contract.",
        "The Contractor shall not begin physical work until award requirements are satisfied, including any required notice to proceed, bonds, insurance, access coordination, safety requirements, and initial submittals. Changes to the contract may be made only by written modification signed by the Contracting Officer.",
        "Accounting data, inspection and acceptance, invoicing, WAWF routing, and contract administration instructions are continued in the Uniform Contract Format sections. Invoices and receiving reports shall be submitted in accordance with Section G and applicable DFARS WAWF instructions.",
    ]
    sf1449_draw_paragraphs(c, remarks, y - 22, size=6.8)
    c.setFont("Helvetica", 5.8)
    c.drawString(x, 35, "Prescribed by GSA - FAR (48 CFR) 53.236-1(d)")
    c.setFont("Helvetica-Bold", 6.2)
    c.drawRightString(x + w, 35, "STANDARD FORM 1442 (REV. 12/20XX)")


def sf1442_render_award_packet(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    path = folder / compact_doc_name(s, "Award")
    path.parent.mkdir(parents=True, exist_ok=True)
    total_pages = sf1442_total_pages()
    c = pdf_canvas.Canvas(str(path), pagesize=letter)

    sf1442_draw_page_one(c, s, data, total_pages)
    c.showPage()
    sf1442_draw_page_two(c, s, data, total_pages)
    c.showPage()

    y = sf1442_draw_header(c, s, "Continuation Sheet - Table of Contents", 3, total_pages)
    y = sf1449_section_heading(c, "Uniform Contract Format", y)
    toc_rows = [
        ["Section", "Title", "Use in This Package"],
        ["A", "Solicitation/Contract Form", "SF 1442 pages"],
        ["B", "Construction Work and Prices/Costs", "CLIN schedule and pricing"],
        ["C", "Description/Specifications/Work Statement", "Statement of work narrative"],
        ["D", "Packaging and Marking", "Delivery packaging and marking instructions"],
        ["E", "Inspection and Acceptance", "Inspection, acceptance, and QA terms"],
        ["F", "Deliveries or Performance", "Period, place, and schedule of performance"],
        ["G", "Contract Administration Data", "Payment, COR, invoicing, and administration"],
        ["H", "Special Contract Requirements", "Special terms not covered elsewhere"],
        ["I", "Contract Clauses", "FAR and supplemental clauses"],
        ["J", "List of Attachments", "Attachments and exhibits"],
    ]
    y = sf1449_draw_table(c, 25, y, [68, 250, 244], toc_rows, [16] + [18] * 10, header_rows=1)
    y -= 25
    y = sf1449_section_heading(c, "Document Control", y)
    sf1449_draw_table(c, 25, y, [140, 140, 140, 142], [["Instrument", "Contract", "Profile", "Firm-fixed-price"], ["Solicitation", s.solicitation_number, "Contract", s.contract_number], ["Issued By", data["contracting_office"]["piid_activity"], "Contractor", s.winner["name"]]], [18, 18, 18], header_rows=0)
    c.showPage()

    y = sf1442_draw_header(c, s, "Section B - Construction Work", 4, total_pages)
    y = sf1449_section_heading(c, "Section B - Construction Work and Prices/Costs", y)
    y = sf1449_draw_paragraphs(c, ["This section continues the SF 1442 offer/award price schedule. The CLIN schedule below controls the item numbers, work descriptions, quantities, units, unit prices, and amounts."], y)
    clin_rows = [["CLIN", "Description", "Qty", "Unit", "Unit Price", "Amount"]]
    for item in s.line_items:
        clin_rows.append([item["clin"], item["description"], item["quantity"], item["unit"], money(item["unit_price"]), money(item["amount"])])
    y = sf1449_draw_table(c, 25, y, [68, 225, 56, 56, 80, 77], clin_rows, [17] + [40] * len(s.line_items), header_rows=1, right_align_cols={4, 5})
    c.setFont("Helvetica-Bold", 8.5)
    c.drawString(25, y - 18, f"Total Evaluated / Award Amount: {money(line_item_total(s.line_items))}")
    y -= 42
    sf1449_draw_paragraphs(c, ["Prices include all labor, materials, overhead, general and administrative expense, and profit unless otherwise stated in the schedule."], y)
    c.showPage()

    y = sf1442_draw_header(c, s, "Sections C and D", 5, total_pages)
    y = sf1449_section_heading(c, "Section C - Description / Specifications / Work Statement", y)
    y = sf1449_draw_paragraphs(c, [f"C.1 Scope. The Contractor shall furnish all plant, labor, materials, equipment, supervision, and transportation necessary to perform {s.archetype['requirement']} under solicitation number {s.solicitation_number}.", *[f"C.1.{idx + 1} Required Characteristic. {item}." for idx, item in enumerate(profile_characteristics(s), start=1)], "C.2 Requirements. Specific work requirements, drawings, specifications, quality standards, quantities, and other construction requirements are contained in the contract documents.", "C.3 Order of Precedence. In the event of conflict, the terms and conditions of this contract take precedence over the offer unless otherwise stated in writing by the Contracting Officer."], y)
    y = sf1449_section_heading(c, "Section D - Packaging and Marking", y)
    sf1449_draw_paragraphs(c, ["D.1 Materials. Materials, equipment, and construction submittals shall be marked and delivered as directed by the Contracting Officer.", "D.2 Site Delivery. Contractor deliveries shall be coordinated with the Government before arrival at the work site."], y)
    c.showPage()

    y = sf1442_draw_header(c, s, "Sections E and F", 6, total_pages)
    y = sf1449_section_heading(c, "Section E - Inspection and Acceptance", y)
    y = sf1449_draw_paragraphs(c, ["E.1 Inspection. Work will be inspected by the Government for conformance with the contract drawings, specifications, and clauses.", "E.2 Acceptance. Acceptance occurs upon written confirmation by the Contracting Officer or authorized Government representative.", *[f"E.2.{idx} Acceptance Criterion. {item}." for idx, item in enumerate(profile_acceptance_criteria(s), start=1)]], y)
    y = sf1449_section_heading(c, "Section F - Deliveries or Performance", y)
    sf1449_draw_paragraphs(c, [f"F.1 Period of Performance. The Contractor shall begin performance within 10 calendar days after notice to proceed and complete performance within {sf1442_completion_days(s)} calendar days.", f"F.2 Place of Performance. Performance will occur at {s.delivery_address.replace(chr(10), ', ')}.", "F.3 Notice to Proceed. When required, the Government will issue a written notice to proceed."], y)
    c.showPage()

    y = sf1442_draw_header(c, s, "Sections G and H", 7, total_pages)
    y = sf1449_section_heading(c, "Section G - Contract Administration Data", y)
    y = sf1449_draw_paragraphs(c, ["G.1 Contracting Officer. Only the Contracting Officer may change the terms and conditions of this contract.", "G.2 COR. A Contracting Officer's Representative may be designated in writing after award.", "G.3 Invoices. Invoices shall be submitted through Wide Area WorkFlow and shall reference the contract number, CLIN, period of performance, and amount billed.", f"G.4 WAWF Instructions.\nDFARS 252.232-7006 WAWF payment instructions fill-ins for this training contract:\nDocument type: Construction and Facilities Management Invoice\nPay Official DoDAAC: {data['contracting_office']['payment_office']['code']}\nIssue By DoDAAC: {data['contracting_office']['piid_activity']}\nAdmin DoDAAC: {data['contracting_office']['piid_activity']}\nInspect By DoDAAC: {data['contracting_office']['piid_activity']}\nShip To Code: F2D3JC\nService Acceptor (DoDAAC): F2D3JC\nWAWF point of contact: {s.co['name']}, {s.co['phone']}"], y, size=7.8)
    y = sf1449_section_heading(c, "Continuation of SF 1442 Accounting and Award Amount Blocks", y)
    y = sf1449_draw_table(c, 25, y, [170, 392], [["Accounting and Appropriation Data", s.accounting_data], ["Total Award Amount", money(line_item_total(s.line_items))], ["Payment Office", f"{data['contracting_office']['payment_office']['name']}\n{data['contracting_office']['payment_office'].get('address', data['contracting_office']['payment_office']['name'])}"]], [34, 20, 28], header_rows=0)
    y -= 18
    y = sf1449_section_heading(c, "Section H - Special Contract Requirements", y)
    sf1449_draw_paragraphs(c, ["H.1 Key Personnel. The superintendent and safety representative are considered key personnel. Substitutions require prior written Government approval.", "H.2 Organizational Conflict of Interest. The Contractor shall disclose any actual or potential OCI that may affect impartial performance.", "H.3 Training Data. Exercise data and artifacts are for instructional use only and shall not be represented as official procurement actions."], y, size=7.8)
    c.showPage()

    y = sf1442_draw_header(c, s, "Section I - Contract Clauses", 8, total_pages)
    y = sf1449_section_heading(c, "Section I - Contract Clauses", y)
    clause_rows = [["Clause", "Title", "Date", "Method"]]
    clause_rows.extend([[entry["clause"], entry["title"], entry["date"], entry["method"]] for entry in sf1442_clause_entries()])
    sf1449_draw_table(c, 25, y, [100, 282, 78, 102], clause_rows, [16] + [15] * (len(clause_rows) - 1), header_rows=1)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(25, 95, "COMMERCIAL CONSTRUCTION ADDENDUM")
    c.line(25, 90, 587, 90)
    sf1449_draw_wrapped(c, "The clauses listed above are incorporated by reference or set forth in full text. FAR 52.212-series commercial terms are used with construction/site-work addenda. Fill-ins, bonding requirements, site requirements, safety controls, inspection requirements, and other addenda are stated in the applicable UCF sections.", 25, 78, 562, size=7.8, leading=10)
    c.showPage()

    for page_offset, blocks in enumerate(sf1442_full_text_pages(), start=9):
        title = "Section I - Full Text Clauses" if page_offset == 9 else "Section I - Full Text Clauses Continued"
        y = sf1442_draw_header(c, s, title, page_offset, total_pages)
        y = sf1449_section_heading(c, title, y)
        for clause_title, paragraphs in blocks:
            c.setFont("Helvetica-Bold", 8.5)
            c.drawString(25, y, clause_title.upper())
            y -= 13
            for idx, paragraph in enumerate(paragraphs):
                prefix = f"({chr(97 + idx)}) " if len(paragraphs) > 1 else ""
                y = sf1449_draw_wrapped(c, prefix + paragraph, 25, y, 562, size=7.8, leading=10)
                y -= 7
            y -= 2
        c.showPage()

    y = sf1442_draw_header(c, s, "Section J - Attachments", 18, total_pages)
    y = sf1449_section_heading(c, "Section J - List of Attachments", y)
    attachment_rows = sf1449_attachment_rows(s)
    if len(attachment_rows) > 1:
        sf1449_draw_table(c, 25, y, [90, 472], attachment_rows, [18] + [22] * (len(attachment_rows) - 1), header_rows=1)
    else:
        sf1449_draw_paragraphs(c, ["No attachments are included."], y)
    c.save()


def sf1442_write_award(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    sf1442_render_award_packet(folder, s, data)


def bpa_total_pages() -> int:
    return 3


def bpa_period_label(s: Scenario) -> str:
    if s.archetype.get("_inject_expired_vehicle"):
        return f"10/01/{GENERIC_YEAR_PREV2} through 09/30/{GENERIC_YEAR_PREV}"
    return fmt_period_range(s.timeline["award"], s.timeline["pop_end"], sf_style=True)


def bpa_draw_footer(c: Any, page: int, total_pages: int) -> None:
    c.setStrokeColor(colors.black)
    c.setLineWidth(0.8)
    c.line(25, 30, 587, 30)
    c.setFont("Helvetica", 7)
    c.setFillColor(colors.black)
    c.drawString(25, 20, "Training BPA Package - Not for Award")
    c.drawRightString(587, 20, f"Page {page} of {total_pages}")


def bpa_draw_header(c: Any, s: Scenario, title: str, page: int, total_pages: int, data: dict[str, Any]) -> float:
    sf1449_draw_training_marks(c, page, total_pages, continuation=False)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(25, 750, title.upper())
    c.setFont("Helvetica", 8.2)
    c.drawString(25, 738, f"BPA {s.contract_number}")
    c.setFont("Helvetica", 8)
    c.drawRightString(587, 752, f"Office: {data['contracting_office']['piid_activity']}")
    c.drawRightString(587, 740, f"Contractor: {s.winner['name']}")
    c.drawRightString(587, 728, f"Page {page} of {total_pages}")
    c.setLineWidth(0.8)
    c.line(25, 716, 587, 716)
    bpa_draw_footer(c, page, total_pages)
    return 695


def bpa_clause_rows() -> list[list[str]]:
    return [
        ["Reference", "Title / Use"],
        ["BPA Ordering Procedures", "Authorized callers, call limits, scope control, and limitation of obligation."],
        ["Commercial Acquisition Procedures", "Commercial product and commercial service procedures for the covered supplies or services."],
        ["FAR 52.204-7", "System for Award Management."],
        ["FAR 52.204-13", "System for Award Management Maintenance."],
        ["FAR 52.204-21", "Basic Safeguarding of Covered Contractor Information Systems."],
        ["FAR 52.212-4", "Contract Terms and Conditions - Commercial Products and Commercial Services."],
        ["FAR 52.232-33", "Payment by Electronic Funds Transfer - System for Award Management."],
        ["DFARS 252.232-7003", "Electronic Submission of Payment Requests and Receiving Reports."],
    ]


def bpa_draw_cover(c: Any, s: Scenario, data: dict[str, Any], total_pages: int) -> None:
    office = data["contracting_office"]
    payment = office["payment_office"]
    x = 25
    y = 760
    w = 562
    sf1449_draw_training_marks(c, 1, total_pages, continuation=False)

    title_w, req_w, page_w = 350, 140, 72
    c.rect(x, y - 42, title_w, 42, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 10.2)
    c.drawCentredString(x + title_w / 2, y - 12, "SOLICITATION/CONTRACT/ORDER FOR COMMERCIAL PRODUCTS")
    c.drawCentredString(x + title_w / 2, y - 24, "AND COMMERCIAL SERVICES")
    c.setFont("Helvetica-Bold", 6.0)
    c.drawCentredString(x + title_w / 2, y - 36, "BLANKET PURCHASE AGREEMENT")
    sf1449_draw_cell(c, x + title_w, y, req_w, 42, "1. Requisition Number", "N/A - BPA MASTER")
    sf1449_draw_cell(c, x + title_w + req_w, y, page_w, 42, "Page 1 of", str(total_pages))
    y -= 42

    widths = [110, 130, 95, 135, 92]
    labels = ["2. Contract/BPA Number", "3. Effective Date", "4. Order Number", "5. Solicitation Number", "6. Issue Date"]
    values = [s.contract_number, fmt_sf1449_date(s.timeline["award"]), "SEE BPA CALLS", "BPA SETUP", fmt_sf1449_date(s.timeline["solicitation"])]
    cursor = x
    for width, label, value in zip(widths, labels, values):
        sf1449_draw_cell(c, cursor, y, width, 38, label, value)
        cursor += width
    y -= 38

    sf1449_draw_cell(c, x, y, 190, 36, "7. For BPA Information Call", f"a. Name: {s.co['name']}\nb. Telephone Number: {s.co['phone']}")
    sf1449_draw_cell(c, x + 190, y, 220, 36, "8. BPA Period", bpa_period_label(s))
    sf1449_draw_cell(c, x + 410, y, 152, 36, "14. Method", "[X] BPA   [ ] FSS   [X] FAR 13")
    y -= 36

    office_block = f"{office['piid_activity']}\n{office['office_name']}\n{office['office_address']}"
    sf1449_draw_cell(c, x, y, 150, 58, "9. Issued By Code " + office["piid_activity"], office_block, max_lines=5)
    sf1449_draw_cell(c, x + 150, y, 273, 58, "10. BPA Arrangement", "[X] Single-award   [ ] Multiple-award\nCommercial BPA training arrangement\nCalls are subject to purchase limits and authorized caller controls.", max_lines=4)
    sf1449_draw_cell(c, x + 423, y, 139, 58, "11. Delivery/Performance", "Specified on individual BPA calls.\n13a. DPAS Rated Order\n[ ] Yes    13b. Rating:")
    y -= 58

    sf1449_draw_cell(c, x, y, 170, 54, "12. Discount Terms", "Net 30 unless call states otherwise")
    sf1449_draw_cell(c, x + 170, y, 180, 54, "15. Deliver To Code F2D3JC", "Specified on individual BPA calls.\nGovernment caller will identify location and acceptance POC.", max_lines=4)
    sf1449_draw_cell(c, x + 350, y, 212, 54, "16. Administered By Code " + office["piid_activity"], office_block, max_lines=4)
    y -= 54

    contractor_block = f"{s.winner['name']}\n{s.winner['address']}\nTelephone Number: {s.winner.get('phone', 'DSN 318-555-02XX')}\n[ ] 17b. Check if remittance is different and put such address in offer"
    payment_block = f"{payment['name']}\n{payment.get('address', payment['name'])}\n[ ] 18b. Submit invoices to address shown unless checked: See call"
    sf1449_draw_cell(c, x, y, 337, 72, "17a. Contractor / Offeror Code " + award_vendor_code(s) + " Facility Code", contractor_block, max_lines=6)
    sf1449_draw_cell(c, x + 337, y, 225, 72, "18a. Payment Will Be Made By Code " + payment["code"], payment_block, max_lines=5)
    y -= 72

    schedule_widths = [74, 268, 57, 50, 58, 55]
    header_h, body_h, helper_h = 26, 144, 11
    sf1449_draw_table(c, x, y, schedule_widths, [["19. Item Number", "20. Schedule of Supplies/Services", "21. Quantity", "22. Unit", "23. Unit Price", "24. Amount"]], [header_h], header_rows=1)
    body_top = y - header_h
    cursor = x
    for width in schedule_widths:
        c.rect(cursor, body_top - body_h, width, body_h, stroke=1, fill=0)
        cursor += width
    c.setFont("Helvetica-Bold", 8.8)
    c.drawCentredString(x + w / 2, body_top - 54, "SEE BPA TERMS, AUTHORIZED CALLERS, PURCHASE LIMITS, AND INDIVIDUAL CALLS")
    c.setFont("Helvetica", 7)
    c.drawCentredString(x + w / 2, body_top - 72, f"Unit prices are established in Attachment 1 - {price_list_attachment_title(s)}. Quantities are ordered on individual calls only.")
    c.drawCentredString(x + w / 2, body_top - 86, "This master BPA does not obligate funds and has no ceiling. Each call must cite funding, quantities, delivery/performance, and price.")
    c.rect(x, body_top - body_h - helper_h, w, helper_h, stroke=1, fill=0)
    c.setFont("Helvetica", 5.5)
    c.drawCentredString(x + w / 2, body_top - body_h - 8, "(Use Reverse and/or Attach Additional Sheets as Necessary)")
    y = body_top - body_h - helper_h

    sf1449_draw_cell(c, x, y, 430, 38, "25. Accounting and Appropriation Data", "NOT CITED ON MASTER BPA - SEE INDIVIDUAL CALLS")
    sf1449_draw_cell(c, x + 430, y, 132, 38, "26. Total Award Amount", "N/A - BPA MASTER")
    y -= 38
    sf1449_draw_cell(c, x, y, w, 25, "27. Terms and Conditions", "[X] BPA terms, authorized callers, ordering procedures, and clauses are attached.")
    y -= 25

    sf1449_draw_cell(c, x, y, 280, 40, "28. Supplier Agreement", "Contractor agrees to furnish supplies or services ordered under authorized BPA calls subject to the attached BPA terms.", max_lines=3)
    sf1449_draw_cell(c, x + 280, y, 282, 40, "29. Establishment of BPA", f"The Government establishes this BPA with {s.winner['name']} for the period and terms shown herein.", max_lines=3)
    y -= 40

    sf1449_draw_cell(c, x, y, 281, 28, "30a. Signature of Offeror/Contractor", "//SIGNED//")
    sf1449_draw_cell(c, x + 281, y, 281, 28, "31a. United States of America (Signature of Contracting Officer)", award_co_signature_value(s))
    y -= 28
    sf1449_draw_cell(c, x, y, 210, 27, "30b. Name and Title of Signer", s.winner["signer"], max_lines=2)
    sf1449_draw_cell(c, x + 210, y, 71, 27, "30c. Date Signed", fmt_sf1449_date(s.timeline["award"]))
    sf1449_draw_cell(c, x + 281, y, 210, 27, "31b. Name of Contracting Officer", s.co["name"])
    sf1449_draw_cell(c, x + 491, y, 71, 27, "31c. Date Signed", award_co_sign_date_value(s))

    c.setFont("Helvetica", 5.8)
    c.drawString(x, 35, "AUTHORIZED FOR LOCAL REPRODUCTION - PREVIOUS EDITION IS NOT USABLE")
    c.setFont("Helvetica-Bold", 6.2)
    c.drawRightString(x + w, 35, "STANDARD FORM 1449 STYLE BPA PACKAGE")


def bpa_render_award_packet(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    path = folder / award_packet_file_name(s)
    path.parent.mkdir(parents=True, exist_ok=True)
    total_pages = bpa_total_pages()
    c = pdf_canvas.Canvas(str(path), pagesize=letter)

    bpa_draw_cover(c, s, data, total_pages)
    c.showPage()

    y = bpa_draw_header(c, s, "BPA Terms", 2, total_pages, data)
    y = sf1449_section_heading(c, "BPA Terms and Conditions", y)
    summary_rows = [
        ["BPA Number", s.contract_number, "BPA Period", bpa_period_label(s)],
        ["Contractor", s.winner["name"], "Per-Call Limit", money(bpa_call_limit_value(s))],
        ["Authorized Office", data["contracting_office"]["office_symbol"], "Funding", "Individual calls only"],
        ["Pricing", f"Attachment 1 - {price_list_attachment_title(s)}", "Ceiling", "None - BPA does not obligate or cap funds"],
    ]
    y = sf1449_draw_table(c, 25, y, [100, 180, 105, 177], summary_rows, [20] * len(summary_rows), header_rows=0)
    y -= 18
    term_blocks = [
        ("1. Description of Agreement", [f"This BPA establishes a simplified method for future authorized calls for {s.archetype['requirement']}. The agreement does not by itself obligate the Government to order supplies or services."]),
        ("2. Extent of Obligation", ["The Government is obligated only to the extent of authorized BPA calls placed by designated callers and accepted by the Contractor. The master BPA does not cite funds or create a minimum purchase obligation."]),
        ("3. Purchase Limitation", [f"Individual calls may not exceed {money(bpa_call_limit_value(s))} unless specifically authorized in writing by the Contracting Officer. This BPA does not establish a ceiling and does not obligate funds; cumulative call activity is reviewed at least annually for continued use of the agreement."]),
        ("4. Individuals Authorized to Purchase", [f"Authorized callers are the Contracting Officer, delegated ordering officials named in the file, and mission partner representatives specifically identified in writing by {s.co['name']}."]),
        ("5. Ordering Procedures", ["Calls may be placed by email or written call document. Each call shall identify the BPA number, call number, requirement, quantity, unit price, total price, funding citation, delivery or performance location, required date, and acceptance point of contact."]),
        ("5a. Pricing", [f"Prices for typical items and services are established in Attachment 1 - {price_list_attachment_title(s)}. Prices are per unit; quantities are established only on individual calls. Items not on the price list may be added by the Contracting Officer at fair and reasonable prices documented on the call."]),
        ("6. Delivery Tickets and Invoices", ["Delivery tickets shall reference the BPA and call number and identify the items delivered or services performed. Invoices shall be submitted only after Government acceptance and shall cite the specific call funding and CLIN data."]),
        ("7. Administration", ["Only the Contracting Officer may change the terms of this BPA. Callers may not direct work outside the scope, increase a call beyond delegated authority, or authorize performance without an issued call."]),
    ]
    for heading, paragraphs in term_blocks:
        c.setFont("Helvetica-Bold", 8.7)
        c.drawString(25, y, heading.upper())
        y -= 12
        y = sf1449_draw_paragraphs(c, paragraphs, y, size=7.5)
        y -= 2
    c.showPage()

    y = bpa_draw_header(c, s, "Clauses and References", 3, total_pages, data)
    y = sf1449_section_heading(c, "Clauses and References", y)
    y = sf1449_draw_table(c, 25, y, [125, 437], bpa_clause_rows(), [18] + [28] * (len(bpa_clause_rows()) - 1), header_rows=1)
    y -= 20
    y = sf1449_section_heading(c, "Reference Text", y)
    reference_paragraphs = [
        "This BPA package uses abbreviated reference language. Clause prescriptions, alternates, fill-ins, and local procedures should be verified against applicable acquisition guidance.",
        "The Contractor shall maintain active registration, provide standard commercial terms for ordered supplies or services, and submit invoices through the method identified on each call.",
        "The Government may discontinue use of the BPA at any time. Termination or cancellation of a call shall be handled through the Contracting Officer and documented in the applicable call file.",
    ]
    sf1449_draw_paragraphs(c, reference_paragraphs, y, size=8.0)
    c.save()


def bpa_write_award(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    if is_multiple_award_master(s):
        for awardee in master_awardees(s):
            bpa_render_award_packet(folder, scenario_for_master_awardee(s, awardee), data)
        write_price_list_pdf(folder, s)
        write_multiple_award_roster_pdf(folder, s)
        return
    bpa_render_award_packet(folder, s, data)
    write_price_list_pdf(folder, s)


def write_outlook_thread_pdf(
    path: Path,
    subject: str,
    messages: list[dict[str, Any]],
    mailbox: str = "Microsoft Outlook",
) -> None:
    """Render an Outlook-like conversation, newest message first."""
    path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="OutlookTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            textColor=colors.black,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="OutlookLabel",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=10,
            leading=14,
            textColor=colors.black,
        )
    )
    styles.add(
        ParagraphStyle(
            name="OutlookMeta",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            textColor=colors.black,
        )
    )
    styles.add(
        ParagraphStyle(
            name="OutlookBody",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10.2,
            leading=14.2,
            textColor=colors.black,
            spaceAfter=5,
        )
    )
    styles.add(
        ParagraphStyle(
            name="OutlookBullet",
            parent=styles["OutlookBody"],
            leftIndent=22,
            bulletIndent=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="OutlookSmall",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#444444"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="SignatureName",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=8.5,
            leading=10,
            textColor=colors.HexColor("#17365D"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="SignatureLine",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=8.5,
            leading=10,
            textColor=colors.HexColor("#17365D"),
        )
    )

    story: list[Any] = []

    for idx, message in enumerate(messages):
        if idx:
            divider = Table([[""]], colWidths=[6.95 * inch], hAlign="LEFT")
            divider.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.65, colors.HexColor("#B7B7B7"))]))
            story.append(Spacer(1, 0.12 * inch))
            story.append(divider)
            story.append(Spacer(1, 0.10 * inch))
        if message.get("sent_notice"):
            story.append(p(message["sent_notice"], styles["OutlookSmall"]))
            story.append(Spacer(1, 0.06 * inch))
        rows = [
            ["From:", message.get("from", "")],
            ["Sent:", message.get("sent", "")],
            ["To:", message.get("to", "")],
        ]
        if message.get("cc"):
            rows.append(["Cc:", message["cc"]])
        if message.get("bcc"):
            rows.append(["Bcc:", message["bcc"]])
        if idx:
            rows.append(["Subject:", message.get("subject", subject)])
        table = Table(
            [[p(label, styles["OutlookLabel"]), p(value, styles["OutlookMeta"])] for label, value in rows],
            colWidths=[0.8 * inch, 6.15 * inch],
            hAlign="LEFT",
        )
        table.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 2),
                    ("TOPPADDING", (0, 0), (-1, -1), 1),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                ]
            )
        )
        story.append(table)
        if not idx:
            story.append(Spacer(1, 0.08 * inch))
            story.append(p(message.get("subject", subject), styles["OutlookTitle"]))
        story.append(Spacer(1, 0.08 * inch))
        add_email_body(story, str(message.get("body", "")), styles)
        if message.get("table"):
            add_email_table(story, message["table"], message.get("widths"))
        if message.get("attachments"):
            add_attachment_bar(story, message["attachments"], styles)
        signature = message.get("signature")
        if signature:
            story.append(Spacer(1, 0.05 * inch))
            story.append(p(str(message.get("closing") or "V/r,"), styles["OutlookBody"]))
            for line_idx, line in enumerate(signature):
                story.append(p(line, styles["SignatureName" if line_idx == 0 else "SignatureLine"]))

    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        rightMargin=0.48 * inch,
        leftMargin=0.48 * inch,
        topMargin=0.72 * inch,
        bottomMargin=0.62 * inch,
        title=subject,
    )
    doc.build(story, onFirstPage=email_page_marks, onLaterPages=email_page_marks)


def write_sor_docx(path: Path, s: Scenario) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if Document is None:
        write_pdf(
            path.with_suffix(".pdf"),
            "STATEMENT OF REQUIREMENTS",
            [
                ("Requirement", s.archetype["title"]),
                ("Requesting Unit", f"{s.customer['display_name']} ({s.customer['unit']})"),
                ("Requiring Activity POC", s.requester),
                ("Approval Authority", s.approver),
                ("Date Submitted", fmt_date(s.timeline["requirement"])),
                ("Required Delivery", f"NLT {fmt_date(s.timeline['delivery'])}"),
                ("Period of Performance", performance_period_label(s)),
                ("File Number", s.file_number),
                ("Requirement Type", category_label(s)),
                *ordering_reference_rows(s),
                (
                    "Background",
                    f"The {s.customer['unit']} identified a recurring mission support need for {s.archetype['requirement']}. "
                    "The requirement supports deployed operations at an undisclosed overseas location.",
                ),
                (
                    "Objective",
                    f"Provide {lowercase_display_phrase(s.archetype['title'])} sufficient to maintain mission continuity while the requiring activity manages the underlying operational need.",
                ),
                ("Scope", " ".join([f"The contractor shall provide {s.archetype['requirement']}."] + category_special_terms(s))),
                ("Delivery and Performance", f"{s.archetype['delivery_note']} Delivery or performance location: {s.delivery_address}"),
                (
                    "Acceptance",
                    f"The requiring activity will inspect deliverables or services. Acceptance will be documented by {person_display(s.requester)} or another designated Government representative.",
                ),
            ],
        )
        return

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)

    banner = doc.add_paragraph()
    banner.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = banner.add_run(EXERCISE_BANNER)
    run.bold = True
    run.font.color.rgb = RGBColor(176, 0, 0)

    doc.add_heading("STATEMENT OF REQUIREMENTS", 0)
    doc.add_heading(s.archetype["title"], level=1)
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    facts = [
        ("Requesting Unit", f"{s.customer['display_name']} ({s.customer['unit']})"),
        ("Requiring Activity POC", s.requester),
        ("Approval Authority", s.approver),
        ("Date Submitted", fmt_date(s.timeline["requirement"])),
        ("Required Delivery", f"NLT {fmt_date(s.timeline['delivery'])}"),
        ("Period of Performance", performance_period_label(s)),
        ("File Number", s.file_number),
        ("Requirement Type", category_label(s)),
        *ordering_reference_rows(s),
    ]
    for label, value in facts:
        row = table.add_row().cells
        row[0].text = label
        row[1].text = value

    doc.add_heading("1. Background", level=1)
    doc.add_paragraph(
        f"The {s.customer['unit']} identified a recurring mission support need for {s.archetype['requirement']}. "
        "The requirement supports deployed operations at an undisclosed overseas location."
    )
    if is_ordering_action(s):
        doc.add_paragraph(ordering_relationship_sentence(s))
    doc.add_heading("2. Objective", level=1)
    doc.add_paragraph(
        f"Provide {lowercase_display_phrase(s.archetype['title'])} sufficient to maintain mission continuity while the requiring activity manages the underlying operational need."
    )
    doc.add_heading("3. Scope", level=1)
    doc.add_paragraph(f"The contractor shall provide {s.archetype['requirement']}.")
    for term in category_special_terms(s):
        doc.add_paragraph(term, style=None)
    section_num = 4
    characteristics = profile_characteristics(s)
    if characteristics:
        doc.add_heading(f"{section_num}. Required Characteristics", level=1)
        for item in characteristics:
            doc.add_paragraph(item, style="List Bullet")
        section_num += 1
    doc.add_heading(f"{section_num}. Delivery and Performance", level=1)
    doc.add_paragraph(s.archetype["delivery_note"])
    doc.add_paragraph(f"Delivery or performance location: {s.delivery_address}")
    section_num += 1
    doc.add_heading(f"{section_num}. Acceptance", level=1)
    doc.add_paragraph(
        f"The requiring activity will inspect deliverables or services. Acceptance will be documented by {person_display(s.requester)} or another designated Government representative."
    )
    acceptance = profile_acceptance_criteria(s)
    if acceptance:
        for item in acceptance:
            doc.add_paragraph(item, style="List Bullet")
    doc.save(str(path))


def action_prefix(s: Scenario) -> str:
    return slugify(truncate_filename(str(s.archetype["folder_label"]), MAX_ACTION_LABEL_CHARS, "Requirement"))


def solicitation_doc_name(s: Scenario) -> str:
    if re.search(r"XXR\d{4}$", s.solicitation_number or "", re.I):
        return compact_doc_name(s, "RFP")
    return compact_doc_name(s, "RFQ")


def category_label(s: Scenario) -> str:
    return {
        "supply": "Commercial Product / Supply",
        "service": "Commercial Service",
        "construction": "Construction / Site Work",
        "bpa": "Blanket Purchase Agreement",
        "idiq": "Indefinite-Delivery Contract",
        "bpa_call": "BPA Call",
        "idiq_order": "IDIQ Order",
    }.get(s.category, s.category.title())


def is_ordering_action(s: Scenario) -> bool:
    return bool(s.parent_contract_number)


def parent_reference_label(s: Scenario) -> str:
    if not is_ordering_action(s):
        return ""
    return f"{s.parent_instrument_label} {s.parent_contract_number}"


def call_or_order_label(s: Scenario) -> str:
    if s.category == "bpa_call":
        return "BPA Call"
    if s.category == "idiq_order":
        return "Task/Delivery Order"
    return "Contract"


def ordering_relationship_sentence(s: Scenario) -> str:
    if s.category == "bpa_call":
        return f"This action is BPA call {s.contract_number} issued under parent BPA {s.parent_contract_number}."
    if s.category == "idiq_order":
        return f"This action is task/delivery order {s.contract_number} issued under parent IDIQ {s.parent_contract_number}."
    return ""


def ordering_reference_rows(s: Scenario) -> list[tuple[str, str]]:
    if not is_ordering_action(s):
        return []
    return [
        ("Parent Instrument", parent_reference_label(s)),
        (call_or_order_label(s), s.contract_number),
    ]


def effective_requirement_category(s: Scenario) -> str:
    return s.requirement_category or s.category


def is_service_requirement(s: Scenario) -> bool:
    return effective_requirement_category(s) == "service"


def is_construction_requirement(s: Scenario) -> bool:
    return effective_requirement_category(s) == "construction"


def category_special_terms(s: Scenario) -> list[str]:
    if s.category in {"bpa_call", "idiq_order"}:
        terms = [
            f"This action is an individual call placed against master BPA {s.parent_contract_number} and must remain within the BPA scope and caller authority."
            if s.category == "bpa_call"
            else f"This action is an order placed against IDIQ contract {s.parent_contract_number} and must remain within the ordering vehicle scope and ceiling.",
            "Funding, delivery or performance requirements, and acceptance are controlled by this call/order document.",
        ]
        if is_service_requirement(s):
            terms.extend(
                [
                    "The Contractor shall provide recurring services during the stated period of performance.",
                    "The Contractor shall maintain a quality control process and correct Government-identified deficiencies within the response time stated in the contract file.",
                    "Invoices shall identify the service period, CLIN, and accepted amount.",
                ]
            )
        elif is_construction_requirement(s):
            terms.extend(
                [
                    "The Contractor shall furnish all labor, materials, equipment, supervision, safety controls, and incidentals required to complete the work.",
                    "Work shall be coordinated with the Government before mobilization. No field work may begin until site access and safety requirements are satisfied.",
                    "The Contractor shall protect existing utilities, roads, facilities, and mission operations during performance.",
                ]
            )
        else:
            terms.extend(
                [
                    "The Contractor shall deliver conforming supplies or commercial items to the Government-designated location.",
                    "Acceptance occurs after Government inspection confirms quantity, condition, and basic conformance with the requirement.",
                    "Delivery tickets, packing slips, and invoices shall reference the call/order number, CLIN, quantity, and amount.",
                ]
            )
        return terms
    if s.category == "construction":
        return [
            "The Contractor shall furnish all labor, materials, equipment, supervision, safety controls, and incidentals required to complete the work.",
            "Work shall be coordinated with the Government before mobilization. No field work may begin until site access and safety requirements are satisfied.",
            "The Contractor shall protect existing utilities, roads, facilities, and mission operations during performance.",
        ]
    if s.category == "service":
        terms = [
            "The Contractor shall provide recurring services during the stated period of performance.",
            "The Contractor shall maintain a quality control process and correct Government-identified deficiencies within the response time stated in the contract file.",
            "Invoices shall identify the service period, CLIN, and accepted amount.",
        ]
        if s.archetype.get("option_note"):
            terms.append(str(s.archetype["option_note"]))
        return terms
    if s.category == "bpa":
        return [
            "The BPA establishes ordering procedures only and does not obligate funds until an authorized call is issued.",
            "Each BPA call shall identify the requirement, quantity, funding citation, delivery or performance location, and acceptance point of contact.",
            "Callers may not direct work outside the scope, exceed delegated call limits, or alter BPA terms without the Contracting Officer.",
        ]
    if s.category == "idiq":
        return [
            "The IDIQ establishes ordering procedures and a contract ceiling for future task or delivery orders.",
            "Each order shall identify the specific scope, CLINs, funding citation, delivery or performance location, and acceptance point of contact.",
            "The Contractor shall not perform work outside an issued task or delivery order signed by an authorized Contracting Officer.",
        ]
    return [
        "The Contractor shall deliver conforming supplies or commercial items to the Government-designated location.",
        "Acceptance occurs after Government inspection confirms quantity, condition, and basic conformance with the requirement.",
        "Delivery tickets, packing slips, and invoices shall reference the contract number, CLIN, quantity, and amount.",
    ]


def profile_text_list(value: Any, limit: int = 8) -> list[str]:
    if not isinstance(value, list):
        return []
    items: list[str] = []
    for item in value[:limit]:
        text = re.sub(r"\s+", " ", str(item or "")).strip(" .")
        if text and text.lower() not in {existing.lower() for existing in items}:
            items.append(text)
    return items


def requirement_profile(s: Scenario) -> dict[str, Any]:
    profile = s.archetype.get("_requirement_profile")
    return profile if isinstance(profile, dict) else {}


def profile_characteristics(s: Scenario) -> list[str]:
    return profile_text_list(requirement_profile(s).get("salient_characteristics"), 10)


def profile_acceptance_criteria(s: Scenario) -> list[str]:
    return profile_text_list(requirement_profile(s).get("acceptance_criteria"), 8)


def profile_quote_requirements(s: Scenario) -> list[str]:
    return profile_text_list(requirement_profile(s).get("quote_submission_requirements"), 8)


def profile_delivery_docs(s: Scenario) -> list[str]:
    return profile_text_list(requirement_profile(s).get("delivery_documentation"), 6)


def profile_table(title: str, items: list[str]) -> list[list[str]]:
    rows = [["No.", title]]
    rows.extend([[str(idx), item] for idx, item in enumerate(items, start=1)])
    return rows


def prompt_profile_kind(archetype: dict[str, Any], category: str, requirement_category: str, prompt: str) -> str:
    text = " ".join(
        str(archetype.get(key, ""))
        for key in ["key", "title", "folder_label", "requirement", "clin_description", "market_note"]
    ).lower()
    text = f"{text} {prompt.lower()}"
    def has_terms(terms: list[str]) -> bool:
        return any(re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", text) for term in terms)

    if requirement_category == "construction":
        return "construction"
    if has_terms(["f-35", "f35", "aircraft", "fighter", "engine module", "aircraft component"]):
        return "aircraft"
    if has_terms(["armored vehicle", "armoured vehicle", "uparmor", "up-armored", "mrap", "light tactical vehicle"]):
        return "armored_vehicle"
    if has_terms(["vehicle", "truck", "suv", "pickup", "sedan", "van", "bus"]):
        return "vehicle"
    if has_terms(["generator", "power unit", "light tower"]):
        return "generator"
    if has_terms(["toner", "paper", "copy paper", "office supplies", "printer cartridge"]):
        return "office_supplies"
    if has_terms(["network", "cable", "ethernet", "fiber", "comm", "communications"]):
        return "network"
    if has_terms(["hvac", "air conditioning", "a/c", "split unit", "chiller"]):
        return "hvac"
    if has_terms(["water", "ice", "food", "consumable"]):
        return "consumable"
    if requirement_category == "service":
        return "service"
    if is_master_vehicle_category(category):
        return "master"
    return "supply"


def default_requirement_profile(
    archetype: dict[str, Any],
    category: str,
    requirement_category: str,
    prompt: str,
    rng: random.Random,
) -> dict[str, Any]:
    kind = prompt_profile_kind(archetype, category, requirement_category, prompt)
    title = str(archetype.get("title") or archetype.get("requirement") or "Requirement")
    generic_docs = ["Delivery ticket or completion record", "Invoice referencing contract/order number and CLIN", "Warranty or support documentation when commercially provided"]
    profiles: dict[str, dict[str, list[str]]] = {
        "generator": {
            "salient_characteristics": [
                "Continuous output rating sized for the stated load requirement",
                "Diesel-powered unit suitable for deployed outdoor use",
                "Weather-resistant enclosure with lockable controls",
                "Voltage and phase configuration compatible with supported facility equipment",
                "Required cables, grounding materials, drip pan, and operator manual included",
                "Startup check and basic operator familiarization at delivery",
            ],
            "acceptance_criteria": [
                "Quantity and model match the contract line item",
                "No visible shipping damage, fluid leaks, or missing panels",
                "Startup and functional output check completed at delivery",
                "Required accessories, manuals, and warranty/support information received",
            ],
            "quote_submission_requirements": [
                "State continuous kW rating, voltage/phase, fuel type, enclosure type, and included accessories",
                "Identify delivery lead time, offload/startup support, and warranty terms",
                "Price all required accessories and delivery charges by CLIN",
            ],
            "delivery_documentation": generic_docs + ["Startup/functional check record"],
        },
        "office_supplies": {
            "salient_characteristics": [
                "Commercially packaged office supply items in new condition",
                "Paper brightness, size, weight, or cartridge compatibility identified in the quote",
                "Items delivered in manufacturer packaging or equivalent protective packaging",
                "Substitutions require equal or better compatibility and Government acceptance",
            ],
            "acceptance_criteria": [
                "Item count matches the packing slip and CLIN quantity",
                "No water damage, crushed packaging, or visibly defective cartridges",
                "Toner/ink part numbers are compatible with listed printer models",
            ],
            "quote_submission_requirements": [
                "List manufacturer/part number or equal item description",
                "State case/box quantities and delivery lead time",
                "Identify any proposed substitutions clearly",
            ],
            "delivery_documentation": generic_docs + ["Packing slip with part numbers and quantities"],
        },
        "vehicle": {
            "salient_characteristics": [
                "Vehicle class, seating/cargo capacity, drivetrain, and minimum safety equipment identified",
                "Vehicles delivered roadworthy with keys, registration/support documents, and operator manuals",
                "Maintenance, warranty, or replacement support terms included when applicable",
                "Delivery condition documented with mileage, fuel level, and visible damage notes",
            ],
            "acceptance_criteria": [
                "VIN/serial and vehicle class match quote and award document",
                "Basic lights, brakes, tires, safety equipment, and keys verified at handoff",
                "Required documentation and warranty/support contacts received",
            ],
            "quote_submission_requirements": [
                "Identify make/model or equivalent, year/model condition, capacity, and included equipment",
                "Describe maintenance, warranty, replacement, and delivery support",
                "State delivery availability and any host-nation documentation limitations",
            ],
            "delivery_documentation": generic_docs + ["Vehicle handoff/condition sheet"],
        },
        "armored_vehicle": {
            "salient_characteristics": [
                "Light armored or up-armored vehicle configuration suitable for deployed security movement",
                "Seating, payload, armor/safety package, communications power provisions, and basic recovery equipment identified",
                "Operator documentation, keys, maintenance support, and export/import documentation included as applicable",
                "Delivery includes condition inspection and familiarization with safety limitations",
            ],
            "acceptance_criteria": [
                "Vehicle configuration and safety package match the award description",
                "No visible structural damage or missing mission-essential equipment",
                "Documentation, keys, maintenance contacts, and handoff inspection completed",
            ],
            "quote_submission_requirements": [
                "Describe armored configuration, seating, payload, support package, and delivery/export limitations",
                "State maintenance/warranty support and availability of replacement parts",
                "Identify delivery schedule and any assumptions requiring Government coordination",
            ],
            "delivery_documentation": generic_docs + ["Vehicle condition and equipment checklist"],
        },
        "aircraft": {
            "salient_characteristics": [
                "Major aviation end item, component, or support package identified by configuration, part number, or approved equivalent",
                "Airworthiness, traceability, preservation, packaging, and documentation requirements identified",
                "Compatibility with the stated platform or support mission clearly addressed",
                "Inspection, acceptance, and warranty/support limitations stated in the quote",
            ],
            "acceptance_criteria": [
                "Configuration, part number, serial/lot data, and documentation match the award",
                "Packaging, preservation, and traceability records are complete",
                "Government technical representative confirms basic conformance before acceptance",
            ],
            "quote_submission_requirements": [
                "Provide configuration, part number/NSN if applicable, traceability, condition, and documentation package",
                "State delivery schedule, preservation/packaging method, warranty/support limitations, and export assumptions",
                "Identify any proposed equivalent item or deviation from the requested configuration",
            ],
            "delivery_documentation": generic_docs + ["Traceability/airworthiness or conformance documentation"],
        },
        "network": {
            "salient_characteristics": [
                "Cable type, pathway, drop count, labeling, termination standard, and test method identified",
                "Work includes routing, cable management, faceplates/patch panels, cleanup, and as-built labeling",
                "Contractor coordinates access, outages, and work areas before installation",
            ],
            "acceptance_criteria": [
                "Drop count and locations match the requirement",
                "Continuity/certification or functional test results provided",
                "Cable labels, patch panel map, and cleanup accepted by Government POC",
            ],
            "quote_submission_requirements": [
                "Identify cable type, number of drops, materials, installation approach, and test/certification method",
                "State access requirements, estimated work duration, and assumptions about existing infrastructure",
            ],
            "delivery_documentation": generic_docs + ["Test results and as-built drop list"],
        },
        "hvac": {
            "salient_characteristics": [
                "Equipment/system to be serviced identified by location, unit type, capacity, and symptoms or required work",
                "Repair includes diagnosis, parts/materials, labor, refrigerant handling when applicable, and functional check",
                "Contractor coordinates work hours, access, and safety controls with the facility POC",
            ],
            "acceptance_criteria": [
                "Repair or service completed for the listed unit/location",
                "Functional check demonstrates cooling/heating operation as applicable",
                "Service ticket identifies parts, labor, readings, and remaining deficiencies if any",
            ],
            "quote_submission_requirements": [
                "Describe diagnostic approach, included parts/materials, labor assumptions, and response time",
                "Identify any exclusions, required Government-furnished access, or long-lead parts",
            ],
            "delivery_documentation": generic_docs + ["Service ticket with functional check results"],
        },
        "construction": {
            "salient_characteristics": [
                "Work area, major work elements, materials, safety controls, and closeout documents identified",
                "Contractor furnishes labor, supervision, materials, equipment, tools, and incidentals unless stated otherwise",
                "Site access, laydown area, utility protection, outage coordination, and work hours coordinated before mobilization",
                "Submittals, quality control, cleanup, punch list correction, and warranty information included",
            ],
            "acceptance_criteria": [
                "Work is complete in the specified area and conforms to the stated scope",
                "No unresolved safety, cleanup, access, or utility protection deficiencies remain",
                "Government representative completes final inspection and punch list closure",
                "Closeout documents, photos, warranty data, and as-built notes received when applicable",
            ],
            "quote_submission_requirements": [
                "Submit technical approach, schedule, safety controls, quality control plan, and relevant construction experience",
                "Identify major materials/equipment, assumptions, exclusions, and site access requirements",
                "Price mobilization, construction work, and closeout by CLIN",
            ],
            "delivery_documentation": generic_docs + ["Final inspection/punch list closure record"],
        },
        "service": {
            "salient_characteristics": [
                "Staffing plan, schedule, service locations, supervision, quality control, and customer coordination identified",
                "Contractor furnishes labor, supervision, tools, supplies, and incidentals unless stated otherwise",
                "Service logs or completion tickets support receiving and invoice review",
            ],
            "acceptance_criteria": [
                "Service performed at the required location and frequency",
                "Customer-identified deficiencies corrected within the stated response time",
                "Service log or completion ticket supports the invoiced period",
            ],
            "quote_submission_requirements": [
                "Describe staffing, schedule, quality control, supplies/equipment, and deficiency correction process",
                "State start date, service frequency, assumptions, and exclusions",
            ],
            "delivery_documentation": generic_docs + ["Service log or completion ticket"],
        },
        "master": {
            "salient_characteristics": [
                "Master vehicle scope, ordering procedures, ordering period, authorized users, and limits clearly stated",
                "Individual calls/orders will establish actual scope, quantities, funding, delivery/performance, and acceptance",
                "Price list or ordering categories support future fair and reasonable call/order pricing",
            ],
            "acceptance_criteria": [
                "Master file contains signed vehicle terms, ordering period, scope, and price list/order categories",
                "Registry/tracker records vehicle number, status, limits, period, and folder location",
            ],
            "quote_submission_requirements": [
                "Submit technical capability, ordering procedures, price list/categories, management approach, and past performance",
                "Identify scope boundaries, response times, and any ordering limitations",
            ],
            "delivery_documentation": ["Signed master vehicle", "Price list or ordering category attachment", "Registry/tracker entry"],
        },
        "supply": {
            "salient_characteristics": [
                f"Commercial item or supply package suitable for {lowercase_display_phrase(title)}",
                "New or serviceable items delivered with standard commercial documentation",
                "Compatible accessories, packaging, delivery, and warranty/support information included when applicable",
            ],
            "acceptance_criteria": [
                "Quantity, condition, and basic conformance match the CLIN description",
                "No visible damage or missing required accessories",
                "Packing slip, delivery ticket, and warranty/support documentation received when applicable",
            ],
            "quote_submission_requirements": [
                "Describe offered items, manufacturer/part number or equal description, delivery lead time, warranty/support, and any substitutions",
                "Price all delivery, setup, and accessory charges by CLIN",
            ],
            "delivery_documentation": generic_docs,
        },
        "consumable": {
            "salient_characteristics": [
                "Consumables are commercially packaged, sealed when applicable, and suitable for deployed storage conditions",
                "Delivery quantity, lot/case count, expiration/shelf-life when applicable, and pallet configuration identified",
                "Offload, staging, and delivery schedule coordinated with receiving point",
            ],
            "acceptance_criteria": [
                "Quantity and packaging match the packing slip and CLIN",
                "No visible damage, leakage, contamination, or expired shelf-life items",
                "Receiving point signs delivery ticket after count and condition check",
            ],
            "quote_submission_requirements": [
                "State case/lot quantities, shelf-life if applicable, packaging, delivery lead time, and offload assumptions",
                "Identify any substitutions or minimum order quantities",
            ],
            "delivery_documentation": generic_docs + ["Packing slip with lot/case quantities"],
        },
    }
    selected = profiles.get(kind, profiles["supply"])
    return {
        "kind": kind,
        "salient_characteristics": selected["salient_characteristics"],
        "acceptance_criteria": selected["acceptance_criteria"],
        "quote_submission_requirements": selected["quote_submission_requirements"],
        "delivery_documentation": selected["delivery_documentation"],
    }


def ensure_requirement_profile(
    archetype: dict[str, Any],
    category: str,
    requirement_category: str,
    prompt: str,
    rng: random.Random,
) -> None:
    existing = archetype.get("_requirement_profile")
    if isinstance(existing, dict) and profile_text_list(existing.get("salient_characteristics")):
        return
    archetype["_requirement_profile"] = default_requirement_profile(archetype, category, requirement_category, prompt, rng)


def category_clause_rows(s: Scenario) -> list[list[str]]:
    rows = [["Reference", "Why It Appears In This Mock File"]]
    if s.category == "construction":
        rows.extend(
            [
                ["FAR 52.236-7", "Permits and responsibilities for construction-style work."],
                ["FAR 52.236-13", "Accident prevention and site safety controls."],
                ["FAR 52.243-4", "Changes clause for fixed-price construction."],
            ]
        )
    elif s.category == "service":
        rows.extend(
            [
                ["FAR 52.212-4", "Commercial terms and conditions."],
                ["FAR 52.217-8", "Short extension language where service continuity may matter."],
                ["FAR 52.246-4", "Inspection of services."],
            ]
        )
    elif s.category == "bpa":
        rows.extend(
            [
                ["BPA Ordering Procedures", "Blanket purchase agreement ordering procedures and limitations."],
                ["FAR 52.212-4", "Commercial terms applied to authorized calls."],
                ["DFARS 252.232-7003", "Electronic invoicing for calls when applicable."],
            ]
        )
    elif s.category == "idiq":
        rows.extend(
            [
                ["FAR 16.504", "Indefinite-quantity contract ordering structure."],
                ["FAR 52.216-18", "Ordering."],
                ["FAR 52.216-22", "Indefinite Quantity."],
            ]
        )
    else:
        rows.extend(
            [
                ["FAR 52.212-4", "Commercial terms and conditions."],
                ["FAR 52.211-6", "Brand-name-or-equal style reference if applicable."],
                ["FAR 52.246-2", "Inspection of supplies where applicable."],
            ]
        )
    return rows


def requirement_support_doc_type(s: Scenario) -> str | None:
    if is_service_requirement(s):
        return "PWS"
    if is_construction_requirement(s):
        return "SOW"
    return None


def requirement_support_doc_name(s: Scenario) -> str | None:
    doc_type = requirement_support_doc_type(s)
    if not doc_type:
        return None
    return compact_doc_name(s, doc_type, "docx")


def docx_set_cell(cell: Any, text: str, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(str(text))
    run.bold = bold


def add_docx_banner(doc: Any) -> None:
    banner = doc.add_paragraph()
    banner.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = banner.add_run(EXERCISE_BANNER)
    run.bold = True
    run.font.color.rgb = RGBColor(176, 0, 0)


def configure_docx_page(doc: Any) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)


def add_docx_fact_table(doc: Any, facts: list[tuple[str, str]]) -> None:
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    for label, value in facts:
        row = table.add_row().cells
        docx_set_cell(row[0], label, bold=True)
        docx_set_cell(row[1], value)


def sentence_fragment(value: str) -> str:
    return str(value).strip().rstrip(".")


def pws_performance_rows(s: Scenario) -> list[tuple[str, str, str, str]]:
    considerations = technical_factor_list(s)
    rows = [
        (
            "Service start / continuity",
            sentence_fragment(s.archetype["delivery_note"]) + ".",
            "Start service by required date and avoid unapproved service gaps.",
            "Customer observation and contractor service log.",
        ),
        (
            "Recurring service performance",
            f"Perform {lowercase_display_phrase(sentence_fragment(s.archetype['clin_description']))} in accordance with the approved schedule.",
            "No more than minor missed tasks per service period; corrected after Government notice.",
            "Random inspection and customer feedback.",
        ),
        (
            "Quality control",
            "Maintain a QC process and correct deficiencies within the response time stated in the file.",
            "Deficiencies corrected within one duty day unless mission access prevents correction.",
            "QC log review and Government surveillance.",
        ),
        (
            "Documentation / invoicing",
            "Provide service logs or other evidence supporting accepted performance and invoices.",
            "Invoices identify the service period, CLIN, and accepted amount.",
            "Invoice package and receiving confirmation.",
        ),
    ]
    if any("supply" in factor.lower() for factor in considerations):
        rows.insert(
            2,
            (
                "Supplies / consumables",
                "Provide contractor-furnished supplies or consumables necessary for performance unless stated otherwise.",
                "Supplies available before service is degraded.",
                "Spot check and customer report.",
            ),
        )
    return rows


def sow_work_rows(s: Scenario) -> list[tuple[str, str]]:
    return [
        ("Mobilization", "Coordinate site access, work hours, laydown area, and safety expectations before beginning field work."),
        ("Site work / performance", f"Complete {s.archetype['requirement']} using contractor-furnished labor, supervision, tools, materials, equipment, and incidentals."),
        ("Utility and facility protection", "Protect existing utilities, roads, structures, and mission operations. Stop work and notify the Government if unknown conditions are discovered."),
        ("Safety controls", "Conduct daily safety briefings, control the work area, use appropriate PPE, and comply with installation access and safety direction."),
        ("Cleanup", "Remove debris, excess materials, and contractor equipment from the site unless the Government directs otherwise."),
        ("Closeout", "Provide completion notice, as-built notes when applicable, warranty information, and supporting photos or tickets for acceptance."),
    ]


def write_requirement_support_docx(path: Path, s: Scenario) -> None:
    doc_type = requirement_support_doc_type(s)
    if not doc_type:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    title = "PERFORMANCE WORK STATEMENT" if doc_type == "PWS" else "STATEMENT OF WORK"
    if Document is None:
        sections = [
            {
                "heading": "Requirement Summary",
                "table": [
                    ["Field", "Value"],
                    ["Requirement", s.archetype["title"]],
                    ["Customer", f"{s.customer['display_name']} ({s.customer['unit']})"],
                    ["POC", s.requester],
                    ["Period of Performance", performance_period_label(s)],
                    ["Place of Performance", s.delivery_address],
                    *[[label, value] for label, value in ordering_reference_rows(s)],
                ],
            },
            {"heading": "Scope", "paragraphs": [f"The Contractor shall provide {s.archetype['requirement']}."]},
        ]
        write_pdf(path.with_suffix(".pdf"), title, s.archetype["title"], sections)
        return

    doc = Document()
    configure_docx_page(doc)
    add_docx_banner(doc)
    doc.add_heading(title, 0)
    doc.add_heading(s.archetype["title"], level=1)
    add_docx_fact_table(
        doc,
        [
            ("Requirement Type", category_label(s)),
            ("Requesting Unit", f"{s.customer['display_name']} ({s.customer['unit']})"),
            ("Requiring Activity POC", s.requester),
            ("Government Acceptance POC", person_display(s.requester)),
            ("Place of Performance", s.delivery_address),
            ("Period of Performance", performance_period_label(s)),
            ("File Number", s.file_number),
            *ordering_reference_rows(s),
        ],
    )

    if doc_type == "PWS":
        doc.add_heading("1. General", level=1)
        doc.add_paragraph(
            f"This Performance Work Statement describes the recurring service requirement for {s.archetype['requirement']}. "
            "The document is written for exercise use and supports the solicitation and technical evaluation file."
        )
        doc.add_heading("2. Scope of Services", level=1)
        doc.add_paragraph(f"The Contractor shall provide {lowercase_display_phrase(sentence_fragment(s.archetype['clin_description']))}.")
        for term in category_special_terms(s):
            doc.add_paragraph(term)
        doc.add_heading("3. Performance Requirements Summary", level=1)
        prs = doc.add_table(rows=1, cols=4)
        prs.style = "Table Grid"
        for idx, header in enumerate(["Performance Objective", "Standard", "Acceptable Quality Level", "Surveillance Method"]):
            docx_set_cell(prs.rows[0].cells[idx], header, bold=True)
        for objective, standard, aql, method in pws_performance_rows(s):
            cells = prs.add_row().cells
            docx_set_cell(cells[0], objective, bold=True)
            docx_set_cell(cells[1], standard)
            docx_set_cell(cells[2], aql)
            docx_set_cell(cells[3], method)
        doc.add_heading("4. Government Furnished Information and Access", level=1)
        doc.add_paragraph(
            "The Government will provide access coordination, facility points of contact, and any known mission constraints affecting performance. "
            "The Contractor remains responsible for furnishing labor, supervision, supplies, tools, and equipment unless the contract states otherwise."
        )
        doc.add_heading("5. Deliverables and Acceptance", level=1)
        deliverables = doc.add_table(rows=1, cols=3)
        deliverables.style = "Table Grid"
        for idx, header in enumerate(["Deliverable", "Frequency", "Acceptance Basis"]):
            docx_set_cell(deliverables.rows[0].cells[idx], header, bold=True)
        for item in [
            ("Service schedule / start coordination", "Before performance begins", "Accepted by requiring activity POC."),
            ("Service log or completion ticket", "Each service period", "Supports receiving and invoice review."),
            ("Deficiency correction status", "As needed", "Closed after Government confirms correction."),
        ]:
            cells = deliverables.add_row().cells
            for idx, value in enumerate(item):
                docx_set_cell(cells[idx], value, bold=idx == 0)
    else:
        doc.add_heading("1. Scope of Work", level=1)
        doc.add_paragraph(
            f"The Contractor shall provide all labor, materials, equipment, supervision, transportation, and incidentals necessary to perform {s.archetype['requirement']}."
        )
        doc.add_heading("2. Work Requirements", level=1)
        work_table = doc.add_table(rows=1, cols=2)
        work_table.style = "Table Grid"
        docx_set_cell(work_table.rows[0].cells[0], "Work Element", bold=True)
        docx_set_cell(work_table.rows[0].cells[1], "Requirement", bold=True)
        for element, requirement in sow_work_rows(s):
            cells = work_table.add_row().cells
            docx_set_cell(cells[0], element, bold=True)
            docx_set_cell(cells[1], requirement)
        doc.add_heading("3. Schedule and Coordination", level=1)
        doc.add_paragraph(
            f"{s.archetype['delivery_note']} The Contractor shall coordinate the work schedule with the Government before mobilization and shall not change the schedule without Contracting Officer direction."
        )
        doc.add_heading("4. Submittals", level=1)
        submittals = doc.add_table(rows=1, cols=3)
        submittals.style = "Table Grid"
        for idx, header in enumerate(["Submittal", "Due", "Purpose"]):
            docx_set_cell(submittals.rows[0].cells[idx], header, bold=True)
        for item in [
            ("Work plan / schedule", "Before field work", "Confirm sequence, access, and phasing."),
            ("Safety plan or daily safety approach", "Before field work", "Document hazard controls and work area protection."),
            ("Completion documentation", "At closeout", "Support inspection, acceptance, and payment file."),
        ]:
            cells = submittals.add_row().cells
            for idx, value in enumerate(item):
                docx_set_cell(cells[idx], value, bold=idx == 0)
        doc.add_heading("5. Inspection and Acceptance", level=1)
        doc.add_paragraph(
            f"The Government will inspect completed work for conformance with this SOW. Acceptance will be documented by {person_display(s.requester)} or another designated Government representative."
        )

    doc.save(str(path))


def write_initial_documents(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    requester_name = person_display(s.requester)
    co_name = s.co["name"]
    subject = f"{s.archetype['title']} - Requirements Package"
    requester = requester_header(s)
    approver = approver_header(s)
    co = co_header(s, data)
    support_doc = requirement_support_doc_name(s)
    sor_doc = compact_doc_name(s, "SOR", "docx")
    requirement_attachments = [sor_doc]
    if support_doc:
        requirement_attachments.append(support_doc)
    requirement_attachments.append("IGE.pdf")
    ordering_note = f"\n\nOrdering vehicle note: {ordering_relationship_sentence(s)}" if is_ordering_action(s) else ""
    requirement_note = variation_text(s, "requirement_note")
    evaluation_note = technical_review_context_note(variation_text(s, "evaluation_note"))
    requirement_context = f"\n\nFor context, {requirement_note}" if requirement_note else ""
    evaluation_context = f"\n\nFile context: {evaluation_note}" if evaluation_note else ""

    approval_lead = pick_phrase(
        s,
        "req_approval_lead",
        [
            "The requiring activity validated the need and approved release of the SOR and IGE. We have enough mission detail to start the acquisition file, but the package is still rough in the usual places.",
            "Requirement is validated on our end and the SOR/IGE are approved for release. The package should give you enough to open the file; let us know where it needs work.",
            "We reviewed and approved the attached requirement. The SOR and IGE are good to release to contracting, although a couple of areas may need refinement once vendors start asking questions.",
        ],
    )
    approval_close = pick_phrase(
        s,
        "req_approval_close",
        [
            "Please advise if you need cleaner quantities, a site visit, or a different funding trail before you release the solicitation.",
            "Reach back if you need better quantities or a walkthrough before solicitation.",
            "If anything in the package blocks solicitation release, send it back and we will turn it quickly.",
        ],
    )
    request_lead = pick_phrase(
        s,
        "req_request_lead",
        [
            f"Request approval to route the attached requirement for {s.archetype['requirement']}.",
            f"Requesting your approval on the attached package for {s.archetype['requirement']}.",
            f"Attached requirement for {s.archetype['requirement']} is ready for your review and approval.",
        ],
    )
    request_close = pick_phrase(
        s,
        "req_request_close",
        [
            "I built the estimate from the information we have on hand. If contracting needs a cleaner breakout, I can revise it after they tell us what they need.",
            "The estimate uses the best information available to the shop right now; happy to rework it if contracting needs a different breakout.",
            "Estimate is based on what we have on hand. I can refine quantities or pricing assumptions if contracting asks.",
        ],
    )

    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Req Email"),
        subject,
        [
            {
                "from": approver,
                "sent": f"{fmt_date(s.timeline['ige'])} {email_time(s, 't1', 6, 42)}",
                "to": co,
                "cc": requester,
                "subject": f"FW: {subject}",
                "body": with_greeting(
                    s,
                    "approver",
                    person_display(s.co["name"]),
                    (
                        f"{approval_lead}\n\n"
                        f"Requested delivery/performance: NLT {fmt_date(s.timeline['delivery'])}. "
                        f"{approval_close}"
                        f"{requirement_context}"
                        f"{ordering_note}"
                    ),
                    key="req_fw",
                ),
                "attachments": requirement_attachments,
                "signature": approver_signature(s),
                "closing": persona_closing(s, "approver"),
            },
            {
                "from": requester,
                "sent": f"{fmt_date(s.timeline['requirement'])} {email_time(s, 't2', 9, 18)}",
                "to": approver,
                "subject": subject,
                "body": with_greeting(
                    s,
                    "requester",
                    "Sir/Ma'am",
                    (
                        f"{request_lead} "
                        f"The requested need date is {fmt_date(s.timeline['delivery'])}. The current mission impact is manageable, "
                        "but delay will increase operational risk.\n\n"
                        f"{request_close}"
                        f"{requirement_context}"
                        f"{ordering_note}"
                    ),
                    key="req_request",
                ),
                "attachments": requirement_attachments,
                "signature": requester_signature(s),
                "closing": persona_closing(s, "requester"),
            },
        ],
    )

    sor_lead = pick_phrase(
        s,
        "sor_lead",
        [
            "Attached is the statement of requirements and supporting information.",
            "Statement of requirements and supporting documents are attached for the file.",
            "Sending over the SOR and supporting information for this requirement.",
        ],
    )
    sor_close = pick_phrase(
        s,
        "sor_close",
        [
            "We are available to answer vendor questions, but please route anything that changes price, delivery, or performance back through the approval chain. The attached requirement documents are the versions approved by the mission partner.",
            "If vendors have questions we can support, but changes to price, delivery, or performance need to come back through the approval chain. These attachments are the approved versions.",
            "Happy to support vendor questions. Anything that moves price, delivery, or performance needs approval-chain review first. Attached versions are the ones the mission partner approved.",
        ],
    )

    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "SOR Email"),
        f"SOR - {s.archetype['title']}",
        [
            {
                "from": requester,
                "sent": f"{fmt_date(s.timeline['requirement'])} {email_time(s, 't3', 13, 6)}",
                "to": co,
                "cc": approver,
                "subject": f"SOR - {s.archetype['title']}",
                "body": with_greeting(
                    s,
                    "requester",
                    person_display(s.co["name"]),
                    (
                        f"{sor_lead} "
                        f"The delivery/performance location is {s.delivery_address.replace(chr(10), ', ')}.\n\n"
                        f"{sor_close}"
                        f"{requirement_context}"
                        f"{ordering_note}"
                    ),
                    key="sor_email",
                ),
                "attachments": requirement_attachments[:-1],
                "signature": requester_signature(s),
                "closing": persona_closing(s, "requester"),
            }
        ],
    )

    write_sor_docx(folder / sor_doc, s)
    if support_doc:
        write_requirement_support_docx(folder / support_doc, s)

    write_pdf(
        folder / compact_doc_name(s, "IGE"),
        "Independent Government Estimate",
        f"{s.archetype['title']} | {funding_reference_label(s)}",
        [
            {
                "heading": "Estimate Summary",
                "table": line_item_table(s.line_items, include_unit_price=True),
                "widths": [0.45 * inch, 2.65 * inch, 0.45 * inch, 0.45 * inch, 1.15 * inch, 1.15 * inch],
            },
            {
                "heading": "Basis of Estimate",
                "paragraphs": [
                    f"The estimate is based on prior deployed support actions, informal market checks, commercial catalog information, and customer technical input. Specific prior year references have been generalized for exercise reuse.",
                    *([ordering_relationship_sentence(s)] if is_ordering_action(s) else []),
                    *(
                        [f"Estimated annual usage for planning only (a BPA establishes no ceiling): {money(float(s.archetype.get('_master_estimated_value') or s.base_amount))}."]
                        if s.category == "bpa"
                        else [f"Planned IDIQ ceiling: {money(idiq_ceiling_value(s))}; guaranteed minimum: {money(idiq_minimum_value(s))}."]
                        if s.category == "idiq"
                        else [f"Estimated amount for planning and funding: {money(s.base_amount)}."]
                    ),
                    *(["The master vehicle estimate does not obligate funds. Funding belongs on individual calls or orders."] if is_master_vehicle(s) else []),
                ],
            },
        ],
    )

    eval_subject = f"Evaluation approach - {s.archetype['title']}"
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Eval Approach"),
        eval_subject,
        [
            {
                "from": approver,
                "sent": f"{fmt_date(s.timeline['market_research'])} {email_time(s, 't4', 15, 12)}",
                "to": co,
                "cc": requester,
                "subject": f"RE: {eval_subject}",
                "body": (
                    "Concur with the approach below. Please keep the evaluation straightforward in the solicitation.\n\n"
                    f"For the mission partner, Technical should consist of {technical_consideration_summary(s)}. "
                    "Contracting can handle Price and Past Performance in the award decision.\n\n"
                    "If a vendor is technically acceptable but has an obvious performance risk, flag it before award."
                    f"{evaluation_context}"
                ),
                "signature": approver_signature(s),
                "closing": persona_closing(s, "approver"),
            },
            {
                "from": co,
                "sent": f"{fmt_date(s.timeline['market_research'])} {email_time(s, 't5', 11, 36)}",
                "to": approver,
                "cc": requester,
                "subject": eval_subject,
                "body": apply_persona_texture(
                    s,
                    "co",
                    (
                        pick_phrase(
                            s,
                            "eval_co_lead",
                            [
                                "Before I release this, I need your call on what matters most so the solicitation matches the mission need.",
                                "Before this goes out, confirm the evaluation priorities below so the solicitation matches what the mission actually needs.",
                                "Need your input on evaluation priorities before I release the solicitation.",
                            ],
                        )
                        + "\n\n"
                        f"My recommended evaluation approach is {evaluation_strategy_summary(s)}\n\n"
                        "I will keep the evaluation simple and avoid creating a formal source-selection style record. "
                        "Please confirm those are the right mission drivers."
                        f"{evaluation_context}"
                    ),
                    key="eval_co",
                ),
                "signature": co_signature(s, data),
                "closing": persona_closing(s, "co"),
            },
            {
                "from": requester,
                "sent": f"{fmt_date(s.timeline['ige'])} {email_time(s, 't6', 16, 4)}",
                "to": co,
                "cc": approver,
                "subject": eval_subject,
                "body": (
                    "Can you let us know what evaluation approach you plan to use? We want to make sure the solicitation reflects what matters to the mission partner before it goes out.\n\n"
                    "We can support a technical review if you need us to look at quotes after receipt."
                ),
                "signature": requester_signature(s),
                "closing": persona_closing(s, "requester"),
            },
        ],
    )


F9_LABELS = [
    (13.4, 158.1, 4.6, "NO.", "normal", 6.5, "left", False),
    (15.5, 62.0, 90.0, "Request for Purchase", "bold", 11, "left", False),
    (21.9, 13.5, 17.8, "INSTALLATION", "normal", 6.5, "left", False),
    (21.9, 158.1, 6.8, "DATE", "normal", 6.5, "left", False),
    (30.3, 158.1, 8.4, "CLASS", "normal", 6.5, "left", False),
    (38.8, 13.5, 13.6, "THROUGH:", "bold", 6.5, "left", False),
    (38.8, 158.0, 42.7, "CONTRACT, PURCHASE ORDER OR\nDELIVERY ORDER NO.", "normal", 6.5, "left", True),
    (49.9, 13.5, 8.5, "FROM:", "bold", 6.5, "left", False),
    (56.0, 34.4, 151.9, "IT IS REQUESTED THAT THE SUPPLIES AND SERVICES ENUMERATED BELOW AND IN THE ATTACHED LIST, BE", "normal", 6.5, "left", False),
    (60.0, 13.5, 22.0, "PURCHASED FOR", "normal", 6.5, "left", False),
    (60.0, 84.7, 22.5, "FOR DELIVERY TO", "normal", 6.5, "left", False),
    (60.0, 158.1, 21.5, "NOT LATER THAN", "normal", 6.5, "left", False),
    (68.7, 181.5, 15.7, "ESTIMATED\nTOTAL COST", "normal", 6.5, "left", True),
    (70.6, 13.5, 11.7, "ITEM", "normal", 6.5, "left", False),
    (70.6, 39.4, 76.6, "DESCRIPTION OF MATERIAL OR SERVICES TO BE PURCHASED", "normal", 6.3, "left", False),
    (70.6, 127.3, 14.6, "QUANTITY", "normal", 6.5, "left", False),
    (70.6, 142.8, 9.8, "UNIT", "normal", 6.5, "left", False),
    (193.3, 164.7, 10.0, "TOTAL", "bold", 6.5, "right", False),
    (198.6, 13.5, 12.4, "PURPOSE", "bold", 6.5, "left", False),
    (208.4, 13.5, 6.8, "DATE", "normal", 6.5, "left", False),
    (208.6, 54.2, 64.8, "TYPED NAME AND GRADE OF REQUESTING OFFICIAL", "normal", 6.5, "left", False),
    (208.4, 127.8, 14.7, "SIGNATURE", "normal", 6.5, "left", False),
    (216.4, 127.8, 20.5, "TELEPHONE NO.", "normal", 6.5, "left", False),
    (224.9, 13.5, 6.8, "DATE", "normal", 6.5, "left", False),
    (224.9, 54.2, 63.3, "TYPED NAME AND GRADE OF APPROVING OFFICIAL", "normal", 6.5, "left", False),
    (224.9, 127.8, 14.7, "SIGNATURE", "normal", 6.5, "left", False),
    (238.0, 16.6, 175.8, "I certify that the supplies and services listed above and in the attached list are properly chargeable to the following allotments, the available balances of which are sufficient to cover the cost thereof, and funds have been committed.", "normal", 6.5, "left", True),
    (246.2, 13.5, 37.9, "ACCOUNTING CLASSIFICATION", "normal", 6.5, "left", False),
    (246.2, 156.0, 10.9, "AMOUNT", "normal", 6.5, "left", False),
    (254.7, 13.5, 6.8, "DATE", "normal", 6.5, "left", False),
    (254.7, 127.8, 14.7, "SIGNATURE", "normal", 6.5, "left", False),
    (255.0, 54.2, 64.1, "TYPED NAME AND GRADE OF CERTIFYING OFFICIAL", "normal", 6.5, "left", False),
    (267.4, 13.5, 38.9, "AF IMT 9, 19770301, V2", "normal", 6, "left", False),
]

F9_LINES = [
    (21.12, 157.33, 45.69, "h"), (21.11, 12.86, 144.78, "h"),
    (29.72, 12.78, 190.35, "h"), (38.18, 12.78, 190.35, "h"),
    (46.63, 12.78, 144.53, "h"), (55.12, 12.78, 190.35, "h"),
    (59.33, 12.78, 190.35, "h"), (67.82, 12.78, 190.35, "h"),
    (75.59, 12.78, 190.35, "h"), (191.59, 12.78, 190.35, "h"),
    (197.51, 12.78, 190.35, "h"), (207.92, 12.78, 190.35, "h"),
    (215.72, 126.82, 76.30, "h"), (224.18, 12.78, 190.35, "h"),
    (236.88, 12.78, 190.35, "h"), (245.62, 12.78, 190.35, "h"),
    (254.08, 12.78, 190.35, "h"),
    (67.82, 25.22, 123.77, "v"), (207.92, 53.42, 28.96, "v"),
    (254.08, 53.42, 12.72, "v"), (59.33, 83.64, 8.46, "v"),
    (67.82, 126.82, 123.77, "v"), (207.92, 126.82, 28.96, "v"),
    (254.08, 126.82, 12.72, "v"), (67.82, 142.32, 123.77, "v"),
    (245.62, 155.02, 8.46, "v"), (12.88, 157.68, 8.07, "v"),
    (67.82, 175.08, 129.72, "v"), (59.33, 153.06, 132.26, "v"),
    (21.12, 157.50, 34.01, "v"),
]

F9_RECT = (12.70, 12.88, 190.50, 254.00)
F9_FIELDS = {
    "NUMBER": (158.6, 16.0, 43.5),
    "INSTAL": (13.2, 24.5, 143.7),
    "DATE_2": (164.8, 24.5, 32.5),
    "CONTOFF": (13.2, 32.9, 143.7),
    "CLASS": (158.6, 32.9, 43.5),
    "THROUGH": (27.5, 41.4, 129.4),
    "PONUMBER": (158.3, 46.7, 43.5),
    "FROM": (22.5, 49.9, 134.4),
    "FOR": (13.2, 62.6, 68.9),
    "DELIVERTO": (84.4, 62.6, 68.1),
    "NLTDATE": (157.7, 62.6, 43.6),
    "GRNDTOT": (175.6, 192.6, 27.1),
    "PURPOSE": (14.0, 200.0, 188.0),
    "RQSTDATE": (16.5, 213.0, 33.0),
    "REQNAME": (54.3, 213.0, 71.6),
    "PHONE": (127.3, 220.5, 75.4),
    "APPRDATE": (17.1, 229.2, 33.0),
    "APPRNAME": (54.0, 229.2, 71.6),
    "ACCTCLASS": (13.2, 249.1, 141.4),
    "ACCTAMT": (155.5, 249.1, 47.2),
    "CTFYDATE": (16.5, 258.5, 33.0),
    "CTFYNAME": (54.1, 258.5, 71.6),
}
F9_ITEM_ROW_HEIGHT = 5.5
F9_ITEM_FIRST_Y = 76.6


def pt_x(x_mm: float) -> float:
    return x_mm * mm


def pt_y(y_mm: float) -> float:
    return letter[1] - y_mm * mm


def draw_top_left_text(
    canvas: Any,
    text: str,
    x_mm: float,
    y_mm: float,
    width_mm: float,
    size: float = 6.5,
    bold: bool = False,
    align: str = "left",
    leading: float | None = None,
    max_lines: int | None = None,
) -> None:
    font = "Helvetica-Bold" if bold else "Helvetica"
    canvas.setFont(font, size)
    lines: list[str] = []
    for raw_line in str(text).splitlines() or [""]:
        lines.extend(split_text_to_width(canvas, raw_line, width_mm * mm, font, size))
    if max_lines is not None:
        lines = lines[:max_lines]
    line_height = leading or (size * 1.15)
    x = pt_x(x_mm)
    y = pt_y(y_mm) - size
    for idx, line in enumerate(lines):
        yy = y - idx * line_height
        if align == "center":
            canvas.drawCentredString(x + (width_mm * mm) / 2, yy, line)
        elif align == "right":
            canvas.drawRightString(x + width_mm * mm, yy, line)
        else:
            canvas.drawString(x, yy, line)


def split_text_to_width(canvas: Any, text: str, width_pt: float, font: str, size: float) -> list[str]:
    words = str(text).split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if not current or canvas.stringWidth(candidate, font, size) <= width_pt:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [""]


def draw_value(
    canvas: Any,
    field: str,
    text: str,
    align: str = "left",
    size: float = 9,
    max_lines: int = 1,
) -> None:
    if text in ("", None):
        return
    x_mm, y_mm, w_mm = F9_FIELDS[field]
    font = "Courier"
    canvas.setFont(font, size)
    lines = []
    for raw in str(text).splitlines() or [""]:
        lines.extend(split_text_to_width(canvas, raw, w_mm * mm - 2, font, size))
    lines = lines[:max_lines]
    line_height = size * 1.15
    for idx, line in enumerate(lines):
        x = pt_x(x_mm) + (1 if align == "left" else 0)
        y = pt_y(y_mm + 0.5) - size - idx * line_height
        if align == "center":
            canvas.drawCentredString(pt_x(x_mm + w_mm / 2), y, line)
        elif align == "right":
            canvas.drawRightString(pt_x(x_mm + w_mm) - 1, y, line)
        else:
            canvas.drawString(x, y, line)


def draw_signature(canvas: Any, name: str, x_mm: float, y_mm: float, w_mm: float, h_mm: float) -> None:
    if not name:
        return
    rng = random.Random(name)
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#183A78"))
    canvas.setLineWidth(0.7)
    x0 = pt_x(x_mm + 3)
    y0 = pt_y(y_mm + h_mm / 2)
    width = (w_mm - 8) * mm
    points = []
    for idx in range(9):
        t = idx / 8
        x = x0 + width * t
        y = y0 + (rng.random() - 0.5) * h_mm * mm * 0.55
        points.append((x, y))
    path = canvas.beginPath()
    path.moveTo(*points[0])
    for p1, p2 in zip(points[1:-1], points[2:]):
        c1x = p1[0] - width * 0.04
        c1y = p1[1] + (rng.random() - 0.5) * h_mm * mm
        c2x = p1[0] + width * 0.04
        c2y = p2[1] + (rng.random() - 0.5) * h_mm * mm
        path.curveTo(c1x, c1y, c2x, c2y, p2[0], p2[1])
    canvas.drawPath(path, stroke=1, fill=0)
    canvas.restoreState()


def write_form9_pdf(path: Path, s: Scenario, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    c = pdf_canvas.Canvas(str(path), pagesize=letter)
    c.setTitle(s.pr_number)

    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(colors.HexColor("#B00000"))
    c.drawCentredString(letter[0] / 2, letter[1] - 0.20 * inch, EXERCISE_BANNER)
    c.setFillColor(colors.black)
    c.setStrokeColor(colors.black)
    c.setLineWidth(0.3)

    rect_x, rect_y, rect_w, rect_h = F9_RECT
    c.rect(pt_x(rect_x), pt_y(rect_y + rect_h), rect_w * mm, rect_h * mm, stroke=1, fill=0)

    for y, x, length, direction in F9_LINES:
        if direction == "h":
            c.line(pt_x(x), pt_y(y), pt_x(x + length), pt_y(y))
        else:
            c.line(pt_x(x), pt_y(y), pt_x(x), pt_y(y + length))

    for y, x, width, text, weight, size, align, wrap in F9_LABELS:
        draw_top_left_text(
            c,
            text,
            x,
            y,
            width,
            size=size,
            bold=weight == "bold",
            align=align,
            leading=size * 1.15,
            max_lines=3 if wrap else 1,
        )

    purpose = (
        f"{s.archetype['requirement']}. Requirement supports deployed mission operations. "
        f"Exercise file only. {EXERCISE_BANNER}"
    )
    total_amount = line_item_total(s.line_items)
    certified_total = total_amount
    shortfall_amount = s.archetype.get("_inject_funding_shortfall_amount")
    if shortfall_amount:
        certified_total = float(shortfall_amount)

    draw_value(c, "NUMBER", s.pr_number, "center")
    draw_value(c, "INSTAL", data["contracting_office"]["installation"])
    draw_value(c, "DATE_2", fmt_form9_date(s.timeline["funding"]), "center")
    draw_value(c, "CONTOFF", data["contracting_office"]["office_symbol"])
    draw_value(c, "CLASS", "ROUTINE", "center")
    draw_value(c, "THROUGH", f"{s.customer['unit']}/CC")
    draw_value(c, "PONUMBER", parent_reference_label(s) if is_ordering_action(s) else "")
    draw_value(c, "FROM", s.customer["unit"])
    draw_value(c, "FOR", s.customer["unit"])
    draw_value(c, "DELIVERTO", s.delivery_address.replace("\n", " "), max_lines=1)
    draw_value(c, "NLTDATE", fmt_form9_date(s.timeline["delivery"]), "center")

    for idx, item in enumerate(s.line_items[:12]):
        c.setFont("Courier", 9)
        row_y = F9_ITEM_FIRST_Y + 0.7 + idx * 8.2
        c.drawCentredString(pt_x(13.2 + 11.7 / 2), pt_y(row_y) - 9, item["clin"])
        desc_lines = split_text_to_width(c, item["description"], (100.8 - 1) * mm, "Courier", 9)
        c.drawString(pt_x(26.5), pt_y(row_y) - 9, desc_lines[0])
        if len(desc_lines) > 1:
            c.setFont("Courier", 7.5)
            c.drawString(pt_x(26.5), pt_y(row_y + 3.9) - 7.5, desc_lines[1])
            c.setFont("Courier", 9)
        c.drawRightString(pt_x(127.3 + 14.6) - 2, pt_y(row_y) - 9, item["quantity"])
        c.drawCentredString(pt_x(142.9 + 9.8 / 2), pt_y(row_y) - 9, item["unit"])
        c.drawRightString(pt_x(153.6 + 21.1) - 2, pt_y(row_y) - 9, money(item["unit_price"]))
        c.drawRightString(pt_x(175.6 + 27.1) - 2, pt_y(row_y) - 9, money(item["amount"]))

    draw_value(c, "GRNDTOT", money(certified_total), "right")
    draw_top_left_text(c, purpose, 14.0, 200.0, 188.0, size=8, leading=9.5, max_lines=3)
    draw_value(c, "RQSTDATE", fmt_form9_date(s.timeline["requirement"]), "center")
    draw_value(c, "REQNAME", s.requester, max_lines=1)
    draw_signature(c, s.requester, 127.8, 209, 75, 6)
    draw_value(c, "PHONE", "DSN 318-455-XXXX")
    draw_value(c, "APPRDATE", fmt_form9_date(s.timeline["funding"]), "center")
    draw_value(c, "APPRNAME", s.approver, max_lines=1)
    draw_signature(c, s.approver, 127.8, 225.5, 75, 9.5)
    draw_value(c, "ACCTCLASS", s.loa, max_lines=1)
    draw_value(c, "ACCTAMT", money(certified_total), "right")
    if not s.archetype.get("_inject_missing_certification"):
        draw_value(c, "CTFYDATE", fmt_form9_date(s.timeline["funding"]), "center")
        draw_value(c, "CTFYNAME", s.certifier, max_lines=1)
        draw_signature(c, s.certifier, 127.8, 255, 75, 10)

    c.showPage()
    c.save()


def write_master_vehicle_funding_memo(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    vehicle_label = master_vehicle_label(s.category)
    action_label = "BPA calls" if s.category == "bpa" else "task or delivery orders"
    guarantee_note = f" See {compact_doc_name(s, 'Min Guarantee')}." if s.category == "idiq" else ""
    write_pdf(
        folder / compact_doc_name(s, "No Funding"),
        f"Funding Note - Master {vehicle_label}",
        f"{s.contract_number} | {s.archetype['title']}",
        [
            {
                "heading": "Purpose",
                "paragraphs": [
                    f"This folder documents establishment of a master {vehicle_label}. The master vehicle itself does not obligate funds and does not authorize performance until an individual {'call' if s.category == 'bpa' else 'order'} is issued.",
                    f"The absence of a Form 9 or LOA citation on the master agreement is intentional for this training file. Funding must be validated on each {action_label[:-1] if action_label.endswith('s') else action_label} before performance or payment.",
                ],
            },
            {
                "heading": "Funding Control",
                "table": [
                    ["Field", "Value"],
                    [f"{vehicle_label} Number", s.contract_number],
                    ["Funding Document", f"N/A - {vehicle_label} MASTER"],
                    ["ACRN / LOA", f"Not cited on master {vehicle_label}"],
                    *([
                        ["Per-Call Purchase Limitation", money(bpa_call_limit_value(s))],
                        ["Ceiling", "None - BPAs do not establish a ceiling"],
                    ] if s.category == "bpa" else [
                        ["IDIQ Ceiling (Maximum)", money(idiq_ceiling_value(s))],
                        ["Guaranteed Minimum", money(idiq_minimum_value(s))],
                        ["Minimum Guarantee Tracking", f"See {compact_doc_name(s, 'Min Guarantee')}"],
                    ]),
                    ["Funding Location", f"Individual {action_label}"],
                ],
                "widths": [1.65 * inch, 4.85 * inch],
            },
            {
                "heading": "Controller Note",
                "paragraphs": [
                    f"If a trainee attempts to pay from the master {vehicle_label} alone, the correct issue is that the master agreement contains no funds. The trainee should locate the specific {'call' if s.category == 'bpa' else 'task or delivery order'} and confirm the number, funding citation, receipt, and invoice support.{guarantee_note}"
                ],
            },
        ],
    )
    if s.category == "idiq":
        write_idiq_minimum_guarantee_memo(folder, s)


def write_idiq_minimum_guarantee_memo(folder: Path, s: Scenario) -> None:
    write_pdf(
        folder / compact_doc_name(s, "Min Guarantee"),
        "Minimum Guarantee Tracking Memo",
        f"{s.contract_number} | {s.archetype['title']}",
        [
            {
                "heading": "Purpose",
                "paragraphs": [
                    "This memo documents how the training file tracks the stated IDIQ guaranteed minimum without using the master agreement as an invoice or payment document.",
                    "The master IDIQ establishes the ordering vehicle. Actual performance and payment are authorized only by funded task or delivery orders issued under the vehicle.",
                ],
            },
            {
                "heading": "Tracking Summary",
                "table": [
                    ["Field", "Value"],
                    ["IDIQ", s.contract_number],
                    ["Guaranteed Minimum", money(idiq_minimum_value(s))],
                    ["Tracking Method", "Minimum guarantee is satisfied or tracked through the first funded task or delivery order(s) issued under the vehicle."],
                    ["Master Funding", "No ACRN or LOA is cited on this master training agreement; do not invoice or pay from the master alone."],
                    ["Trainee Check", "Locate the funded task or delivery order before approving receipt or invoice support."],
                ],
                "widths": [1.65 * inch, 4.85 * inch],
            },
        ],
    )


def write_funding_documents(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    if is_master_vehicle(s):
        write_master_vehicle_funding_memo(folder, s, data)
        return
    write_form9_pdf(folder / compact_doc_name(s, "Form 9"), s, data)


def estimate_value_label(s: Scenario) -> str:
    amounts = [float(quote["amount"]) for quote in s.quote_rows if quote.get("amount") is not None] or [float(s.base_amount)]
    low = min(amounts) * 0.95
    high = max(amounts) * 1.05
    if s.category == "bpa":
        label = "representative basket range; no BPA ceiling"
    elif s.category == "idiq":
        label = "evaluated basket range; see ceiling/minimum"
    else:
        label = "estimated range"
    return f"~${low / 1000:.0f}K - ${high / 1000:.0f}K ({label})"


def funding_reference_label(s: Scenario) -> str:
    if is_master_vehicle(s):
        return f"N/A - {master_vehicle_label(s.category)} MASTER"
    return s.pr_number


def funding_reference_heading(s: Scenario) -> str:
    return "Funding Document" if is_master_vehicle(s) else "PR / Form 9"


def market_research_purpose(s: Scenario) -> str:
    if is_master_vehicle(s):
        action_label = "BPA calls" if s.category == "bpa" else "task or delivery orders"
        return (
            f"Document market research conducted to identify capable sources and support establishing a master {master_vehicle_label(s.category)} "
            f"for {s.archetype['requirement']}. The master vehicle is a contracting solution for recurring requirements; individual {action_label} will cite funding."
        )
    if is_ordering_action(s):
        return (
            f"Document market research confirming that {parent_reference_label(s)} is an available ordering vehicle, "
            f"that {s.contract_number} is within the parent scope, and that the parent awardee can perform {s.archetype['requirement']}."
        )
    return pick_phrase(
        s,
        "mrr_purpose",
        [
            f"Document market research conducted to identify capable sources within the installation vendor pool for {s.archetype['requirement']}, and confirm adequate competition for solicitation.",
            f"Record the market research performed to identify capable sources for {s.archetype['requirement']} and verify that adequate competition exists before solicitation.",
            f"Summarize market research supporting the acquisition of {s.archetype['requirement']}, including the vendor pool reviewed and the basis for expecting adequate competition.",
        ],
    )


def market_research_findings(s: Scenario) -> list[tuple[str, str]]:
    if is_ordering_action(s):
        parent_scope = str(s.parent_vehicle.get("scope") or s.archetype["market_note"])
        return [
            ("Ordering vehicle traceability confirmed.", ordering_relationship_sentence(s)),
            ("Order appears within scope.", f"The requirement aligns with the parent scope: {parent_scope}"),
            ("PR/Form 9 traceability confirmed.", f"This order is tied to Form 9 {s.pr_number} and estimated funding of {money(s.base_amount)}; the parent vehicle itself is not being funded by this action."),
            ("Evaluation priorities captured.", f"Solicitation/evaluation should consider {evaluation_strategy_summary(s)}"),
            ("Parent awardee capability confirmed.", f"{s.winner['name']} is the parent awardee and was contacted for order-specific pricing, delivery, and performance confirmation."),
        ]
    findings = [
        ("Adequate competition exists.", f"{len(s.contractors)} vendor(s) were identified as capable and interested."),
        ("Evaluation priorities captured.", f"Solicitation/evaluation should consider {evaluation_strategy_summary(s)}"),
        ("Requirement appears commercially supportable.", s.archetype["market_note"]),
    ]
    if is_master_vehicle(s):
        vehicle_label = master_vehicle_label(s.category)
        action_label = "BPA calls" if s.category == "bpa" else "task or delivery orders"
        findings.insert(
            1,
            (
                f"{vehicle_label} vehicle strategy supported.",
                f"The requirement is recurring or order-based in nature, so a master {vehicle_label} is appropriate. Funding will be placed on individual {action_label}, not on the master vehicle.",
            ),
        )
        findings.insert(
            2,
            (
                "Funding traceability controlled at order level.",
                f"The master file should not contain a funded Form 9 for the full ceiling. Each future {action_label[:-1] if action_label.endswith('s') else action_label} should include its own PR/Form 9, LOA, scope, quantity, and acceptance documentation.",
            ),
        )
    else:
        findings.insert(
            1,
            ("PR/Form 9 traceability confirmed.", f"Market research is tied to Form 9 {s.pr_number} and estimated funding of {money(s.base_amount)}."),
        )
        if s.archetype.get("_ai_plan_guardrail"):
            findings.insert(
                2,
                (
                    "Instrument classification retained by contracting.",
                    f"Contracting treated this as a {category_label(s).lower()} because the primary requirement is {s.archetype['clin_description']}. Incidental delivery, offload, staging, placement, or setup support did not change the core acquisition type.",
                ),
            )
    if is_ordering_action(s):
        findings.insert(1, ("Ordering vehicle traceability confirmed.", ordering_relationship_sentence(s)))
    return findings


def market_research_recommendation(s: Scenario) -> str:
    if is_master_vehicle(s):
        vehicle_label = master_vehicle_label(s.category)
        action_label = "BPA calls" if s.category == "bpa" else "task or delivery orders"
        return (
            f"Proceed with competitive solicitation to establish a master {vehicle_label} with the vendor pool identified above. "
            f"The master vehicle should document ordering scope, ceiling, price list or ordering terms, and evaluation approach, but should not obligate the full ceiling. "
            f"Use separate {action_label} for funded requirements and evaluate responses using {evaluation_strategy_summary(s)}"
        )
    if is_ordering_action(s):
        return (
            f"Proceed with the funded {call_or_order_label(s).lower()} under {parent_reference_label(s)}. "
            f"The file should retain the order-specific PR/Form 9, scope, quantity, price confirmation, technical review, and acceptance documentation. "
            f"Award decision should confirm the order is within parent scope and that {s.winner['name']} remains the proper awardee for this order."
        )
    return pick_phrase(
        s,
        "mrr_recommend",
        [
            f"Proceed with competitive solicitation to the vendor pool identified above. Use the PR/Form 9 package as the funding baseline and evaluate responses using {evaluation_strategy_summary(s)} "
            f"Expected award value remains within the planned training range and should be documented against {s.pr_number}.",
            f"Recommend competitive solicitation to the vendors identified above, with the PR/Form 9 package as the funding baseline. Evaluate responses using {evaluation_strategy_summary(s)} "
            f"Anticipated value supports simplified procedures and should be documented against {s.pr_number}.",
            f"Competition is adequate; proceed to solicitation using the vendor pool above. Evaluation should follow {evaluation_strategy_summary(s)} "
            f"Fund and document the action against {s.pr_number}.",
        ],
    )


def customer_mrr_label(s: Scenario) -> str:
    return (
        f"{customer_office_symbol(s.customer['unit'])} ({person_display(s.requester)}) / "
        f"{approver_office_symbol(s)} ({person_display(s.approver)})"
    )


def mrr_vendor_note(s: Scenario, vendor: dict[str, str], idx: int) -> str:
    if is_ordering_action(s):
        return "Parent awardee; contacted to confirm order-specific capacity, pricing, delivery, and performance support."
    base_notes = [
        "Confirmed interest and capability; can meet the stated delivery/performance window.",
        "Base-support contractor; will quote and coordinate access/staging.",
        "Prior related installation work; POC confirmed available resources.",
        "Local deployed footprint; can source labor, equipment, or materials regionally.",
        "Responsive to outreach; capability appears adequate for solicitation.",
        "Returned the capability call same day; no concerns with the requirement as described.",
        "Smaller shop, but POC stated they can support this scope within the window.",
    ]
    scenario_rng(s, "mrr_vendor_notes").shuffle(base_notes)
    note = base_notes[idx % len(base_notes)]
    if vendor["name"] == s.winner["name"]:
        note += " Strong preliminary fit."
    return note


def write_market_research(folder: Path, s: Scenario) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / compact_doc_name(s, "MRR")
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="MrrTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=14,
            leading=16,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#17365D"),
            spaceAfter=3,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrSubtitle",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=9,
            leading=10,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#4F4F4F"),
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrHeading",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=9.2,
            leading=10,
            textColor=colors.HexColor("#17365D"),
            spaceBefore=7,
            spaceAfter=3,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrBody",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=8,
            leading=9.4,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrSmall",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=6.8,
            leading=7.8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrSmallBold",
            parent=styles["MrrSmall"],
            fontName="Helvetica-Bold",
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrTableHeader",
            parent=styles["MrrSmallBold"],
            textColor=colors.white,
        )
    )
    styles.add(
        ParagraphStyle(
            name="MrrBullet",
            parent=styles["MrrBody"],
            leftIndent=14,
            bulletIndent=5,
            spaceAfter=0.8,
        )
    )

    story: list[Any] = [
        p("MARKET RESEARCH MEMORANDUM FOR RECORD", styles["MrrTitle"]),
        p(s.archetype["title"], styles["MrrSubtitle"]),
    ]

    meta_rows = [
        ["Requirement", s.archetype["requirement"], funding_reference_heading(s), funding_reference_label(s)],
        ["Customer", customer_mrr_label(s), "Estimated Value", estimate_value_label(s)],
        ["Prepared By", f"{s.co['name']}, CCO, XXX ECONS/LGCA", "Date", fmt_date(s.timeline["market_research"])],
    ]
    if is_ordering_action(s):
        meta_rows.append(["Parent Instrument", parent_reference_label(s), call_or_order_label(s), s.contract_number])
    meta_table = Table(
        [[p(cell, styles["MrrSmallBold"] if col in [0, 2] else styles["MrrSmall"]) for col, cell in enumerate(row)] for row in meta_rows],
        colWidths=[1.35 * inch, 3.05 * inch, 1.35 * inch, 1.25 * inch],
        hAlign="LEFT",
    )
    meta_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F0F0F0")),
                ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#F0F0F0")),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7B7B7")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(meta_table)

    def heading(text: str) -> None:
        story.append(p(text, styles["MrrHeading"]))
        rule = Table([[""]], colWidths=[7.0 * inch], hAlign="LEFT")
        rule.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.45, colors.HexColor("#B7B7B7"))]))
        story.append(rule)

    heading("1. Purpose")
    story.append(
        p(
            market_research_purpose(s),
            styles["MrrBody"],
        )
    )

    heading("2. Methodology")
    if is_ordering_action(s):
        methodology = (
            f"Reviewed {parent_reference_label(s)}, the package vehicle registry, the requirement email traffic, and the order-specific funding document. "
            f"Contacted {s.winner['name']} to confirm the order quantity, price-list applicability, delivery or performance timing, and any mission constraints."
        )
    else:
        methodology = (
            f"Screened the installation vendor pool, contacted {len(s.contractors)} vendor(s) to confirm interest/capacity, and reviewed priorities from the evaluation-approach email traffic."
        )
    story.append(
        p(
            methodology,
            styles["MrrBody"],
        )
    )

    heading("3. Vendors Surveyed")
    vendor_rows = [["Vendor", "UEI", "Capability / Notes", "Disposition"]]
    for idx, vendor in enumerate(s.contractors):
        vendor_rows.append(
            [
                vendor["name"],
                vendor["code"],
                mrr_vendor_note(s, vendor, idx),
                "Parent awardee" if is_ordering_action(s) else "Will solicit",
            ]
        )
    vendor_table = Table(
        [
            [
                p(
                    cell,
                    styles["MrrTableHeader"] if row_idx == 0 else styles["MrrSmallBold" if col_idx == 0 else "MrrSmall"],
                )
                for col_idx, cell in enumerate(row)
            ]
            for row_idx, row in enumerate(vendor_rows)
        ],
        colWidths=[1.85 * inch, 1.05 * inch, 3.35 * inch, 0.75 * inch],
        hAlign="LEFT",
        repeatRows=1,
    )
    vendor_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17365D")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7B7B7")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    for row_idx in range(1, len(vendor_rows)):
        if row_idx % 2 == 1:
            vendor_table.setStyle(TableStyle([("BACKGROUND", (0, row_idx), (-1, row_idx), colors.HexColor("#F7F7F7"))]))
    story.append(vendor_table)

    heading("4. Findings")
    for lead, detail in market_research_findings(s):
        story.append(Paragraph(f"<b>{escape(lead)}</b> {escape(detail)}", styles["MrrBullet"], bulletText="-"))

    heading("5. Acquisition Strategy / Recommendation")
    story.append(
        p(
            market_research_recommendation(s),
            styles["MrrBody"],
        )
    )

    story.append(Spacer(1, 0.08 * inch))
    story.append(p("Prepared and approved:", styles["MrrBody"]))
    story.append(p("//SIGNED//", ParagraphStyle(name="MrrSigned", parent=styles["MrrBody"], fontName="Courier-Bold", fontSize=14, leading=15, textColor=colors.HexColor("#17365D"))))
    for idx, line in enumerate(
        [
            signature_name(s.co["name"]),
            "Contingency Contracting Officer",
            "XXX Expeditionary Contracting Squadron",
            fmt_date(s.timeline["market_research"]),
        ]
    ):
        story.append(p(line, styles["MrrSmallBold" if idx == 0 else "MrrSmall"]))

    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        rightMargin=0.50 * inch,
        leftMargin=0.50 * inch,
        topMargin=0.56 * inch,
        bottomMargin=0.35 * inch,
        title="Market Research Memorandum for Record",
    )
    doc.build(story, onFirstPage=mrr_page_marks, onLaterPages=mrr_page_marks)


def use_simple_rfq_email(s: Scenario) -> bool:
    return s.solicitation_style == "rfq-email"


def evaluation_factor_list(s: Scenario) -> list[str]:
    return evaluation_factors_from_focus(s.archetype["evaluation_focus"])


def is_price_factor(factor: str) -> bool:
    lower = factor.lower()
    return "price" in lower or "cost" in lower


def factor_evaluation_approach(factor: str, s: Scenario | None = None) -> str:
    lower = factor.lower()
    if is_price_factor(factor):
        return "Price will be evaluated for fairness, reasonableness, completeness, and total evaluated price."
    if "past performance" in lower:
        return "Past Performance will be evaluated using recent and relevant information available to the Government, customer input, and any quote information provided."
    if "technical" in lower:
        if s is None:
            return "Technical will be reviewed to determine whether the quote meets the Government's requirement and presents acceptable performance risk."
        return f"Technical will consist of {technical_consideration_summary(s)}. These items will be reviewed together to determine whether the quote meets the Government's requirement and presents acceptable performance risk."
    return f"{factor_title(factor)} will be reviewed as a technical consideration for acceptability and mission risk."


def technical_factor_list(s: Scenario) -> list[str]:
    return technical_factor_list_from_archetype(s.archetype)


def quote_submission_items(s: Scenario) -> list[str]:
    items = [
        "Pricing by CLIN, including any delivery, setup, removal, or recurring charges.",
        f"Technical description addressing {technical_consideration_summary(s)}.",
        "Delivery or performance schedule, including earliest available start or delivery date.",
        "Recent and relevant past performance information, unless already known to the Government.",
        "UEI/CAGE or other vendor identifier, point of contact, phone, and email.",
    ]
    items.extend(profile_quote_requirements(s))
    if is_service_requirement(s):
        items.append("Staffing approach, quality control approach, and proposed option-period pricing if applicable.")
    if is_construction_requirement(s):
        items.append("Site-work approach, safety controls, schedule, and confirmation that required permits/access constraints are understood.")
    return items


def solicitation_contract_type(s: Scenario) -> str:
    if s.category == "bpa_call":
        return f"Firm-fixed-price BPA call under {s.parent_contract_number}"
    if s.category == "idiq_order":
        return f"Firm-fixed-price order under {s.parent_contract_number}"
    return "Firm-fixed-price"


def solicitation_award_intent(s: Scenario) -> str:
    if is_multiple_award_master(s):
        vehicle_label = master_vehicle_label(s.category)
        return (
            f"The Government intends to establish a multiple-award {vehicle_label} pool resulting from this solicitation. "
            "Each individual award will carry its own PIID and ordering terms."
        )
    return f"The Government intends to award a {solicitation_contract_type(s).lower()} resulting from this solicitation."


def solicitation_award_basis_label(s: Scenario) -> str:
    if is_multiple_award_master(s):
        return f"Multiple-award best value ({len(master_awardees(s))} anticipated awards)"
    return "Best value: Price, Past Performance, Technical"


def solicitation_evaluation_paragraphs(s: Scenario) -> list[str]:
    if is_multiple_award_master(s):
        return [
            "Awards may be made to multiple responsible offerors whose quotes conform to the solicitation and are most advantageous to the Government for establishing the ordering pool, considering Price, Past Performance, and Technical.",
            f"Technical will consist of {technical_consideration_summary(s)}. These items will be reviewed together as a practical technical check rather than as individually scored items.",
        ]
    return [
        "Award will be made to the responsible offeror whose quote conforms to the solicitation and is most advantageous to the Government, considering Price, Past Performance, and Technical.",
        f"Technical will consist of {technical_consideration_summary(s)}. These items will be reviewed together as a practical technical check rather than as individually scored items.",
    ]


def ordering_solicitation_paragraphs(s: Scenario) -> list[str]:
    if not is_ordering_action(s):
        return []
    return [
        ordering_relationship_sentence(s),
        "Quotes shall be evaluated and awarded only within the scope, ordering limits, and terms of the parent instrument.",
    ]


def solicitation_dates_table(s: Scenario) -> list[list[str]]:
    return [
        ["Event", "Date"],
        ["Solicitation issued", fmt_date(s.timeline["solicitation"])],
        ["Questions due", f"{fmt_date(s.timeline['questions_due'])}, 1600L"],
        ["Government response to questions", fmt_date(s.timeline["questions_due"] + timedelta(days=1))],
        ["Quotes due", f"{fmt_date(s.timeline['quotes_due'])}, 1200L"],
        ["Anticipated award", fmt_date(s.timeline["award"])],
        ["Required delivery/performance", fmt_date(s.timeline["delivery"])],
    ]


def solicitation_instruction_heading(s: Scenario) -> str:
    if is_construction_requirement(s):
        return "3. FAR 52.212-1 / Construction Instructions to Offerors (Tailored Addendum)"
    return "3. FAR 52.212-1 - Instructions to Offerors (Tailored Addendum)"


def solicitation_instruction_paragraphs(s: Scenario) -> list[str]:
    if is_construction_requirement(s):
        return [
            "FAR 52.212-1 is used with a construction/site-work addendum for this commercial construction training acquisition. Quotes shall be submitted by email to the Contracting Officer by the quotes-due date.",
            "Quotes shall address the construction/site-work details below and include only the information needed to evaluate the stated approach.",
            *quote_submission_items(s),
            "Offerors are encouraged to submit their best quote initially. The Government may award without discussions.",
        ]
    return [
        "FAR 52.212-1, Instructions to Offerors - Commercial Products and Commercial Services, applies to this acquisition with the following addendum. Quotes shall be submitted by email to the Contracting Officer by the quotes-due date.",
        "Quotes shall include only the information needed to evaluate the approach stated below.",
        *quote_submission_items(s),
        "Offerors are encouraged to submit their best quote initially. The Government may award without discussions.",
    ]


def solicitation_evaluation_heading(s: Scenario) -> str:
    if is_construction_requirement(s):
        return "4. Evaluation - Commercial Construction / Site Work"
    return "4. Evaluation - Commercial Products and Commercial Services"


def solicitation_clause_rows(s: Scenario) -> list[list[str]]:
    rows = [["Reference", "Title / Use in This Solicitation"]]
    if is_construction_requirement(s):
        rows.extend(
            [
                ["FAR 52.212-1", "Commercial instructions provision used with the construction/site-work addendum in this solicitation."],
                ["FAR 52.212-4", "Commercial terms used with construction/site-work addenda in any resulting award."],
                ["FAR 52.236-2", "Differing Site Conditions."],
                ["FAR 52.236-3", "Site Investigation and Conditions Affecting the Work."],
                ["FAR 52.236-13", "Accident Prevention."],
            ]
        )
    else:
        rows.extend(
            [
                ["FAR 52.212-1", "Instructions to Offerors - Commercial Products and Commercial Services. Applies with the tailored addendum in this solicitation."],
                ["FAR 52.212-2", "Evaluation - Commercial Products and Commercial Services. Evaluation approach is tailored in the solicitation."],
                ["FAR 52.212-4", "Contract Terms and Conditions - Commercial Products and Commercial Services. Applies to any resulting award."],
            ]
        )
    if is_service_requirement(s):
        rows.append(
            ["FAR 52.222-41", "Service Contract Labor Standards. The applicable area wage determination is incorporated by reference and applies to covered service employees."]
        )
    elif not is_construction_requirement(s):
        rows.extend(
            [
                ["FAR 52.211-6", "Brand Name or Equal, when a brand-name reference is used only to describe salient characteristics."],
                ["FAR 52.246-2", "Inspection of Supplies - Fixed-Price."],
            ]
        )
    rows.extend(
        [
            ["FAR 52.204-7", "System for Award Management."],
            ["FAR 52.204-13", "System for Award Management Maintenance."],
            ["FAR 52.232-33", "Payment by Electronic Funds Transfer - System for Award Management."],
        ]
    )
    if is_service_requirement(s):
        rows.extend(
            [
                ["FAR 52.217-8", "Option to Extend Services. Continued performance may be required up to 6 months within contract limits and rates."],
                ["FAR 52.217-9", "Option to Extend the Term of the Contract. Option exercise by written notice; total duration controlled by the schedule."],
                ["FAR 52.237-3", "Continuity of Services, if service continuity is mission-essential."],
            ]
        )
    if s.category == "bpa_call":
        rows.append(["Parent BPA", f"BPA call issued under parent BPA {s.parent_contract_number}; call must remain within authorized scope and call limitations."])
    if s.category == "idiq_order":
        rows.extend(
            [
                ["FAR 52.216-18", f"Ordering under parent IDIQ {s.parent_contract_number}."],
                ["FAR 52.216-22", "Indefinite Quantity; performance is authorized only by issued orders."],
            ]
        )
    return rows


def rfq_email_body(s: Scenario, data: dict[str, Any]) -> str:
    quote_due = fmt_date(s.timeline["quotes_due"])
    submission_items = "\n".join(f"- {item}" for item in quote_submission_items(s))
    factor_lines = "\n".join(f"{idx}. {factor_title(factor)}" for idx, factor in enumerate(evaluation_factor_list(s), start=1))
    characteristic_lines = "\n".join(f"- {item}" for item in profile_characteristics(s))
    acceptance_lines = "\n".join(f"- {item}" for item in profile_acceptance_criteria(s))
    clin_lines = "\n".join(
        f"{item['clin']} - {item['description']} Qty {item['quantity']} {item['unit']}" for item in s.line_items
    )
    ordering_lines = ""
    if is_ordering_action(s):
        ordering_lines = f"Parent {s.parent_instrument_label}: {s.parent_contract_number}\n{call_or_order_label(s)} Number: {s.contract_number}\n"
    rfq_open = pick_phrase(s, "rfq_open", ["Good afternoon,", "Good morning,", "Greetings,"])
    rfq_invite = pick_phrase(
        s,
        "rfq_invite",
        [
            "Your firm is invited to submit a quote in response to this Request for Quotation (RFQ).",
            "Your firm is identified as a potential source and is invited to quote on this Request for Quotation (RFQ).",
            "This Request for Quotation (RFQ) is being sent to your firm and other potential sources.",
        ],
    )
    rfq_compete = pick_phrase(
        s,
        "rfq_compete",
        [
            "This is a competitive solicitation. Please review the requirements below and submit your quote no later than the deadline indicated.",
            "This solicitation is competitive. Review the requirements below and submit your quote by the stated deadline.",
            "This is a competitive request. Late quotes may not be considered, so please review the requirements and respond by the deadline below.",
        ],
    )
    return (
        f"{rfq_open}\n\n"
        f"The {data['contracting_office']['office_name']} has a requirement for {s.archetype['requirement']}. "
        f"{rfq_invite}\n\n"
        f"{rfq_compete}\n\n"
        "1. Requirement Summary\n"
        f"Solicitation Number: {s.solicitation_number}\n"
        f"{funding_reference_heading(s)}: {funding_reference_label(s)}\n"
        f"{ordering_lines}"
        f"Description: {s.archetype['requirement']}\n"
        f"Place of Performance: {s.delivery_address.replace(chr(10), ', ')}\n"
        f"Delivery/Performance: {s.archetype['delivery_note']}\n"
        f"Type of Contract: {solicitation_contract_type(s)}\n\n"
        + (f"Required Characteristics:\n{characteristic_lines}\n\n" if characteristic_lines else "")
        + (f"Inspection / Acceptance Criteria:\n{acceptance_lines}\n\n" if acceptance_lines else "")
        + "2. CLIN Schedule\n"
        f"{clin_lines}\n\n"
        "3. Quote Submission Requirements\n\n"
        f"{submission_items}\n\n"
        "4. How Quotes Will Be Evaluated\n"
        "Award will be made to the responsible quoter whose quote represents the best overall value to the Government. "
        "Price alone may not be the determining factor when past performance or technical risk materially differs. "
        f"Technical will consist of {technical_consideration_summary(s)}.\n\n"
        f"{factor_lines}\n\n"
        "5. Important Dates\n"
        f"Questions Due: {fmt_date(s.timeline['questions_due'])}, 1600L\n"
        f"Quotes Due: {quote_due}, 1200L\n"
        f"Anticipated Award: {fmt_date(s.timeline['award'])}\n\n"
        f"Submit quotes by email to {s.co['email']} with the subject line: Quote - [Your Firm Name] - {s.archetype['title']}.\n\n"
        + pick_phrase(
            s,
            "rfq_reserve",
            [
                "The Government reserves the right to award without further discussion based on initial quotes, cancel this solicitation, or issue an amendment if questions warrant a change.",
                "The Government may award on initial quotes without discussions, cancel this solicitation, or amend it if vendor questions warrant a change.",
                "The Government intends to evaluate quotes and award without discussions, but reserves the right to hold discussions, amend, or cancel this solicitation.",
            ],
        )
    )


def write_rfq_email_solicitation(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    bcc = "; ".join(vendor_email(vendor) for vendor in s.contractors)
    write_outlook_thread_pdf(
        folder / solicitation_doc_name(s),
        f"RFQ - {s.archetype['title']} - Quotes Due {fmt_date(s.timeline['quotes_due'])}",
        [
            {
                "sent_notice": (
                    f"Sent Items | This message was sent on {fmt_date(s.timeline['solicitation'])} "
                    f"{email_time(s, 't7', 15, 18)} | {len(s.contractors)} BCC recipients"
                ),
                "from": co_header(s, data),
                "sent": f"{fmt_date(s.timeline['solicitation'])} {email_time(s, 't8', 15, 18)}",
                "to": co_header(s, data),
                "bcc": bcc,
                "subject": f"RFQ - {s.archetype['title']} - Quotes Due {fmt_date(s.timeline['quotes_due'])}",
                "body": apply_persona_texture(s, "co", rfq_email_body(s, data), key="rfq_email"),
                "signature": co_signature(s, data),
                "closing": persona_closing(s, "co"),
            }
        ],
    )


def write_combined_solicitation(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    solicitation_title = "Combined Synopsis/Solicitation"
    if s.category == "bpa_call":
        solicitation_title = "RFQ for BPA Call"
    elif s.category == "idiq_order":
        solicitation_title = "RFQ for IDIQ Order"
    elif is_construction_requirement(s):
        solicitation_title = "Combined Synopsis/Solicitation - Construction / Site Work"
    elif is_service_requirement(s):
        solicitation_title = "Combined Synopsis/Solicitation - Commercial Services"

    eval_rows = [["Factor", "Evaluation Approach"]]
    for factor in evaluation_factor_list(s):
        eval_rows.append([factor_title(factor), factor_evaluation_approach(factor, s)])

    sections: list[dict[str, Any]] = [
        {
            "heading": "Combined Synopsis/Solicitation Notice",
            "paragraphs": [
                "This is a combined synopsis/solicitation prepared for a training acquisition file. A separate written solicitation is not issued.",
                f"The {data['contracting_office']['office_name']} requests quotations for {s.archetype['requirement']}.",
                f"Solicitation number: {s.solicitation_number}. {funding_reference_heading(s)}: {funding_reference_label(s)}. Requirement type: {category_label(s)}.",
                *ordering_solicitation_paragraphs(s),
                solicitation_award_intent(s),
            ],
            "table": [
                ["Field", "Value", "Field", "Value"],
                ["Solicitation", s.solicitation_number, funding_reference_heading(s), funding_reference_label(s)],
                *([["Parent Instrument", parent_reference_label(s), call_or_order_label(s), s.contract_number]] if is_ordering_action(s) else []),
                ["Contracting Officer", s.co["name"], "Quotes Due", f"{fmt_date(s.timeline['quotes_due'])}, 1200L"],
                ["Award Basis", solicitation_award_basis_label(s), "Contract Type", solicitation_contract_type(s)],
            ],
            "widths": [1.25 * inch, 2.25 * inch, 1.25 * inch, 1.75 * inch],
        },
        {
            "heading": "1. Requirement and CLIN Schedule",
            "paragraphs": [
                f"The Contractor shall provide {s.archetype['requirement']}.",
                f"Delivery/performance location: {s.delivery_address}",
                s.archetype["delivery_note"],
            ],
            "table": line_item_table(s.line_items, include_amount=False, include_total=False),
            "widths": [0.6 * inch, 4.6 * inch, 0.55 * inch, 0.55 * inch],
        },
        {
            "heading": "2. Important Dates",
            "table": solicitation_dates_table(s),
            "widths": [2.4 * inch, 2.5 * inch],
        },
        {
            "heading": solicitation_instruction_heading(s),
            "paragraphs": solicitation_instruction_paragraphs(s),
        },
        {
            "heading": solicitation_evaluation_heading(s),
            "paragraphs": solicitation_evaluation_paragraphs(s),
            "table": eval_rows,
            "widths": [1.4 * inch, 5.0 * inch],
        },
    ]
    if profile_acceptance_criteria(s):
        sections.insert(
            2,
            {
                "heading": "1b. Inspection and Acceptance Criteria",
                "table": profile_table("Acceptance Criteria", profile_acceptance_criteria(s)),
                "widths": [0.45 * inch, 6.05 * inch],
            },
        )
    if profile_characteristics(s):
        sections.insert(
            2,
            {
                "heading": "1a. Required Characteristics",
                "table": profile_table("Characteristic", profile_characteristics(s)),
                "widths": [0.45 * inch, 6.05 * inch],
            },
        )

    if is_service_requirement(s):
        sections.append(
            {
                "heading": "5. Service Options",
                "paragraphs": [
                    "The Government may include options to preserve service continuity if the mission need continues and funds are available.",
                    "FAR 52.217-8 may permit short-term continued performance within the limits and rates specified in the contract. FAR 52.217-9 may permit exercise of stated option periods by written notice from the Contracting Officer.",
                    str(s.archetype.get("option_note", "Option periods, if included, must be priced separately and exercised only by written modification.")),
                ],
            }
        )
    next_section = 6 if is_service_requirement(s) else 5

    sections.extend(
        [
            {
                "heading": f"{next_section}. Special Terms By Requirement Type",
                "paragraphs": category_special_terms(s),
            },
            {
                "heading": f"{next_section + 1}. Applicable Provisions and Clauses",
                "paragraphs": [
                    "The following provisions and clauses are included for training realism. The clause list is tailored to the mock acquisition and should align with the award file."
                ],
                "table": solicitation_clause_rows(s),
                "widths": [1.25 * inch, 5.25 * inch],
            },
            {
                "heading": f"{next_section + 2}. Submission Instructions",
                "paragraphs": [
                    f"Submit quotes to {s.co['email']} with the subject line: Quote - [Your Firm Name] - {s.archetype['title']}.",
                    "Direct questions to the Contracting Officer by the questions-due date. If the Government changes the requirement, all solicited vendors will receive the same amendment or response.",
                    "The Government reserves the right to cancel the solicitation at any time without obligation.",
                ],
            },
        ]
    )

    write_pdf(
        folder / solicitation_doc_name(s),
        solicitation_title,
        f"{s.solicitation_number} | {s.archetype['title']}",
        sections,
    )


def write_solicitation(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    if use_simple_rfq_email(s):
        write_rfq_email_solicitation(folder, s, data)
    else:
        write_combined_solicitation(folder, s, data)
    if has_price_list(s):
        write_price_list_pdf(folder, s, solicitation_template=True)


def quote_price_text(quote: dict[str, Any]) -> str:
    return "No quote submitted" if quote.get("amount") is None else money(quote["amount"])


def quote_vendor(s: Scenario, vendor_name: str) -> dict[str, str]:
    return next((contractor for contractor in s.contractors if contractor["name"] == vendor_name), s.contractors[0])


def quote_factor_rows(quote: dict[str, Any]) -> list[list[str]]:
    rows = [["Technical Consideration Addressed", "Vendor Response"]]
    for factor, response in quote.get("factor_responses", {}).items():
        rows.append([factor_title(factor), response])
    return rows


def quote_no_response_body(s: Scenario, vendor: dict[str, str], quote: dict[str, Any]) -> str:
    options = [
        (
            f"Thank you for the opportunity to quote {s.solicitation_number}. "
            "After reviewing the required delivery/performance window, we are unable to submit a quote for this requirement."
        ),
        (
            f"{vendor['name']} respectfully submits a no-quote response for {s.solicitation_number}. "
            "We do not have sufficient available crews/material on the required timeline."
        ),
        (
            "We reviewed the RFQ package and will not be providing pricing at this time. "
            "Please keep us on the distribution list for future base-support requirements."
        ),
    ]
    return stable_pick(quote["vendor"] + s.solicitation_number + str(quote.get("response_order", "")), options)


QUOTE_PALETTES = [
    {"header": "#17365D", "secondary": "#4F6D7A", "stripe": "#F1F5FA", "total": "#E8EEF7", "line": "#6F8DB3"},
    {"header": "#31572C", "secondary": "#4F772D", "stripe": "#F3F8EE", "total": "#E8F2DD", "line": "#90A955"},
    {"header": "#6A040F", "secondary": "#9D0208", "stripe": "#FFF1F1", "total": "#F8D7DA", "line": "#D00000"},
    {"header": "#5F3B1D", "secondary": "#8C5E34", "stripe": "#FAF4EC", "total": "#F1DFCB", "line": "#B08968"},
    {"header": "#244B5A", "secondary": "#3A6C7D", "stripe": "#EDF6F8", "total": "#DDEFF2", "line": "#6AA2B3"},
    {"header": "#3D405B", "secondary": "#5E6472", "stripe": "#F4F5F8", "total": "#E5E7EF", "line": "#8187A3"},
]


def quote_palette(quote: dict[str, Any]) -> dict[str, str]:
    idx = int(quote.get("response_order", 0)) % len(QUOTE_PALETTES)
    return QUOTE_PALETTES[idx]


def quote_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="QuoteTitle", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=16, leading=18, spaceAfter=6))
    styles.add(ParagraphStyle(name="QuoteSubtitle", parent=styles["Normal"], fontName="Helvetica", fontSize=8.5, leading=10, textColor=colors.HexColor("#555555"), spaceAfter=8))
    styles.add(ParagraphStyle(name="QuoteVendor", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=14, leading=16, textColor=colors.HexColor("#17365D"), spaceAfter=2))
    styles.add(ParagraphStyle(name="QuoteEstimate", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=18, leading=20, textColor=colors.HexColor("#3B3B3B"), alignment=TA_CENTER, spaceAfter=5))
    styles.add(ParagraphStyle(name="QuoteSection", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=10, leading=12, textColor=colors.HexColor("#17365D"), spaceBefore=8, spaceAfter=4))
    styles.add(ParagraphStyle(name="QuoteBody", parent=styles["Normal"], fontName="Helvetica", fontSize=9.2, leading=12, spaceAfter=5))
    styles.add(ParagraphStyle(name="QuoteSmall", parent=styles["Normal"], fontName="Helvetica", fontSize=7.7, leading=9.2))
    styles.add(ParagraphStyle(name="QuoteSmallBold", parent=styles["QuoteSmall"], fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="QuoteHeader", parent=styles["QuoteSmallBold"], textColor=colors.white))
    styles.add(ParagraphStyle(name="QuoteTotal", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=12, leading=14, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="QuoteMono", parent=styles["Normal"], fontName="Courier", fontSize=8.5, leading=10.5))
    return styles


def quote_table(
    story: list[Any],
    rows: list[list[Any]],
    styles: dict[str, ParagraphStyle],
    widths: list[float] | None = None,
    header_bg: str = "#17365D",
    stripe: bool = False,
    stripe_bg: str = "#F6F8FA",
    grid_color: str = "#A6A6A6",
) -> None:
    if not rows:
        return
    converted = [
        [p(cell, styles["QuoteHeader"] if row_idx == 0 else styles["QuoteSmall"]) for cell in row]
        for row_idx, row in enumerate(rows)
    ]
    table = Table(converted, colWidths=widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(header_bg)),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor(grid_color)),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    if stripe:
        for row_idx in range(1, len(rows)):
            if row_idx % 2 == 1:
                table.setStyle(TableStyle([("BACKGROUND", (0, row_idx), (-1, row_idx), colors.HexColor(stripe_bg))]))
    story.append(table)
    story.append(Spacer(1, 0.10 * inch))


def add_quote_brand_bar(
    story: list[Any],
    vendor: dict[str, str],
    quote: dict[str, Any],
    styles: dict[str, ParagraphStyle],
    palette: dict[str, str],
    label: str,
) -> None:
    table = Table(
        [
            [
                p(vendor["name"], styles["QuoteHeader"]),
                p(label, styles["QuoteHeader"]),
                p(quote["quote_number"], styles["QuoteHeader"]),
            ]
        ],
        colWidths=[3.6 * inch, 1.7 * inch, 1.2 * inch],
        hAlign="LEFT",
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(palette["header"])),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                ("BOX", (0, 0), (-1, -1), 0.55, colors.HexColor(palette["line"])),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.12 * inch))


def quote_meta_rows(s: Scenario, vendor: dict[str, str], quote: dict[str, Any]) -> list[list[str]]:
    rows = [
        ["Quote Number", quote["quote_number"], "Solicitation", s.solicitation_number],
        ["Vendor", vendor["name"], "UEI", vendor["code"]],
        ["POC", vendor.get("signer", "Authorized Representative"), "Valid For", f"{quote['validity_days']} calendar days"],
        ["Phone / Email", f"{vendor.get('phone', '')} / {vendor_email(vendor)}", "Total", quote_price_text(quote)],
    ]
    if is_ordering_action(s):
        rows.insert(1, ["Parent Instrument", parent_reference_label(s), call_or_order_label(s), s.contract_number])
    return rows


def add_quote_email_style(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    story.append(p(f"From: {vendor_header(vendor)}", styles["QuoteSmallBold"]))
    story.append(p(f"Sent: {fmt_date(s.timeline['quotes_due'])} {email_time(s, 't9', 9 + quote.get('response_order', 0), 7 + quote.get('response_order', 0))}", styles["QuoteSmall"]))
    story.append(p(f"To: {outlook_name(s.co['name'], 'XXX ECONS/LGCA', s.co['email'])}", styles["QuoteSmall"]))
    story.append(p(f"Subject: Quote - {s.solicitation_number} - {s.archetype['title']}", styles["QuoteSmall"]))
    story.append(Spacer(1, 0.08 * inch))
    parent_text = f" This quote is submitted for {call_or_order_label(s).lower()} {s.contract_number} under {parent_reference_label(s)}." if is_ordering_action(s) else ""
    story.append(p(f"Please accept the attached quote from {vendor['name']} for {s.archetype['requirement']}.{parent_text}", styles["QuoteBody"]))
    story.append(p(f"Total quoted price: {quote_price_text(quote)}. {quote['delivery']}", styles["QuoteBody"]))
    quote_table(story, line_item_table(quote["line_items"], include_unit_price=True), styles, [0.50 * inch, 2.95 * inch, 0.45 * inch, 0.45 * inch, 0.90 * inch, 0.95 * inch], palette["header"], True, palette["stripe"], palette["line"])
    factor_rows = quote_factor_rows(quote)
    if len(factor_rows) > 1:
        quote_table(story, factor_rows, styles, [1.85 * inch, 4.55 * inch], palette["secondary"], True, palette["stripe"], palette["line"])
    story.append(p("\n".join([vendor.get("signer", "Authorized Representative"), vendor["name"], vendor.get("phone", ""), vendor_email(vendor)]), styles["QuoteSmall"]))


def add_quote_letterhead_style(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    header = Table(
        [
            [p(vendor["name"], styles["QuoteVendor"]), p("QUOTATION", styles["QuoteEstimate"])],
            [p(vendor["address"], styles["QuoteSmall"]), p(f"{quote['quote_number']}\n{fmt_date(s.timeline['quotes_due'])}", styles["QuoteSmallBold"])],
        ],
        colWidths=[4.3 * inch, 2.3 * inch],
        hAlign="LEFT",
    )
    header.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 1), (-1, 1), 0.8, colors.HexColor(palette["line"]))]))
    story.append(header)
    story.append(Spacer(1, 0.12 * inch))
    story.append(p(f"Submitted to {s.co['name']} in response to {s.solicitation_number} for {s.archetype['title']}.", styles["QuoteBody"]))
    quote_table(story, quote_meta_rows(s, vendor, quote), styles, [1.0 * inch, 2.45 * inch, 0.95 * inch, 2.1 * inch], palette["header"], True, palette["stripe"], palette["line"])
    story.append(p("Price Schedule", styles["QuoteSection"]))
    quote_table(story, line_item_table(quote["line_items"], include_unit_price=True), styles, [0.50 * inch, 2.95 * inch, 0.45 * inch, 0.45 * inch, 0.90 * inch, 0.95 * inch], palette["header"], True, palette["stripe"], palette["line"])
    story.append(p("Technical / Delivery Notes", styles["QuoteSection"]))
    for factor, response in quote.get("factor_responses", {}).items():
        story.append(Paragraph(f"<b>{escape(factor_title(factor))}:</b> {escape(response)}", styles["QuoteBody"]))
    story.append(Spacer(1, 0.08 * inch))
    story.append(p(f"Authorized for submission by {vendor.get('signer', 'Authorized Representative')}.", styles["QuoteSmallBold"]))


def add_quote_estimate_style(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    story.append(p("ESTIMATE", styles["QuoteEstimate"]))
    quote_table(story, quote_meta_rows(s, vendor, quote), styles, [1.0 * inch, 2.45 * inch, 0.95 * inch, 2.1 * inch], palette["header"], True, palette["stripe"], palette["line"])
    story.append(p(f"Work/Items: {s.archetype['requirement']}", styles["QuoteBody"]))
    quote_table(story, line_item_table(quote["line_items"], include_unit_price=True), styles, [0.50 * inch, 2.95 * inch, 0.45 * inch, 0.45 * inch, 0.90 * inch, 0.95 * inch], palette["header"], True, palette["stripe"], palette["line"])
    total_box = Table([[p(f"TOTAL ESTIMATE: {quote_price_text(quote)}", styles["QuoteTotal"])]], colWidths=[6.5 * inch], hAlign="LEFT")
    total_box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1.2, colors.HexColor(palette["header"])), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(palette["total"])), ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    story.append(total_box)
    story.append(Spacer(1, 0.12 * inch))
    factor_rows = quote_factor_rows(quote)
    if len(factor_rows) > 1:
        story.append(p("Response Notes", styles["QuoteSection"]))
        quote_table(story, factor_rows, styles, [1.85 * inch, 4.55 * inch], palette["secondary"], True, palette["stripe"], palette["line"])


def add_quote_technical_style(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    story.append(p(f"{vendor['name']} Technical and Price Response", styles["QuoteTitle"]))
    subtitle = f"{s.solicitation_number} | {s.archetype['title']} | {quote['quote_number']}"
    if is_ordering_action(s):
        subtitle += f" | {parent_reference_label(s)} / {s.contract_number}"
    story.append(p(subtitle, styles["QuoteSubtitle"]))
    story.append(p("1. Understanding of Requirement", styles["QuoteSection"]))
    story.append(p(f"{vendor['name']} understands the Government requires {s.archetype['requirement']} at {s.delivery_address.replace(chr(10), ', ')}.", styles["QuoteBody"]))
    story.append(p("2. Evaluation Factor Response", styles["QuoteSection"]))
    factor_rows = quote_factor_rows(quote)
    if len(factor_rows) > 1:
        quote_table(story, factor_rows, styles, [1.85 * inch, 4.55 * inch], palette["header"], True, palette["stripe"], palette["line"])
    story.append(p("3. Price", styles["QuoteSection"]))
    quote_table(story, line_item_table(quote["line_items"], include_unit_price=True), styles, [0.50 * inch, 2.95 * inch, 0.45 * inch, 0.45 * inch, 0.90 * inch, 0.95 * inch], palette["header"], True, palette["stripe"], palette["line"])
    story.append(p(f"Quote validity: {quote['validity_days']} calendar days. Submitted by {vendor.get('signer', 'Authorized Representative')}.", styles["QuoteSmall"]))


def add_quote_simple_style(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    story.append(p("Vendor Quote", styles["QuoteTitle"]))
    quote_table(
        story,
        [
            ["Field", "Response"],
            ["Vendor", vendor["name"]],
            ["Solicitation", s.solicitation_number],
            *([["Parent Instrument", parent_reference_label(s)], [call_or_order_label(s), s.contract_number]] if is_ordering_action(s) else []),
            ["Quote No.", quote["quote_number"]],
            ["Delivery / Performance", quote["delivery"]],
            ["Total Price", quote_price_text(quote)],
        ],
        styles,
        [1.55 * inch, 4.95 * inch],
        palette["header"],
        True,
        palette["stripe"],
        palette["line"],
    )
    quote_table(story, line_item_table(quote["line_items"], include_unit_price=True), styles, [0.50 * inch, 2.95 * inch, 0.45 * inch, 0.45 * inch, 0.90 * inch, 0.95 * inch], palette["header"], True, palette["stripe"], palette["line"])
    if quote.get("factor_responses"):
        story.append(p("Vendor comments", styles["QuoteSection"]))
        for factor, response in quote["factor_responses"].items():
            story.append(p(f"{factor_title(factor)} - {response}", styles["QuoteBody"]))
    story.append(p(vendor.get("signer", "Authorized Representative"), styles["QuoteSmallBold"]))


def add_quote_no_response(story: list[Any], s: Scenario, vendor: dict[str, str], quote: dict[str, Any], styles: dict[str, ParagraphStyle], palette: dict[str, str]) -> None:
    story.append(p(f"From: {vendor_header(vendor)}", styles["QuoteSmallBold"]))
    story.append(p(f"Sent: {fmt_date(s.timeline['quotes_due'])} {email_time(s, 't10', 10 + quote.get('response_order', 0), 3 + quote.get('response_order', 0))}", styles["QuoteSmall"]))
    story.append(p(f"To: {outlook_name(s.co['name'], 'XXX ECONS/LGCA', s.co['email'])}", styles["QuoteSmall"]))
    story.append(p(f"Subject: No quote - {s.solicitation_number}", styles["QuoteSmall"]))
    story.append(Spacer(1, 0.10 * inch))
    notice = Table([[p(quote_no_response_body(s, vendor, quote), styles["QuoteBody"])]], colWidths=[6.5 * inch], hAlign="LEFT")
    notice.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(palette["total"])),
                ("BOX", (0, 0), (-1, -1), 0.7, colors.HexColor(palette["line"])),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(notice)
    story.append(Spacer(1, 0.12 * inch))
    story.append(p("\n".join([vendor.get("signer", "Authorized Representative"), vendor["name"], vendor_email(vendor)]), styles["QuoteSmall"]))


def write_quotes(folder: Path, s: Scenario) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    styles = quote_styles()
    subtitle = f"{s.solicitation_number} | {s.archetype['title']} | Quotes due {fmt_date(s.timeline['quotes_due'])}, 1200L"
    if is_ordering_action(s):
        subtitle += f" | {parent_reference_label(s)} / {s.contract_number}"
    story: list[Any] = [
        p("Contractor Quotes / Responses", styles["QuoteTitle"]),
        p(subtitle, styles["QuoteSubtitle"]),
    ]
    quote_rows = sorted(s.quote_rows, key=lambda row: row.get("response_order", 0))
    for idx, quote in enumerate(quote_rows):
        vendor = quote_vendor(s, quote["vendor"])
        palette = quote_palette(quote)
        if idx:
            story.append(PageBreak())
        label = "NO QUOTE RESPONSE" if quote.get("non_response") else f"{quote['quote_format'].replace('_', ' ').upper()} QUOTE"
        add_quote_brand_bar(story, vendor, quote, styles, palette, label)
        if quote.get("non_response"):
            add_quote_no_response(story, s, vendor, quote, styles, palette)
        elif quote["quote_format"] == "email":
            add_quote_email_style(story, s, vendor, quote, styles, palette)
        elif quote["quote_format"] == "letterhead":
            add_quote_letterhead_style(story, s, vendor, quote, styles, palette)
        elif quote["quote_format"] == "estimate":
            add_quote_estimate_style(story, s, vendor, quote, styles, palette)
        elif quote["quote_format"] == "technical":
            add_quote_technical_style(story, s, vendor, quote, styles, palette)
        else:
            add_quote_simple_style(story, s, vendor, quote, styles, palette)
    doc = SimpleDocTemplate(
        str(folder / compact_doc_name(s, "Quotes")),
        pagesize=letter,
        rightMargin=0.62 * inch,
        leftMargin=0.62 * inch,
        topMargin=0.62 * inch,
        bottomMargin=0.58 * inch,
        title=f"Quotes - {s.solicitation_number}",
    )
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def quote_received_display(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "No quote"
    offset_rng = random.Random(f"{s.contract_number}|received|{quote['vendor']}")
    if s.archetype.get("_inject_late_quote") and quote["vendor"] == s.winner["name"]:
        received = s.timeline["quotes_due"] + timedelta(days=offset_rng.randint(1, 3))
    else:
        received = s.timeline["quotes_due"] - timedelta(days=offset_rng.randint(0, 2))
    return fmt_date(received)


def quote_summary_rows(s: Scenario) -> list[list[str]]:
    rows = [["Vendor", "Received", "Overall Technical", "Quoted Price", "Notes"]]
    for quote in s.quote_rows:
        if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
            note = "Selected for the multiple-award pool."
        elif quote["vendor"] == s.winner["name"]:
            note = "Most advantageous quote selected for award"
        else:
            note = quote.get("deficiency_note", quote_deficiency_note(quote))
        rows.append(
            [
                quote["vendor"],
                quote_received_display(s, quote),
                quote["technical"],
                quote_price_text(quote),
                note,
            ]
        )
    return rows


def factor_finding_for_quote(s: Scenario, quote: dict[str, Any], factor: str) -> tuple[str, str]:
    if quote.get("non_response"):
        return "No Response", "No quote or technical response was received by the stated deadline."
    if is_price_factor(factor):
        if quote.get("amount") is None:
            return "No Response", "No price was submitted."
        if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
            return "Fair/Reasonable", "Price was complete and fair and reasonable for award in the multiple-award pool."
        if quote["vendor"] == s.winner["name"]:
            return "Fair/Reasonable", "Price was complete and fair and reasonable based on adequate competition."
        if quote["technical"] == "Acceptable":
            return "Evaluated", "Price was complete but did not provide an advantage over the selected quote."
        return "Evaluated", "Price was received, but the quote was not most advantageous due to technical risk or missing information."
    missing = quote.get("missing_factors") or []
    if factor in missing:
        finding = "Unacceptable" if quote["technical"] == "Unacceptable" else "Clarification Needed"
        return finding, f"Quote did not clearly address {factor_title(factor)}."
    if factor in quote.get("factor_responses", {}):
        if quote["vendor"] == s.winner["name"] or (is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"])):
            return "Acceptable", "Quote addressed this technical consideration with no material exception noted."
        return "Acceptable", "Quote addressed this technical consideration; no unique benefit over the selected quote was identified."
    return "Not Addressed", f"The file does not show a clear response for {factor_title(factor)}."


def factor_review_rows(s: Scenario) -> list[list[str]]:
    rows = [["Vendor", "Technical Consideration", "Finding", "Rationale"]]
    for quote in s.quote_rows:
        if quote.get("non_response"):
            continue
        for factor in technical_factor_list(s):
            finding, rationale = factor_finding_for_quote(s, quote, factor)
            rows.append([quote["vendor"], factor_title(factor), finding, rationale])
    return rows


def technical_review_request_rows(s: Scenario) -> list[list[str]]:
    rows = [["Vendor", "Technical Consideration", "Evaluator Finding", "Evaluator Notes"]]
    for quote in s.quote_rows:
        if quote.get("non_response"):
            continue
        for factor in technical_factor_list(s):
            rows.append([quote["vendor"], factor_title(factor), "", ""])
    return rows


def factor_decision_rows(s: Scenario) -> list[list[str]]:
    if is_multiple_award_master(s):
        rows = [["Awardee", "Technical Consideration", "Technical Finding", "Decision Impact"]]
        for quote in master_awardee_quote_rows(s):
            for factor in technical_factor_list(s):
                finding, rationale = factor_finding_for_quote(s, quote, factor)
                if finding == "Acceptable":
                    rationale = f"Selected for multiple-award pool; {rationale}"
                rows.append([quote["vendor"], factor_title(factor), finding, rationale])
        return rows
    winner_quote = next((quote for quote in s.quote_rows if quote["vendor"] == s.winner["name"]), s.quote_rows[0])
    rows = [["Technical Consideration", "Technical Finding", "Decision Impact"]]
    for factor in technical_factor_list(s):
        finding, rationale = factor_finding_for_quote(s, winner_quote, factor)
        rows.append([factor_title(factor), finding, rationale])
    return rows


def has_past_performance_factor(s: Scenario) -> bool:
    return any("past performance" in factor.lower() for factor in evaluation_factor_list(s))


def co_price_analysis_note(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "No price submitted."
    if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
        return "Complete CLIN/pricing basis; fair and reasonable for inclusion in the multiple-award pool."
    if quote["vendor"] == s.winner["name"]:
        return "Complete CLIN pricing; fair and reasonable based on adequate competition."
    if quote["technical"] == "Acceptable":
        if quote.get("amount") is not None and float(quote["amount"]) > float(s.base_amount):
            return "Higher than selected quote with no documented technical or performance benefit justifying the premium."
        return "Evaluated, but no technical or price advantage over selected quote was documented."
    return "Price noted; quote not selected because technical risk or missing information prevented award."


def past_performance_finding_for_quote(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "Not evaluated"
    if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
        return "Relevant / no adverse information"
    if quote["vendor"] == s.winner["name"]:
        return "Relevant / no adverse information"
    if quote["technical"] == "Unacceptable":
        return "Not a discriminator; technical risk controlled award"
    return "Relevant / no known advantage"


def past_performance_sources_for_quote(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "No quote received; no vendor-provided past performance reviewed."
    sources = [
        "Quote submission",
        "local vendor file notes",
        "customer feedback available to the contracting office",
        "SAM/responsibility screening",
    ]
    if is_ordering_action(s) and quote["vendor"] == s.winner["name"]:
        sources.append(f"parent {s.parent_instrument_label} record")
    return "; ".join(sources) + "."


def past_performance_relevance_for_quote(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "Not evaluated"
    if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
        return "Relevant to the IDIQ/BPA ordering scope"
    if quote["vendor"] == s.winner["name"]:
        return "Relevant to the requirement"
    if quote["technical"] == "Unacceptable":
        return "Limited discriminator"
    return "Relevant or somewhat relevant"


def past_performance_risk_for_quote(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "Not evaluated"
    if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
        return "Low performance risk; no adverse information found"
    if quote["vendor"] == s.winner["name"]:
        return "Low performance risk; no adverse information found"
    if quote["technical"] == "Unacceptable":
        return "No separate advantage identified"
    if quote["technical"] == "Acceptable with clarification":
        return "Acceptable history, but technical clarification risk remains"
    return "No known adverse information"


def past_performance_rationale_for_quote(s: Scenario, quote: dict[str, Any]) -> str:
    if quote.get("non_response"):
        return "Vendor did not submit a quote, so past performance was not considered for award."
    if is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
        return "Available information supports including this firm in the multiple-award pool; no adverse performance issue increased award risk."
    if quote["vendor"] == s.winner["name"]:
        if is_ordering_action(s):
            return f"Parent awardee record and available customer feedback support using {quote['vendor']} for this order."
        return "Available information showed relevant performance history and no adverse information that would increase award risk."
    if quote["technical"] == "Unacceptable":
        return "Past performance did not overcome the unacceptable technical finding."
    if quote["technical"] == "Acceptable with clarification":
        return "Past performance did not offset the clarification risk in the technical response."
    return "Past performance was acceptable, but it did not provide a documented advantage over the selected quote."


def past_performance_evaluation_rows(s: Scenario) -> list[list[str]]:
    rows = [["Vendor", "Information Reviewed", "Relevance", "Performance Risk / Finding", "Rationale"]]
    for quote in s.quote_rows:
        rows.append(
            [
                quote["vendor"],
                past_performance_sources_for_quote(s, quote),
                past_performance_relevance_for_quote(s, quote),
                past_performance_risk_for_quote(s, quote),
                past_performance_rationale_for_quote(s, quote),
            ]
        )
    return rows


def past_performance_decision_rows(s: Scenario) -> list[list[str]]:
    if is_multiple_award_master(s):
        rows = [["Awardee", "Past Performance Finding", "Performance Risk", "Decision Impact"]]
        for quote in master_awardee_quote_rows(s):
            rows.append(
                [
                    quote["vendor"],
                    past_performance_finding_for_quote(s, quote),
                    past_performance_risk_for_quote(s, quote),
                    past_performance_rationale_for_quote(s, quote),
                ]
            )
        return rows
    winner_quote = next((quote for quote in s.quote_rows if quote["vendor"] == s.winner["name"]), s.quote_rows[0])
    rows = [["Field", "Decision Record"]]
    rows.extend(
        [
            ["Awardee", s.winner["name"]],
            ["Information Reviewed", past_performance_sources_for_quote(s, winner_quote)],
            ["Past Performance Finding", past_performance_finding_for_quote(s, winner_quote)],
            ["Performance Risk", past_performance_risk_for_quote(s, winner_quote)],
            ["Decision Impact", past_performance_rationale_for_quote(s, winner_quote)],
        ]
    )
    return rows


def quote_abstract_rows(s: Scenario) -> list[list[str]]:
    rows = [["Vendor", "Response", "Technical", "Past Performance", "Total Price", "CO Analysis / Decision Impact"]]
    for quote in s.quote_rows:
        if quote.get("non_response"):
            response = "No quote"
            technical = "Not evaluated"
            decision = "Not eligible for award; no quote received."
        elif is_multiple_award_master(s) and is_master_awardee_vendor(s, quote["vendor"]):
            response = "Quote received"
            technical = quote["technical"]
            awardee = master_awardee_for_vendor(s, quote["vendor"])
            contract_number = str(awardee.get("contract_number") or "").strip()
            suffix = f" ({contract_number})" if contract_number else ""
            decision = f"Selected for multiple-award pool{suffix}."
        elif quote["vendor"] == s.winner["name"]:
            response = "Quote received"
            technical = quote["technical"]
            decision = "Selected as most advantageous quote."
        elif quote["technical"] == "Unacceptable":
            response = "Quote received"
            technical = quote["technical"]
            decision = "Not eligible for award due to unacceptable technical risk."
        elif quote["technical"] == "Acceptable with clarification":
            response = "Quote received"
            technical = quote["technical"]
            decision = "Not selected; clarification risk not offset by price or other benefit."
        else:
            response = "Quote received"
            technical = quote["technical"]
            decision = "Not selected; no advantage over selected quote."
        rows.append([quote["vendor"], response, technical, past_performance_finding_for_quote(s, quote), quote_price_text(quote), f"{co_price_analysis_note(s, quote)} {decision}"])
    return rows


def master_pricing_basis_paragraph(s: Scenario) -> list[str]:
    if not is_master_vehicle(s):
        return []
    if s.category == "bpa":
        return [
            "Pricing basis: proposed unit prices/price lists were evaluated against a representative basket of typical call items. "
            "Evaluated totals in the abstract are for comparison only - they do not establish a ceiling, an obligated amount, or a cap on future calls. "
            f"The awarded BPA carries the contractor's price list and a per-call purchase limitation of {money(bpa_call_limit_value(s))}."
        ]
    if is_construction_requirement(s) and not price_list_has_vehicle_classes(s):
        return [
            "Pricing basis: evaluated pricing for the MACC award pool was used to support awardee selection and overall price reasonableness for the ordering vehicle. "
            "The master MACC does not establish a standard construction price list. Project-specific task order prices will be competed among eligible awardees under the fair-opportunity procedures, unless a documented exception applies. "
            f"The awarded IDIQ establishes a ceiling of {money(idiq_ceiling_value(s))} and a guaranteed minimum of {money(idiq_minimum_value(s))}; funds obligate only on individual task orders."
        ]
    return [
        "Pricing basis: proposed unit prices were evaluated against a representative basket of estimated order quantities. "
        f"Evaluated totals in the abstract are for comparison only. The awarded IDIQ establishes a ceiling of {money(idiq_ceiling_value(s))} "
        f"and a guaranteed minimum of {money(idiq_minimum_value(s))}; funds obligate only on individual orders."
    ]


def best_value_rationale_paragraphs(s: Scenario) -> list[str]:
    if is_multiple_award_master(s):
        vehicle_label = master_vehicle_label(s.category)
        awardee_names = master_awardee_name_set(s)
        paragraphs = [
            (
                f"The solicitation contemplated establishment of a multiple-award {vehicle_label} pool. "
                f"Awards are recommended to {len(awardee_names)} responsible offerors whose quotes conformed to the solicitation, addressed the stated technical considerations, and provided fair and reasonable evaluated pricing for the ordering vehicle."
            )
        ]
        for quote in s.quote_rows:
            if quote["vendor"] in awardee_names:
                awardee = master_awardee_for_vendor(s, quote["vendor"])
                contract_number = str(awardee.get("contract_number") or "").strip()
                contract_text = f" under {contract_number}" if contract_number else ""
                paragraphs.append(
                    f"{quote['vendor']} is recommended for award{contract_text}; the quote was technically acceptable, past performance presented no adverse risk, and the evaluated pricing supports inclusion in the pool."
                )
            elif quote.get("non_response"):
                paragraphs.append(f"{quote['vendor']} was not considered for award because no quote was received by the stated deadline.")
            elif quote["technical"] == "Unacceptable":
                missing = "; ".join(factor_title(factor) for factor in quote.get("missing_factors", [])) or "one or more technical considerations"
                paragraphs.append(f"{quote['vendor']} was not selected for the pool because the quote did not clearly address {missing}, creating unacceptable performance risk.")
            elif quote["technical"] == "Acceptable with clarification":
                missing = "; ".join(factor_title(factor) for factor in quote.get("missing_factors", [])) or "one or more technical considerations"
                paragraphs.append(f"{quote['vendor']} was not selected for the pool because the quote required clarification for {missing} and did not provide an offsetting benefit.")
            else:
                paragraphs.append(f"{quote['vendor']} was evaluated, but the record did not identify a basis to include the firm in the award pool.")
        paragraphs.append("Individual orders will identify the selected awardee, scope, funding citation, performance location, schedule, and order price in accordance with the ordering procedures.")
        return paragraphs
    paragraphs = [
        (
            f"The solicitation stated award would be made to the responsible offeror whose quote conformed to the solicitation and was most advantageous to the Government, considering Price, Past Performance, and Technical. "
            f"{s.winner['name']} is recommended because its quote addressed the stated technical considerations and provided the most advantageous combination of acceptable technical response, relevant past performance, performance risk, and price."
        )
    ]
    for quote in s.quote_rows:
        if quote["vendor"] == s.winner["name"]:
            continue
        if quote.get("non_response"):
            paragraphs.append(f"{quote['vendor']} was not considered for award because no quote was received by the stated deadline.")
        elif quote["technical"] == "Unacceptable":
            missing = "; ".join(factor_title(factor) for factor in quote.get("missing_factors", [])) or "one or more technical considerations"
            paragraphs.append(f"{quote['vendor']} was not most advantageous because the quote did not clearly address {missing}, creating unacceptable performance risk.")
        elif quote["technical"] == "Acceptable with clarification":
            missing = "; ".join(factor_title(factor) for factor in quote.get("missing_factors", [])) or "one or more technical considerations"
            paragraphs.append(f"{quote['vendor']} presented additional risk because the quote required clarification for {missing}; no offsetting benefit justified selecting it over the recommended awardee.")
        elif quote.get("amount") is not None and float(quote["amount"]) > float(s.base_amount):
            paragraphs.append(f"{quote['vendor']} was technically acceptable but quoted a higher price than {s.winner['name']} and offered no documented technical benefit that justified the price premium.")
        else:
            paragraphs.append(f"{quote['vendor']} was evaluated, but the record did not identify a technical or price advantage over {s.winner['name']}.")
    paragraphs.append("Based on the technical review, past performance consideration, and price analysis, the recommended award represents the most advantageous quote to the Government rather than a stand-alone lowest-price selection.")
    return paragraphs


def write_responsibility_screening(folder: Path, s: Scenario) -> None:
    """Pre-award vendor responsibility screening - present in every evaluated file."""
    sam_inactive = bool(s.archetype.get("_inject_sam_inactive"))
    rows = [["Vendor", "UEI", "SAM Registration", "Exclusions Check"]]
    for quote in s.quote_rows:
        is_winner = quote["vendor"] == s.winner["name"]
        if quote.get("non_response"):
            status = "Not checked - no quote received"
            exclusions = "Not checked"
        elif is_winner and sam_inactive:
            status = "INACTIVE - registration lapsed"
            exclusions = "No active exclusions found"
        else:
            status = "Active - registration current"
            exclusions = "No active exclusions found"
        rows.append([quote["vendor"], str(quote.get("uei", "")), status, exclusions])
    write_pdf(
        folder / compact_doc_name(s, "SAM"),
        "Vendor Responsibility Screening",
        f"{s.solicitation_number} | Screened prior to award decision",
        [
            {
                "heading": "Screening Results",
                "table": rows,
                "widths": [1.9 * inch, 1.35 * inch, 1.85 * inch, 1.4 * inch],
            },
            {
                "heading": "Basis",
                "paragraphs": [
                    "Screening reflects registration and exclusion information available to the contracting office at the time of the award decision. "
                    "An offeror must have an active registration at time of offer and through award unless an exception applies.",
                    f"Screened by: {s.co['name']}, Contingency Contracting Officer.",
                ],
            },
        ],
    )


def write_evaluation(folder: Path, s: Scenario) -> None:
    quote_table = quote_summary_rows(s)
    factor_table = factor_review_rows(s)
    request_table = technical_review_request_rows(s)
    factor_widths = [1.45 * inch, 1.35 * inch, 1.05 * inch, 2.55 * inch]
    request_widths = [1.65 * inch, 1.7 * inch, 1.35 * inch, 1.8 * inch]
    evaluation_note = technical_review_context_note(variation_text(s, "evaluation_note"))
    evaluation_context = f"\n\nContext from the earlier requirements traffic: {evaluation_note}" if evaluation_note else ""
    if is_multiple_award_master(s):
        selected_technical_sentence = (
            f"The recommended awardees for the {master_vehicle_label(s.category)} pool are technically acceptable across the stated technical considerations. "
            "No material exceptions were identified in the quotes selected for award."
        )
    else:
        selected_technical_sentence = (
            f"{s.winner['name']} is technically acceptable across the stated technical considerations. "
            "No material exceptions were identified in the quote selected for award."
        )

    write_pdf(
        folder / compact_doc_name(s, "Receipt Log"),
        "Quote Receipt Log",
        f"{s.solicitation_number} | {fmt_date(s.timeline['quotes_due'])}",
        [{"heading": "Quotes Received", "table": quote_table, "widths": [1.7 * inch, 1.0 * inch, 1.05 * inch, 0.95 * inch, 1.7 * inch]}],
    )

    write_responsibility_screening(folder, s)

    write_tech_eval_docs = not s.archetype.get("_inject_missing_tech_eval")

    if write_tech_eval_docs:
        write_outlook_thread_pdf(
            folder / compact_doc_name(s, "Tech Eval Req"),
            f"Technical evaluation request - {s.solicitation_number}",
            [
                {
                    "from": co_header(s),
                    "sent": f"{fmt_date(s.timeline['tech_eval_request'])} {email_time(s, 't11', 9, 28)}",
                    "to": requester_header(s),
                    "cc": approver_header(s),
                    "subject": f"Technical evaluation request - {s.solicitation_number}",
                    "body": (
                        f"Please evaluate the contractor responses received for {lowercase_display_phrase(s.archetype['title'])} against the requirement and the technical considerations discussed before solicitation.\n\n"
                        + (f"{ordering_relationship_sentence(s)} Please keep the technical review limited to whether the quoted approach fits within the call/order requirement; contracting will confirm the parent instrument and ordering authority.\n\n" if is_ordering_action(s) else "")
                        + "Please provide a technical finding for each technical consideration by vendor. Do not evaluate price, past performance, or recommend award; contracting will prepare the quote abstract, price analysis, past performance consideration, and best-value decision. I need your technical review to identify whether any response omitted information, requires clarification, or creates performance risk."
                        + evaluation_context
                    ),
                    "table": request_table,
                    "widths": request_widths,
                    "attachments": [compact_doc_name(s, "Quotes"), solicitation_doc_name(s)],
                    "signature": co_signature(s),
                }
            ],
        )

        write_outlook_thread_pdf(
            folder / compact_doc_name(s, "Tech Eval"),
            f"RE: Technical evaluation request - {s.solicitation_number}",
            [
                {
                    "from": requester_header(s),
                    "sent": f"{fmt_date(s.timeline['tech_eval'])} {email_time(s, 't12', 13, 41)}",
                    "to": co_header(s),
                    "cc": approver_header(s),
                    "subject": f"RE: Technical evaluation request - {s.solicitation_number}",
                    "body": (
                        f"We reviewed each contractor response against the technical considerations for {lowercase_display_phrase(s.archetype['title'])}.\n\n"
                        + (f"We treated this as a requirement under {parent_reference_label(s)} and did not assess price, funding, or ordering authority.\n\n" if is_ordering_action(s) else "")
                        + f"{selected_technical_sentence}\n\n"
                        "The technical findings are below. We did not evaluate price, past performance, or make the award decision."
                        f"{evaluation_context}"
                    ),
                    "table": factor_table,
                    "widths": factor_widths,
                    "signature": requester_signature(s),
                },
                {
                    "from": co_header(s),
                    "sent": f"{fmt_date(s.timeline['tech_eval_request'])} {email_time(s, 't13', 9, 28)}",
                    "to": requester_header(s),
                    "cc": approver_header(s),
                    "subject": f"Technical evaluation request - {s.solicitation_number}",
                    "body": (
                        f"Please evaluate the quotes received for {lowercase_display_phrase(s.archetype['title'])} against the requirement and the technical considerations discussed before solicitation.\n\n"
                        "I need a concise technical finding for each vendor and each technical consideration. Please do not evaluate price, past performance, or make the award decision; just identify whether each response is technically acceptable, whether any technical consideration was not addressed, and whether any clarification is needed."
                        f"{evaluation_context}"
                    ),
                    "signature": co_signature(s),
                },
            ],
        )

    if has_past_performance_factor(s):
        write_pdf(
            folder / compact_doc_name(s, "Past Perf"),
            "Past Performance Evaluation",
            f"{s.solicitation_number} | {fmt_date(s.timeline['decision'])}",
            [
                {
                    "heading": "Evaluation Basis",
                    "paragraphs": [
                        "The solicitation identified Past Performance as an evaluation factor. The Contracting Officer reviewed recent and relevant information available in the file, vendor quote information, local customer feedback, and responsibility information.",
                        "This past performance review was considered with the technical findings and price analysis in the award decision. It was not scored separately as a formal source-selection rating.",
                        *([f"For this ordering action, the review also considered the parent {s.parent_instrument_label} record and whether the order remains consistent with the parent vehicle."] if is_ordering_action(s) else []),
                    ],
                },
                {
                    "heading": "Past Performance Findings",
                    "table": past_performance_evaluation_rows(s),
                    "widths": [1.15 * inch, 1.55 * inch, 1.05 * inch, 1.35 * inch, 1.4 * inch],
                },
            ],
        )

    if is_multiple_award_master(s):
        decision_section = {
            "heading": "Decision",
            "paragraphs": [
                f"Awards are recommended to {len(master_awardees(s))} firms for the multiple-award {master_vehicle_label(s.category)} pool.",
                "Each recommended awardee submitted an acceptable quote, was found responsible for this training file, and is listed below with its assigned PIID.",
            ],
            "table": master_awardee_rows(s),
            "widths": [0.9 * inch, 1.55 * inch, 1.0 * inch, 0.95 * inch, 0.9 * inch, 0.85 * inch],
        }
        past_performance_decision_widths = [1.35 * inch, 1.25 * inch, 1.25 * inch, 2.65 * inch]
        factor_decision_widths = [1.35 * inch, 1.45 * inch, 1.05 * inch, 2.65 * inch]
    else:
        decision_section = {
            "heading": "Decision",
            "paragraphs": [
                f"Award is recommended to {s.winner['name']} for {money(s.base_amount)}.",
                *([ordering_relationship_sentence(s)] if is_ordering_action(s) else []),
                "The recommended awardee represents the quote most advantageous to the Government, considering Price, Past Performance, and Technical, consistent with the solicitation evaluation language.",
            ],
        }
        past_performance_decision_widths = [1.55 * inch, 4.95 * inch]
        factor_decision_widths = [1.55 * inch, 1.25 * inch, 3.7 * inch]

    write_pdf(
        folder / compact_doc_name(s, "Decision"),
        "Award Decision Document",
        f"{s.solicitation_number} | {fmt_date(s.timeline['decision'])}",
        [
            decision_section,
            *([
                {
                    "heading": "Ordering Vehicle",
                    "table": [
                        ["Field", "Value"],
                        ["Parent Instrument", parent_reference_label(s)],
                        [call_or_order_label(s), s.contract_number],
                        ["Ordering Finding", "Award remains within the documented requirement scope, ordering vehicle reference, and funded call/order amount."],
                    ],
                    "widths": [1.65 * inch, 4.85 * inch],
                }
            ] if is_ordering_action(s) else []),
            {
                "heading": "Evaluation Factors",
                "table": [["Factor", "Evaluation Approach"], *[[factor_title(factor), factor_evaluation_approach(factor, s)] for factor in evaluation_factor_list(s)]],
                "widths": [1.65 * inch, 4.85 * inch],
            },
            *([
                {
                    "heading": "Past Performance Evaluation",
                    "paragraphs": [
                        "Past Performance was evaluated in the separate Past Performance Evaluation memorandum in this folder and considered in the best-value decision.",
                    ],
                    "table": past_performance_decision_rows(s),
                    "widths": past_performance_decision_widths,
                }
            ] if has_past_performance_factor(s) else []),
            {"heading": "Quote Abstract and CO Price Analysis", "table": quote_abstract_rows(s), "widths": [1.15 * inch, 0.65 * inch, 0.8 * inch, 1.05 * inch, 0.8 * inch, 2.05 * inch]},
            {"heading": "Quote Receipt Summary", "table": quote_table, "widths": [1.7 * inch, 1.0 * inch, 1.05 * inch, 0.95 * inch, 1.7 * inch]},
            {"heading": "Awardee Technical Findings", "table": factor_decision_rows(s), "widths": factor_decision_widths},
            {"heading": "Best-Value Rationale", "paragraphs": master_pricing_basis_paragraph(s) + best_value_rationale_paragraphs(s)},
        ],
    )


def write_price_list_pdf(folder: Path, s: Scenario, solicitation_template: bool = False) -> None:
    if not has_price_list(s):
        return
    label = "Price Template" if solicitation_template else "Price List"
    write_pdf(
        folder / compact_doc_name(s, label),
        price_list_attachment_title(s),
        f"{s.contract_number} | {s.archetype['title']}",
        [
            {
                "heading": "Ordering Price List",
                "paragraphs": price_list_intro_paragraphs(s, solicitation_template),
                "table": price_list_rows(s, solicitation_template),
                "widths": price_list_widths(s, solicitation_template),
            }
        ],
    )


def write_macc_ordering_procedures_pdf(folder: Path, s: Scenario) -> None:
    if not has_macc_ordering_procedures(s):
        return
    write_pdf(
        folder / compact_doc_name(s, "Fair Opportunity"),
        "Fair Opportunity Ordering Procedures",
        f"{s.contract_number} | {s.archetype['title']}",
        [
            {
                "heading": "Purpose",
                "paragraphs": [
                    "This attachment describes how the Government will place construction task orders under the multiple-award construction contract.",
                    "The master contract establishes the awardee pool, scope boundaries, ordering period, ceiling, minimum guarantee, and contract clauses. It does not authorize construction work or establish a standing price list for future projects.",
                ],
            },
            {
                "heading": "Fair Opportunity",
                "paragraphs": [
                    "For each task order above the micro-purchase threshold, the Contracting Officer will provide each eligible MACC awardee a fair opportunity to be considered unless an authorized exception is documented in the task order file.",
                    "Fair opportunity may be provided through an email request for task order proposal, a task order request for quotation/proposal, or another written method that gives eligible awardees the project scope, response instructions, and evaluation approach.",
                ],
            },
            {
                "heading": "Task Order Request Package",
                "table": [
                    ["Element", "Typical Content"],
                    ["Project SOW / specifications", "Project-specific description of work, site constraints, acceptance criteria, safety expectations, and closeout requirements."],
                    ["Drawings / sketches", "Included when needed to define dimensions, locations, phasing, or utility/interface requirements."],
                    ["Schedule", "Site visit date if used, proposal due date, anticipated notice to proceed, and completion requirement."],
                    ["Evaluation approach", "Price and any task-order technical factors such as schedule, safety approach, key personnel, material approach, or relevant experience."],
                    ["Funding", "Task order funding citation, ceiling/amount, and any limitation on available funds."],
                ],
                "widths": [1.75 * inch, 4.75 * inch],
            },
            {
                "heading": "Selection and Documentation",
                "paragraphs": [
                    "The task order file documents the awardee considered, responses received, technical findings when used, price analysis, and best-value rationale.",
                    "A task order issued under this MACC identifies the selected awardee, order number, funded amount, period of performance, place of performance, SOW/specifications, and any order-specific clauses or attachments.",
                    "Exceptions to fair opportunity, including urgent need or logical follow-on when applicable, must be documented before award of the task order.",
                ],
            },
        ],
    )


def write_award(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    if s.category == "bpa":
        bpa_write_award(folder, s, data)
        return
    if s.category == "construction":
        sf1442_write_award(folder, s, data)
        return
    write_price_list_pdf(folder, s)
    write_macc_ordering_procedures_pdf(folder, s)
    sf1449_write_award(folder, s, data)
    return

    award_heading = "SF 1449 Style Award Summary"
    award_title = "Solicitation/Contract/Order for Commercial Products and Commercial Services"
    if s.category == "construction":
        award_heading = "SF 1442 Style Award Summary"
        award_title = "Solicitation, Offer, and Award - Construction / Site Work"
    sections = [
        {
            "heading": award_heading,
            "table": [
                ["Field", "Value"],
                ["Contract Number", s.contract_number],
                ["Solicitation Number", s.solicitation_number],
                ["Requirement Type", category_label(s)],
                ["Award Date", fmt_date(s.timeline["award"])],
                ["Contractor", f"{s.winner['name']}\nUEI: {s.winner['code']}\n{s.winner['address']}"],
                ["Issued By", f"{data['contracting_office']['piid_activity']}\n{data['contracting_office']['office_address']}"],
                ["Payment Office", f"{data['contracting_office']['payment_office']['code']} - {data['contracting_office']['payment_office']['name']}"],
            ],
            "widths": [1.6 * inch, 5.0 * inch],
        },
        {
            "heading": "Schedule",
            "table": line_item_table(s.line_items),
            "widths": [0.55 * inch, 3.7 * inch, 0.45 * inch, 0.45 * inch, 1.0 * inch],
        },
        {
            "heading": "Accounting and Appropriation Data",
            "paragraphs": [s.accounting_data],
        },
        {
            "heading": "Section C - Description / Specifications",
            "paragraphs": [
                f"The Contractor shall provide {s.archetype['requirement']}.",
                *category_special_terms(s),
            ],
        },
        {
            "heading": "Section F - Deliveries or Performance",
            "paragraphs": [
                f"Place of performance: {s.delivery_address}",
                f"Required delivery/performance start: {fmt_date(s.timeline['delivery'])}. Period of performance: {performance_period_label(s)}, unless modified in writing by the Contracting Officer.",
            ],
        },
        {
            "heading": "Section G - Contract Administration",
            "paragraphs": [
                "Only the Contracting Officer may change the terms and conditions of this contract.",
                f"WAWF point of contact: {s.co['name']}, {s.co['phone']}.",
                "Invoices shall reference the contract number, CLIN, period of performance or delivery date, and amount billed.",
            ],
        },
        {
            "heading": "Selected Clauses / References",
            "table": category_clause_rows(s),
            "widths": [1.5 * inch, 5.0 * inch],
        },
        {
            "heading": "Signatures",
            "table": [
                ["Party", "Name", "Date"],
                ["Contractor", s.winner["signer"], fmt_date(s.timeline["award"])],
                ["Government", s.co["name"], fmt_date(s.timeline["award"])],
            ],
            "widths": [1.2 * inch, 3.6 * inch, 1.2 * inch],
        },
    ]
    write_pdf(
        folder / compact_doc_name(s, "Award"),
        award_title,
        f"{s.contract_number} | {s.archetype['title']}",
        sections,
    )


def write_delivery(folder: Path, s: Scenario) -> None:
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Delivery"),
        f"Receipt confirmation - {s.contract_number}",
        [
            {
                "from": requester_header(s),
                "sent": f"{fmt_date(s.timeline['delivery'])} {email_time(s, 't14', 14, 47)}",
                "to": co_header(s),
                "cc": approver_header(s),
                "subject": f"Receipt confirmation - {s.contract_number}",
                "body": with_greeting(
                    s,
                    "requester",
                    person_display(s.co["name"]),
                    (
                        pick_phrase(
                            s,
                            "delivery_lead",
                            [
                                f"The requiring activity confirms receipt/performance for {lowercase_display_phrase(s.archetype['title'])} under {s.contract_number}.",
                                f"Confirming receipt/performance for {lowercase_display_phrase(s.archetype['title'])} under {s.contract_number}.",
                                f"This confirms the unit received/accepted {lowercase_display_phrase(s.archetype['title'])} under {s.contract_number}.",
                            ],
                        )
                        + "\n\n"
                        + (f"Parent instrument: {parent_reference_label(s)}\n" if is_ordering_action(s) else "")
                        + f"Vendor: {s.winner['name']}\n"
                        f"Location: {s.delivery_address.replace(chr(10), ', ')}\n"
                        + pick_phrase(
                            s,
                            "delivery_note",
                            [
                                "No immediate discrepancies noted. Please retain this message in the file as receiving support.",
                                "Nothing discrepant on receipt. Keep this in the file as receiving support.",
                                "Receipt looked good; no discrepancies to report. This message can serve as receiving support for the file.",
                            ],
                        )
                        + "\n\n"
                        + ("Acceptance checks completed:\n" + "\n".join(f"- {item}" for item in profile_acceptance_criteria(s)) + "\n\n" if profile_acceptance_criteria(s) else "")
                        + ("Supporting documentation received:\n" + "\n".join(f"- {item}" for item in profile_delivery_docs(s)) + "\n\n" if profile_delivery_docs(s) else "")
                        + "This is not an invoice approval by itself. Vendor still needs to submit the invoice against the correct contract and CLINs."
                    ),
                    key="delivery",
                ),
                "signature": requester_signature(s),
                "closing": persona_closing(s, "requester"),
            }
        ],
    )


def write_customer_followup_email(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    subject = f"Status check - {s.archetype['title']}"
    ask = pick_phrase(
        s,
        "followup_ask",
        [
            "Checking on where this requirement stands. Leadership asked for an update at this morning's standup.",
            "Any movement on this one? The shop is asking for a timeline.",
            "Quick status check on this requirement when you get a minute - no fire, just keeping our tracker current.",
        ],
    )
    answer = pick_phrase(
        s,
        "followup_answer",
        [
            "Working it in sequence with the rest of the workload. Nothing needed from your side right now; I will reach out if the file needs anything.",
            "It is moving. I will flag you the moment I need anything from the unit.",
            "On track. No action needed from you at this point - will advise if vendor questions change that.",
        ],
    )
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Status"),
        subject,
        [
            {
                "from": co_header(s, data),
                "sent": f"{fmt_date(s.timeline['market_research'])} {email_time(s, 't15', 10, 51)}",
                "to": requester_header(s),
                "subject": f"RE: {subject}",
                "body": with_greeting(s, "co", person_display(s.requester), apply_persona_texture(s, "co", answer, key="followup_co"), key="followup_co"),
                "signature": co_signature(s, data),
                "closing": persona_closing(s, "co"),
            },
            {
                "from": requester_header(s),
                "sent": f"{fmt_date(s.timeline['market_research'])} {email_time(s, 't16', 8, 22)}",
                "to": co_header(s, data),
                "subject": subject,
                "body": with_greeting(s, "requester", person_display(s.co["name"]), apply_persona_texture(s, "requester", ask, key="followup_req"), key="followup_req"),
                "signature": requester_signature(s),
                "closing": persona_closing(s, "requester"),
            },
        ],
    )


def write_funding_clarification_email(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    subject = f"Funding cert - {s.pr_number}"
    correction = pick_phrase(
        s,
        "funding_fix",
        [
            "Disregard the earlier cert sheet - the org code field had a transposition. Corrected certification is attached; the line of accounting and amount are unchanged.",
            "Resending the certification with the org code corrected. No change to the LOA or the certified amount.",
            "The first cert had a typo in the org code block. Attached version is correct; funding line and amount did not change.",
        ],
    )
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Funding Clarification"),
        subject,
        [
            {
                "from": approver_header(s),
                "sent": f"{fmt_date(s.timeline['funding'])} {email_time(s, 't17', 14, 9)}",
                "to": co_header(s, data),
                "cc": requester_header(s),
                "subject": f"RE: {subject}",
                "body": with_greeting(
                    s,
                    "approver",
                    person_display(s.co["name"]),
                    f"{correction}\n\nCertified amount: {money(s.base_amount)} against {s.pr_number}.",
                    key="funding_fix",
                ),
                "attachments": ["Corrected funding certification.pdf"],
                "signature": approver_signature(s),
                "closing": persona_closing(s, "approver"),
            }
        ],
    )


def write_vendor_question_email(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    candidates = [vendor for vendor in s.contractors if vendor["name"] != s.winner["name"]] or s.contractors
    vendor = scenario_rng(s, "vendor_question_pick").choice(candidates)
    subject = f"Question - {s.solicitation_number} - {s.archetype['title']}"
    question = pick_phrase(
        s,
        "vendor_question",
        [
            "Can you confirm whether delivery vehicles require an escort from the entry control point, and how much lead time gate access requests need?",
            "Is the delivery/performance window negotiable by a few days either direction if material availability shifts, or is the stated date firm?",
            "Will the Government provide staging space near the work/delivery location, or should we plan to deliver directly from off-site?",
            "Can you confirm the invoice submission method and whether partial deliveries can be invoiced separately?",
        ],
    )
    answer = pick_phrase(
        s,
        "vendor_answer",
        [
            "See response below. This answer is provided to all offerors and does not change the requirement, pricing structure, or due dates in the solicitation.",
            "Answer below. No change to the solicitation requirements or due dates results from this response, and it has been shared with all vendors.",
            "Response below - being released to all potential offerors. The solicitation stands as written.",
        ],
    )
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Vendor QA"),
        subject,
        [
            {
                "from": co_header(s, data),
                "sent": f"{fmt_date(s.timeline['questions_due'])} {email_time(s, 't18', 16, 2)}",
                "to": vendor_header(vendor),
                "bcc": "; ".join(vendor_email(v) for v in s.contractors),
                "subject": f"RE: {subject}",
                "body": apply_persona_texture(s, "co", f"{answer}\n\nQ: {question}\nA: Coordinate specifics with the contracting office after award; for quoting purposes assume the conditions stated in the solicitation.", key="vendor_answer"),
                "signature": co_signature(s, data),
                "closing": persona_closing(s, "co"),
            },
            {
                "from": vendor_header(vendor),
                "sent": f"{fmt_date(s.timeline['questions_due'])} {email_time(s, 't19', 11, 37)}",
                "to": co_header(s, data),
                "subject": subject,
                "body": f"Good day,\n\nReference solicitation {s.solicitation_number}. {question}\n\nThank you for the opportunity to quote.",
                "signature": [vendor.get("signer", "Authorized Representative"), vendor["name"], vendor_email(vendor)],
                "closing": "Regards,",
            },
        ],
    )


def write_vehicle_closeout_thread(folder: Path, vehicle: dict[str, Any], data: dict[str, Any]) -> None:
    """Renewal-decision email traffic that makes an expired master vehicle unambiguous.

    This is the primary trainee-facing evidence for expired-vehicle/expired-parent
    injects: months alone cannot signal expiration in a year-masked kit, so the
    record itself documents the decision not to renew.
    """
    number = str(vehicle.get("vehicle_number", ""))
    instrument = str(vehicle.get("instrument") or "BPA")
    title = str(vehicle.get("title") or "recurring support requirement")
    vendor = str(vehicle.get("vendor") or "the contractor")
    rng = random.Random(f"{number}|closeout")
    co = rng.choice(data["contracting_office"]["contacts"])
    office_symbol = data["contracting_office"]["office_symbol"]
    customer_unit = str(vehicle.get("customer") or "")
    customer = next((c for c in data["customers"] if c["unit"] == customer_unit), rng.choice(data["customers"]))
    approver = rng.choice(customer["approvers"])
    co_addr = outlook_name(co["name"], office_symbol, co["email"])
    approver_addr = outlook_name(approver, customer_office_symbol(customer["unit"]), person_email(approver))
    period_end = str(vehicle.get("period_end") or f"30 September {GENERIC_YEAR_PREV}")
    action_word = "calls" if instrument == "BPA" else "task or delivery orders"
    subject = f"{instrument} {number} - period expiration and renewal decision"
    write_outlook_thread_pdf(
        folder / compact_doc_name(s, "Renewal Decision"),
        subject,
        [
            {
                "from": co_addr,
                "sent": f"29 September {GENERIC_YEAR_PREV} 1404L",
                "to": approver_addr,
                "cc": outlook_name(rng.choice(customer["requesters"]), customer_office_symbol(customer["unit"])),
                "subject": f"RE: {subject}",
                "body": (
                    f"Decision is documented for the file: {instrument} {number} ({title}) will NOT be re-established. "
                    f"The ordering period ends {period_end} and there are no remaining option or continuation periods.\n\n"
                    f"Effective that date, no further {action_word} are authorized against {number}. The agreement is closed out. "
                    f"{vendor} has been notified that the Government will place no further orders.\n\n"
                    "Route any new requirements as standalone purchase requests, or against the follow-on vehicle if one is established. "
                    "If anyone attempts to cite this number on a new requirement, send them to the contracting office first."
                ),
                "signature": email_signature(co["name"], "Contingency Contracting Officer", data["contracting_office"]["office_name"], f"DSN: {co['phone'].replace('DSN ', '')}", co["email"]),
            },
            {
                "from": approver_addr,
                "sent": f"26 September {GENERIC_YEAR_PREV} 0938L",
                "to": co_addr,
                "subject": f"RE: {subject}",
                "body": (
                    f"We looked at the usage numbers on our side. {'Call' if instrument == 'BPA' else 'Order'} volume this year did not justify keeping the agreement open, "
                    "and the recurring portion of the requirement is being absorbed into the larger base support contract.\n\n"
                    "The unit concurs with letting it expire. We will route anything new through a fresh purchase request."
                ),
                "signature": email_signature(approver, "Approving Official", customer["display_name"], "DSN: 318-XXX-4410", person_email(approver)),
            },
            {
                "from": co_addr,
                "sent": f"15 September {GENERIC_YEAR_PREV} 1117L",
                "to": approver_addr,
                "subject": subject,
                "body": (
                    f"The ordering period for {instrument} {number} ({title}) ends {period_end}.\n\n"
                    "Before it lapses I need the mission partner's position: do we re-establish the vehicle for another period, "
                    "or let it expire? If usage has dropped or the requirement is moving to another vehicle, expiration is the cleaner option.\n\n"
                    "If we let it lapse, be aware the unit cannot place or request new orders against this number afterward."
                ),
                "signature": email_signature(co["name"], "Contingency Contracting Officer", data["contracting_office"]["office_name"], f"DSN: {co['phone'].replace('DSN ', '')}", co["email"]),
            },
        ],
    )


def write_parent_archive_folder(contract_files_dir: Path, vehicle: dict[str, Any], data: dict[str, Any]) -> Path:
    """Minimal archived master file for an expired parent that was never generated in this office.

    A thin folder is realistic - the prior rotation closed the vehicle out - and it
    gives the student a real place to find the closeout traffic.
    """
    number = str(vehicle.get("vehicle_number", ""))
    label = truncate_filename(str(vehicle.get("title") or "Master Vehicle"), MAX_ACTION_LABEL_CHARS, "Master Vehicle")
    folder = contract_files_dir / sanitize_filename(f"{number} - {label}")
    award_folder = folder / "7. Award"
    award_folder.mkdir(parents=True, exist_ok=True)
    write_vehicle_closeout_thread(award_folder, vehicle, data)
    instrument = str(vehicle.get("instrument") or "BPA")
    limit_rows = (
        [["Per-Call Purchase Limitation", money(float(vehicle["call_limit"]))]] if vehicle.get("call_limit") else []
    ) + (
        [["IDIQ Ceiling (Maximum)", money(float(vehicle["ceiling"]))]] if vehicle.get("ceiling") else []
    )
    write_pdf(
        award_folder / compact_doc_name_for_number(number, "Vehicle Summary"),
        f"Master {instrument} Summary - Closed",
        f"{number} | {vehicle.get('title', '')}",
        [
            {
                "heading": "Vehicle Record",
                "table": [
                    ["Field", "Entry"],
                    [f"{instrument} Number", number],
                    ["Contractor", str(vehicle.get("vendor", ""))],
                    ["Ordering Period", f"{vehicle.get('period_start', '')} through {vehicle.get('period_end', '')}"],
                    *limit_rows,
                    ["Status", "EXPIRED - not renewed; no further orders authorized"],
                ],
                "widths": [2.0 * inch, 4.4 * inch],
            },
            {
                "heading": "Disposition",
                "paragraphs": [
                    "The ordering period ended and the vehicle was not re-established. See the renewal decision email traffic in this folder.",
                    "The remainder of the original master file was retired with the prior rotation's records. This summary and the closeout traffic are retained for reference.",
                ],
            },
        ],
    )
    return folder


def write_prior_performance_archive(contract_files_dir: Path, record: dict[str, Any], s: Scenario, data: dict[str, Any]) -> Path:
    """Archived prior action with documented delivery problems by the current awardee."""
    prior_number = str(record.get("prior_number", ""))
    label = truncate_filename(str(record.get("folder_label") or "Prior Requirement"), MAX_ACTION_LABEL_CHARS, "Prior Requirement")
    vendor = str(record.get("vendor", ""))
    folder = contract_files_dir / sanitize_filename(f"{prior_number} - {label}")
    delivery_folder = folder / "8. Delivery Confirmation"
    delivery_folder.mkdir(parents=True, exist_ok=True)
    subject = f"Delivery problems - {prior_number}"
    co_addr = co_header(s, data)
    requester_addr = requester_header(s)
    write_outlook_thread_pdf(
        delivery_folder / compact_doc_name_for_number(prior_number, "Delivery Issue"),
        subject,
        [
            {
                "from": co_addr,
                "sent": f"19 June {GENERIC_YEAR_PREV} 1322L",
                "to": requester_addr,
                "cc": approver_header(s),
                "subject": f"RE: {subject}",
                "body": (
                    f"Documented for the record. {vendor} delivered nine days late, short on quantity, and only completed the requirement after "
                    "repeated follow-up. The discrepancies and the vendor's responsiveness are noted in the file.\n\n"
                    "I am keeping this in the contract file as past performance information. It should be considered in any future evaluation "
                    "involving this contractor."
                ),
                "signature": co_signature(s, data),
            },
            {
                "from": requester_addr,
                "sent": f"19 June {GENERIC_YEAR_PREV} 0907L",
                "to": co_addr,
                "subject": subject,
                "body": (
                    f"Reporting problems with the delivery under {prior_number}. The vendor was nine days past the required date, the first delivery "
                    "was short, and several items arrived damaged. We refused two items and the replacements took another week.\n\n"
                    "The unit ultimately got what it needed, but it took constant follow-up. Documenting so it is on record."
                ),
                "signature": requester_signature(s),
            },
        ],
    )
    write_pdf(
        delivery_folder / compact_doc_name_for_number(prior_number, "Past Perf Memo"),
        "Memorandum for Record - Contractor Past Performance",
        f"{prior_number} | {vendor}",
        [
            {
                "heading": "Record",
                "table": [
                    ["Field", "Entry"],
                    ["Contract", prior_number],
                    ["Contractor", vendor],
                    ["Issue", "Late delivery (9 days), short quantity, damaged items, slow correction"],
                    ["Resolution", "Requirement eventually completed after repeated Government follow-up"],
                    ["Disposition", "Retain in file; consider in future source selections involving this contractor"],
                ],
                "widths": [1.5 * inch, 4.9 * inch],
            },
            {
                "heading": "Note",
                "paragraphs": [
                    "This memorandum documents performance information for use in future evaluations in accordance with simplified acquisition procedures. "
                    "It is not a formal performance report, but it is part of the office record on this contractor."
                ],
            },
        ],
    )
    return folder


def write_benign_extras(action_root: Path, s: Scenario, data: dict[str, Any]) -> None:
    """Occasionally add harmless extra correspondence so action files do not
    all share an identical document census. These extras are deliberately
    benign - they resolve themselves inside the document and are never
    exercise injects."""
    rng = scenario_rng(s, "extras")
    if s.stage >= 3 and rng.random() < 0.30:
        write_customer_followup_email(stage_path(action_root, 1), s, data)
    if s.stage >= 2 and not is_master_vehicle(s) and rng.random() < 0.25:
        write_funding_clarification_email(stage_path(action_root, 2), s, data)
    if s.stage >= 4 and rng.random() < 0.35:
        write_vendor_question_email(stage_path(action_root, 4), s, data)


def stage_path(action_root: Path, stage: int) -> Path:
    return action_root / stage_folder_name(stage)


def generate_action(action_root: Path, s: Scenario, data: dict[str, Any]) -> None:
    action_root.mkdir(parents=True, exist_ok=True)
    for stage, folder_name in STAGE_FOLDERS:
        if stage <= s.stage:
            (action_root / folder_name).mkdir(parents=True, exist_ok=True)

    if s.archetype.get("_inject_expired_vehicle"):
        # Render the entire expired master file as a prior-year record.
        set_active_year_token(GENERIC_YEAR_PREV2)
    try:
        if s.stage >= 1:
            write_initial_documents(stage_path(action_root, 1), s, data)
        if s.stage >= 2:
            write_funding_documents(stage_path(action_root, 2), s, data)
        if s.stage >= 3:
            write_market_research(stage_path(action_root, 3), s)
        if s.stage >= 4:
            write_solicitation(stage_path(action_root, 4), s, data)
        if s.stage >= 5:
            write_quotes(stage_path(action_root, 5), s)
        if s.stage >= 6:
            write_evaluation(stage_path(action_root, 6), s)
        if s.stage >= 7:
            write_award(stage_path(action_root, 7), s, data)
        if s.stage >= 8:
            write_delivery(stage_path(action_root, 8), s)
        if s.stage >= 7 and not is_master_vehicle(s):
            maybe_write_admin_mod(stage_path(action_root, 7), s, data)
            if is_service_requirement(s):
                write_cor_designation_letter(stage_path(action_root, 7), s, data)
        if s.archetype.get("_inject_expired_vehicle") and s.stage >= 7:
            closeout_vehicle = {
                "vehicle_number": s.contract_number,
                "instrument": "BPA" if s.category == "bpa" else "IDIQ",
                "title": s.archetype["title"],
                "vendor": s.winner["name"],
                "customer": s.customer["unit"],
                "period_end": f"30 September {GENERIC_YEAR_PREV}",
                "call_limit": s.archetype.get("_bpa_call_limit", ""),
                "ceiling": s.archetype.get("_idiq_ceiling", ""),
            }
            write_vehicle_closeout_thread(stage_path(action_root, 7), closeout_vehicle, data)
        write_benign_extras(action_root, s, data)
    finally:
        set_active_year_token(GENERIC_YEAR)


def scenario_manifest_row(s: Scenario, action_root: Path) -> dict[str, Any]:
    claimed_stage = int(s.archetype.get("_inject_tracker_claimed_stage") or 0)
    return {
        "index": s.index,
        "folder": str(action_root.name),
        "folder_path": str(action_root),
        "title": s.archetype["title"],
        "category": s.category,
        "requirement_category": s.requirement_category,
        "stage": s.stage,
        "stage_name": STAGE_FOLDERS[(claimed_stage or s.stage) - 1][1],
        "customer": s.customer["unit"],
        "requester": s.requester,
        "co": s.co["name"],
        "contractor": master_awardee_summary(s) if is_multiple_award_master(s) else s.winner["name"],
        "awardee_count": len(master_awardees(s)) if is_multiple_award_master(s) else "",
        "awardees": master_awardee_display_names(s) if is_multiple_award_master(s) else "",
        "awardee_contract_numbers": master_awardee_contract_numbers_text(s) if is_multiple_award_master(s) else "",
        "pr_number": funding_reference_label(s),
        "solicitation_number": s.solicitation_number,
        "solicitation_style": s.solicitation_style,
        "contract_number": s.contract_number,
        "piid_sequence": s.piid_sequence,
        "parent_instrument": s.parent_instrument_label,
        "parent_contract_number": s.parent_contract_number,
        "amount": 0 if is_master_vehicle(s) else s.base_amount,
        "award_date": fmt_date(s.timeline["award"]) if s.stage >= 7 else "",
        "pop_end": f"{fmt_date(s.timeline['pop_end'])}{following_year_suffix(s.timeline['award'], s.timeline['pop_end'])}" if s.stage >= 7 else "",
        "delivery_date": fmt_date(s.timeline["delivery"]) if s.stage >= 8 else "",
        "parent_found_in_registry": bool(s.parent_vehicle),
        "standalone_parent_order": bool(s.parent_contract_number and not s.parent_vehicle),
        "injects": ";".join(s.archetype.get("_injects") or []),
        "tracker_stage": s.archetype.get("_inject_tracker_claimed_stage") or "",
        "ai_plan_used": bool(s.archetype.get("_ai_plan_used")),
        "ai_plan_rationale": str(s.archetype.get("_ai_plan_rationale") or ""),
        "ai_plan_guardrail": str(s.archetype.get("_ai_plan_guardrail") or ""),
    }


def scenario_ai_context(s: Scenario, action_root: Path) -> dict[str, Any]:
    return {
        "contract_number": s.contract_number,
        "folder": str(action_root.name),
        "title": s.archetype["title"],
        "category": s.category,
        "requirement_category": s.requirement_category,
        "stage": s.stage,
        "solicitation_style": s.solicitation_style,
        "requirement": s.archetype["requirement"],
        "variation_profile": s.archetype.get("_variation_profile", {}),
        "evaluation_strategy": evaluation_strategy_summary(s),
        "technical_considerations": technical_considerations_from_focus(s.archetype["evaluation_focus"]),
        "line_items": [
            {
                "clin": item["clin"],
                "description": item["description"],
                "quantity": item["quantity"],
                "unit": item["unit"],
                "amount": item["amount"],
            }
            for item in s.line_items
        ],
        "awardee": s.winner["name"],
        "award_amount": s.base_amount,
        "vendors": [
            {
                "vendor": row["vendor"],
                "amount": row.get("amount"),
                "technical": row.get("technical"),
                "past_performance": past_performance_finding_for_quote(s, row),
                "past_performance_relevance": past_performance_relevance_for_quote(s, row),
                "past_performance_risk": past_performance_risk_for_quote(s, row),
                "non_response": row.get("non_response"),
                "omitted_technical": row.get("missing_factors", []),
            }
            for row in s.quote_rows
        ],
        "parent_contract_number": s.parent_contract_number,
        "documents_expected": {
            "sor": s.stage >= 1,
            "form9_or_no_funding_memo": s.stage >= 2,
            "market_research": s.stage >= 3,
            "solicitation": s.stage >= 4,
            "quotes": s.stage >= 5,
            "technical_evaluation": s.stage >= 6,
            "past_performance_evaluation": s.stage >= 6,
            "award": s.stage >= 7,
            "delivery_confirmation": s.stage >= 8,
            "pws": s.stage >= 1 and s.requirement_category == "service",
            "sow": s.stage >= 1 and s.requirement_category == "construction",
        },
    }


def write_ai_plan_file(package_dir: Path, plan: dict[str, Any] | None, messages: list[str]) -> Path:
    office_controller_dir(package_dir).mkdir(parents=True, exist_ok=True)
    path = office_controller_dir(package_dir) / "_ai_scenario_plan.json"
    payload = {
        "controller_only": True,
        "messages": messages,
        "plan": plan or {},
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def build_ai_qa_prompt(context: list[dict[str, Any]]) -> str:
    return f"""
Review this generated CCO training package metadata. Return one JSON object.
You are checking realism and internal consistency, not rewriting the package.
Focus on issues like mismatched evaluation factors, missing past performance evaluation,
technical evaluators assessing price, unrealistic quantity-to-price relationships,
wrong award form for construction, service periods that are not one year, and parent BPA/IDIQ logic.

Return:
summary: short string
findings: array of objects with severity, finding, recommendation
realism_notes: array of strings
controller_notes: array of strings

Metadata:
{json.dumps(context, indent=2)}
"""


def request_ai_qa_report(context: list[dict[str, Any]], model: str = "", provider: str = "codex-cli") -> tuple[dict[str, Any] | None, str]:
    system_prompt = (
        "You are a controller-side QA reviewer for fictitious deployed CCO training packages. "
        "Return only JSON. Be concise, practical, and training-focused."
    )
    return call_ai_json(system_prompt, build_ai_qa_prompt(context), model, provider)


def render_ai_qa_markdown(report: dict[str, Any] | None, message: str, context: list[dict[str, Any]]) -> str:
    lines = [
        "# AI QA Report",
        "",
        "Controller-only note. Do not place this file in the trainee mock office unless intentionally used as an exercise-control artifact.",
        "",
        f"Status: {message}",
        "",
    ]
    if not report:
        lines.extend(
            [
                "## Deterministic Summary",
                "",
                f"Actions reviewed: {len(context)}",
            ]
        )
        for item in context:
            lines.append(f"- {item['contract_number']}: {item['title']} ({item['category']}, stage {item['stage']})")
        lines.append("")
        return "\n".join(lines)

    summary = clean_ai_text(report.get("summary"), 700)
    if summary:
        lines.extend(["## Summary", "", summary, ""])
    findings = report.get("findings") if isinstance(report.get("findings"), list) else []
    lines.extend(["## Findings", ""])
    if findings:
        for raw in findings[:12]:
            if not isinstance(raw, dict):
                continue
            severity = clean_ai_text(raw.get("severity"), 40) or "note"
            finding = clean_ai_text(raw.get("finding"), 700)
            recommendation = clean_ai_text(raw.get("recommendation"), 700)
            if finding:
                lines.append(f"- [{severity}] {finding}")
                if recommendation:
                    lines.append(f"  Recommendation: {recommendation}")
    else:
        lines.append("- No AI findings returned.")
    for section, label in [("realism_notes", "Realism Notes"), ("controller_notes", "Controller Notes")]:
        values = report.get(section) if isinstance(report.get(section), list) else []
        if values:
            lines.extend(["", f"## {label}", ""])
            for value in values[:10]:
                note = clean_ai_text(value, 700)
                if note:
                    lines.append(f"- {note}")
    lines.append("")
    return "\n".join(lines)


def write_ai_qa_report(package_dir: Path, context: list[dict[str, Any]], model: str = "", provider: str = "codex-cli") -> tuple[Path, str]:
    report, message = request_ai_qa_report(context, model, provider)
    office_controller_dir(package_dir).mkdir(parents=True, exist_ok=True)
    path = office_controller_dir(package_dir) / "_ai_qa_report.md"
    path.write_text(render_ai_qa_markdown(report, message, context), encoding="utf-8")
    return path, message


def write_manifests(package_dir: Path, rows: list[dict[str, Any]]) -> None:
    controller = office_controller_dir(package_dir)
    controller.mkdir(parents=True, exist_ok=True)
    json_path = controller / "_controller_manifest.json"
    csv_path = controller / "_controller_manifest.csv"
    # remove legacy root-level copies so the office root stays trainee-clean
    (package_dir / "_controller_manifest.json").unlink(missing_ok=True)
    (package_dir / "_controller_manifest.csv").unlink(missing_ok=True)
    json_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    if rows:
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=manifest_fieldnames(rows), extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)


MANIFEST_FIELD_ORDER = [
    "index",
    "folder",
    "folder_path",
    "title",
    "category",
    "requirement_category",
    "stage",
    "stage_name",
    "customer",
    "requester",
    "co",
    "contractor",
    "awardee_count",
    "awardees",
    "awardee_contract_numbers",
    "pr_number",
    "solicitation_number",
    "solicitation_style",
    "contract_number",
    "piid_sequence",
    "parent_instrument",
    "parent_contract_number",
    "amount",
    "award_date",
    "pop_end",
    "delivery_date",
    "parent_found_in_registry",
    "standalone_parent_order",
    "ai_plan_used",
    "ai_plan_rationale",
    "ai_plan_guardrail",
]


def manifest_fieldnames(rows: list[dict[str, Any]]) -> list[str]:
    keys = set()
    for row in rows:
        keys.update(row.keys())
    ordered = [field for field in MANIFEST_FIELD_ORDER if field in keys]
    ordered.extend(sorted(keys.difference(ordered)))
    return ordered


def is_placeholder_row(row: dict[str, Any]) -> bool:
    return bool(row.get("deleted_placeholder")) or str(row.get("title") or "").strip().lower() == "piid not used"


def active_manifest_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in rows if not is_placeholder_row(row)]


def load_manifest_rows(package_dir: Path) -> list[dict[str, Any]]:
    json_path = office_controller_dir(package_dir) / "_controller_manifest.json"
    if not json_path.exists():
        json_path = package_dir / "_controller_manifest.json"
    csv_path = package_dir / "_controller_manifest.csv"
    if json_path.exists():
        try:
            payload = json.loads(json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            payload = []
        if isinstance(payload, list):
            return [row for row in payload if isinstance(row, dict)]
    if csv_path.exists():
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            return list(csv.DictReader(handle))
    return []


def piid_parts_from_contract_number(value: Any) -> tuple[str, int]:
    match = re.search(r"FA4867XX([A-Z])(\d{4})", str(value or "").upper())
    return (match.group(1), int(match.group(2))) if match else ("", 0)


def piid_sequence_from_contract_number(value: Any, instrument_letter: str = "") -> int:
    letter, sequence = piid_parts_from_contract_number(value)
    if instrument_letter and letter != instrument_letter.upper()[:1]:
        return 0
    return sequence


def update_sequence_map(target: dict[str, int], value: Any) -> None:
    for match in re.finditer(r"FA4867XX([A-Z])(\d{4})", str(value or "").upper()):
        letter, sequence = match.group(1), int(match.group(2))
        target[letter] = max(target.get(letter, 0), sequence)


def highest_existing_piid_sequences(rows: list[dict[str, Any]], package_dir: Path) -> dict[str, int]:
    highest_by_instrument: dict[str, int] = {}
    for row in rows:
        update_sequence_map(highest_by_instrument, row.get("contract_number") or row.get("folder"))
        update_sequence_map(highest_by_instrument, row.get("awardee_contract_numbers"))
        update_sequence_map(highest_by_instrument, row.get("awardees"))
    scan_dirs = [office_files_dir(package_dir), package_dir]
    for scan_dir in scan_dirs:
        if scan_dir.exists():
            for child in scan_dir.iterdir():
                if child.is_dir():
                    update_sequence_map(highest_by_instrument, child.name)
    return highest_by_instrument


def highest_existing_piid_sequence(rows: list[dict[str, Any]], package_dir: Path, instrument_letter: str = "") -> int:
    highest_by_instrument = highest_existing_piid_sequences(rows, package_dir)
    if instrument_letter:
        return highest_by_instrument.get(instrument_letter.upper()[:1], 0)
    return max(highest_by_instrument.values(), default=0)


def highest_output_piid_sequences(output_root: Path) -> dict[str, int]:
    highest_by_instrument: dict[str, int] = {}
    if not output_root.exists():
        return highest_by_instrument
    for package_dir in output_root.iterdir():
        if not package_dir.is_dir() or package_dir.name.startswith((".", "_")):
            continue
        for letter, sequence in highest_existing_piid_sequences(load_manifest_rows(package_dir), package_dir).items():
            highest_by_instrument[letter] = max(highest_by_instrument.get(letter, 0), sequence)
        for action_dir in package_dir.iterdir():
            if action_dir.is_dir():
                update_sequence_map(highest_by_instrument, action_dir.name)
    return highest_by_instrument


def highest_output_piid_sequence(output_root: Path, instrument_letter: str = "") -> int:
    highest_by_instrument = highest_output_piid_sequences(output_root)
    if instrument_letter:
        return highest_by_instrument.get(instrument_letter.upper()[:1], 0)
    return max(highest_by_instrument.values(), default=0)


def read_sequence_state(output_root: Path) -> dict[str, Any]:
    path = output_root / SEQUENCE_STATE_FILE
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def clean_sequence_map(value: Any) -> dict[str, int]:
    if not isinstance(value, dict):
        return {}
    cleaned: dict[str, int] = {}
    for raw_letter, raw_sequence in value.items():
        letter = str(raw_letter or "").strip().upper()[:1]
        if not re.fullmatch(r"[A-Z]", letter or ""):
            continue
        try:
            sequence = int(raw_sequence or 0)
        except (TypeError, ValueError):
            sequence = 0
        if sequence > 0:
            cleaned[letter] = max(cleaned.get(letter, 0), sequence)
    return cleaned


def write_sequence_state(output_root: Path, highest_by_instrument: dict[str, int]) -> None:
    path = output_root / SEQUENCE_STATE_FILE
    clean_map = clean_sequence_map(highest_by_instrument)
    payload = {
        "highest_by_instrument": clean_map,
        "highest_sequence": max(clean_map.values(), default=0),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": "Controller state for avoiding duplicate mock PIID numbers by instrument letter across generated output packages.",
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def acquire_sequence_lock(output_root: Path, timeout_seconds: float = 20.0) -> Any:
    lock_path = output_root / SEQUENCE_LOCK_FILE
    deadline = time.time() + timeout_seconds
    while True:
        try:
            handle = lock_path.open("x", encoding="utf-8")
            handle.write(f"{time.time()}\n")
            handle.flush()
            return handle
        except FileExistsError:
            try:
                age = time.time() - lock_path.stat().st_mtime
                if age > 300:
                    lock_path.unlink()
                    continue
            except OSError:
                pass
            if time.time() >= deadline:
                raise RuntimeError("Timed out waiting for PIID sequence lock.")
            time.sleep(0.1)


def release_sequence_lock(handle: Any) -> None:
    try:
        lock_path = Path(handle.name)
        handle.close()
        lock_path.unlink(missing_ok=True)
    except OSError:
        pass


def reserve_piid_sequences(
    output_root: Path,
    count: int,
    rng: random.Random,
    minimum_start_after: int = 0,
    instrument_letter: str = "P",
) -> list[int]:
    output_root.mkdir(parents=True, exist_ok=True)
    letter = (instrument_letter or "P").upper()[:1]
    lock = acquire_sequence_lock(output_root)
    try:
        state = read_sequence_state(output_root)
        stored_by_instrument = clean_sequence_map(state.get("highest_by_instrument"))
        stored_highest = stored_by_instrument.get(letter, 0)
        observed_highest = highest_output_piid_sequence(output_root, letter)
        start_after = max(minimum_start_after, stored_highest, observed_highest)
        sequences = piid_sequence_numbers_after(count, rng, start_after)
        stored_by_instrument[letter] = max([stored_highest, observed_highest, *sequences])
        write_sequence_state(output_root, stored_by_instrument)
        return sequences
    finally:
        release_sequence_lock(lock)


def reserve_contiguous_piid_sequences(
    output_root: Path,
    count: int,
    rng: random.Random,
    start_after: int,
    instrument_letter: str,
) -> list[int]:
    sequences: list[int] = []
    current = start_after
    for _ in range(max(0, count)):
        current = reserve_piid_sequences(output_root, 1, rng, current, instrument_letter)[0]
        sequences.append(current)
    return sequences


def next_manifest_index(rows: list[dict[str, Any]]) -> int:
    highest = 0
    for row in rows:
        try:
            highest = max(highest, int(row.get("index") or 0))
        except (TypeError, ValueError):
            continue
    return highest + 1


def workload_status(row: dict[str, Any]) -> str:
    if is_placeholder_row(row):
        return "PIID not used"
    stage = int(row.get("tracker_stage") or row.get("stage") or 0)
    category = str(row.get("category", ""))
    if stage >= 8:
        return "Delivered / receipt in file"
    if stage == 7:
        return "Awarded"
    if stage == 6:
        return "Evaluation"
    if stage == 5:
        return "Quotes received"
    if stage == 4:
        return "Solicitation out"
    if stage == 3:
        return "Market research"
    if stage == 2:
        if category in {"bpa", "idiq"}:
            return "No-fund master vehicle"
        return "Funded / pending solicitation"
    return "Requirements development"


def tracker_turnover_note(row: dict[str, Any]) -> str:
    if is_placeholder_row(row):
        return "PIID intentionally left unused; no action folder should exist for this row."
    category = str(row.get("category", ""))
    stage = int(row.get("tracker_stage") or row.get("stage") or 0)
    if str(row.get("standalone_parent_order", "")).lower() in {"true", "1", "yes"}:
        parent_label = " ".join(part for part in [row.get("parent_instrument"), row.get("parent_contract_number")] if part).strip()
        return f"Call/order file references parent {parent_label}; master file was not generated in this package."
    if row.get("parent_contract_number") and not row.get("parent_found_in_registry"):
        return "Parent vehicle referenced; master file not in this tracker snapshot."
    if category == "bpa":
        return "Master agreement; calls carry funding."
    if category == "idiq":
        return "Ordering vehicle; check orders for actual obligations."
    note_seed = random.Random(f"{row.get('contract_number', '')}|tracker_note")
    if stage < 7:
        return note_seed.choice(
            [
                "Open action; old rotation did not finish award file.",
                "Still open - prior rotation ran out of time on this one.",
                "Open at turnover; pick up from the last completed stage folder.",
            ]
        )
    if stage == 7:
        return note_seed.choice(
            [
                "Awarded; receiving documentation not yet in folder.",
                "Award complete; waiting on customer receipt confirmation.",
                "Awarded - chase the receiving report if the customer goes quiet.",
            ]
        )
    if int(row.get("index") or 0) % 6 == 0:
        return ""
    return note_seed.choice(
        [
            "No immediate issue noted in turnover tracker.",
            "Closed out clean as far as this tracker shows.",
            "Complete; no follow-up flagged at turnover.",
            "",
        ]
    )


def scenario_vehicle_record(s: Scenario, action_root: Path, package_dir: Path) -> dict[str, Any] | list[dict[str, Any]] | None:
    if s.category not in {"bpa", "idiq"}:
        return None
    instrument = "BPA" if s.category == "bpa" else "IDIQ"
    status = "Active" if s.stage >= 7 else "Pre-award"
    obligated = 0 if is_master_vehicle(s) else s.base_amount
    if s.category == "bpa":
        ceiling_value: Any = ""
        call_limit_value: Any = bpa_call_limit_value(s)
        minimum_value: Any = ""
        estimated_value: Any = float(s.archetype.get("_master_estimated_value") or 0) or ""
    else:
        ceiling_value = idiq_ceiling_value(s)
        call_limit_value = ""
        minimum_value = idiq_minimum_value(s)
        estimated_value = ""
    if is_multiple_award_master(s):
        expired = bool(s.archetype.get("_inject_expired_vehicle"))
        period_start = f"1 October {GENERIC_YEAR_PREV2}" if expired else (fmt_date(s.timeline["award"]) if s.stage >= 7 else "")
        period_end = (
            f"30 September {GENERIC_YEAR_PREV}"
            if expired
            else f"{fmt_date(s.timeline['pop_end'])}{following_year_suffix(s.timeline['award'], s.timeline['pop_end'])}"
            if s.stage >= 7
            else ""
        )
        award_date = f"1 October {GENERIC_YEAR_PREV2}" if expired else (fmt_date(s.timeline["award"]) if s.stage >= 7 else "")
        records: list[dict[str, Any]] = []
        for awardee in master_awardees(s):
            contractor = contractor_for_master_awardee(s, awardee)
            records.append(
                {
                    "vehicle_number": str(awardee.get("contract_number") or s.contract_number),
                    "instrument": instrument,
                    "title": s.archetype["title"],
                    "scope": s.archetype["requirement"],
                    "requirement_category": s.requirement_category,
                    "status": "Expired" if expired else status,
                    "vendor": contractor["name"],
                    "vendor_code": contractor.get("code", ""),
                    "vendor_address": contractor.get("address", ""),
                    "vendor_phone": contractor.get("phone", ""),
                    "vendor_signer": contractor.get("signer", ""),
                    "awardee_count": "",
                    "awardees": [],
                    "multiple_award_pool": True,
                    "pool_awardees": master_awardee_display_names(s),
                    "pool_contract_numbers": master_awardee_contract_numbers_text(s),
                    "customer": s.customer["unit"],
                    "contracting_officer": s.co["name"],
                    "ceiling": ceiling_value,
                    "call_limit": call_limit_value,
                    "minimum_guarantee": minimum_value,
                    "estimated_annual_value": estimated_value,
                    "base_obligated_amount": obligated,
                    "order_obligated_amount": 0.0,
                    "order_count": 0,
                    "obligated_amount": obligated,
                    "period_start": period_start,
                    "period_end": period_end,
                    "award_date": award_date,
                    "package": package_dir.name,
                    "folder": str(action_root.name),
                    "folder_path": str(action_root),
                    "price_list_title": price_list_attachment_title(s) if has_price_list(s) else "",
                    "price_list": vehicle_price_list_record(s, awardee),
                }
            )
        return records
    if s.archetype.get("_inject_expired_vehicle"):
        return {
            "vehicle_number": s.contract_number,
            "instrument": instrument,
            "title": s.archetype["title"],
            "scope": s.archetype["requirement"],
            "requirement_category": s.requirement_category,
            "status": "Expired",
            "vendor": master_awardee_summary(s) if is_multiple_award_master(s) else s.winner["name"],
            "vendor_code": "" if is_multiple_award_master(s) else s.winner["code"],
            "vendor_address": "" if is_multiple_award_master(s) else s.winner.get("address", ""),
            "vendor_phone": "" if is_multiple_award_master(s) else s.winner.get("phone", ""),
            "vendor_signer": "" if is_multiple_award_master(s) else s.winner.get("signer", ""),
            "awardee_count": len(master_awardees(s)) if is_multiple_award_master(s) else "",
            "awardees": master_awardees(s),
            "customer": s.customer["unit"],
            "contracting_officer": s.co["name"],
            "ceiling": ceiling_value,
            "call_limit": call_limit_value,
            "minimum_guarantee": minimum_value,
            "estimated_annual_value": estimated_value,
            "base_obligated_amount": obligated,
            "order_obligated_amount": 0.0,
            "order_count": 0,
            "obligated_amount": obligated,
            "period_start": f"1 October {GENERIC_YEAR_PREV2}",
            "period_end": f"30 September {GENERIC_YEAR_PREV}",
            "award_date": f"1 October {GENERIC_YEAR_PREV2}",
            "package": package_dir.name,
            "folder": str(action_root.name),
            "folder_path": str(action_root),
            "price_list_title": price_list_attachment_title(s) if has_price_list(s) else "",
            "price_list": vehicle_price_list_record(s),
        }
    return {
        "vehicle_number": s.contract_number,
        "instrument": instrument,
        "title": s.archetype["title"],
        "scope": s.archetype["requirement"],
        "requirement_category": s.requirement_category,
        "status": status,
        "vendor": master_awardee_summary(s) if is_multiple_award_master(s) else s.winner["name"],
        "vendor_code": "" if is_multiple_award_master(s) else s.winner["code"],
        "vendor_address": "" if is_multiple_award_master(s) else s.winner.get("address", ""),
        "vendor_phone": "" if is_multiple_award_master(s) else s.winner.get("phone", ""),
        "vendor_signer": "" if is_multiple_award_master(s) else s.winner.get("signer", ""),
        "awardee_count": len(master_awardees(s)) if is_multiple_award_master(s) else "",
        "awardees": master_awardees(s),
        "customer": s.customer["unit"],
        "contracting_officer": s.co["name"],
        "ceiling": ceiling_value,
        "call_limit": call_limit_value,
        "minimum_guarantee": minimum_value,
        "estimated_annual_value": estimated_value,
        "base_obligated_amount": obligated,
        "order_obligated_amount": 0.0,
        "order_count": 0,
        "obligated_amount": obligated,
        "period_start": fmt_date(s.timeline["award"]) if s.stage >= 7 else "",
        "period_end": f"{fmt_date(s.timeline['pop_end'])}{following_year_suffix(s.timeline['award'], s.timeline['pop_end'])}" if s.stage >= 7 else "",
        "award_date": fmt_date(s.timeline["award"]) if s.stage >= 7 else "",
        "package": package_dir.name,
        "folder": str(action_root.name),
        "folder_path": str(action_root),
        "price_list_title": price_list_attachment_title(s) if has_price_list(s) else "",
        "price_list": vehicle_price_list_record(s),
    }


def scenario_parent_reference_record(s: Scenario, action_root: Path, package_dir: Path) -> dict[str, Any] | None:
    if not is_ordering_action(s):
        return None
    return {
        "action_number": s.contract_number,
        "parent_number": s.parent_contract_number,
        "parent_instrument": s.parent_instrument_label,
        "parent_found_in_registry": bool(s.parent_vehicle),
        "title": s.archetype["title"],
        "requirement_category": s.requirement_category,
        "vendor": s.winner["name"],
        "amount": s.base_amount,
        "status": workload_status({"stage": s.stage}),
        "package": package_dir.name,
        "folder": str(action_root.name),
        "folder_path": str(action_root),
    }


def scenario_inject_parent_record(s: Scenario, package_dir: Path) -> dict[str, Any] | None:
    """Return the (mutated) parent vehicle record for parent-side injects.

    Kept package-level only so synthetic parent numbers cannot collide with
    real master records in the global registry.
    """
    if not is_ordering_action(s):
        return None
    inject_keys = set(s.archetype.get("_injects") or [])
    if not inject_keys & {"expired-parent", "near-ceiling-parent", "call-limit-breach", "out-of-scope-order"}:
        return None
    if not s.parent_vehicle:
        return None
    record = {key: value for key, value in s.parent_vehicle.items() if not str(key).startswith("_")}
    if not record.get("package"):
        record["package"] = package_dir.name
    record["inject"] = True
    return record


def vehicle_registry_file(output_root: Path) -> Path:
    return output_root / "_vehicle_registry.json"


def load_vehicle_registry(output_root: Path) -> list[dict[str, Any]]:
    path = vehicle_registry_file(output_root)
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if isinstance(payload, list):
        return [record for record in payload if isinstance(record, dict)]
    if isinstance(payload, dict):
        vehicles = payload.get("vehicles", [])
        if isinstance(vehicles, list):
            return [record for record in vehicles if isinstance(record, dict)]
    return []


def merge_vehicle_records(*record_groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for group in record_groups:
        for record in group:
            number = str(record.get("vehicle_number", "")).upper()
            if not number:
                continue
            merged[number] = {**merged.get(number, {}), **record}
    return sorted(merged.values(), key=lambda item: str(item.get("vehicle_number", "")))


def write_global_vehicle_registry(output_root: Path, vehicles: list[dict[str, Any]]) -> None:
    path = vehicle_registry_file(output_root)
    current = load_vehicle_registry(output_root)
    path.write_text(
        json.dumps(
            {
                "generated_at": current_controller_timestamp(),
                "vehicles": merge_vehicle_records(current, vehicles),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def write_package_vehicle_registry(
    package_dir: Path,
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
) -> None:
    controller = office_controller_dir(package_dir)
    controller.mkdir(parents=True, exist_ok=True)
    (package_dir / "_vehicle_registry.json").unlink(missing_ok=True)
    (controller / "_vehicle_registry.json").write_text(
        json.dumps(
            {
                "generated_at": current_controller_timestamp(),
                "package": package_dir.name,
                "vehicles": merge_vehicle_records(vehicles),
                "parent_references": references,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def load_package_vehicle_registry(package_dir: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    path = office_controller_dir(package_dir) / "_vehicle_registry.json"
    if not path.exists():
        path = package_dir / "_vehicle_registry.json"
    if not path.exists():
        return [], []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return [], []
    if isinstance(payload, list):
        return [record for record in payload if isinstance(record, dict)], []
    if not isinstance(payload, dict):
        return [], []
    vehicles = payload.get("vehicles", [])
    references = payload.get("parent_references", [])
    return (
        [record for record in vehicles if isinstance(record, dict)] if isinstance(vehicles, list) else [],
        [record for record in references if isinstance(record, dict)] if isinstance(references, list) else [],
    )


def merge_parent_reference_records(*record_groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[tuple[str, str], dict[str, Any]] = {}
    for group in record_groups:
        for record in group:
            action = str(record.get("action_number", "")).upper()
            parent = str(record.get("parent_number", "")).upper()
            if not action and not parent:
                continue
            key = (action, parent)
            merged[key] = {**merged.get(key, {}), **record}
    return sorted(merged.values(), key=lambda item: (str(item.get("parent_number", "")), str(item.get("action_number", ""))))


def numeric_money_value(value: Any) -> float:
    try:
        if value in (None, ""):
            return 0.0
        return float(str(value).replace("$", "").replace(",", ""))
    except (TypeError, ValueError):
        return 0.0


def parent_base_obligated_amount(vehicle: dict[str, Any]) -> float:
    if vehicle.get("base_obligated_amount") not in (None, ""):
        return numeric_money_value(vehicle.get("base_obligated_amount"))
    if vehicle.get("order_obligated_amount") not in (None, ""):
        return max(0.0, numeric_money_value(vehicle.get("obligated_amount")) - numeric_money_value(vehicle.get("order_obligated_amount")))
    return numeric_money_value(vehicle.get("obligated_amount"))


def references_by_parent(references: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for ref in references:
        parent = str(ref.get("parent_number") or "").upper()
        if not parent:
            continue
        grouped.setdefault(parent, []).append(ref)
    return grouped


def apply_order_obligation_rollups(
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    grouped = references_by_parent(references)
    updated: list[dict[str, Any]] = []
    for vehicle in vehicles:
        record = dict(vehicle)
        parent_number = str(record.get("vehicle_number") or "").upper()
        order_refs = grouped.get(parent_number, [])
        order_total = round(sum(numeric_money_value(ref.get("amount")) for ref in order_refs), 2)
        base_obligated = round(parent_base_obligated_amount(record), 2)
        record["base_obligated_amount"] = base_obligated
        record["order_obligated_amount"] = order_total
        record["order_count"] = len(order_refs)
        record["obligated_amount"] = round(base_obligated + order_total, 2)
        ceiling = numeric_money_value(record.get("ceiling"))
        if ceiling:
            record["remaining_ceiling"] = round(ceiling - numeric_money_value(record.get("obligated_amount")), 2)
            if record["remaining_ceiling"] < 0 and str(record.get("status") or "").lower() == "active":
                record["status"] = "Active - ceiling exceeded"
        call_limit = numeric_money_value(record.get("call_limit"))
        if call_limit and order_refs:
            record["largest_call_or_order"] = round(max(numeric_money_value(ref.get("amount")) for ref in order_refs), 2)
        updated.append(record)
    return merge_vehicle_records(updated)


def parent_admin_status_formula(row_number: int) -> str:
    return (
        f'=IF($G{row_number}>0,'
        f'IF($K{row_number}<0,"OVER CEILING","OK"),'
        f'IF(AND($H{row_number}>0,$J{row_number}>$H{row_number}),"CALL LIMIT EXCEEDED","OK"))'
    )


def write_parent_order_admin_workbook(
    folder: Path,
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
) -> Path | None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
        from openpyxl.worksheet.table import Table as XlsxTable
        from openpyxl.worksheet.table import TableStyleInfo
    except ImportError:
        return None

    admin = parent_admin_dir(folder)
    admin.mkdir(parents=True, exist_ok=True)
    output_path = admin / "Order Administration Tracker.xlsx"
    wb = Workbook()
    ws_summary = wb.active
    ws_summary.title = "Summary"
    ws_log = wb.create_sheet("Order Log")
    for ws in [ws_summary, ws_log]:
        ws.sheet_view.showGridLines = False

    header_fill = PatternFill("solid", fgColor="1F4E78")
    alert_fill = PatternFill("solid", fgColor="FCE4D6")
    ok_fill = PatternFill("solid", fgColor="E2F0D9")
    header_font = Font(color="FFFFFF", bold=True)
    title_font = Font(size=15, bold=True, color="1F4E78")
    subtitle_font = Font(size=10, color="666666")
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    money_format = '$#,##0.00'

    ws_summary["A1"] = "Parent Vehicle Order Administration"
    ws_summary["A1"].font = title_font
    ws_summary["A2"] = "Tracks calls/task orders issued against the parent vehicle and shows ceiling or call-limit posture."
    ws_summary["A2"].font = subtitle_font
    ws_summary.merge_cells("A1:K1")
    ws_summary.merge_cells("A2:K2")
    ws_summary.append([])
    summary_headers = [
        "Parent Number",
        "Instrument",
        "Title",
        "Vendor",
        "Req Cat",
        "Base Obligated",
        "Ceiling",
        "Call Limit",
        "Order Count",
        "Order Total",
        "Remaining",
        "Status",
    ]
    ws_summary.append(summary_headers)
    summary_header_row = ws_summary.max_row
    max_log_rows = max(2, len(references) + 25)
    log_amount_range = f"'Order Log'!$F$2:$F${max_log_rows}"
    log_parent_range = f"'Order Log'!$B$2:$B${max_log_rows}"
    for vehicle in vehicles:
        row_num = ws_summary.max_row + 1
        parent_number = str(vehicle.get("vehicle_number") or "")
        ws_summary.append(
            [
                parent_number,
                vehicle.get("instrument", ""),
                vehicle.get("title", ""),
                vehicle.get("vendor", "") or vehicle.get("pool_awardees", ""),
                category_label_from_text(str(vehicle.get("requirement_category", ""))),
                parent_base_obligated_amount(vehicle),
                numeric_money_value(vehicle.get("ceiling")) or "",
                numeric_money_value(vehicle.get("call_limit")) or "",
                f'=COUNTIF({log_parent_range},A{row_num})',
                f'=SUMIF({log_parent_range},A{row_num},{log_amount_range})',
                f'=IF(G{row_num}>0,G{row_num}-F{row_num}-J{row_num},"")',
                parent_admin_status_formula(row_num),
            ]
        )

    log_headers = ["Action Number", "Parent Number", "Action Title", "Req Cat", "Contractor", "Amount", "Status", "Folder"]
    ws_log.append(log_headers)
    for ref in references:
        ws_log.append(
            [
                ref.get("action_number", ""),
                ref.get("parent_number", ""),
                ref.get("title", ""),
                category_label_from_text(str(ref.get("requirement_category", ""))),
                ref.get("vendor", ""),
                numeric_money_value(ref.get("amount")),
                ref.get("status", ""),
                ref.get("folder", ""),
            ]
        )

    for ws, header_row in [(ws_summary, summary_header_row), (ws_log, 1)]:
        for cell in ws[header_row]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for row in ws_summary.iter_rows(min_row=summary_header_row + 1, max_row=ws_summary.max_row, min_col=1, max_col=12):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        for cell in row[5:11]:
            cell.number_format = money_format if cell.column in {6, 7, 8, 10, 11} else "0"
    for row in ws_log.iter_rows(min_row=1, max_row=ws_log.max_row, min_col=1, max_col=8):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cell in ws_log["F"][1:]:
        cell.number_format = money_format

    summary_widths = {1: 18, 2: 12, 3: 34, 4: 32, 5: 15, 6: 16, 7: 16, 8: 14, 9: 12, 10: 16, 11: 16, 12: 20}
    log_widths = {1: 18, 2: 18, 3: 34, 4: 15, 5: 30, 6: 14, 7: 20, 8: 42}
    for col_idx, width in summary_widths.items():
        ws_summary.column_dimensions[get_column_letter(col_idx)].width = width
    for col_idx, width in log_widths.items():
        ws_log.column_dimensions[get_column_letter(col_idx)].width = width

    ws_summary.freeze_panes = f"A{summary_header_row + 1}"
    ws_log.freeze_panes = "A2"
    if ws_summary.max_row >= summary_header_row:
        ref = f"A{summary_header_row}:L{ws_summary.max_row}"
        table = XlsxTable(displayName="ParentAdminSummary", ref=ref)
        table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        ws_summary.add_table(table)
    if ws_log.max_row >= 1:
        ref = f"A1:H{max(2, ws_log.max_row)}"
        if ws_log.max_row == 1:
            ws_log.append(["", "", "", "", "", "", "", ""])
        table = XlsxTable(displayName="ParentOrderLog", ref=ref)
        table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        ws_log.add_table(table)

    from openpyxl.formatting.rule import FormulaRule

    status_range = f"L{summary_header_row + 1}:L{ws_summary.max_row}"
    ws_summary.conditional_formatting.add(status_range, FormulaRule(formula=[f'OR(LEFT(L{summary_header_row + 1},4)="OVER",ISNUMBER(SEARCH("EXCEEDED",L{summary_header_row + 1})))'], fill=alert_fill))
    ws_summary.conditional_formatting.add(status_range, FormulaRule(formula=[f'L{summary_header_row + 1}="OK"'], fill=ok_fill))
    wb.save(output_path)
    return output_path


def write_parent_order_admin_files(
    package_dir: Path,
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
) -> list[Path]:
    grouped_refs = references_by_parent(references)
    if not grouped_refs:
        return []
    vehicles_by_folder: dict[Path, list[dict[str, Any]]] = {}
    refs_by_folder: dict[Path, list[dict[str, Any]]] = {}
    for vehicle in vehicles:
        parent_number = str(vehicle.get("vehicle_number") or "").upper()
        refs = grouped_refs.get(parent_number, [])
        if not refs:
            continue
        folder_path = Path(str(vehicle.get("folder_path") or ""))
        if not folder_path.exists():
            folder_name = str(vehicle.get("folder") or "")
            folder_path = office_files_dir(package_dir) / folder_name if folder_name else Path()
        if not folder_path or not folder_path.exists():
            continue
        vehicles_by_folder.setdefault(folder_path, []).append(vehicle)
        refs_by_folder.setdefault(folder_path, []).extend(refs)
    written: list[Path] = []
    for folder_path, folder_vehicles in vehicles_by_folder.items():
        unique_refs = merge_parent_reference_records(refs_by_folder.get(folder_path, []))
        path = write_parent_order_admin_workbook(folder_path, sorted(folder_vehicles, key=lambda item: str(item.get("vehicle_number", ""))), unique_refs)
        if path:
            written.append(path)
    return written


def current_controller_timestamp() -> str:
    from datetime import datetime

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def write_workload_tracker(
    package_dir: Path,
    rows: list[dict[str, Any]],
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
) -> Path | None:
    try:
        from openpyxl import Workbook
        from openpyxl.chart import BarChart, Reference
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
        from openpyxl.worksheet.table import Table as XlsxTable
        from openpyxl.worksheet.table import TableStyleInfo
    except ImportError:
        return None

    admin = office_admin_dir(package_dir)
    admin.mkdir(parents=True, exist_ok=True)
    output_path = admin / "Contract Workload Tracker.xlsx"
    (package_dir / "Contract Workload Tracker.xlsx").unlink(missing_ok=True)
    wb = Workbook()
    ws_dashboard = wb.active
    ws_dashboard.title = "Dashboard"
    ws_workload = wb.create_sheet("Workload")
    ws_vehicles = wb.create_sheet("Vehicles")
    ws_links = wb.create_sheet("Parent Links")

    for ws in [ws_dashboard, ws_workload, ws_vehicles, ws_links]:
        ws.sheet_view.showGridLines = False

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    title_font = Font(size=16, bold=True, color="1F4E78")
    subtitle_font = Font(size=10, color="666666")
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    money_format = '$#,##0.00'

    workload_headers = [
        "Contract Number",
        "Parent",
        "Requirement",
        "Customer",
        "Vendor",
        "Type",
        "Req Cat",
        "Stage",
        "Status",
        "Award Amount",
        "PR/Form 9",
        "Solicitation",
        "Award Date",
        "POP End",
        "Delivery Date",
        "CO",
        "Notes",
        "Folder",
    ]
    ws_workload.append(workload_headers)
    for row in rows:
        parent = " ".join(part for part in [row.get("parent_instrument"), row.get("parent_contract_number")] if part)
        ws_workload.append(
            [
                row.get("awardee_contract_numbers") or row.get("contract_number", ""),
                parent,
                row.get("title", ""),
                row.get("customer", ""),
                row.get("contractor", ""),
                category_label_from_text(str(row.get("category", ""))),
                category_label_from_text(str(row.get("requirement_category", ""))),
                row.get("stage_name", ""),
                workload_status(row),
                float(row.get("amount") or 0),
                row.get("pr_number", ""),
                row.get("solicitation_number", ""),
                row.get("award_date", ""),
                row.get("pop_end", ""),
                row.get("delivery_date", ""),
                row.get("co", ""),
                tracker_turnover_note(row),
                row.get("folder", ""),
            ]
        )
    format_table_sheet(
        ws_workload,
        "WorkloadTable",
        len(rows) + 1,
        len(workload_headers),
        header_fill,
        header_font,
        border,
        money_cols={10},
        widths={
            1: 19,
            2: 19,
            3: 34,
            4: 12,
            5: 26,
            6: 20,
            7: 16,
            8: 22,
            9: 24,
            10: 14,
            11: 15,
            12: 16,
            13: 14,
            14: 14,
            15: 14,
            16: 20,
            17: 42,
            18: 36,
        },
        get_column_letter=get_column_letter,
        XlsxTable=XlsxTable,
        TableStyleInfo=TableStyleInfo,
    )

    vehicle_headers = [
        "Vehicle Number",
        "Instrument",
        "Title",
        "Status",
        "Vendor",
        "Awardees",
        "Customer",
        "Ceiling",
        "Obligated",
        "Call Limit",
        "Period Start",
        "Period End",
        "CO",
        "Scope",
        "Folder",
    ]
    ws_vehicles.append(vehicle_headers)
    for vehicle in merge_vehicle_records(vehicles):
        ws_vehicles.append(
            [
                vehicle.get("vehicle_number", ""),
                vehicle.get("instrument", ""),
                vehicle.get("title", ""),
                vehicle.get("status", ""),
                vehicle.get("vendor", ""),
                (
                    "; ".join(str(item.get("name", "")) for item in vehicle.get("awardees", []) if isinstance(item, dict))
                    if isinstance(vehicle.get("awardees"), list) and vehicle.get("awardees")
                    else str(vehicle.get("pool_awardees") or "")
                ),
                vehicle.get("customer", ""),
                float(vehicle["ceiling"]) if vehicle.get("ceiling") else "",
                float(vehicle.get("obligated_amount") or 0),
                float(vehicle["call_limit"]) if vehicle.get("call_limit") else "",
                vehicle.get("period_start", ""),
                vehicle.get("period_end", ""),
                vehicle.get("contracting_officer", ""),
                vehicle.get("scope", ""),
                vehicle.get("folder", ""),
            ]
        )
    format_table_sheet(
        ws_vehicles,
        "VehiclesTable",
        len(vehicles) + 1,
        len(vehicle_headers),
        header_fill,
        header_font,
        border,
        money_cols={8, 9, 10},
        widths={1: 19, 2: 12, 3: 30, 4: 14, 5: 26, 6: 42, 7: 12, 8: 14, 9: 14, 10: 13, 11: 14, 12: 14, 13: 20, 14: 52, 15: 36},
        get_column_letter=get_column_letter,
        XlsxTable=XlsxTable,
        TableStyleInfo=TableStyleInfo,
    )

    link_headers = [
        "Action Number",
        "Parent Number",
        "Parent Type",
        "Parent In Registry",
        "Requirement",
        "Req Cat",
        "Vendor",
        "Amount",
        "Status",
        "Folder",
    ]
    ws_links.append(link_headers)
    for ref in references:
        ws_links.append(
            [
                ref.get("action_number", ""),
                ref.get("parent_number", ""),
                ref.get("parent_instrument", ""),
                "Yes" if ref.get("parent_found_in_registry") else "No",
                ref.get("title", ""),
                category_label_from_text(str(ref.get("requirement_category", ""))),
                ref.get("vendor", ""),
                float(ref.get("amount") or 0),
                ref.get("status", ""),
                ref.get("folder", ""),
            ]
        )
    format_table_sheet(
        ws_links,
        "ParentLinksTable",
        len(references) + 1,
        len(link_headers),
        header_fill,
        header_font,
        border,
        money_cols={8},
        widths={1: 19, 2: 19, 3: 13, 4: 18, 5: 30, 6: 16, 7: 26, 8: 14, 9: 24, 10: 36},
        get_column_letter=get_column_letter,
        XlsxTable=XlsxTable,
        TableStyleInfo=TableStyleInfo,
    )

    build_workload_dashboard(ws_dashboard, rows, vehicles, references, title_font, subtitle_font, header_fill, header_font, border, money_format, BarChart, Reference)

    for ws in [ws_workload, ws_vehicles, ws_links]:
        for row in ws.iter_rows():
            for cell in row:
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=True)

    try:
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except AttributeError:
        pass
    wb.save(output_path)
    return output_path


def category_label_from_text(category: str) -> str:
    return {
        "supply": "Supply",
        "service": "Service",
        "construction": "Construction",
        "bpa": "BPA Master",
        "idiq": "IDIQ Master",
        "bpa_call": "BPA Call",
        "idiq_order": "IDIQ Order",
    }.get(category, category.replace("_", " ").title() if category else "")


def format_table_sheet(
    ws: Any,
    table_name: str,
    row_count: int,
    col_count: int,
    header_fill: Any,
    header_font: Any,
    border: Any,
    money_cols: set[int],
    widths: dict[int, float],
    get_column_letter: Any,
    XlsxTable: Any,
    TableStyleInfo: Any,
) -> None:
    from openpyxl.styles import Alignment

    row_count = max(1, row_count)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for col_idx in range(1, col_count + 1):
        letter = get_column_letter(col_idx)
        ws.column_dimensions[letter].width = widths.get(col_idx, 16)
        if col_idx in money_cols:
            for cell in ws[letter][1:]:
                cell.number_format = '$#,##0.00'
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(col_count)}{row_count}"
    ref = f"A1:{get_column_letter(col_count)}{row_count}"
    table = XlsxTable(displayName=table_name, ref=ref)
    table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    try:
        ws.add_table(table)
    except ValueError:
        pass
    for row in ws.iter_rows(min_row=1, max_row=row_count, max_col=col_count):
        for cell in row:
            cell.border = border


def build_workload_dashboard(
    ws: Any,
    rows: list[dict[str, Any]],
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
    title_font: Any,
    subtitle_font: Any,
    header_fill: Any,
    header_font: Any,
    border: Any,
    money_format: str,
    BarChart: Any,
    Reference: Any,
) -> None:
    from openpyxl.styles import Alignment, Font

    ws["A1"] = "Contract Workload Tracker"
    ws["A1"].font = title_font
    ws["A2"] = "Turnover control sheet generated from the mock office package manifest and vehicle registry."
    ws["A2"].font = subtitle_font
    ws.merge_cells("A1:F1")
    ws.merge_cells("A2:F2")

    action_rows = active_manifest_rows(rows)
    total_actions = len(action_rows)
    total_value = sum(float(row.get("amount") or 0) for row in action_rows)
    active_vehicles = sum(1 for vehicle in vehicles if str(vehicle.get("status", "")).lower() == "active")
    call_order_count = sum(1 for row in action_rows if row.get("category") in {"bpa_call", "idiq_order"})
    open_actions = sum(1 for row in action_rows if int(row.get("stage") or 0) < 7)
    delivered = sum(1 for row in action_rows if int(row.get("stage") or 0) >= 8)

    kpis = [
        ("Total Actions", total_actions),
        ("Total Value", total_value),
        ("Active Vehicles", active_vehicles),
        ("Calls / Orders", call_order_count),
        ("Open Pre-Award", open_actions),
        ("Delivered", delivered),
    ]
    ws.append([])
    start_row = 4
    for idx, (label, value) in enumerate(kpis):
        row = start_row + idx // 3 * 3
        col = 1 + (idx % 3) * 3
        ws.cell(row=row, column=col, value=label)
        ws.cell(row=row + 1, column=col, value=value)
        ws.cell(row=row, column=col).fill = header_fill
        ws.cell(row=row, column=col).font = header_font
        ws.cell(row=row + 1, column=col).font = Font(size=14, bold=True, color="1F4E78")
        if label == "Total Value":
            ws.cell(row=row + 1, column=col).number_format = money_format
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + 1)
        ws.merge_cells(start_row=row + 1, start_column=col, end_row=row + 1, end_column=col + 1)

    status_counts: dict[str, int] = {}
    type_counts: dict[str, int] = {}
    for row in rows:
        status_counts[workload_status(row)] = status_counts.get(workload_status(row), 0) + 1
        label = category_label_from_text(str(row.get("category", "")))
        type_counts[label] = type_counts.get(label, 0) + 1

    ws["A11"] = "Status Summary"
    ws["A11"].font = Font(bold=True, color="1F4E78")
    ws["A12"] = "Status"
    ws["B12"] = "Count"
    for cell in ws["A12:B12"][0]:
        cell.fill = header_fill
        cell.font = header_font
    for idx, (status, count) in enumerate(sorted(status_counts.items()), start=13):
        ws.cell(row=idx, column=1, value=status)
        ws.cell(row=idx, column=2, value=count)

    ws["D11"] = "Type Summary"
    ws["D11"].font = Font(bold=True, color="1F4E78")
    ws["D12"] = "Type"
    ws["E12"] = "Count"
    for cell in ws["D12:E12"][0]:
        cell.fill = header_fill
        cell.font = header_font
    for idx, (action_type, count) in enumerate(sorted(type_counts.items()), start=13):
        ws.cell(row=idx, column=4, value=action_type)
        ws.cell(row=idx, column=5, value=count)

    if status_counts:
        chart = BarChart()
        chart.title = "Actions by Status"
        chart.y_axis.title = "Actions"
        chart.x_axis.title = "Status"
        data = Reference(ws, min_col=2, min_row=12, max_row=12 + len(status_counts))
        cats = Reference(ws, min_col=1, min_row=13, max_row=12 + len(status_counts))
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        chart.height = 7
        chart.width = 12
        ws.add_chart(chart, "G11")

    notes_row = 23
    ws.cell(notes_row, 1, "Turnover Notes")
    ws.cell(notes_row, 1).font = Font(bold=True, color="1F4E78")
    notes = [
        "Tracker is intentionally a turnover aid, not a substitute for the contract file.",
        "Blank or stale-looking notes are intentional realism unless a controller marks them as an inject.",
        "Use Parent Links to trace BPA calls and IDIQ orders back to their master vehicles.",
    ]
    for idx, note in enumerate(notes, start=notes_row + 1):
        ws.cell(idx, 1, note)
        ws.merge_cells(start_row=idx, start_column=1, end_row=idx, end_column=6)

    for col in range(1, 12):
        ws.column_dimensions[chr(64 + col)].width = 16
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["D"].width = 22
    for row in ws.iter_rows(min_row=1, max_row=32, max_col=12):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = border



def effective_tracker_stage(row: dict[str, Any]) -> int:
    if is_placeholder_row(row):
        return 0
    return int(row.get("tracker_stage") or row.get("stage") or 0)


def write_continuity_binder(package_dir: Path, rows: list[dict[str, Any]], vehicles: list[dict[str, Any]], data: dict[str, Any]) -> Path | None:
    """Walk-in continuity notes: the document a departing CCO leaves on top of the files."""
    rows = active_manifest_rows(rows)
    if not rows:
        return None
    rng = random.Random(f"{package_dir.name}|binder")
    departing = rng.choice(data["contracting_office"]["contacts"])
    office_name = data["contracting_office"]["office_name"]
    open_rows = [row for row in rows if effective_tracker_stage(row) < 7]
    awarded_rows = [row for row in rows if effective_tracker_stage(row) == 7]
    intro = rng.choice(
        [
            "These notes go with the contract files and the workload tracker. Read them before you touch anything - the tracker is a summary, the files are the record.",
            "Quick orientation for the incoming CCO. The tracker has the full list; below is what actually needs your attention first.",
            "Turnover notes for the office files. I kept these short on purpose - verify everything against the actual folders before acting.",
        ]
    )
    hot_candidates = sorted(open_rows, key=lambda row: float(row.get("amount") or 0), reverse=True)[:3]
    hot_lines = [
        f"{row.get('contract_number')} - {row.get('title')}: currently at {row.get('stage_name')}. {tracker_turnover_note(row) or 'Pick up from the last stage folder.'}"
        for row in hot_candidates
    ]
    for vehicle in vehicles:
        if str(vehicle.get("status", "")).lower() == "expired":
            hot_lines.append(
                f"{vehicle.get('vehicle_number')} - {vehicle.get('title')}: this {vehicle.get('instrument', 'vehicle')} EXPIRED and was not renewed. "
                "Do not place or accept new calls/orders against it. See the renewal decision email in the master file."
            )
    open_table = [["Contract", "Requirement", "Stage", "Vendor", "Amount"]]
    for row in open_rows:
        open_table.append(
            [
                str(row.get("contract_number", "")),
                str(row.get("title", "")),
                str(row.get("stage_name", "")),
                str(row.get("contractor", "")),
                money(float(row.get("amount") or 0)),
            ]
        )
    awarded_table = [["Contract", "Requirement", "Vendor", "Amount", "Waiting On"]]
    for row in awarded_rows:
        awarded_table.append(
            [
                str(row.get("contract_number", "")),
                str(row.get("title", "")),
                str(row.get("contractor", "")),
                money(float(row.get("amount") or 0)),
                "Receiving documentation",
            ]
        )
    vehicle_table = [["Vehicle", "Type", "Status", "Period End", "Ceiling / Limit"]]
    for vehicle in vehicles:
        vehicle_table.append(
            [
                str(vehicle.get("vehicle_number", "")),
                str(vehicle.get("instrument", "")),
                str(vehicle.get("status", "")),
                str(vehicle.get("period_end", "")),
                money(float(vehicle["ceiling"])) if vehicle.get("ceiling") else (f"Call limit {money(float(vehicle['call_limit']))}" if vehicle.get("call_limit") else ""),
            ]
        )
    sections: list[dict[str, Any]] = [
        {
            "heading": "How To Use These Notes",
            "paragraphs": [
                intro,
                f"Workload tracker: Contract Workload Tracker.xlsx in {OFFICE_ADMIN_DIRNAME}. Total actions in this turnover: {len(rows)}.",
            ],
        }
    ]
    if hot_lines:
        sections.append({"heading": "Work These First", "paragraphs": hot_lines})
    if len(open_table) > 1:
        sections.append({"heading": "Open Pre-Award Actions", "table": open_table, "widths": [1.15 * inch, 2.0 * inch, 1.45 * inch, 1.35 * inch, 0.85 * inch]})
    if len(awarded_table) > 1:
        sections.append({"heading": "Awarded - Awaiting Receipt", "table": awarded_table, "widths": [1.15 * inch, 2.0 * inch, 1.6 * inch, 0.95 * inch, 1.1 * inch]})
    if len(vehicle_table) > 1:
        sections.append({"heading": "Ordering Vehicles", "table": vehicle_table, "widths": [1.2 * inch, 0.7 * inch, 0.9 * inch, 1.5 * inch, 1.0 * inch]})
    sections.append(
        {
            "heading": "Outgoing CCO",
            "paragraphs": [
                f"{departing['name']}, {office_name}. Reachable through the contracting office orderly room if something in these files does not add up.",
                "Verify funding documents, vehicle periods, and award signatures yourself. Do not assume the tracker is right.",
            ],
        }
    )
    admin = office_admin_dir(package_dir)
    admin.mkdir(parents=True, exist_ok=True)
    (package_dir / "Continuity Binder.pdf").unlink(missing_ok=True)
    path = admin / "Continuity Binder.pdf"
    write_pdf(path, "Contracting Office Continuity Notes", f"{office_name} | Office: {package_dir.name}", sections)
    return path


def maybe_write_admin_mod(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    """Occasionally add a no-cost administrative modification to an awarded file (benign noise)."""
    if is_master_vehicle(s):
        return
    rng = scenario_rng(s, "admin_mod")
    if rng.random() >= 0.18:
        return
    change = rng.choice(
        [
            (
                "Administrative change of contracting officer.",
                f"The contracting officer for this contract is changed to {rng.choice(data['contracting_office']['contacts'])['name']}. All other terms and conditions remain unchanged.",
            ),
            (
                "Correction of payment office information.",
                f"Block 18a payment office information is corrected to read {data['contracting_office']['payment_office']['name']} ({data['contracting_office']['payment_office']['code']}). No change to payment terms.",
            ),
            (
                "Administrative correction of delivery point of contact.",
                "The receiving point of contact identified in the delivery instructions is updated. Delivery location, schedule, and acceptance procedures are unchanged.",
            ),
            (
                "Administrative correction of typographical error.",
                "A typographical error in the continuation schedule heading is corrected. No change to any CLIN, quantity, unit price, or total amount.",
            ),
        ]
    )
    sections = [
        {
            "heading": "Modification Summary",
            "table": [
                ["Field", "Entry"],
                ["Modification Number", "P00001"],
                ["Contract Number", s.contract_number],
                ["Effective Date", fmt_date(s.timeline["delivery"])],
                ["Contractor", s.winner["name"]],
                ["Issued By", data["contracting_office"]["office_symbol"]],
                ["Modification Type", "Administrative (SF 30 style)"],
            ],
            "widths": [1.6 * inch, 4.7 * inch],
        },
        {
            "heading": "Description of Modification",
            "paragraphs": [
                change[0],
                change[1],
                f"Total contract value unchanged: {money(s.base_amount)}. This modification is administrative and requires no contractor signature.",
            ],
        },
    ]
    write_pdf(folder / compact_doc_name(s, "Mod P00001"), "Amendment of Solicitation / Modification of Contract", f"{s.contract_number} | Modification P00001 (Administrative)", sections)


def write_cor_designation_letter(folder: Path, s: Scenario, data: dict[str, Any]) -> None:
    """COR designation memo for awarded service contracts."""
    duties = [
        "Monitor contractor performance against the PWS performance requirements summary and surveillance methods.",
        "Document surveillance results and maintain a COR file with inspection records and correspondence.",
        "Review invoices for consistency with services actually received and recommend acceptance or rejection.",
        "Report performance problems, accidents, or labor issues to the contracting officer immediately.",
        "Coordinate Government-furnished access, escorts, and facility entry required for performance.",
    ]
    limitations = [
        "The COR is NOT authorized to change the terms and conditions of the contract.",
        "The COR may not direct work outside the PWS, authorize additional cost, or extend the period of performance.",
        "Only the contracting officer may modify the contract or take action on disputes.",
    ]
    sections = [
        {
            "heading": "Designation",
            "table": [
                ["Field", "Entry"],
                ["Contract", s.contract_number],
                ["Requirement", s.archetype["title"]],
                ["Contractor", s.winner["name"]],
                ["COR", person_display(s.requester)],
                ["Unit", s.customer["display_name"]],
                ["Designating CO", s.co["name"]],
                ["Effective", fmt_date(s.timeline["award"])],
            ],
            "widths": [1.5 * inch, 4.8 * inch],
        },
        {"heading": "Duties", "paragraphs": duties},
        {"heading": "Limitations", "paragraphs": limitations},
        {
            "heading": "Acknowledgement",
            "paragraphs": [
                f"Designated by {s.co['name']}, Contingency Contracting Officer. //SIGNED//",
                f"Acknowledged by {person_display(s.requester)}, {s.customer['display_name']}. //SIGNED//",
            ],
        },
    ]
    write_pdf(folder / compact_doc_name(s, "COR"), "Contracting Officer's Representative Designation", f"{s.contract_number} | {s.archetype['title']}", sections)


def ensure_gpc_log(office_dir: Path, data: dict[str, Any], volume: str = "standard") -> Path | None:
    """Office-level GPC purchase log. Written once as ambient texture; never overwritten.

    Short-term offices buy heavily on the card before contracts stand up, so
    volume='heavy' roughly doubles the activity.
    """
    admin = office_admin_dir(office_dir)
    admin.mkdir(parents=True, exist_ok=True)
    output_path = admin / "GPC Purchase Log.xlsx"
    if output_path.exists():
        return output_path
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        return None
    rng = random.Random("gpc-log-v1")
    cardholders = [person_display(contact["name"]) for contact in data["contracting_office"]["contacts"][:4]]
    vendors = [contractor["name"] for contractor in data["contractors"][:8]] + [
        "Base Self-Help Store",
        "Regional Hardware Distributor",
        "Local Office Supply Vendor",
        "Installation Sign Shop",
    ]
    items = [
        "Hand tools and consumable shop supplies",
        "Printer toner and office consumables",
        "Replacement padlocks and key blanks",
        "Extension cords and surge protectors",
        "Cleaning supplies for common areas",
        "Batteries and small electronics accessories",
        "Safety vests and gloves",
        "Water cooler service and cups",
        "Small parts for facility self-help repair",
        "First aid cabinet restock",
    ]
    wb = Workbook()
    ws = wb.active
    ws.title = "GPC Log"
    ws.sheet_view.showGridLines = False
    headers = ["Date", "Cardholder", "Vendor", "Description", "Amount", "Status"]
    ws.append(headers)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    row_count = rng.randint(55, 75) if volume == "heavy" else rng.randint(26, 38)
    month_cursor = 1
    for _ in range(row_count):
        month_cursor = min(12, month_cursor + rng.choice([0, 0, 1]))
        day = rng.randint(2, 27)
        amount = round(rng.uniform(35, 3400), 2)
        status = rng.choices(["Reconciled", "Reconciled", "Reconciled", "Pending", "Disputed"], k=1)[0]
        ws.append(
            [
                f"{day} {MONTHS[month_cursor - 1][:3]} {GENERIC_YEAR}",
                rng.choice(cardholders),
                rng.choice(vendors),
                rng.choice(items),
                amount,
                status,
            ]
        )
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
    widths = {1: 14, 2: 18, 3: 30, 4: 40, 5: 12, 6: 12}
    for idx, width in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = width
    for row in ws.iter_rows(min_row=1, max_row=row_count + 1, max_col=6):
        for cell in row:
            cell.border = border
            cell.alignment = Alignment(vertical="top")
    for cell in ws["E"][1:]:
        cell.number_format = '$#,##0.00'
    ws.freeze_panes = "A2"
    wb.save(output_path)
    return output_path


def scrub_global_registry(output_root: Path, package: str = "", folder: str = "") -> None:
    records = load_vehicle_registry(output_root)
    kept = []
    for record in records:
        record_package = str(record.get("package") or "")
        record_folder = str(record.get("folder") or "")
        if folder and record_package == package and record_folder == folder:
            continue
        if not folder and package and record_package == package:
            continue
        kept.append(record)
    vehicle_registry_file(output_root).write_text(
        json.dumps({"generated_at": current_controller_timestamp(), "vehicles": kept}, indent=2),
        encoding="utf-8",
    )


def clear_delete_blockers(path_value: str) -> None:
    """Clear Windows attributes that can block deleting OneDrive-hosted output."""
    try:
        os.chmod(path_value, stat.S_IREAD | stat.S_IWRITE | stat.S_IEXEC)
    except OSError:
        pass
    if os.name == "nt":
        try:
            subprocess.run(["attrib", "-R", "-S", "-H", path_value], capture_output=True, text=True, check=False)
        except OSError:
            pass


def retry_remove(func: Any, path_value: str, exc: Any) -> None:
    clear_delete_blockers(path_value)
    func(path_value)


def retry_remove_legacy(func: Any, path_value: str, exc_info: Any) -> None:
    retry_remove(func, path_value, exc_info[1] if exc_info else None)


def remove_tree(path: Path) -> None:
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=retry_remove)
    else:
        shutil.rmtree(path, onerror=retry_remove_legacy)


def deleted_action_placeholder(row: dict[str, Any], action_folder: str) -> dict[str, Any]:
    contract_number = str(row.get("contract_number") or "")
    if not contract_number:
        letter, sequence = piid_parts_from_contract_number(action_folder)
        if letter and sequence:
            contract_number = f"FA4867XX{letter}{sequence:04d}"
    sequence_number = row.get("piid_sequence") or piid_sequence_from_contract_number(contract_number)
    return {
        "index": row.get("index", ""),
        "folder": "",
        "folder_path": "",
        "title": "PIID not used",
        "category": "",
        "requirement_category": "",
        "stage": "",
        "stage_name": "",
        "customer": "",
        "requester": "",
        "co": "",
        "contractor": "",
        "pr_number": "",
        "solicitation_number": "",
        "solicitation_style": "",
        "contract_number": contract_number,
        "piid_sequence": sequence_number,
        "parent_instrument": "",
        "parent_contract_number": "",
        "amount": "",
        "award_date": "",
        "pop_end": "",
        "delivery_date": "",
        "parent_found_in_registry": False,
        "standalone_parent_order": False,
        "injects": "",
        "tracker_stage": "",
        "deleted_placeholder": True,
        "notes": "PIID not used",
    }


def refresh_package_artifacts(
    package_dir: Path,
    rows: list[dict[str, Any]],
    vehicles: list[dict[str, Any]],
    references: list[dict[str, Any]],
    inject_entries: list[dict[str, Any]],
    data: dict[str, Any],
) -> None:
    controller = office_controller_dir(package_dir)
    admin = office_admin_dir(package_dir)
    action_rows = active_manifest_rows(rows)
    if rows:
        write_manifests(package_dir, rows)
    else:
        for stale in [controller / "_controller_manifest.json", controller / "_controller_manifest.csv", package_dir / "_controller_manifest.json", package_dir / "_controller_manifest.csv"]:
            stale.unlink(missing_ok=True)
    write_package_vehicle_registry(package_dir, vehicles, references)
    if rows or vehicles:
        write_workload_tracker(package_dir, rows, vehicles, references)
        if action_rows or vehicles:
            write_continuity_binder(package_dir, action_rows, vehicles, data)
        else:
            for stale in [admin / "Continuity Binder.pdf", package_dir / "Continuity Binder.pdf"]:
                stale.unlink(missing_ok=True)
    else:
        for stale in [admin / "Contract Workload Tracker.xlsx", admin / "Continuity Binder.pdf", package_dir / "Contract Workload Tracker.xlsx", package_dir / "Continuity Binder.pdf"]:
            stale.unlink(missing_ok=True)
    if inject_entries:
        write_inject_key(package_dir, inject_entries)
    else:
        for stale in [controller / "_inject_key.json", controller / "_inject_key.md", package_dir / "_inject_key.json", package_dir / "_inject_key.md"]:
            stale.unlink(missing_ok=True)


def maintenance_delete_action(output_root: Path, package_name: str, action_folder: str, data: dict[str, Any]) -> None:
    package_dir = resolve_append_package(output_root, package_name)
    existing_rows = load_manifest_rows(package_dir)
    matched_row = next((row for row in existing_rows if str(row.get("folder")) == action_folder), None)
    action_root = office_files_dir(package_dir) / action_folder
    if not action_root.exists() or not action_root.is_dir():
        action_root = package_dir / action_folder  # legacy layout
    if not action_root.exists() or not action_root.is_dir():
        if matched_row is None:
            raise SystemExit(f"Action folder not found: {action_root}")
    else:
        remove_tree(action_root)
    rows = [
        deleted_action_placeholder(row, action_folder) if str(row.get("folder")) == action_folder else row
        for row in existing_rows
    ]
    vehicles, references = load_package_vehicle_registry(package_dir)
    vehicles = [record for record in vehicles if str(record.get("folder") or "") != action_folder]
    references = [record for record in references if str(record.get("folder") or "") != action_folder]
    inject_entries = [entry for entry in load_inject_key(package_dir) if str(entry.get("folder")) != action_folder]
    refresh_package_artifacts(package_dir, rows, vehicles, references, inject_entries, data)
    scrub_global_registry(output_root, package=package_dir.name, folder=action_folder)


def maintenance_delete_package(output_root: Path, package_name: str) -> None:
    package_dir = resolve_append_package(output_root, package_name)
    remove_tree(package_dir)
    scrub_global_registry(output_root, package=package_dir.name)
    write_sequence_state(output_root, highest_output_piid_sequences(output_root))


def export_trainee_copy(output_root: Path, office_name: str, destination: str = "") -> Path:
    """Copy an office for trainee handoff, excluding all controller material."""
    office_dir = resolve_append_package(output_root, office_name)
    if destination.strip():
        export_root = Path(destination.strip())
    else:
        export_root = output_root / "_exports"
    export_root.mkdir(parents=True, exist_ok=True)
    target = export_root / office_dir.name
    if target.exists():
        stamp = time.strftime("%Y%m%d_%H%M%S")
        target = export_root / f"{office_dir.name}_{stamp}"
    shutil.copytree(
        office_dir,
        target,
        ignore=shutil.ignore_patterns(OFFICE_CONTROLLER_DIRNAME, "_inject_key*", "_controller_manifest*", "_ai_*", "_vehicle_registry*"),
    )
    leaked = [p for p in target.rglob("_*") if p.name.startswith("_")]
    for path_obj in leaked:
        if path_obj.is_dir():
            remove_tree(path_obj)
        else:
            path_obj.unlink(missing_ok=True)
    return target


def piid_from_existing_path(path: Path) -> str:
    for part in [path.name, *reversed(path.parts[:-1])]:
        match = PIID_PATTERN.search(str(part))
        if match:
            return match.group(0).upper()
    return ""


def piid_from_existing_file_content(path: Path) -> str:
    text = ""
    if path.suffix.lower() == ".pdf":
        text = read_pdf_text(path, max_pages=2)
    elif path.suffix.lower() == ".docx":
        text = read_docx_text(path)
    match = PIID_PATTERN.search(text or "")
    return match.group(0).upper() if match else ""


def manifest_contract_for_existing_file(office_dir: Path, path: Path, contract_by_folder: dict[str, str]) -> str:
    try:
        relative = path.relative_to(office_files_dir(office_dir))
    except ValueError:
        return ""
    if not relative.parts:
        return ""
    return contract_by_folder.get(str(relative.parts[0]), "")


def existing_docx_heading_text(path: Path) -> str:
    if path.suffix.lower() != ".docx" or Document is None:
        return ""
    try:
        doc = Document(str(path))
        return " ".join(paragraph.text for paragraph in doc.paragraphs[:12]).lower()
    except Exception:
        return ""


def stage_fallback_label_for_path(path: Path) -> str:
    for part in reversed(path.parts):
        stage = str(part).strip()
        if re.match(r"^\d+\.", stage):
            if stage.startswith("1."):
                return "Initial Doc"
            if stage.startswith("2."):
                return "Funding"
            if stage.startswith("3."):
                return "MRR"
            if stage.startswith("4."):
                return "Solicitation"
            if stage.startswith("5."):
                return "Quotes"
            if stage.startswith("6."):
                return "Decision"
            if stage.startswith("7."):
                return "Award"
            if stage.startswith("8."):
                return "Delivery"
            if stage.startswith("9."):
                return "Admin"
    return ""


def stage_number_for_path(path: Path) -> int:
    for part in reversed(path.parts):
        match = re.match(r"^(\d+)\.", str(part).strip())
        if match:
            return int(match.group(1))
    return 0


def compact_label_for_existing_file(path: Path) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", path.stem.lower()).strip()
    stage_num = stage_number_for_path(path)
    pdf_text = ""
    if path.suffix.lower() == ".pdf":
        pdf_text = read_pdf_text(path, max_pages=2).lower()
        if "independent government estimate" in pdf_text:
            return "IGE"
        if stage_num == 2:
            if "funding note - master" in pdf_text or "does not obligate funds" in pdf_text:
                return "No Funding"
            if "request for purchase" in pdf_text and ("af imt 9" in pdf_text or "funds have been committed" in pdf_text):
                return "Form 9"
            if "minimum guarantee" in pdf_text:
                return "Min Guarantee"
        if stage_num == 4:
            if "response below" in pdf_text or re.search(r"\bq:\s", pdf_text):
                return "Vendor QA"
            if "ordering price list" in pdf_text or "price template" in pdf_text:
                return "Price Template"
            if "request for proposal" in pdf_text or "rfp -" in pdf_text:
                return "RFP"
            if "request for quotation" in pdf_text or "rfq -" in pdf_text or "combined synopsis/solicitation" in pdf_text or "solicitation number" in pdf_text:
                return "RFQ"
        if stage_num == 6:
            if "award decision document" in pdf_text:
                return "Decision"
            if "technical findings are below" in pdf_text or "we reviewed each contractor response" in pdf_text:
                return "Tech Eval"
            if "please evaluate" in pdf_text or "i need your technical review" in pdf_text:
                return "Tech Eval Req"
        if stage_num == 7:
            if "awardee roster" in pdf_text:
                return "Awardee Roster"
            if "fair opportunity" in pdf_text:
                return "Fair Opportunity"
            if "solicitation/contract/order" in pdf_text or "standard form 1449" in pdf_text or "standard form 1442" in pdf_text:
                return "Award"
            if "price list" in pdf_text:
                return "Price List"
    rules = [
        (r"\bsor email\b|\bsor email traffic\b", "SOR Email"),
        (r"\brequirement email\b|\brequirement email traffic\b|\breq email\b", "Req Email"),
        (r"\bstatement of work\b|\bsow\b", "SOW"),
        (r"\bperformance work statement\b|\bpws\b", "PWS"),
        (r"\bstatement of requirements\b|\bsor\b", "SOR"),
        (r"\bindependent government estimate\b|\bige\b", "IGE"),
        (r"\bform 9\b", "Form 9"),
        (r"\bminimum guarantee\b|\bmin guarantee\b", "Min Guarantee"),
        (r"\bno funding\b|\bmaster no funding\b", "No Funding"),
        (r"\bmarket research\b|\bmrr\b", "MRR"),
        (r"\brfq\b", "RFQ"),
        (r"\brfp\b", "RFP"),
        (r"\bsolicitation\b", "Solicitation"),
        (r"\bquote receipt\b|\breceipt log\b", "Receipt Log"),
        (r"\bvendor responsibility\b|\bsam\b", "SAM"),
        (r"\btechnical evaluation request\b|\btech eval req\b", "Tech Eval Req"),
        (r"\btechnical evaluation\b|\btech eval\b", "Tech Eval"),
        (r"\bpast performance\b|\bpast perf\b", "Past Perf"),
        (r"\baward decision\b|\bdecision\b", "Decision"),
        (r"\bawardee roster\b", "Awardee Roster"),
        (r"\bfair opportunity\b", "Fair Opportunity"),
        (r"\bprice template\b", "Price Template"),
        (r"\bprice list\b", "Price List"),
        (r"\bdelivery status\b|\bdelivery\b", "Delivery"),
        (r"\bfunding clarification\b", "Funding Clarification"),
        (r"\bvendor qa\b|\bquestion answer\b", "Vendor QA"),
        (r"\brenewal decision\b", "Renewal Decision"),
        (r"\bvehicle summary\b", "Vehicle Summary"),
        (r"\bdelivery issue\b", "Delivery Issue"),
        (r"\bpast perf memo\b", "Past Perf Memo"),
        (r"\bmod p00001\b|\bp00001\b", "Mod P00001"),
        (r"\bcor\b", "COR"),
        (r"\baward\b", "Award"),
    ]
    for pattern, label in rules:
        if re.search(pattern, normalized):
            return label
    docx_text = existing_docx_heading_text(path)
    if "statement of work" in docx_text:
        return "SOW"
    if "performance work statement" in docx_text:
        return "PWS"
    if "statement of requirements" in docx_text:
        return "SOR"
    if pdf_text:
        if "minimum guarantee" in pdf_text:
            return "Min Guarantee"
    stage_label = stage_fallback_label_for_path(path)
    if stage_label:
        return stage_label
    stem = PIID_PATTERN.sub("", path.stem)
    stem = re.sub(r"^[\s._-]+|[\s._-]+$", "", stem)
    stem = stem.replace("_", " ").replace("-", " ")
    return truncate_filename(stem, 22, "Doc")


def existing_awardee_label(path: Path) -> str:
    stem = PIID_PATTERN.sub("", path.stem)
    stem = re.sub(r"^[\s._-]+|[\s._-]+$", "", stem)
    stem = stem.replace("_", " ").replace("-", " ")
    return truncate_filename(stem, 22, "Awardee")


def award_packet_vendor_label(path: Path) -> str:
    text = read_pdf_text(path, max_pages=3)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    for index, line in enumerate(lines):
        if "CONTRACTOR / OFFEROR CODE" not in line.upper():
            continue
        for candidate in lines[index + 1:index + 6]:
            upper = candidate.upper()
            if upper.startswith(("FACILITY", "TELEPHONE", "COMMERCIAL", "[", "18A.", "PAYMENT")):
                continue
            if re.fullmatch(r"[A-Z0-9]{8,}", candidate):
                continue
            return truncate_filename(candidate, 22, "Awardee")
    return existing_awardee_label(path)


def should_number_existing_award_packet(path: Path, label: str) -> bool:
    if path.suffix.lower() != ".pdf" or label != "Award" or stage_number_for_path(path) != 7:
        return False
    peer_piids: set[str] = set()
    for peer in path.parent.glob("*.pdf"):
        peer_label = compact_label_for_existing_file(peer)
        if peer_label != "Award":
            continue
        peer_piid = piid_from_existing_path(peer) or piid_from_existing_file_content(peer)
        if peer_piid:
            peer_piids.add(peer_piid)
    return len(peer_piids) > 1


def is_probable_multiple_award_packet(path: Path, label: str) -> bool:
    if path.suffix.lower() != ".pdf" or label != "Award" or not PIID_PATTERN.search(path.name):
        return False
    if not any(str(part).strip().startswith("7.") for part in path.parts):
        return False
    peer_piids: set[str] = set()
    for peer in path.parent.glob("*.pdf"):
        match = PIID_PATTERN.search(peer.name)
        if not match:
            continue
        peer_label = compact_label_for_existing_file(peer)
        peer_normalized = re.sub(r"[^a-z0-9]+", " ", peer.stem.lower()).strip()
        if peer_label == "Award" and not re.search(r"\baward\b|\bsf\s*144[29]\b", peer_normalized):
            peer_piids.add(match.group(0).upper())
    return len(peer_piids) > 1


def unique_compact_target(path: Path, target_name: str) -> Path:
    target = path.with_name(target_name)
    if target.name.lower() == path.name.lower():
        return path
    if not target.exists():
        return target
    ext = target.suffix
    base = target.stem
    for index in range(2, 100):
        suffix = f"_{index}"
        max_stem = max(8, MAX_DOCUMENT_NAME_CHARS - len(ext) - len(suffix))
        candidate = path.with_name(f"{truncate_filename(base, max_stem, base)}{suffix}{ext}")
        if candidate.name.lower() == path.name.lower():
            return path
        if not candidate.exists():
            return candidate
    raise SystemExit(f"Could not find an available compact filename near: {path}")


def rename_path_if_clear(source: Path, target: Path, renamed: list[tuple[Path, Path]]) -> None:
    if not source.exists() or source == target:
        return
    if target.exists():
        return
    source.rename(target)
    renamed.append((source, target))


def maintenance_shorten_known_folders(root: Path, renamed: list[tuple[Path, Path]]) -> None:
    files_dir = office_files_dir(root)
    if not files_dir.exists():
        return
    for action_dir in files_dir.iterdir():
        if not action_dir.is_dir():
            continue
        for stage_num, default_name in STAGE_FOLDERS:
            default_dir = action_dir / default_name
            for alias in STAGE_FOLDER_ALIASES.get(stage_num, []):
                rename_path_if_clear(action_dir / alias, default_dir, renamed)
        for alias in PARENT_ADMIN_DIR_ALIASES:
            rename_path_if_clear(action_dir / alias, action_dir / PARENT_ADMIN_DIRNAME, renamed)


def compact_action_folder_name_from_row(row: dict[str, Any]) -> str:
    if is_placeholder_row(row):
        return ""
    title = str(row.get("title") or "Requirement")
    category = str(row.get("category") or "").lower()
    awardee_count = manifest_int(row.get("awardee_count"))
    if awardee_count and category in {"bpa", "idiq"}:
        label = truncate_filename(title, MAX_ACTION_LABEL_CHARS, "Award Pool")
        return sanitize_filename(f"MA {master_vehicle_label(category)} - {label}")
    contract_number = str(row.get("contract_number") or "")
    if not contract_number:
        return ""
    label = truncate_filename(title, MAX_ACTION_LABEL_CHARS, "Requirement")
    return sanitize_filename(f"{contract_number} - {label}")


def unique_action_folder_path(files_dir: Path, current: Path, desired_name: str) -> Path:
    target = files_dir / desired_name
    if target == current or not target.exists():
        return target
    for index in range(2, 100):
        suffix = f"_{index}"
        max_name = max(8, 48 - len(suffix))
        candidate = files_dir / f"{truncate_filename(desired_name, max_name, desired_name)}{suffix}"
        if candidate == current or not candidate.exists():
            return candidate
    return current


def replace_folder_refs_in_obj(value: Any, mapping: dict[str, str]) -> Any:
    if isinstance(value, dict):
        return {key: replace_folder_refs_in_obj(item, mapping) for key, item in value.items()}
    if isinstance(value, list):
        return [replace_folder_refs_in_obj(item, mapping) for item in value]
    if isinstance(value, str):
        return mapping.get(value, value)
    return value


def update_record_folder_refs(records: list[dict[str, Any]], mapping: dict[str, str], package_dir: Path) -> list[dict[str, Any]]:
    updated: list[dict[str, Any]] = []
    for record in records:
        item = dict(record)
        old_folder = str(item.get("folder") or "")
        if old_folder in mapping:
            new_folder = mapping[old_folder]
            item["folder"] = new_folder
            item["folder_path"] = str(office_files_dir(package_dir) / new_folder)
        updated.append(item)
    return updated


def maintenance_shorten_action_folders(output_root: Path, root: Path, renamed: list[tuple[Path, Path]]) -> None:
    rows = load_manifest_rows(root)
    if not rows:
        return
    files_dir = office_files_dir(root)
    if not files_dir.exists():
        return
    mapping: dict[str, str] = {}
    for row in active_manifest_rows(rows):
        old_name = str(row.get("folder") or "")
        if not old_name:
            continue
        current = files_dir / old_name
        if not current.exists() or not current.is_dir():
            continue
        desired_name = compact_action_folder_name_from_row(row)
        if not desired_name or desired_name == old_name:
            continue
        target = unique_action_folder_path(files_dir, current, desired_name)
        if target == current:
            continue
        current.rename(target)
        renamed.append((current, target))
        mapping[old_name] = target.name
    if not mapping:
        return

    updated_rows: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        old_folder = str(item.get("folder") or "")
        if old_folder in mapping:
            new_folder = mapping[old_folder]
            item["folder"] = new_folder
            item["folder_path"] = str(office_files_dir(root) / new_folder)
        updated_rows.append(item)

    vehicles, references = load_package_vehicle_registry(root)
    updated_vehicles = update_record_folder_refs(vehicles, mapping, root)
    updated_references = update_record_folder_refs(references, mapping, root)
    updated_injects = replace_folder_refs_in_obj(load_inject_key(root), mapping)
    data = load_data()
    refresh_package_artifacts(root, updated_rows, updated_vehicles, updated_references, updated_injects, data)
    write_global_vehicle_registry(output_root, [record for record in updated_vehicles if not record.get("inject")])


def max_relative_path_info(root: Path, base: Path | None = None) -> tuple[int, Path | None]:
    if not root.exists():
        return 0, None
    base = base or root
    longest_length = 0
    longest_path: Path | None = None
    for path in root.rglob("*"):
        try:
            relative = path.relative_to(base)
            length = len(str(relative))
        except ValueError:
            length = len(str(path))
        if length > longest_length:
            longest_length = length
            longest_path = path
    return longest_length, longest_path


def path_budget_warnings(output_root: Path, package_dir: Path) -> list[str]:
    warnings: list[str] = []
    office_length, office_path = max_relative_path_info(package_dir, package_dir)
    controlled_length, controlled_path = max_relative_path_info(package_dir, output_root)
    if office_length > MAX_OFFICE_RELATIVE_PATH_CHARS and office_path:
        warnings.append(
            f"Office-relative path budget is {office_length}/{MAX_OFFICE_RELATIVE_PATH_CHARS}: {office_path.relative_to(package_dir)}"
        )
    if controlled_length > MAX_CONTROLLED_RELATIVE_PATH_CHARS and controlled_path:
        warnings.append(
            f"Output-root path budget is {controlled_length}/{MAX_CONTROLLED_RELATIVE_PATH_CHARS}: {controlled_path.relative_to(output_root)}"
        )
    return warnings


def maintenance_shorten_output_names(output_root: Path, office_name: str) -> tuple[list[tuple[Path, Path]], int, Path | None]:
    if office_name.strip().lower() in {"all", "*"}:
        roots = [path for path in output_root.iterdir() if path.is_dir() and not path.name.startswith("_")]
    else:
        roots = [resolve_append_package(output_root, office_name)]

    renamed: list[tuple[Path, Path]] = []
    supported_exts = {".pdf", ".docx", ".xlsx"}
    for root in roots:
        maintenance_shorten_action_folders(output_root, root, renamed)
        maintenance_shorten_known_folders(root, renamed)
        contract_by_folder = {
            str(row.get("folder") or ""): str(row.get("contract_number") or "")
            for row in load_manifest_rows(root)
            if row.get("folder") and row.get("contract_number")
        }
        files = sorted((path for path in root.rglob("*") if path.is_file()), key=lambda item: len(str(item)), reverse=True)
        for path in files:
            if OFFICE_CONTROLLER_DIRNAME in path.parts:
                continue
            if path.suffix.lower() not in supported_exts:
                continue
            piid = piid_from_existing_path(path) or manifest_contract_for_existing_file(root, path, contract_by_folder) or piid_from_existing_file_content(path)
            needs_label_repair = path.name.endswith("_Initial_Doc.docx")
            if not piid:
                continue
            label = compact_label_for_existing_file(path)
            if is_probable_multiple_award_packet(path, label) or should_number_existing_award_packet(path, label):
                award_piid = piid_from_existing_file_content(path) or piid
                target_name = compact_doc_name_for_number(award_piid, award_packet_vendor_label(path), path.suffix)
            else:
                target_name = compact_doc_name_for_label(label, path.suffix)
            needs_path_repair = len(path.name) > MAX_DOCUMENT_NAME_CHARS or len(str(path)) > 240
            needs_style_repair = path.suffix.lower() in {".pdf", ".docx"} and path.name.lower() != target_name.lower()
            if not needs_path_repair and not needs_label_repair and not needs_style_repair:
                continue
            target = unique_compact_target(path, target_name)
            if target != path:
                path.rename(target)
                renamed.append((path, target))

    all_paths = [path for root in roots for path in root.rglob("*")]
    longest = max(all_paths, key=lambda item: len(str(item)), default=None)
    return renamed, len(str(longest)) if longest else 0, longest


def read_pdf_text(path: Path, max_pages: int = 8) -> str:
    if PdfReader is None or not path.exists():
        return ""
    try:
        reader = PdfReader(str(path))
        parts: list[str] = []
        for idx, page in enumerate(reader.pages):
            if idx >= max_pages:
                break
            parts.append(page.extract_text() or "")
        return "\n".join(parts)
    except Exception:
        return ""


def read_docx_text(path: Path) -> str:
    if Document is None or not path.exists():
        return ""
    try:
        doc = Document(str(path))
        paragraphs = [paragraph.text for paragraph in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                paragraphs.extend(cell.text for cell in row.cells)
        return "\n".join(paragraphs)
    except Exception:
        return ""


def first_matching_file(folder: Path, pattern: str) -> Path | None:
    if not folder.exists():
        return None
    return next((path for path in sorted(folder.glob(pattern)) if path.is_file()), None)


def first_matching_file_any(folder: Path, patterns: list[str]) -> Path | None:
    for pattern in patterns:
        match = first_matching_file(folder, pattern)
        if match:
            return match
    return None


def matching_files(folder: Path, pattern: str) -> list[Path]:
    if not folder.exists():
        return []
    return [path for path in sorted(folder.glob(pattern)) if path.is_file()]


def manifest_int(value: Any, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return default
        return int(float(str(value)))
    except (TypeError, ValueError):
        return default


def split_manifest_values(value: Any) -> list[str]:
    return [part.strip() for part in str(value or "").split(";") if part.strip()]


def stage_folder(action_dir: Path, stage: int) -> Path:
    names = stage_folder_names(stage)
    for stage_name in names:
        candidate = action_dir / stage_name
        if candidate.exists():
            return candidate
    return action_dir / names[0]


def validate_office(output_root: Path, office_name: str) -> tuple[list[str], Path | None]:
    """Integrity check: flag anything anomalous that is not explained by a recorded inject."""
    office_dir = resolve_append_package(output_root, office_name)
    rows = load_manifest_rows(office_dir)
    vehicles, references = load_package_vehicle_registry(office_dir)
    inject_entries = load_inject_key(office_dir)
    injected_folders = {str(entry.get("folder")): [i.get("key") for i in entry.get("injects", [])] for entry in inject_entries}
    files_dir = office_files_dir(office_dir)
    problems: list[str] = []
    notes: list[str] = []
    if PdfReader is None:
        notes.append("PDF semantic text checks skipped because pypdf is not available in this runtime.")
    if Document is None:
        notes.append("DOCX semantic text checks skipped because python-docx is not available in this runtime.")

    disk_folders = {child.name for child in files_dir.iterdir() if child.is_dir()} if files_dir.exists() else set()
    action_rows = active_manifest_rows(rows)
    manifest_folders = {str(row.get("folder")) for row in action_rows if str(row.get("folder") or "")}
    for missing in sorted(manifest_folders - disk_folders):
        problems.append(f"Manifest lists '{missing}' but no folder exists in {OFFICE_FILES_DIRNAME}.")
    archive_folders = set()
    for vehicle in vehicles:
        if vehicle.get("folder") and vehicle["folder"] not in manifest_folders:
            archive_folders.add(str(vehicle["folder"]))
    for entry in inject_entries:
        for inject in entry.get("injects", []):
            for field in ("prior_folder", "folder"):
                value = str((inject.get("details") or {}).get(field) or "")
                if value:
                    archive_folders.add(value)
    for orphan in sorted(disk_folders - manifest_folders - archive_folders):
        problems.append(f"Folder '{orphan}' exists on disk but is not in the controller manifest (and is not a known vehicle archive).")

    for row in action_rows:
        folder_name = str(row.get("folder"))
        action_dir = files_dir / folder_name
        if not action_dir.exists():
            continue
        actual_stage = int(row.get("stage") or 0)
        claimed = int(row.get("tracker_stage") or 0)
        row_injects = injected_folders.get(folder_name, [])
        for stage_num, stage_name in STAGE_FOLDERS:
            existing_stage_dirs = [action_dir / name for name in stage_folder_names(stage_num) if (action_dir / name).exists()]
            if stage_num <= actual_stage and not existing_stage_dirs:
                problems.append(f"{folder_name}: stage {stage_num} folder missing but manifest stage is {actual_stage}.")
            if stage_num > actual_stage and existing_stage_dirs:
                problems.append(f"{folder_name}: stage folder '{stage_name}' exists beyond manifest stage {actual_stage}.")
        if claimed and claimed != actual_stage and "tracker-mismatch" not in row_injects:
            problems.append(f"{folder_name}: tracker_stage {claimed} differs from actual stage {actual_stage} with no tracker-mismatch inject recorded.")
        if row.get("injects"):
            for key in str(row["injects"]).split(";"):
                if key and key not in row_injects:
                    problems.append(f"{folder_name}: manifest records inject '{key}' but the inject answer key has no matching entry.")

        category = str(row.get("requirement_category") or row.get("category") or "").lower()
        action_category = str(row.get("category") or "").lower()
        stage1 = stage_folder(action_dir, 1)
        stage2 = stage_folder(action_dir, 2)
        stage4 = stage_folder(action_dir, 4)
        stage6 = stage_folder(action_dir, 6)
        stage7 = stage_folder(action_dir, 7)

        if action_category == "idiq_order" and numeric_money_value(row.get("amount")) > TASK_ORDER_AWARD_CAP:
            problems.append(f"{folder_name}: individual task order amount exceeds {money(TASK_ORDER_AWARD_CAP)} realism cap.")

        if actual_stage >= 1:
            sow_files = matching_files(stage1, "SOW.docx") or matching_files(stage1, "*_SOW.docx") or matching_files(stage1, "SOW_*.docx")
            pws_files = matching_files(stage1, "PWS.docx") or matching_files(stage1, "*_PWS.docx") or matching_files(stage1, "PWS_*.docx")
            if category == "construction":
                if not sow_files:
                    problems.append(f"{folder_name}: construction requirement is missing a SOW support document in stage 1.")
                if pws_files:
                    problems.append(f"{folder_name}: construction requirement has a PWS support document; expected SOW.")
                sor_text = read_docx_text(first_matching_file_any(stage1, ["SOR.docx", "*_SOR.docx", "SOR_*.docx"]) or Path())
                if any(term in sor_text.lower() for term in ["vehicle class", "vin/serial", "leased non-tactical vehicle"]):
                    problems.append(f"{folder_name}: construction SOR contains vehicle-leasing terminology.")
            elif category == "service":
                if not pws_files:
                    problems.append(f"{folder_name}: service requirement is missing a PWS support document in stage 1.")
                if sow_files:
                    problems.append(f"{folder_name}: service requirement has a SOW support document; expected PWS.")

        if actual_stage >= 2 and action_category == "idiq":
            guarantee_memo = first_matching_file_any(stage2, ["Min Guarantee.pdf", "*_Min_Guarantee.pdf", "Minimum Guarantee Tracking Memo.pdf"]) or Path()
            if not guarantee_memo.exists():
                problems.append(f"{folder_name}: IDIQ master funding folder is missing minimum guarantee tracking memo.")

        if actual_stage >= 4:
            solicitation_pdf = first_matching_file_any(stage4, ["RFQ.pdf", "Solicitation.pdf", "*_RFQ.pdf", "*_Solicitation.pdf", "*_Requirement_Solicitation.pdf"])
            solicitation_text = read_pdf_text(solicitation_pdf) if solicitation_pdf else ""
            if category == "supply" and any(term in solicitation_text for term in ["Differing Site Conditions", "Accident Prevention"]):
                problems.append(f"{folder_name}: supply solicitation contains construction clause language.")
            if category == "construction" and solicitation_text:
                if "52.212" not in solicitation_text:
                    problems.append(f"{folder_name}: construction solicitation does not preserve FAR 52.212-series commercial language.")
                if "52.236" not in solicitation_text:
                    problems.append(f"{folder_name}: construction solicitation is missing construction/site-work clause references.")

        awardee_count = manifest_int(row.get("awardee_count"))
        if awardee_count:
            awardee_piids = split_manifest_values(row.get("awardee_contract_numbers"))
            if len(awardee_piids) != awardee_count:
                problems.append(f"{folder_name}: awardee_count is {awardee_count} but manifest lists {len(awardee_piids)} awardee PIIDs.")
            if actual_stage >= 6:
                decision_pdf = first_matching_file_any(stage6, ["Decision.pdf", "*_Decision.pdf", "Decision Document.pdf"]) or Path()
                decision_text = read_pdf_text(decision_pdf)
                if not decision_pdf.exists():
                    problems.append(f"{folder_name}: multiple-award master is missing the decision document in stage 6.")
                elif decision_text:
                    if "Awards are recommended" not in decision_text:
                        problems.append(f"{folder_name}: multiple-award decision document does not use plural award recommendation language.")
                    if "Selected for multiple-award pool" not in decision_text:
                        problems.append(f"{folder_name}: multiple-award decision document is missing award-pool selection language.")
                    if "Awardee Technical Findings" in decision_text:
                        technical_section = decision_text.split("Awardee Technical Findings", 1)[1]
                        if "Not Addressed" in technical_section:
                            problems.append(f"{folder_name}: awardee technical findings contain 'Not Addressed' for a selected multiple-award firm.")
            if actual_stage >= 7:
                roster_pdf = first_matching_file_any(stage7, ["Awardee Roster.pdf", "*_Awardee_Roster.pdf", "Multiple Award * Awardee Roster.pdf"])
                if not roster_pdf:
                    problems.append(f"{folder_name}: multiple-award master is missing the awardee roster in stage 7.")
                if action_category == "idiq" and category == "construction":
                    fair_opportunity_pdf = first_matching_file_any(stage7, ["Fair Opportunity.pdf", "*_Fair_Opportunity.pdf", "Fair Opportunity Ordering Procedures.pdf"]) or Path()
                    if not fair_opportunity_pdf.exists():
                        problems.append(f"{folder_name}: construction MACC is missing fair opportunity ordering procedures in stage 7.")
                    construction_price_lists = [
                        path.name
                        for path in matching_files(stage7, "*Price*List*.pdf")
                        if "Vehicle Lease" not in path.name
                    ]
                    if construction_price_lists:
                        problems.append(f"{folder_name}: construction MACC should not carry a standard price list artifact ({', '.join(construction_price_lists)}).")
                for piid in awardee_piids:
                    if not first_matching_file(stage7, f"{piid}*.pdf"):
                        problems.append(f"{folder_name}: multiple-award master is missing an award packet PDF for {piid}.")
                if action_category == "idiq":
                    funding_text = read_pdf_text(first_matching_file_any(stage2, ["Min Guarantee.pdf", "*_Min_Guarantee.pdf", "Minimum Guarantee Tracking Memo.pdf"]) or Path())
                    if funding_text and "funded task or delivery order" not in funding_text:
                        problems.append(f"{folder_name}: IDIQ minimum guarantee memo does not explain funded-order tracking.")

    vehicle_numbers = {str(v.get("vehicle_number", "")).upper() for v in vehicles}
    for row in action_rows:
        parent = str(row.get("parent_contract_number") or "").upper()
        if parent and parent not in vehicle_numbers:
            notes.append(f"{row.get('folder')}: parent {parent} not in office registry (standalone reference - acceptable, verify intentional).")
    for vehicle in vehicles:
        folder_name = str(vehicle.get("folder") or "")
        is_phantom = any("phantom-master" in keys and not folder_name for keys in injected_folders.values()) and not folder_name
        if folder_name and not (files_dir / folder_name).exists():
            problems.append(f"Vehicle {vehicle.get('vehicle_number')}: registry points to folder '{folder_name}' which does not exist.")
        elif not folder_name and not vehicle.get("inject") and not is_phantom:
            problems.append(f"Vehicle {vehicle.get('vehicle_number')}: registry entry has no folder and no recorded inject explaining it.")

    vehicles_by_number = {str(vehicle.get("vehicle_number") or "").upper(): vehicle for vehicle in vehicles}
    refs_by_parent = references_by_parent(references)
    for parent_number, parent_refs in refs_by_parent.items():
        vehicle = vehicles_by_number.get(parent_number)
        if not vehicle:
            continue
        folder_name = str(vehicle.get("folder") or "")
        if folder_name and (files_dir / folder_name).exists():
            admin_tracker = parent_admin_dir(files_dir / folder_name) / "Order Administration Tracker.xlsx"
            if not admin_tracker.exists():
                problems.append(f"Vehicle {parent_number}: order/call exists but parent folder is missing {PARENT_ADMIN_DIRNAME}\\Order Administration Tracker.xlsx.")
        ceiling = numeric_money_value(vehicle.get("ceiling"))
        call_limit = numeric_money_value(vehicle.get("call_limit"))
        order_total = sum(numeric_money_value(ref.get("amount")) for ref in parent_refs)
        base_obligated = parent_base_obligated_amount(vehicle)
        if ceiling and base_obligated + order_total > ceiling + 0.01:
            explained = any("near-ceiling-parent" in injected_folders.get(str(ref.get("folder") or ""), []) for ref in parent_refs)
            if not explained:
                problems.append(
                    f"Vehicle {parent_number}: cumulative IDIQ orders {money(base_obligated + order_total)} exceed ceiling {money(ceiling)} with no ceiling inject recorded."
                )
        if call_limit:
            for ref in parent_refs:
                amount = numeric_money_value(ref.get("amount"))
                if amount > call_limit + 0.01 and "call-limit-breach" not in injected_folders.get(str(ref.get("folder") or ""), []):
                    problems.append(
                        f"Vehicle {parent_number}: call/order {ref.get('action_number')} amount {money(amount)} exceeds call limit {money(call_limit)} with no call-limit-breach inject recorded."
                    )

    admin = office_admin_dir(office_dir)
    if rows and not (admin / "Contract Workload Tracker.xlsx").exists():
        problems.append(f"{OFFICE_ADMIN_DIRNAME} is missing Contract Workload Tracker.xlsx.")
    if (action_rows or vehicles) and not (admin / "Continuity Binder.pdf").exists():
        problems.append(f"{OFFICE_ADMIN_DIRNAME} is missing Continuity Binder.pdf.")

    lines = [
        "# Office Validation Report (Controller Only)",
        "",
        f"Office: {office_dir.name}",
        f"Actions in manifest: {len(rows)} | Vehicles: {len(vehicles)} | Inject-bearing actions: {len(inject_entries)}",
        "",
    ]
    if problems:
        lines.append("## Problems (not explained by recorded injects)")
        lines.append("")
        lines.extend(f"- {item}" for item in problems)
    else:
        lines.append("## Result: CLEAN")
        lines.append("")
        lines.append("No unexplained inconsistencies found. Every anomaly on this drive is a recorded inject.")
    if notes:
        lines.append("")
        lines.append("## Notes")
        lines.append("")
        lines.extend(f"- {item}" for item in notes)
    report_path = None
    controller = office_controller_dir(office_dir)
    if controller.exists() or rows:
        controller.mkdir(parents=True, exist_ok=True)
        report_path = controller / "_validation_report.md"
        report_path.write_text("\n".join(lines), encoding="utf-8")
    return problems, report_path


def run_exercise_script(script_path: str, output_root_arg: str) -> int:
    """Run a whole exercise definition: {office, seed, entries: [{scenario, type, stage, count, injects, ...}]}."""
    path = Path(script_path)
    if not path.exists():
        raise SystemExit(f"Script file not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Script file is not valid JSON: {exc}")
    return run_script_payload(payload, output_root_arg)


def run_script_payload(payload: dict[str, Any], output_root_arg: str) -> int:
    office = str(payload.get("office") or DEFAULT_OFFICE_NAME)
    base_seed = payload.get("seed")
    entries = payload.get("entries")
    if not isinstance(entries, list) or not entries:
        raise SystemExit("Script must contain a non-empty 'entries' list.")
    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict) or not str(entry.get("scenario", "")).strip():
            raise SystemExit(f"Script entry {index} must be an object with a 'scenario' prompt.")
        argv = ["--scenario", str(entry["scenario"]).strip(), "--package-name", office]
        if output_root_arg:
            argv += ["--output-root", output_root_arg]
        if entry.get("type"):
            argv += ["--type", str(entry["type"])]
        if entry.get("stage"):
            argv += ["--stage", str(int(entry["stage"]))]
        if entry.get("count"):
            argv += ["--count", str(int(entry["count"]))]
        if entry.get("quantity"):
            argv += ["--quantity", str(int(entry["quantity"]))]
        if entry.get("awardee_count") or entry.get("awardees"):
            argv += ["--awardee-count", str(int(entry.get("awardee_count") or entry.get("awardees")))]
        if entry.get("parent_number"):
            argv += ["--parent-number", str(entry["parent_number"])]
        if entry.get("solicitation_style"):
            argv += ["--solicitation-style", str(entry["solicitation_style"])]
        for inject in entry.get("injects") or []:
            argv += ["--inject", str(inject)]
        if base_seed is not None:
            argv += ["--seed", str(int(base_seed) + index)]
        print(f"--- Script entry {index}/{len(entries)}: {entry['scenario'][:60]}")
        result = main(argv)
        if result != 0:
            raise SystemExit(f"Script entry {index} failed with exit code {result}.")
    print(f"Script complete: {len(entries)} entries generated into office '{office}'.")
    return 0


# ---------------------------------------------------------------------------
# Office Builder: a deployment narrative in, a complete clean office out.
# The narrative drives the MIX of contract actions only. No narrative text is
# ever written into the generated documents, so location masking is preserved.
# Injects are never planted by the builder - controllers add them afterward.
# ---------------------------------------------------------------------------

BUILDER_PROMPTS = {
    "t_wall_barriers": "T-Wall barriers for entry control point hardening",
    "hesco_barriers": "Hesco barriers for perimeter force protection",
    "shelter_tents": "Shelter tents for billeting expansion",
    "gravel_delivery": "Gravel for access road and laydown stabilization",
    "generator_lease": "Generator rental for temporary facility power",
    "generator_maintenance": "Generator service maintenance for deployed power equipment",
    "water_tank_rental": "Potable water tank rental for camp support",
    "bottled_water": "Bottled water delivery surge support",
    "portable_latrines": "Portable latrine and handwash service",
    "traffic_control": "Traffic control devices for flightline and ECP",
    "base_signage": "Installation signage for wayfinding and safety",
    "lumber_materials": "Lumber package for self-help projects",
    "network_cable": "Network cabling installation for admin facilities",
    "forklift_rental": "Rough terrain forklift rental for cargo yard",
    "ice_delivery": "Bagged ice delivery for work-rest cycles",
    "battery_power": "Battery and power accessory resupply",
    "janitorial_services": "Janitorial services for mission support facilities",
    "waste_removal": "Solid waste removal for expeditionary sites",
    "pest_control": "Pest control service for dining and lodging areas",
    "laundry_service": "Laundry service for deployed personnel",
    "hvac_repair": "HVAC repair for mission support facility",
    "vehicle_parts": "Vehicle parts for mission support fleet",
    "office_furniture": "Office furniture for staff expansion",
    "fitness_equipment": "Fitness equipment for the deployed gym",
}

BUILDER_THEMES = {
    "buildup": {
        "keywords": ["bed-down", "beddown", "buildup", "build up", "establish", "new base", "bare base", "open the base", "expansion", "expand", "initial", "surge", "stand up", "standing up"],
        "supply_pool": ["t_wall_barriers", "hesco_barriers", "shelter_tents", "gravel_delivery", "water_tank_rental", "bottled_water", "traffic_control", "base_signage", "lumber_materials", "network_cable", "forklift_rental", "ice_delivery", "battery_power", "office_furniture"],
        "service_pool": ["generator_lease", "portable_latrines", "janitorial_services", "waste_removal"],
        "masters": ["facility_support_bpa"],
        "call_count": (1, 2),
    },
    "sustainment": {
        "keywords": ["sustain", "steady state", "steady-state", "established", "mature", "rotation", "enduring", "ongoing operations"],
        "supply_pool": ["vehicle_parts", "office_furniture", "battery_power", "ice_delivery", "fitness_equipment", "base_signage", "bottled_water", "lumber_materials"],
        "service_pool": ["janitorial_services", "waste_removal", "pest_control", "laundry_service", "generator_maintenance", "hvac_repair", "portable_latrines"],
        "masters": ["facility_support_bpa", "base_support_idiq"],
        "call_count": (2, 4),
    },
    "drawdown": {
        "keywords": ["drawdown", "draw down", "closure", "closing", "retrograde", "transition out", "redeployment", "downsize"],
        "supply_pool": ["forklift_rental", "vehicle_parts", "battery_power", "lumber_materials", "traffic_control"],
        "service_pool": ["waste_removal", "janitorial_services", "laundry_service", "generator_maintenance", "portable_latrines"],
        "masters": ["facility_support_bpa"],
        "call_count": (1, 3),
    },
}

BUILDER_STAGE_WEIGHTS = [(8, 42), (7, 16), (6, 8), (5, 9), (4, 9), (3, 8), (2, 5), (1, 3)]
BUILDER_STAGE_WEIGHTS_SHORT = [(8, 18), (7, 14), (6, 12), (5, 14), (4, 14), (3, 14), (2, 8), (1, 6)]

BUILDER_DURATION_KEYWORDS = {
    "short": ["short term", "short-term", "30 day", "45 day", "60 day", "90 day", "temporary", "exercise support", "immediate response", "initial response", "quick", "interim"],
    "long": ["long term", "long-term", "enduring", "established", "12 month", "twelve month", "year-long", "annual", "rotation", "steady state", "steady-state", "mature"],
}


def detect_builder_duration(narrative: str, theme_name: str) -> str:
    lowered = narrative.lower()
    short_hits = sum(1 for kw in BUILDER_DURATION_KEYWORDS["short"] if kw in lowered)
    long_hits = sum(1 for kw in BUILDER_DURATION_KEYWORDS["long"] if kw in lowered)
    if short_hits > long_hits:
        return "short"
    if long_hits > short_hits:
        return "long"
    return "short" if theme_name == "buildup" else "long"


def detect_builder_theme(narrative: str) -> str:
    lowered = narrative.lower()
    scores = {name: sum(1 for kw in theme["keywords"] if kw in lowered) for name, theme in BUILDER_THEMES.items()}
    best = max(scores, key=lambda name: scores[name])
    if scores[best] == 0:
        return "sustainment" if not any(k in lowered for k in ["deploy", "arrive", "incoming"]) else "buildup"
    return best


def builder_stage(rng: random.Random, duration: str = "long") -> int:
    weights = BUILDER_STAGE_WEIGHTS_SHORT if duration == "short" else BUILDER_STAGE_WEIGHTS
    total = sum(weight for _, weight in weights)
    pick = rng.randint(1, total)
    cumulative = 0
    for stage, weight in weights:
        cumulative += weight
        if pick <= cumulative:
            return stage
    return 8


def build_office_plan(narrative: str, size: int, office: str, seed: int | None, duration: str = "auto") -> dict[str, Any]:
    rng = random.Random(seed if seed is not None else narrative)
    theme_name = detect_builder_theme(narrative)
    theme = BUILDER_THEMES[theme_name]
    size = max(6, min(50, int(size or 18)))
    resolved_duration = duration if duration in {"short", "long"} else detect_builder_duration(narrative, theme_name)
    entries: list[dict[str, Any]] = []

    # Masters first so later calls/orders can ride them through the registry.
    # Short-term offices have little time to establish vehicles; long-term
    # offices are built around them.
    if resolved_duration == "short":
        masters = list(theme["masters"])[:1] if rng.random() < 0.4 else []
    else:
        masters = list(theme["masters"])
        if "base_support_idiq" not in masters and (size >= 14 or rng.random() < 0.5):
            masters.append("base_support_idiq")
    for master_key in masters:
        master_type = "bpa" if "bpa" in master_key else "idiq"
        prompt = "Facility support blanket purchase agreement" if master_type == "bpa" else "Base support IDIQ"
        entries.append({"scenario": prompt, "type": master_type, "stage": 7})

    call_low, call_high = theme["call_count"]
    if resolved_duration == "short":
        call_count = rng.randint(0, 1) if masters else 0
    else:
        call_count = rng.randint(max(2, call_low), max(3, call_high))
    if not masters:
        call_count = 0
    call_prompts = [
        "Repair call against the facility support BPA",
        "Recurring supplies call against the facility support BPA",
        "Incidental services call against the facility support BPA",
    ]
    order_prompts = [
        "Sustainment order off the base support IDIQ",
        "Facility repair order off the base support IDIQ",
    ]

    body_count = size - len(entries) - call_count
    supply_share = 0.62 if theme_name == "buildup" else 0.45
    pool: list[str] = []
    while len(pool) < body_count:
        source = theme["supply_pool"] if rng.random() < supply_share else theme["service_pool"]
        pick = rng.choice(source)
        if pool.count(pick) < 2:  # at most two of the same requirement
            pool.append(pick)
    rng.shuffle(pool)
    for key in pool:
        entry: dict[str, Any] = {"scenario": BUILDER_PROMPTS.get(key, key.replace("_", " "))}
        if key in {"janitorial_services", "waste_removal", "pest_control", "laundry_service", "generator_maintenance"}:
            entry["type"] = "service"
        entry["stage"] = builder_stage(rng, resolved_duration)
        entries.append(entry)

    has_idiq = any(e.get("type") == "idiq" for e in entries)
    has_bpa = any(e.get("type") == "bpa" for e in entries)
    for _ in range(call_count):
        if has_idiq and (not has_bpa or rng.random() < 0.4):
            entries.append({"scenario": rng.choice(order_prompts), "type": "idiq-order", "stage": builder_stage(rng, resolved_duration)})
        elif has_bpa:
            entries.append({"scenario": rng.choice(call_prompts), "type": "bpa-call", "stage": builder_stage(rng, resolved_duration)})

    return {
        "office": office,
        "seed": seed if seed is not None else random.Random(narrative).randint(1, 999999),
        "narrative": narrative,
        "theme": theme_name,
        "duration": resolved_duration,
        "entries": entries,
    }


def qc_regression_payload(office: str) -> dict[str, Any]:
    return {
        "office": office,
        "seed": 7600,
        "entries": [
            {"scenario": "Office paper, printer toner, and basic desk supplies for a contracting office", "type": "supply", "stage": 8},
            {"scenario": "Purchase portable generators for temporary facility power at a deployed installation", "type": "supply", "stage": 8},
            {"scenario": "Handheld radios and network switches for deployed command post communications", "type": "supply", "stage": 8},
            {"scenario": "Trauma kits, AEDs, and clinic supplies for emergency response posture", "type": "supply", "stage": 8},
            {"scenario": "F-35 aircraft support equipment package with documentation and delivery support", "type": "supply", "stage": 8},
            {"scenario": "Generator inspection, maintenance, and repair service for expeditionary power equipment", "type": "service", "stage": 8},
            {"scenario": "Lease light armored vehicles for base security patrol support", "type": "service", "stage": 8},
            {"scenario": "Repair drainage pad and concrete apron for mission support facility access", "type": "construction", "stage": 8},
            {"scenario": "Multiple award BPA for recurring office supplies, toner, small tools, and facility consumables", "type": "bpa", "stage": 7, "awardee_count": 3},
            {"scenario": "Multiple award construction MACC for minor facility repair, electrical, drainage, paving, and site work", "type": "idiq", "stage": 7, "awardee_count": 6},
            {"scenario": "Facility repair order off the base support IDIQ for replacing damaged doors and minor electrical repairs", "type": "idiq-order", "stage": 8},
            {"scenario": "Recurring supplies call against the facility support BPA for batteries, cleaning supplies, and office consumables", "type": "bpa-call", "stage": 8},
        ],
    }


def qc_delete_payload(office: str) -> dict[str, Any]:
    return {
        "office": office,
        "seed": 8800,
        "entries": [
            {"scenario": "Office paper and toner resupply for the contracting office", "type": "supply", "stage": 8},
            {"scenario": "Purchase portable generators for temporary facility power", "type": "supply", "stage": 8},
        ],
    }


def qc_assert(condition: bool, failures: list[str], message: str) -> None:
    if not condition:
        failures.append(message)


def qc_row_by_title(rows: list[dict[str, Any]], title: str) -> dict[str, Any] | None:
    return next((row for row in rows if str(row.get("title") or "") == title), None)


def qc_run_targeted_assertions(office_dir: Path) -> list[str]:
    rows = active_manifest_rows(load_manifest_rows(office_dir))
    vehicles, references = load_package_vehicle_registry(office_dir)
    files_dir = office_files_dir(office_dir)
    failures: list[str] = []
    contract_numbers = [str(row.get("contract_number") or "") for row in rows if row.get("contract_number")]
    qc_assert(len(contract_numbers) == len(set(contract_numbers)), failures, "duplicate contract numbers in manifest")

    expected_supply_titles = [
        "Portable Generator Purchase",
        "Communications Equipment Purchase",
        "Medical Supply Package",
        "F-35 Support Equipment Purchase",
    ]
    for title in expected_supply_titles:
        row = qc_row_by_title(rows, title)
        qc_assert(row is not None, failures, f"missing protected custom profile row: {title}")
        if row:
            qc_assert(str(row.get("requirement_category")) == "supply", failures, f"{title} did not remain a supply action")

    generator_row = qc_row_by_title(rows, "Portable Generator Purchase")
    if generator_row:
        title_text = str(generator_row.get("title") or "").lower()
        qc_assert("t-wall" not in title_text and "barrier" not in title_text, failures, "generator purchase row contains barrier title leakage")

    facility_order = qc_row_by_title(rows, "Facility Repair Order")
    qc_assert(facility_order is not None, failures, "facility repair IDIQ-order prompt did not produce Facility Repair Order")
    if facility_order:
        qc_assert(facility_order.get("category") == "idiq_order", failures, "facility repair order is not an IDIQ order")
        qc_assert(facility_order.get("requirement_category") == "construction", failures, "facility repair order did not remain construction")
        qc_assert(bool(facility_order.get("parent_found_in_registry")), failures, "facility repair order did not link to a parent IDIQ")
        qc_assert("generator" not in str(facility_order.get("title") or "").lower(), failures, "facility repair order leaked generator title")
        parent_number = str(facility_order.get("parent_contract_number") or "")
        parent_vehicle = next((vehicle for vehicle in vehicles if str(vehicle.get("vehicle_number") or "") == parent_number), None)
        qc_assert(parent_vehicle is not None, failures, "facility repair order parent is not in package vehicle registry")
        if parent_vehicle:
            parent_folder = files_dir / str(parent_vehicle.get("folder") or "")
            qc_assert((parent_admin_dir(parent_folder) / "Order Administration Tracker.xlsx").exists(), failures, "facility repair order did not create parent admin tracker")
            order_total = numeric_money_value(parent_vehicle.get("order_obligated_amount"))
            qc_assert(order_total >= numeric_money_value(facility_order.get("amount")), failures, "facility repair order did not roll up into parent obligated amount")
            ceiling = numeric_money_value(parent_vehicle.get("ceiling"))
            if ceiling:
                qc_assert(numeric_money_value(parent_vehicle.get("obligated_amount")) <= ceiling, failures, "facility repair order caused parent ceiling overrun")

    supply_call = qc_row_by_title(rows, "Recurring Supply Call")
    qc_assert(supply_call is not None, failures, "recurring supplies BPA-call prompt did not produce Recurring Supply Call")
    if supply_call:
        qc_assert(supply_call.get("category") == "bpa_call", failures, "recurring supply call is not a BPA call")
        qc_assert(supply_call.get("requirement_category") == "supply", failures, "recurring supply call did not remain supply")
        qc_assert(bool(supply_call.get("parent_found_in_registry")), failures, "recurring supply call did not link to a parent BPA")
        qc_assert("janitorial" not in str(supply_call.get("title") or "").lower(), failures, "recurring supply call leaked janitorial title")

    for row in rows:
        category = str(row.get("requirement_category") or row.get("category") or "").lower()
        action_dir = files_dir / str(row.get("folder") or "")
        if not action_dir.exists():
            failures.append(f"{row.get('contract_number')}: action folder missing")
            continue
        stage1 = stage_folder(action_dir, 1)
        if category == "construction":
            qc_assert(bool(matching_files(stage1, "SOW.docx") or matching_files(stage1, "*_SOW.docx") or matching_files(stage1, "SOW_*.docx")), failures, f"{row.get('folder')}: construction missing SOW")
        if category == "service":
            qc_assert(bool(matching_files(stage1, "PWS.docx") or matching_files(stage1, "*_PWS.docx") or matching_files(stage1, "PWS_*.docx")), failures, f"{row.get('folder')}: service missing PWS")
        if row.get("category") == "idiq_order":
            qc_assert(numeric_money_value(row.get("amount")) <= TASK_ORDER_AWARD_CAP, failures, f"{row.get('folder')}: task order exceeds individual realism cap")
        solicitation = first_matching_file_any(stage_folder(action_dir, 4), ["RFQ.pdf", "Solicitation.pdf", "*_RFQ.pdf", "*_Solicitation.pdf", "*_Requirement_Solicitation.pdf"]) if int(row.get("stage") or 0) >= 4 else None
        if solicitation:
            solicitation_text = read_pdf_text(solicitation)
            if category == "supply":
                qc_assert(
                    not any(term in solicitation_text for term in ["Differing Site Conditions", "Accident Prevention"]),
                    failures,
                    f"{row.get('folder')}: supply solicitation has construction clause language",
                )
            if category == "construction":
                qc_assert("52.212" in solicitation_text and "52.236" in solicitation_text, failures, f"{row.get('folder')}: construction solicitation missing commercial/construction clause mix")

    macc_rows = [row for row in rows if row.get("category") == "idiq" and manifest_int(row.get("awardee_count")) == 6]
    qc_assert(len(macc_rows) == 1, failures, f"expected one 6-awardee IDIQ row, found {len(macc_rows)}")
    if macc_rows:
        row = macc_rows[0]
        awardee_piids = split_manifest_values(row.get("awardee_contract_numbers"))
        qc_assert(len(awardee_piids) == 6, failures, f"expected 6 MACC awardee PIIDs, got {len(awardee_piids)}")
        qc_assert(not str(row.get("folder") or "").startswith(str(row.get("contract_number") or "")), failures, "MACC base folder still starts with base IDIQ PIID")
        action_dir = files_dir / str(row.get("folder") or "")
        award_dir = stage_folder(action_dir, 7)
        award_pdfs = []
        for piid in awardee_piids:
            matches = [
                match
                for match in matching_files(award_dir, f"{piid}*.pdf")
                if not match.stem.endswith(("_Awardee_Roster", "_Fair_Opportunity"))
            ]
            if matches:
                award_pdfs.append(matches[0])
        qc_assert(len(award_pdfs) == 6, failures, f"expected 6 MACC award PDFs, got {len(award_pdfs)}")
        qc_assert(bool(first_matching_file_any(award_dir, ["Fair Opportunity.pdf", "*_Fair_Opportunity.pdf", "Fair Opportunity Ordering Procedures.pdf"])), failures, "MACC missing fair opportunity ordering procedures attachment")
        construction_price_lists = [path.name for path in matching_files(award_dir, "*Price*List*.pdf") if "Vehicle Lease" not in path.name]
        qc_assert(not construction_price_lists, failures, f"MACC still has construction price list artifact: {', '.join(construction_price_lists)}")
        for piid in awardee_piids:
            matches = [
                match
                for match in matching_files(award_dir, f"{piid}*.pdf")
                if not match.stem.endswith(("_Awardee_Roster", "_Fair_Opportunity"))
            ]
            qc_assert(bool(matches), failures, f"missing MACC award packet for {piid}")
            if matches:
                qc_assert("Construction MACC Ordering Scope" not in matches[0].name, failures, f"{matches[0].name} still uses generic ordering-scope name")
        first_award_text = read_pdf_text(award_pdfs[0]) if award_pdfs else ""
        qc_assert("52.212" in first_award_text and "52.236" in first_award_text, failures, "MACC award missing commercial/construction clause mix")
        qc_assert("339999" not in first_award_text, failures, "MACC award still shows generic 339999 NAICS")
        qc_assert(bool(first_matching_file_any(stage_folder(action_dir, 2), ["Min Guarantee.pdf", "*_Min_Guarantee.pdf", "Minimum Guarantee Tracking Memo.pdf"])), failures, "MACC missing minimum guarantee tracking memo")
        decision_text = read_pdf_text(first_matching_file_any(stage_folder(action_dir, 6), ["Decision.pdf", "*_Decision.pdf", "Decision Document.pdf"]) or Path())
        qc_assert("Awards are recommended" in decision_text and "Selected for multiple-award pool" in decision_text, failures, "MACC decision lacks plural/pool selection wording")

    bpa_rows = [row for row in rows if row.get("category") == "bpa" and manifest_int(row.get("awardee_count")) == 3]
    qc_assert(len(bpa_rows) == 1, failures, f"expected one 3-awardee BPA row, found {len(bpa_rows)}")
    if bpa_rows:
        row = bpa_rows[0]
        awardee_piids = split_manifest_values(row.get("awardee_contract_numbers"))
        qc_assert(len(awardee_piids) == 3, failures, f"expected 3 BPA awardee PIIDs, got {len(awardee_piids)}")
        award_dir = stage_folder(files_dir / str(row.get("folder") or ""), 7)
        for piid in awardee_piids:
            qc_assert(bool(matching_files(award_dir, f"{piid}*.pdf")), failures, f"missing BPA award packet for {piid}")
    office_rel_length, office_rel_path = max_relative_path_info(office_dir, office_dir)
    qc_assert(
        office_rel_length <= MAX_OFFICE_RELATIVE_PATH_CHARS,
        failures,
        f"office-relative path budget exceeded: {office_rel_length}/{MAX_OFFICE_RELATIVE_PATH_CHARS} at {office_rel_path.relative_to(office_dir) if office_rel_path else ''}",
    )
    return failures


def run_qc_regression(args: argparse.Namespace) -> int:
    output_root = Path(args.output_root) if args.output_root else Path(tempfile.mkdtemp(prefix="cco-qc-regression-"))
    output_root.mkdir(parents=True, exist_ok=True)
    mixed_office = next_available_dir(output_root, "QC Regression Office").name
    delete_office = next_available_dir(output_root, "QC Delete Office").name
    print(f"QC_ROOT={output_root}")
    print(f"QC_MIXED_OFFICE={mixed_office}")

    run_script_payload(qc_regression_payload(mixed_office), str(output_root))
    mixed_dir = output_root / mixed_office
    problems, report_path = validate_office(output_root, mixed_office)
    if report_path:
        print(f"QC_MIXED_VALIDATION_REPORT={report_path}")
    failures = [f"validator: {item}" for item in problems]
    failures.extend(qc_run_targeted_assertions(mixed_dir))

    print(f"QC_DELETE_OFFICE={delete_office}")
    run_script_payload(qc_delete_payload(delete_office), str(output_root))
    delete_dir = output_root / delete_office
    rows_before_delete = active_manifest_rows(load_manifest_rows(delete_dir))
    delete_row = qc_row_by_title(rows_before_delete, "Portable Generator Purchase")
    if not delete_row or not delete_row.get("folder"):
        failures.append("delete QC could not find generated Portable Generator Purchase row")
    else:
        data = load_data()
        maintenance_delete_action(output_root, delete_office, str(delete_row["folder"]), data)
        delete_problems, delete_report = validate_office(output_root, delete_office)
        if delete_report:
            print(f"QC_DELETE_VALIDATION_REPORT={delete_report}")
        failures.extend(f"delete validator: {item}" for item in delete_problems)
        rows_after_delete = load_manifest_rows(delete_dir)
        placeholder = next((row for row in rows_after_delete if str(row.get("contract_number") or "") == str(delete_row.get("contract_number") or "")), None)
        qc_assert(bool(placeholder and is_placeholder_row(placeholder)), failures, "delete QC did not leave a PIID placeholder row")
        if placeholder:
            qc_assert(str(placeholder.get("folder") or "") == "", failures, "delete QC placeholder still has a folder value")
            qc_assert("intentionally left unused" in tracker_turnover_note(placeholder), failures, "delete QC placeholder tracker note is not explicit")
        qc_assert(not (office_files_dir(delete_dir) / str(delete_row.get("folder"))).exists(), failures, "delete QC action folder still exists on disk")

    if failures:
        print("QC_REGRESSION: FAIL")
        for failure in failures:
            print(f"QC_FAILURE: {failure}")
        return 2
    print("QC_REGRESSION: PASS")
    return 0


def run_office_builder(args: argparse.Namespace) -> int:
    narrative = args.build_office.strip()
    office = truncate_filename(args.package_name, MAX_PACKAGE_NAME_CHARS, "office") if args.package_name else DEFAULT_OFFICE_NAME
    plan = build_office_plan(narrative, args.office_size, office, args.seed, args.office_duration)
    print(f"Office builder theme: {plan['theme']} | duration: {plan['duration']} | actions planned: {len(plan['entries'])}")
    output_root_path = Path(args.output_root) if args.output_root else package_root() / "Outputs"
    office_dir_pre = output_root_path / office
    ensure_gpc_log(office_dir_pre, load_data(), volume="heavy" if plan["duration"] == "short" else "standard")
    result = run_script_payload(plan, args.output_root)
    if result != 0:
        return result
    output_root = Path(args.output_root) if args.output_root else package_root() / "Outputs"
    office_dir = output_root / office
    controller = office_controller_dir(office_dir)
    controller.mkdir(parents=True, exist_ok=True)
    plan_path = controller / "_office_build_plan.json"
    plan_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    print(f"Build plan saved (editable, re-runnable with --script): {plan_path}")
    print("Office is CLEAN - no injects were planted. Add injects by generating individual actions into this office.")
    return 0


def run_maintenance(args: argparse.Namespace) -> int:
    output_root = Path(args.output_root) if args.output_root else package_root() / "Outputs"
    data = load_data()
    for spec in args.delete_action or []:
        package_name, separator, action_folder = str(spec).partition("/")
        if not separator or not package_name.strip() or not action_folder.strip():
            raise SystemExit(f"--delete-action expects PACKAGE/ACTION FOLDER, got: {spec}")
        maintenance_delete_action(output_root, package_name.strip(), action_folder.strip(), data)
        print(f"Deleted action: {spec}")
    if args.delete_package.strip():
        maintenance_delete_package(output_root, args.delete_package.strip())
        print(f"Deleted office: {args.delete_package.strip()}")
    if args.export_trainee.strip():
        target = export_trainee_copy(output_root, args.export_trainee.strip(), args.export_dest)
        print(f"Trainee copy exported (controller files excluded): {target}")
    if args.shorten_names.strip():
        renamed, longest_length, longest_path = maintenance_shorten_output_names(output_root, args.shorten_names.strip())
        print(f"Shortened {len(renamed)} existing output path name(s) in: {args.shorten_names.strip()}")
        for old_path, new_path in renamed[:25]:
            print(f"  {old_path.name} -> {new_path.name}")
        if len(renamed) > 25:
            print(f"  ... {len(renamed) - 25} more")
        if longest_path:
            print(f"Longest output path now: {longest_length} characters")
            print(f"  {longest_path}")
        target = None if args.shorten_names.strip().lower() in {"all", "*"} else resolve_append_package(output_root, args.shorten_names.strip())
        if target:
            for warning in path_budget_warnings(output_root, target):
                print(f"PATH BUDGET WARNING: {warning}", file=sys.stderr)
    if args.validate.strip():
        problems, report_path = validate_office(output_root, args.validate.strip())
        if report_path:
            print(f"Validation report: {report_path}")
        if problems:
            print(f"VALIDATION: {len(problems)} unexplained problem(s) found:", file=sys.stderr)
            for item in problems:
                print(f"  - {item}", file=sys.stderr)
            return 2
        print("VALIDATION: clean - every anomaly on the drive is a recorded inject.")
    return 0


def next_available_dir(root: Path, name: str) -> Path:
    candidate = root / name
    if not candidate.exists():
        return candidate
    for suffix in range(2, 100):
        candidate = root / f"{name}_{suffix:02d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not find available output folder for {name}")


def resolve_append_package(output_root: Path, value: str) -> Path:
    raw = Path(value)
    candidates = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        candidates.append(output_root / value)
        candidates.append(package_root() / value)
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    raise SystemExit(f"--append-package target not found: {value}")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate mock CCO turnover contract files.")
    parser.add_argument("--scenario", default="", help="Scenario prompt for the single contract action to generate.")
    parser.add_argument("--count", type=int, default=1, help="Number of action folders to generate. Default is one.")
    parser.add_argument("--seed", type=int, default=None, help="Random seed for repeatable output.")
    parser.add_argument("--prompt", default="", help="Optional legacy alias for --scenario or batch theme.")
    parser.add_argument(
        "--type",
        choices=["auto", "supply", "service", "construction", "bpa", "idiq", "bpa-call", "bpa_call", "idiq-order", "idiq_order"],
        default="auto",
        help="Requirement type. Use auto unless you want to force the document flavor.",
    )
    parser.add_argument("--quantity", type=int, default=None, help="Override the generated CLIN quantity.")
    parser.add_argument(
        "--solicitation-style",
        choices=["auto", "rfq-email", "combined"],
        default="auto",
        help="Solicitation artifact style. Auto uses RFQ email for simpler low-dollar supply buys and combined synopsis/solicitation otherwise.",
    )
    parser.add_argument("--stage", type=int, choices=range(1, 9), default=None, help="Exact lifecycle stage to generate through.")
    parser.add_argument("--package-name", default="", help="Output package folder name under Outputs.")
    parser.add_argument("--append-package", default="", help="Append generated action folders into an existing package folder under Outputs, or provide a full path.")
    parser.add_argument("--output-root", default="", help="Output root. Defaults to ../Outputs from this tool.")
    parser.add_argument("--max-stage", type=int, choices=range(1, 9), default=8, help="Latest lifecycle stage for randomized batch generation.")
    parser.add_argument("--parent-number", default="", help="Optional parent BPA/IDIQ number for BPA calls or IDIQ orders, such as FA4867XXA0001.")
    parser.add_argument("--awardee-count", type=int, default=None, help="For BPA/IDIQ masters, force the number of awardees. Use 1 for single-award or 2-8 for a multiple-award pool.")
    parser.add_argument(
        "--inject",
        action="append",
        default=[],
        choices=inject_choices(),
        help="Plant a training inject in the generated action. Repeatable. Use 'random' to let the tool pick an applicable inject. A controller-only answer key is written to the package root.",
    )
    parser.add_argument("--delete-action", action="append", default=[], help="Maintenance: delete one action folder and scrub package records. Format: PACKAGE/ACTION FOLDER. Repeatable.")
    parser.add_argument("--delete-package", default="", help="Maintenance: delete an entire package folder and scrub office records.")
    parser.add_argument("--export-trainee", default="", help="Maintenance: export a trainee-ready copy of an office (controller files excluded) to Outputs/_exports or --export-dest.")
    parser.add_argument("--export-dest", default="", help="Optional destination folder for --export-trainee.")
    parser.add_argument("--shorten-names", default="", help="Maintenance: shorten existing generated document filenames for one office, or ALL for every office under the output root.")
    parser.add_argument("--validate", default="", help="Maintenance: integrity-check an office; flags anomalies not explained by recorded injects.")
    parser.add_argument("--qc-regression", action="store_true", help="Generate mixed regression offices in a temp/output root, validate them, and run targeted self-checks.")
    parser.add_argument("--script", default="", help="Generate a whole exercise from a JSON script file (office, seed, entries).")
    parser.add_argument("--build-office", default="", help="Office Builder: describe the deployment scenario in plain language and generate a complete, inject-free office sized by --office-size.")
    parser.add_argument("--office-size", type=int, default=18, help="Approximate number of contract actions for --build-office (6-50). Default 18.")
    parser.add_argument("--office-duration", choices=["auto", "short", "long"], default="auto", help="Office Builder posture: short-term (fewer contracts, heavy GPC log, more open actions) or long-term (established vehicles, calls/orders, mostly complete files). Auto reads the narrative.")
    parser.add_argument("--ai-plan", action="store_true", help="Use an optional AI scenario-planning/variation pass.")
    parser.add_argument("--ai-qa", action="store_true", help="Write a controller-only AI QA report after generation.")
    parser.add_argument("--ai-provider", choices=AI_PROVIDER_CHOICES, default=default_ai_provider(), help="AI provider for --ai-plan/--ai-qa. Default uses the local Codex CLI, not an API key.")
    parser.add_argument("--ai-model", default="", help="Optional AI model override. For codex-cli, blank uses your local Codex default.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.qc_regression:
        return run_qc_regression(args)
    if args.build_office.strip():
        return run_office_builder(args)
    if args.script.strip():
        return run_exercise_script(args.script.strip(), args.output_root)
    if args.delete_action or args.delete_package.strip() or args.export_trainee.strip() or args.shorten_names.strip() or args.validate.strip():
        return run_maintenance(args)
    if args.count < 1:
        raise SystemExit("--count must be at least 1")
    if args.awardee_count is not None and not 1 <= args.awardee_count <= 8:
        raise SystemExit("--awardee-count must be between 1 and 8.")

    data = load_data()
    rng = random.Random(args.seed)
    scenario_type = normalize_scenario_type(args.type)
    ai_provider = normalize_ai_provider(args.ai_provider)
    scenario_text = args.scenario.strip() or args.prompt.strip()
    archetypes = matching_archetypes(data, scenario_text, scenario_type)
    ai_messages: list[str] = []
    ai_plan_payload: dict[str, Any] | None = None
    if args.ai_plan:
        if scenario_text and args.count == 1:
            ai_plan_payload, ai_message = request_ai_scenario_plan(
                scenario_text,
                scenario_type,
                args.solicitation_style,
                args.ai_model,
                ai_provider,
            )
            ai_messages.append(ai_message)
            if ai_plan_payload:
                archetypes = [apply_ai_plan_to_archetype(archetypes[0], ai_plan_payload, scenario_type, scenario_text)]
        elif args.count != 1:
            ai_messages.append("AI scenario planning skipped for batch generation; use count 1 for AI-shaped actions.")
        else:
            ai_messages.append("AI scenario planning skipped because no scenario prompt was provided.")
    output_root = Path(args.output_root) if args.output_root else package_root() / "Outputs"
    existing_vehicle_registry = load_vehicle_registry(output_root)
    append_mode = bool(args.append_package.strip())
    existing_rows: list[dict[str, Any]] = []
    existing_package_vehicles: list[dict[str, Any]] = []
    existing_parent_references: list[dict[str, Any]] = []
    if append_mode:
        package_dir = resolve_append_package(output_root, args.append_package.strip())
    else:
        office_name = truncate_filename(args.package_name, MAX_PACKAGE_NAME_CHARS, "office") if args.package_name else DEFAULT_OFFICE_NAME
        package_dir = output_root / office_name
        if package_dir.exists():
            append_mode = True
        else:
            package_dir.mkdir(parents=True, exist_ok=False)
    if append_mode:
        existing_rows = load_manifest_rows(package_dir)
        existing_package_vehicles, existing_parent_references = load_package_vehicle_registry(package_dir)

    quantity_override = args.quantity
    if quantity_override is None and scenario_text:
        quantity_override = extract_quantity_from_prompt(scenario_text)
    stage_override = args.stage if args.stage is not None else (args.max_stage if args.count == 1 else None)

    rows: list[dict[str, Any]] = list(existing_rows)
    package_vehicle_records: list[dict[str, Any]] = []
    parent_reference_records: list[dict[str, Any]] = []
    ai_context: list[dict[str, Any]] = []
    inject_messages: list[str] = []
    inject_key_entries: list[dict[str, Any]] = load_inject_key(package_dir) if append_mode else []
    requested_injects = [str(item) for item in (args.inject or [])]
    inject_target_index = rng.randint(1, args.count) if requested_injects and args.count > 1 else 1
    next_index = next_manifest_index(existing_rows)
    for index in range(1, args.count + 1):
        archetype = deepcopy(archetypes[0] if scenario_text and args.count == 1 else rng.choice(archetypes))
        sequence_category = infer_category(archetype, scenario_type)
        sequence_letter = contract_letter_for_category(sequence_category, archetype)
        package_start_after = highest_existing_piid_sequence(rows, package_dir, sequence_letter) if append_mode else 0
        piid_sequence = reserve_piid_sequences(output_root, 1, rng, package_start_after, sequence_letter)[0]
        parent_lookup_category = custom_category_from_prompt(scenario_text, scenario_type) if scenario_text else scenario_type
        package_parent_registry = apply_order_obligation_rollups(
            merge_vehicle_records(existing_package_vehicles, package_vehicle_records),
            merge_parent_reference_records(existing_parent_references, parent_reference_records),
        )
        scenario_solicitation_style = args.solicitation_style
        if scenario_solicitation_style == "auto":
            scenario_solicitation_style = str(archetype.get("_ai_solicitation_style") or "auto")
        scenario = build_scenario(
            next_index + index - 1,
            data,
            archetype,
            rng,
            args.max_stage,
            piid_sequence=piid_sequence,
            stage_override=stage_override,
            quantity_override=quantity_override if args.count == 1 else None,
            scenario_type=scenario_type,
            solicitation_style=scenario_solicitation_style,
            parent_number_override=args.parent_number,
            vehicle_registry=parent_lookup_registry_for_category(
                parent_lookup_category,
                existing_vehicle_registry,
                package_parent_registry,
                args.parent_number,
            ),
            scenario_prompt=scenario_text,
            awardee_count_override=args.awardee_count,
            injects=requested_injects if index == inject_target_index else [],
            inject_messages=inject_messages,
        )
        if is_multiple_award_master(scenario):
            awardee_count = len(master_awardees(scenario))
            letter, base_sequence = piid_parts_from_contract_number(scenario.contract_number)
            additional_sequences = reserve_contiguous_piid_sequences(
                output_root,
                max(0, awardee_count - 1),
                rng,
                base_sequence or scenario.piid_sequence,
                letter or contract_letter_for_category(scenario.category, scenario.archetype),
            )
            assign_master_awardee_contract_numbers(scenario, data, additional_sequences)
            scenario.folder_name = multiple_award_pool_folder_name(scenario)
        action_root = office_files_dir(package_dir) / scenario.folder_name
        if action_root.exists():
            raise SystemExit(f"Refusing to overwrite existing action folder: {action_root}")
        generate_action(action_root, scenario, data)
        prior_record = scenario.archetype.get("_inject_prior_performance_record")
        if isinstance(prior_record, dict):
            prior_dir = write_prior_performance_archive(office_files_dir(package_dir), prior_record, scenario, data)
            for detail in scenario.archetype.get("_inject_details") or []:
                if detail.get("key") == "adverse-past-performance":
                    detail["prior_folder"] = prior_dir.name
        if "expired-parent" in (scenario.archetype.get("_injects") or []) and scenario.parent_vehicle:
            existing_master = Path(str(scenario.parent_vehicle.get("folder_path") or ""))
            if scenario.parent_vehicle.get("folder_path") and existing_master.exists():
                master_award = existing_master / "7. Award"
                master_award.mkdir(parents=True, exist_ok=True)
                write_vehicle_closeout_thread(master_award, scenario.parent_vehicle, data)
            else:
                archive_dir = write_parent_archive_folder(office_files_dir(package_dir), scenario.parent_vehicle, data)
                scenario.parent_vehicle["folder"] = archive_dir.name
                scenario.parent_vehicle["folder_path"] = str(archive_dir)
        ai_context.append(scenario_ai_context(scenario, action_root))
        rows.append(scenario_manifest_row(scenario, action_root))
        vehicle_record = scenario_vehicle_record(scenario, action_root, package_dir)
        if vehicle_record:
            if isinstance(vehicle_record, list):
                package_vehicle_records.extend(vehicle_record)
            else:
                package_vehicle_records.append(vehicle_record)
        inject_parent_record = scenario_inject_parent_record(scenario, package_dir)
        if inject_parent_record:
            package_vehicle_records.append(inject_parent_record)
        phantom_record = scenario.archetype.get("_inject_phantom_master_record")
        if isinstance(phantom_record, dict):
            phantom_record = dict(phantom_record)
            phantom_record["package"] = package_dir.name
            phantom_record["inject"] = True
            package_vehicle_records.append(phantom_record)
        inject_entry = inject_answer_key_entry(scenario, action_root)
        if inject_entry:
            inject_key_entries.append(inject_entry)
        parent_reference = scenario_parent_reference_record(scenario, action_root, package_dir)
        if parent_reference:
            parent_reference_records.append(parent_reference)

    all_package_vehicles = merge_vehicle_records(existing_package_vehicles, package_vehicle_records)
    all_parent_references = merge_parent_reference_records(existing_parent_references, parent_reference_records)
    all_package_vehicles = apply_order_obligation_rollups(all_package_vehicles, all_parent_references)
    write_manifests(package_dir, rows)
    write_package_vehicle_registry(package_dir, all_package_vehicles, all_parent_references)
    write_global_vehicle_registry(output_root, [record for record in all_package_vehicles if not record.get("inject")])
    tracker_path = write_workload_tracker(package_dir, rows, all_package_vehicles, all_parent_references)
    parent_admin_paths = write_parent_order_admin_files(package_dir, all_package_vehicles, all_parent_references)
    write_continuity_binder(package_dir, rows, all_package_vehicles, data)
    ensure_gpc_log(package_dir, data)
    inject_key_path = write_inject_key(package_dir, inject_key_entries)
    if inject_key_path:
        print(f"Inject answer key (controller only): {inject_key_path}")
    for message in dict.fromkeys(inject_messages):
        print(f"Inject: {message}", file=sys.stderr)
    if args.ai_plan or ai_messages:
        plan_path = write_ai_plan_file(package_dir, ai_plan_payload, ai_messages)
        print(f"AI scenario plan: {plan_path}")
    if args.ai_qa:
        qa_path, qa_message = write_ai_qa_report(package_dir, ai_context, args.ai_model, ai_provider)
        ai_messages.append(qa_message)
        print(f"AI QA report: {qa_path}")
    for message in dict.fromkeys(ai_messages):
        print(f"AI assist: {message}", file=sys.stderr)
    verb = "Appended" if append_mode else "Generated"
    print(f"{verb} {args.count} action folder(s): {package_dir}")
    print(f"Controller manifest: {office_controller_dir(package_dir) / '_controller_manifest.csv'}")
    if tracker_path:
        print(f"Workload tracker: {tracker_path}")
    for path in parent_admin_paths:
        print(f"Parent order admin tracker: {path}")
    for warning in path_budget_warnings(output_root, package_dir):
        print(f"PATH BUDGET WARNING: {warning}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
