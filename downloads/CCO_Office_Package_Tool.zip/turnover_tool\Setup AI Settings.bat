@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup AI Settings.ps1"
echo.
pause
endlocal
