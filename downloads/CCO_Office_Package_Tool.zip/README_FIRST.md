# Downloadable Setup Guide

This folder can be distributed as a local, download-and-run version of the CCO Office Package Tool. The core generator does not need AI or an API key. AI assist is optional and only runs when the user checks the AI option in the dashboard or uses `--ai-plan` / `--ai-qa` from the command line.

## For The Person Building The Zip

From this folder, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Build_Distribution.ps1
```

The zip is written to:

```text
dist\CCO_Office_Package_Tool.zip
```

The builder excludes generated offices, private settings, cache files, and prior distribution zips:

- `settings.env`
- `Outputs`
- `__pycache__`
- `dist`
- Python bytecode and log files

## For The User Installing It

1. Download the zip.
2. Extract it somewhere normal, such as `Documents`.
3. Open the `turnover_tool` folder.
4. Run `Install Requirements.bat` once if this computer does not already have the Python dependencies.
5. Run `Start Dashboard.bat`.
6. The dashboard opens at `http://127.0.0.1:8765/` or the next available local port.

Generated offices are saved in an `Outputs` folder next to `turnover_tool`.

## Optional AI Setup

The tool can run without AI. If the user wants AI-assisted scenario variation and QA:

1. Run `Setup AI Settings.bat`.
2. Paste the user's OpenAI API key when prompted.
3. Accept the default model unless you have a specific reason to change it.
4. Restart the dashboard if it was already open.
5. Check `AI QA + variation` when generating an action.

This creates a private local file:

```text
turnover_tool\settings.env
```

Do not email, upload, or redistribute `settings.env`. It contains the user's API key. The distribution builder intentionally leaves it out of the zip.

Important: a ChatGPT web subscription is not the same thing as an OpenAI API key. Users who choose API mode need their own API key and API billing on their own account.

## Manual AI Settings

Instead of running the setup script, users can copy `settings.example.env` to `settings.env` and fill in:

```text
CCO_AI_PROVIDER=api
OPENAI_API_KEY=replace-with-your-api-key
OPENAI_MODEL=gpt-4.1-mini
```

Regular environment variables still work and override `settings.env`.

## Local Codex Mode

On your development machine, the default provider remains `codex-cli`, which uses your logged-in local Codex CLI path for AI assist and strips API-key environment variables from that local Codex subprocess.

For a public download, API mode is the cleaner user-owned option because each user supplies their own key.
