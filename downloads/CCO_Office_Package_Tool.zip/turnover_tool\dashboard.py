#!/usr/bin/env python3
"""
Local dashboard for the CCO turnover package generator.

The dashboard intentionally uses only the Python standard library. It serves a
small browser UI and shells out to generate_turnover.py so generation logic
stays in one place.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import socket
import subprocess
import sys
import time
import webbrowser
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


TOOL_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = TOOL_DIR.parent
GENERATOR = TOOL_DIR / "generate_turnover.py"
OUTPUT_ROOT = PACKAGE_ROOT / "Outputs"
AI_PROVIDER_CHOICES = {"codex-cli", "codex", "local", "api", "auto", "none"}


def load_local_settings() -> None:
    settings_path = TOOL_DIR / "settings.env"
    if not settings_path.exists():
        return
    try:
        lines = settings_path.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def dashboard_ai_provider() -> str:
    provider = os.environ.get("CCO_AI_PROVIDER", "codex-cli").strip().lower().replace("_", "-")
    aliases = {
        "codex": "codex-cli",
        "cli": "codex-cli",
        "openai": "api",
        "openai-api": "api",
        "off": "none",
        "false": "none",
    }
    provider = aliases.get(provider, provider)
    return provider if provider in AI_PROVIDER_CHOICES else "codex-cli"


load_local_settings()
DEFAULT_AI_PROVIDER = dashboard_ai_provider()

SCENARIO_TYPES = [
    ("auto", "Auto"),
    ("supply", "Supply"),
    ("service", "Service"),
    ("construction", "Construction"),
    ("bpa", "BPA master"),
    ("idiq", "IDIQ master"),
    ("bpa-call", "BPA call"),
    ("idiq-order", "IDIQ order"),
]

STAGES = [
    (1, "1. Initial Documents & IGE"),
    (2, "2. Funding Documents"),
    (3, "3. Market Research"),
    (4, "4. Solicitation"),
    (5, "5. Quotes or Proposals"),
    (6, "6. Evaluation"),
    (7, "7. Award"),
    (8, "8. Delivery Confirmation"),
]

SOLICITATION_STYLES = [
    ("auto", "Auto"),
    ("combined", "Combined synopsis/solicitation"),
    ("rfq-email", "RFQ email"),
]

INJECT_OPTIONS = [
    ("expired-parent", "Expired parent vehicle"),
    ("near-ceiling-parent", "Parent near ceiling"),
    ("expired-vehicle", "Expired master vehicle"),
    ("call-limit-breach", "BPA call exceeds call limit"),
    ("out-of-scope-order", "Order outside parent scope"),
    ("wrong-appropriation", "Wrong appropriation"),
    ("funding-shortfall", "Certified funding below award"),
    ("missing-certification", "Missing funds certification"),
    ("unjustified-award", "Award not to lowest acceptable"),
    ("late-quote", "Late quote accepted"),
    ("missing-tech-eval", "Missing technical evaluation"),
    ("entity-mismatch", "Vendor entity mismatch"),
    ("pop-clin-mismatch", "PWS period vs CLIN mismatch"),
    ("unsigned-award", "Unsigned award"),
    ("tracker-mismatch", "Tracker disagrees with file"),
    ("phantom-master", "Registry vehicle missing from drive"),
    ("wrong-piid-letter", "Wrong PIID instrument letter"),
    ("sam-inactive", "Awardee SAM registration inactive"),
    ("adverse-past-performance", "Adverse past performance ignored"),
    ("random", "Random applicable inject"),
]


HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CCO Turnover Generator</title>
  <style>
    :root {
      --bg: #f4f6f8;
      --surface: #ffffff;
      --line: #c8d0d8;
      --text: #16202a;
      --muted: #5f6b76;
      --navy: #17365d;
      --navy-2: #10263f;
      --green: #2f6f4e;
      --amber: #9a5b13;
      --red: #a33a3a;
      --focus: #2c6db2;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: "Segoe UI", Arial, sans-serif;
      font-size: 14px;
      line-height: 1.35;
    }
    header {
      background: var(--navy-2);
      color: #fff;
      border-bottom: 4px solid var(--green);
    }
    .topbar {
      max-width: 1360px;
      margin: 0 auto;
      padding: 14px 22px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
    }
    h1 {
      margin: 0;
      font-size: 18px;
      letter-spacing: 0;
      font-weight: 700;
    }
    .status-line {
      color: #dbe6ee;
      font-size: 12px;
      white-space: nowrap;
    }
    main {
      max-width: 1360px;
      margin: 0 auto;
      padding: 18px 22px 32px;
    }
    .layout {
      display: grid;
      grid-template-columns: minmax(520px, 0.98fr) minmax(380px, 0.72fr);
      gap: 16px;
      align-items: start;
    }
    section {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 8px;
      overflow: hidden;
    }
    section h2 {
      margin: 0;
      padding: 10px 12px;
      background: var(--navy);
      color: #fff;
      font-size: 13px;
      letter-spacing: 0;
      font-weight: 700;
    }
    .section-body { padding: 12px; }
    .grid {
      display: grid;
      grid-template-columns: repeat(12, 1fr);
      gap: 10px;
    }
    label {
      display: block;
      color: var(--muted);
      font-size: 12px;
      font-weight: 650;
      margin-bottom: 4px;
    }
    input, select, textarea {
      width: 100%;
      min-height: 34px;
      border: 1px solid #aeb8c2;
      border-radius: 6px;
      background: #fff;
      color: var(--text);
      padding: 7px 8px;
      font: inherit;
    }
    textarea {
      min-height: 120px;
      resize: vertical;
    }
    input:focus, select:focus, textarea:focus, button:focus {
      outline: 2px solid var(--focus);
      outline-offset: 1px;
    }
    .span-12 { grid-column: span 12; }
    .span-8 { grid-column: span 8; }
    .span-6 { grid-column: span 6; }
    .span-4 { grid-column: span 4; }
    .span-3 { grid-column: span 3; }
    .span-2 { grid-column: span 2; }
    .radio-row {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .radio-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      min-height: 34px;
      border: 1px solid #aeb8c2;
      border-radius: 6px;
      padding: 6px 9px;
      background: #fff;
      color: var(--text);
      font-weight: 600;
      font-size: 12px;
    }
    .radio-pill input {
      width: auto;
      min-height: auto;
      margin: 0;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
      margin-top: 12px;
    }
    button, .link-button {
      min-height: 34px;
      border: 1px solid #8b98a6;
      border-radius: 6px;
      background: #fff;
      color: var(--text);
      padding: 7px 11px;
      font: inherit;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    button.primary {
      background: var(--green);
      color: #fff;
      border-color: var(--green);
    }
    button.secondary {
      background: var(--navy);
      color: #fff;
      border-color: var(--navy);
    }
    button.warn {
      background: #fff8ed;
      color: var(--amber);
      border-color: #d6a261;
    }
    button:disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }
    .notice {
      border: 1px solid #d2b36f;
      background: #fff9ec;
      color: #563b0f;
      border-radius: 6px;
      padding: 8px 10px;
      font-size: 12px;
      margin-top: 10px;
      display: none;
    }
    .notice.show { display: block; }
    .queue-panel {
      margin-top: 12px;
      display: grid;
      gap: 8px;
    }
    .result {
      margin-top: 16px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
      font-size: 12px;
    }
    th {
      background: var(--navy);
      color: #fff;
      text-align: left;
      font-weight: 700;
      padding: 7px 6px;
      border: 1px solid #10263f;
      vertical-align: top;
    }
    td {
      border: 1px solid var(--line);
      padding: 7px 6px;
      vertical-align: top;
      overflow-wrap: anywhere;
    }
    tbody tr:nth-child(even) td { background: #f8fafc; }
    .table-wrap { overflow-x: auto; }
    .muted { color: var(--muted); }
    .path {
      font-family: Consolas, "Courier New", monospace;
      font-size: 12px;
      color: #23313f;
      background: #f2f4f6;
      border: 1px solid #d7dde3;
      padding: 7px 8px;
      border-radius: 6px;
      overflow-wrap: anywhere;
    }
    pre {
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      background: #101820;
      color: #eef5fa;
      border-radius: 6px;
      padding: 10px;
      max-height: 260px;
      overflow-y: auto;
      font-size: 12px;
      margin: 10px 0 0;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      min-height: 22px;
      border-radius: 999px;
      padding: 2px 8px;
      font-size: 12px;
      font-weight: 700;
      background: #e8eef7;
      color: #17365d;
    }
    .badge.good { background: #e7f3ec; color: var(--green); }
    .badge.warn { background: #fff3df; color: var(--amber); }
    .badge.bad { background: #fae8e8; color: var(--red); }
    .hidden { display: none !important; }
    .tight-stack { display: grid; gap: 8px; }
    .footer-row {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      margin-top: 8px;
    }
    @media (max-width: 980px) {
      .layout { grid-template-columns: 1fr; }
      .span-8, .span-6, .span-4, .span-3, .span-2 { grid-column: span 12; }
      .topbar { align-items: flex-start; flex-direction: column; }
      .status-line { white-space: normal; }
    }
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <h1>CCO Turnover Generator</h1>
      <div class="status-line" id="statusLine">Loading...</div>
    </div>
  </header>
  <main>
    <div class="layout">
      <section>
        <h2>Generate Action</h2>
        <div class="section-body">
          <form id="generateForm">
            <div class="grid">
              <div class="span-12">
                <label for="scenario">Scenario Prompt</label>
                <textarea id="scenario" name="scenario" required placeholder="Initial task order for 4 vans for 12 months under the vehicle lease IDIQ"></textarea>
              </div>
              <div class="span-4">
                <label for="type">Action Type</label>
                <select id="type" name="type"></select>
              </div>
              <div class="span-4">
                <label for="stage">Lifecycle Stage</label>
                <select id="stage" name="stage"></select>
              </div>
              <div class="span-4">
                <label for="solicitationStyle">Solicitation</label>
                <select id="solicitationStyle" name="solicitation_style"></select>
              </div>
              <div class="span-4 hidden" id="awardeeCountBox">
                <label for="awardeeCount">Awardees</label>
                <select id="awardeeCount" name="awardee_count">
                  <option value="">Auto</option>
                  <option value="1">Single award</option>
                  <option value="2">2 awardees</option>
                  <option value="3">3 awardees</option>
                  <option value="4">4 awardees</option>
                  <option value="5">5 awardees</option>
                  <option value="6">6 awardees</option>
                  <option value="7">7 awardees</option>
                  <option value="8">8 awardees</option>
                </select>
              </div>
              <div class="span-12">
                <label>AI</label>
                <div class="radio-row">
                  <label class="radio-pill"><input type="checkbox" id="aiAssist" name="ai_assist"> AI QA + variation</label>
                </div>
              </div>
              <div class="span-12">
                <label>Injects <span class="muted" style="font-weight:400">(answer key written to package root, controller only)</span></label>
                <div class="radio-row" id="injectRow"></div>
              </div>
              <div class="span-12">
                <label>Output Mode</label>
                <div class="radio-row">
                  <label class="radio-pill"><input type="radio" name="mode" value="new" checked> Default office</label>
                  <label class="radio-pill"><input type="radio" name="mode" value="append"> Choose office</label>
                </div>
              </div>
              <div class="span-6" id="newPackageBox">
                <label for="packageName">Office Name</label>
                <input id="packageName" name="package_name" placeholder="Leave blank for 'Mock Office Drive' (created or appended)">
              </div>
              <div class="span-6 hidden" id="appendPackageBox">
                <label for="appendPackage">Office</label>
                <select id="appendPackage" name="append_package"></select>
              </div>
              <div class="span-6">
                <label for="parentNumber">Parent BPA / IDIQ</label>
                <input id="parentNumber" name="parent_number" placeholder="FA4867XXD0001">
              </div>
              <div class="span-4">
                <label for="quantity">Quantity</label>
                <input id="quantity" name="quantity" type="number" min="1" step="1" placeholder="Auto">
              </div>
              <div class="span-4">
                <label for="count">Count</label>
                <input id="count" name="count" type="number" min="1" max="50" step="1" value="1">
              </div>
              <div class="span-4">
                <label for="seed">Seed</label>
                <input id="seed" name="seed" type="number" step="1" placeholder="Random">
              </div>
            </div>
            <div class="actions">
              <button class="primary" id="generateBtn" type="submit">Generate</button>
              <button type="button" id="queueBtn">Add to Queue</button>
              <button type="button" id="refreshBtn">Refresh Packages</button>
              <button class="warn" type="button" id="clearResultBtn">Clear Result</button>
            </div>
            <div class="notice" id="notice"></div>
          </form>
          <div class="queue-panel">
            <div class="footer-row">
              <span class="muted" id="queueStatus">No queued actions</span>
              <button type="button" id="clearQueueBtn">Clear Queue</button>
            </div>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style="width: 12%">Status</th>
                    <th style="width: 36%">Scenario</th>
                    <th style="width: 16%">Type</th>
                    <th style="width: 12%">AI</th>
                    <th style="width: 14%">Result</th>
                    <th style="width: 10%">Action</th>
                  </tr>
                </thead>
                <tbody id="queueBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2>Build Entire Office from Scenario</h2>
        <div class="section-body">
          <div class="grid">
            <div class="span-12">
              <label for="builderNarrative">Deployment Scenario (drives the mix of files; never printed in documents)</label>
              <textarea id="builderNarrative" placeholder="The CCO team is deploying to a bare base. Force protection buildup and initial bed-down are underway."></textarea>
            </div>
            <div class="span-6">
              <label for="builderOffice">Office Name</label>
              <input id="builderOffice" placeholder="Leave blank for 'Mock Office Drive'">
            </div>
            <div class="span-2">
              <label for="builderSize">Files</label>
              <input id="builderSize" type="number" min="6" max="50" step="1" value="18">
            </div>
            <div class="span-2">
              <label for="builderDuration">Duration</label>
              <select id="builderDuration">
                <option value="auto">Auto (read scenario)</option>
                <option value="short">Short-term (GPC-heavy)</option>
                <option value="long">Long-term (established)</option>
              </select>
            </div>
            <div class="span-2">
              <label for="builderSeed">Seed</label>
              <input id="builderSeed" type="number" step="1" placeholder="Random">
            </div>
          </div>
          <div class="actions">
            <button class="secondary" type="button" id="buildOfficeBtn">Build Office (no injects)</button>
            <span class="muted">Builds a clean office; add injects afterward with the Generate form set to this office.</span>
          </div>
        </div>
      </section>

      <section>
        <h2>Offices</h2>
        <div class="section-body tight-stack">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 38%">Package</th>
                  <th style="width: 14%">Actions</th>
                  <th style="width: 28%">Updated</th>
                  <th style="width: 20%">Folder</th>
                </tr>
              </thead>
              <tbody id="packagesBody"></tbody>
            </table>
          </div>
          <div class="footer-row">
            <span class="muted" id="packageCount">0 offices</span>
            <div class="actions" style="margin-top:0">
              <button type="button" id="qcBtn">Run QC</button>
              <button type="button" id="openOutputsBtn">Open Outputs</button>
            </div>
          </div>
          <div>
            <label for="managePackage">Manage Contract Files</label>
            <div class="radio-row">
              <select id="managePackage" style="flex:1"></select>
              <button type="button" id="loadActionsBtn">Load</button>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 30%">Contract</th>
                  <th style="width: 36%">Requirement</th>
                  <th style="width: 18%">Stage</th>
                  <th style="width: 16%">Delete</th>
                </tr>
              </thead>
              <tbody id="actionsBody"><tr><td colspan="4" class="muted">Load a package to manage its action folders.</td></tr></tbody>
            </table>
          </div>
        </div>
      </section>
    </div>

    <section class="result" id="resultSection">
      <h2>Result</h2>
      <div class="section-body" id="resultBody">
        <span class="muted">No generation run in this browser session.</span>
      </div>
    </section>
  </main>

  <script>
    const state = { packages: [], outputRoot: "", queue: [], queueRunning: false, nextQueueId: 1 };
    const $ = (id) => document.getElementById(id);

    function option(value, label) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = label;
      return opt;
    }

    async function api(path, options = {}) {
      const res = await fetch(path, {
        headers: { "Content-Type": "application/json" },
        ...options
      });
      const data = await res.json();
      if (!res.ok || data.ok === false) {
        throw new Error(data.error || `Request failed: ${res.status}`);
      }
      return data;
    }

    function setNotice(text, kind = "") {
      const notice = $("notice");
      notice.textContent = text || "";
      notice.className = text ? `notice show ${kind}` : "notice";
    }

    function setBusy(isBusy) {
      $("generateBtn").disabled = isBusy;
      $("generateBtn").textContent = isBusy ? "Generating..." : "Generate";
      const queued = state.queue.filter((item) => item.status === "Queued").length;
      $("statusLine").textContent = isBusy ? `Generation running${queued ? ` (${queued} queued)` : ""}` : `Output root: ${state.outputRoot}`;
    }

    function validatePayload(payload) {
      if (!payload.scenario) return "Scenario prompt is required.";
      if (payload.mode === "append" && !payload.append_package) return "Select an office to append to.";
      return "";
    }

    function selectedMode() {
      return document.querySelector("input[name='mode']:checked").value;
    }

    function syncMode() {
      const append = selectedMode() === "append";
      $("newPackageBox").classList.toggle("hidden", append);
      $("appendPackageBox").classList.toggle("hidden", !append);
      if (append && !state.packages.length) {
        setNotice("No office is available to append to.", "warn");
      } else {
        setNotice("");
      }
    }

    function syncAwardeeCount() {
      const isMaster = ["bpa", "idiq"].includes($("type").value);
      $("awardeeCountBox").classList.toggle("hidden", !isMaster);
      if (!isMaster) $("awardeeCount").value = "";
    }

    function populateSelects(data) {
      $("type").replaceChildren(...data.scenario_types.map(([value, label]) => option(value, label)));
      $("stage").replaceChildren(...data.stages.map(([value, label]) => option(value, label)));
      $("stage").value = "8";
      $("solicitationStyle").replaceChildren(...data.solicitation_styles.map(([value, label]) => option(value, label)));
      syncAwardeeCount();
      const injectRow = $("injectRow");
      injectRow.textContent = "";
      for (const [value, label] of (data.inject_options || [])) {
        const pill = document.createElement("label");
        pill.className = "radio-pill";
        const box = document.createElement("input");
        box.type = "checkbox";
        box.className = "inject-box";
        box.value = value;
        pill.append(box, document.createTextNode(` ${label}`));
        injectRow.appendChild(pill);
      }
    }

    function selectedInjects() {
      return Array.from(document.querySelectorAll(".inject-box:checked")).map((box) => box.value);
    }

    function isPlaceholderRow(row) {
      return Boolean(row.deleted_placeholder) || !row.folder || String(row.title || "").toLowerCase() === "piid not used";
    }

    function renderPackageOptions() {
      const select = $("appendPackage");
      const opts = state.packages.map((pkg) => option(pkg.name, pkg.name));
      select.replaceChildren(...opts);
      const manage = $("managePackage");
      const current = manage.value;
      manage.replaceChildren(...state.packages.map((pkg) => option(pkg.name, pkg.name)));
      if (current && state.packages.some((pkg) => pkg.name === current)) manage.value = current;
    }

    function renderPackages() {
      const body = $("packagesBody");
      body.textContent = "";
      for (const pkg of state.packages.slice(0, 14)) {
        const tr = document.createElement("tr");
        const name = document.createElement("td");
        name.innerHTML = `<strong>${escapeHtml(pkg.name)}</strong><br><span class="muted">${escapeHtml(pkg.last_contract || "")}</span>`;
        const actions = document.createElement("td");
        actions.innerHTML = `<span class="badge">${pkg.action_count}</span>`;
        const updated = document.createElement("td");
        updated.textContent = pkg.modified_display;
        const folder = document.createElement("td");
        const open = document.createElement("button");
        open.type = "button";
        open.textContent = "Open";
        open.addEventListener("click", () => openPath(pkg.path));
        const exp = document.createElement("button");
        exp.type = "button";
        exp.textContent = "Export";
        exp.style.marginLeft = "6px";
        exp.title = "Trainee-ready copy without controller files";
        exp.addEventListener("click", () => exportPackage(pkg.name));
        const val = document.createElement("button");
        val.type = "button";
        val.textContent = "Validate";
        val.style.marginLeft = "6px";
        val.addEventListener("click", () => validatePackage(pkg.name));
        const del = document.createElement("button");
        del.type = "button";
        del.className = "warn";
        del.textContent = "Delete";
        del.style.marginLeft = "6px";
        del.addEventListener("click", () => deletePackage(pkg.name));
        folder.append(open, exp, val, del);
        tr.append(name, actions, updated, folder);
        body.appendChild(tr);
      }
      if (!state.packages.length) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = 4;
        td.className = "muted";
        td.textContent = "No packages found.";
        tr.appendChild(td);
        body.appendChild(tr);
      }
      $("packageCount").textContent = `${state.packages.length} office${state.packages.length === 1 ? "" : "s"}`;
      renderPackageOptions();
    }

    function escapeHtml(value) {
      return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
    }

    async function refreshPackages() {
      const data = await api("/api/packages");
      state.packages = data.packages;
      state.outputRoot = data.output_root;
      $("statusLine").textContent = `Output root: ${state.outputRoot}`;
      renderPackages();
      syncMode();
    }

    function formPayload() {
      const payload = {
        scenario: $("scenario").value.trim(),
        type: $("type").value,
        stage: Number($("stage").value),
        solicitation_style: $("solicitationStyle").value,
        mode: selectedMode(),
        package_name: $("packageName").value.trim(),
        append_package: $("appendPackage").value,
        parent_number: $("parentNumber").value.trim(),
        quantity: $("quantity").value ? Number($("quantity").value) : null,
        awardee_count: ["bpa", "idiq"].includes($("type").value) && $("awardeeCount").value ? Number($("awardeeCount").value) : null,
        count: $("count").value ? Number($("count").value) : 1,
        seed: $("seed").value ? Number($("seed").value) : null,
        ai_assist: $("aiAssist").checked,
        injects: selectedInjects()
      };
      return payload;
    }

    function statusBadge(status) {
      const cls = status === "Complete" ? "good" : status === "Error" ? "bad" : status === "Running" ? "warn" : "";
      return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
    }

    function renderQueue() {
      const body = $("queueBody");
      body.textContent = "";
      for (const item of state.queue) {
        const tr = document.createElement("tr");
        const status = document.createElement("td");
        status.innerHTML = statusBadge(item.status);
        const scenario = document.createElement("td");
        scenario.innerHTML = `<strong>${escapeHtml(item.payload.scenario)}</strong><br><span class="muted">${escapeHtml(item.payload.mode === "append" ? `Append: ${item.payload.append_package}` : item.payload.package_name || "New package")}</span>`;
        const type = document.createElement("td");
        type.textContent = `${item.payload.type || "auto"}${item.payload.awardee_count ? ` / ${item.payload.awardee_count} awardees` : ""}`;
        const ai = document.createElement("td");
        ai.textContent = item.payload.ai_assist ? "On" : "Off";
        const result = document.createElement("td");
        if (item.status === "Complete" && item.data?.package_path) {
          const open = document.createElement("button");
          open.type = "button";
          open.textContent = "Open";
          open.addEventListener("click", () => openPath(item.data.package_path));
          result.appendChild(open);
        } else if (item.status === "Error") {
          result.textContent = item.error || "Error";
        } else {
          result.className = "muted";
          result.textContent = item.status === "Running" ? "Working" : "Waiting";
        }
        const action = document.createElement("td");
        if (item.status === "Queued") {
          const remove = document.createElement("button");
          remove.type = "button";
          remove.className = "warn";
          remove.textContent = "Remove";
          remove.addEventListener("click", () => removeQueuedItem(item.id));
          action.appendChild(remove);
        }
        tr.append(status, scenario, type, ai, result, action);
        body.appendChild(tr);
      }
      if (!state.queue.length) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = 6;
        td.className = "muted";
        td.textContent = "No queued actions.";
        tr.appendChild(td);
        body.appendChild(tr);
      }
      const queued = state.queue.filter((item) => item.status === "Queued").length;
      const running = state.queue.filter((item) => item.status === "Running").length;
      const complete = state.queue.filter((item) => item.status === "Complete").length;
      const errors = state.queue.filter((item) => item.status === "Error").length;
      $("queueStatus").textContent = `${queued} queued, ${running} running, ${complete} complete${errors ? `, ${errors} error${errors === 1 ? "" : "s"}` : ""}`;
      $("clearQueueBtn").disabled = !state.queue.some((item) => item.status !== "Running");
    }

    function removeQueuedItem(id) {
      const item = state.queue.find((candidate) => candidate.id === id);
      if (!item || item.status !== "Queued") {
        setNotice("That queue item already started and cannot be removed.", "warn");
        renderQueue();
        return;
      }
      state.queue = state.queue.filter((candidate) => candidate.id !== id);
      setNotice(`Removed from queue: ${item.payload.scenario}`, "");
      renderQueue();
    }

    function enqueueCurrentForm() {
      const payload = formPayload();
      const problem = validatePayload(payload);
      if (problem) {
        setNotice(problem, "warn");
        return;
      }
      const snapshot = JSON.parse(JSON.stringify(payload));
      state.queue.push({
        id: state.nextQueueId++,
        payload: snapshot,
        status: "Queued",
        data: null,
        error: ""
      });
      $("scenario").value = "";
      setNotice(`Queued: ${snapshot.scenario}`, "");
      renderQueue();
      processQueue();
    }

    async function processQueue() {
      if (state.queueRunning) return;
      const item = state.queue.find((candidate) => candidate.status === "Queued");
      if (!item) {
        renderQueue();
        return;
      }
      state.queueRunning = true;
      item.status = "Running";
      item.error = "";
      setBusy(true);
      renderQueue();
      try {
        const data = await api("/api/generate", {
          method: "POST",
          body: JSON.stringify(item.payload)
        });
        item.status = "Complete";
        item.data = data;
        renderResult(data);
        await refreshPackages();
      } catch (err) {
        item.status = "Error";
        item.error = err.message;
        $("resultBody").innerHTML = `<span class="badge bad">Queue Error</span><pre>${escapeHtml(err.message)}</pre>`;
      } finally {
        state.queueRunning = false;
        setBusy(false);
        renderQueue();
        if (state.queue.some((candidate) => candidate.status === "Queued")) {
          setTimeout(processQueue, 250);
        }
      }
    }

    function renderResult(data) {
      const body = $("resultBody");
      const packagePath = data.package_path || "";
      const rows = data.manifest_rows || [];
      const links = [];
      if (packagePath) {
        links.push(`<button type="button" onclick="openPath('${escapeJs(packagePath)}')">Open Package</button>`);
      }
      if (data.tracker_path) {
        links.push(`<button type="button" onclick="openPath('${escapeJs(data.tracker_path)}')">Open Tracker</button>`);
      }
      const manifestRows = rows.map((row) => `
        <tr>
          <td>${escapeHtml(row.contract_number || "")}</td>
          <td>${escapeHtml(row.title || "")}</td>
          <td>${escapeHtml(row.category || "")}</td>
          <td>${escapeHtml(row.stage_name || row.stage || "")}</td>
          <td>${escapeHtml(row.contractor || "")}</td>
          <td>${escapeHtml(row.parent_contract_number || "")}</td>
        </tr>
      `).join("");
      body.innerHTML = `
        <div class="tight-stack">
          <div><span class="badge good">Complete</span></div>
          ${packagePath ? `<div class="path">${escapeHtml(packagePath)}</div>` : ""}
          <div class="actions">${links.join("")}</div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style="width: 16%">Contract</th>
                  <th style="width: 26%">Requirement</th>
                  <th style="width: 12%">Type</th>
                  <th style="width: 16%">Stage</th>
                  <th style="width: 18%">Contractor</th>
                  <th style="width: 12%">Parent</th>
                </tr>
              </thead>
              <tbody>${manifestRows || '<tr><td colspan="6" class="muted">No manifest rows found.</td></tr>'}</tbody>
            </table>
          </div>
          <pre>${escapeHtml((data.stdout || "").trim() || "Generation completed.")}${data.stderr ? "\n\n" + escapeHtml(data.stderr.trim()) : ""}</pre>
        </div>
      `;
    }

    function escapeJs(value) {
      return String(value).replaceAll("\\", "\\\\").replaceAll("'", "\\'");
    }

    async function openPath(path) {
      await api("/api/open-path", {
        method: "POST",
        body: JSON.stringify({ path })
      });
    }

    function firstOutputPath(output, prefix) {
      for (const line of String(output || "").split(/\r?\n/)) {
        if (line.startsWith(prefix)) return line.slice(prefix.length).trim();
      }
      return "";
    }

    async function submitGenerate(event) {
      event.preventDefault();
      const payload = formPayload();
      const problem = validatePayload(payload);
      if (problem) {
        setNotice(problem, "warn");
        return;
      }
      setNotice("");
      setBusy(true);
      try {
        const data = await api("/api/generate", {
          method: "POST",
          body: JSON.stringify(payload)
        });
        renderResult(data);
        await refreshPackages();
      } catch (err) {
        $("resultBody").innerHTML = `<span class="badge bad">Error</span><pre>${escapeHtml(err.message)}</pre>`;
      } finally {
        setBusy(false);
      }
    }

    async function buildOffice() {
      const narrative = $("builderNarrative").value.trim();
      if (!narrative) {
        setNotice("Describe the deployment scenario first.", "warn");
        return;
      }
      if (!window.confirm("Build a complete office now? This generates many files and can take several minutes.")) return;
      setBusy(true);
      try {
        const data = await api("/api/build-office", {
          method: "POST",
          body: JSON.stringify({
            narrative,
            office: $("builderOffice").value.trim(),
            size: $("builderSize").value ? Number($("builderSize").value) : 18,
            duration: $("builderDuration").value,
            seed: $("builderSeed").value ? Number($("builderSeed").value) : null
          })
        });
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge good">Office Built</span><pre>${escapeHtml((data.stdout || "").trim())}</pre></div>`;
        await refreshPackages();
      } catch (err) {
        $("resultBody").innerHTML = `<span class="badge bad">Error</span><pre>${escapeHtml(err.message)}</pre>`;
      } finally {
        setBusy(false);
      }
    }

    async function exportPackage(name) {
      setBusy(true);
      try {
        const data = await api("/api/export", { method: "POST", body: JSON.stringify({ package: name }) });
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge good">Exported</span><pre>${escapeHtml((data.stdout || "").trim())}</pre></div>`;
      } catch (err) {
        setNotice(err.message, "warn");
      } finally {
        setBusy(false);
      }
    }

    async function validatePackage(name) {
      setBusy(true);
      try {
        const data = await api("/api/validate", { method: "POST", body: JSON.stringify({ package: name }) });
        const combined = ((data.stdout || "") + "\n" + (data.stderr || "")).trim();
        const clean = (data.stdout || "").includes("clean");
        const reportPath = firstOutputPath(combined, "Validation report:");
        const links = reportPath ? `<div class="actions"><button type="button" onclick="openPath('${escapeJs(reportPath)}')">Open Validation Report</button></div>` : "";
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge ${clean ? "good" : "bad"}">${clean ? "Validation Clean" : "Validation Problems"}</span>${links}<pre>${escapeHtml(combined)}</pre></div>`;
      } catch (err) {
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge bad">Validation Problems</span><pre>${escapeHtml(err.message)}</pre></div>`;
      } finally {
        setBusy(false);
      }
    }

    async function runQcRegression() {
      if (!window.confirm("Run the built-in QC regression now? This generates temporary QC offices under Outputs/_qc.")) return;
      setBusy(true);
      try {
        const data = await api("/api/qc-regression", { method: "POST", body: "{}" });
        const output = ((data.stdout || "") + "\n" + (data.stderr || "")).trim();
        const qcRoot = data.qc_root || firstOutputPath(output, "QC_ROOT=");
        const links = qcRoot ? `<div class="actions"><button type="button" onclick="openPath('${escapeJs(qcRoot)}')">Open QC Root</button></div>` : "";
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge good">QC Passed</span>${links}<pre>${escapeHtml(output)}</pre></div>`;
        await refreshPackages();
      } catch (err) {
        $("resultBody").innerHTML = `<div class="tight-stack"><span class="badge bad">QC Failed</span><pre>${escapeHtml(err.message)}</pre></div>`;
      } finally {
        setBusy(false);
      }
    }

    async function deletePackage(name) {
      if (!window.confirm(`Permanently delete office "${name}" and all of its contract files?`)) return;
      setBusy(true);
      try {
        await api("/api/delete", { method: "POST", body: JSON.stringify({ package: name }) });
        setNotice(`Deleted office: ${name}`, "");
        $("actionsBody").innerHTML = '<tr><td colspan="4" class="muted">Load a package to manage its action folders.</td></tr>';
        await refreshPackages();
      } catch (err) {
        setNotice(err.message, "warn");
      } finally {
        setBusy(false);
      }
    }

    async function deleteAction(pkgName, folderName) {
      if (!window.confirm(`Permanently delete "${folderName}" from "${pkgName}"? The office tracker, manifest, and registry will be rebuilt.`)) return;
      setBusy(true);
      try {
        await api("/api/delete", { method: "POST", body: JSON.stringify({ package: pkgName, action: folderName }) });
        setNotice(`Deleted action: ${folderName}`, "");
        await refreshPackages();
        await loadPackageActions();
      } catch (err) {
        setNotice(err.message, "warn");
      } finally {
        setBusy(false);
      }
    }

    async function loadPackageActions() {
      const pkgName = $("managePackage").value;
      const body = $("actionsBody");
      if (!pkgName) {
        body.innerHTML = '<tr><td colspan="4" class="muted">No package selected.</td></tr>';
        return;
      }
      try {
        const data = await api(`/api/package?name=${encodeURIComponent(pkgName)}`);
        const rows = data.manifest_rows || [];
        body.textContent = "";
        for (const row of rows) {
          const placeholder = isPlaceholderRow(row);
          const tr = document.createElement("tr");
          const contract = document.createElement("td");
          if (row.awardee_contract_numbers) {
            contract.innerHTML = `<strong>Award pool</strong><br><span class="muted">${escapeHtml(row.awardee_contract_numbers)}</span>`;
          } else {
            contract.textContent = row.contract_number || row.folder || "";
          }
          const title = document.createElement("td");
          title.textContent = placeholder ? "PIID not used" : row.title || "";
          const stage = document.createElement("td");
          stage.textContent = placeholder ? "" : row.stage_name || row.stage || "";
          const del = document.createElement("td");
          if (placeholder) {
            const marker = document.createElement("span");
            marker.className = "badge";
            marker.textContent = "Placeholder";
            del.appendChild(marker);
          } else {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "warn";
            btn.textContent = "Delete";
            btn.addEventListener("click", () => deleteAction(pkgName, row.folder));
            del.appendChild(btn);
          }
          tr.append(contract, title, stage, del);
          body.appendChild(tr);
        }
        if (!rows.length) {
          body.innerHTML = '<tr><td colspan="4" class="muted">No actions in this package.</td></tr>';
        }
      } catch (err) {
        body.innerHTML = `<tr><td colspan="4" class="muted">${escapeHtml(err.message)}</td></tr>`;
      }
    }

    async function init() {
      const stateData = await api("/api/state");
      populateSelects(stateData);
      await refreshPackages();
      renderQueue();
      $("generateForm").addEventListener("submit", submitGenerate);
      $("type").addEventListener("change", syncAwardeeCount);
      $("queueBtn").addEventListener("click", enqueueCurrentForm);
      $("refreshBtn").addEventListener("click", refreshPackages);
      $("clearResultBtn").addEventListener("click", () => {
        $("resultBody").innerHTML = '<span class="muted">No generation run in this browser session.</span>';
      });
      $("clearQueueBtn").addEventListener("click", () => {
        state.queue = state.queue.filter((item) => item.status === "Running");
        renderQueue();
      });
      $("openOutputsBtn").addEventListener("click", () => openPath(state.outputRoot));
      $("qcBtn").addEventListener("click", runQcRegression);
      $("loadActionsBtn").addEventListener("click", loadPackageActions);
      $("managePackage").addEventListener("change", loadPackageActions);
      $("buildOfficeBtn").addEventListener("click", buildOffice);
      for (const radio of document.querySelectorAll("input[name='mode']")) {
        radio.addEventListener("change", syncMode);
      }
      syncMode();
    }

    init().catch((err) => {
      $("statusLine").textContent = "Dashboard error";
      $("resultBody").innerHTML = `<span class="badge bad">Error</span><pre>${escapeHtml(err.message)}</pre>`;
    });
  </script>
</body>
</html>
"""


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback


def modified_display(path: Path) -> str:
    try:
        stamp = datetime.fromtimestamp(path.stat().st_mtime)
    except OSError:
        return ""
    return stamp.strftime("%Y-%m-%d %H:%M")


def package_manifest_path(path: Path) -> Path:
    controller = path / "_controller" / "_controller_manifest.json"
    if controller.exists():
        return controller
    return path / "_controller_manifest.json"


def package_summary(path: Path) -> dict[str, Any]:
    manifest = read_json(package_manifest_path(path), [])
    rows = manifest if isinstance(manifest, list) else []
    action_rows = [row for row in rows if isinstance(row, dict) and not row.get("deleted_placeholder")]
    last_contract = ""
    if action_rows:
        last = action_rows[-1]
        last_contract = str(last.get("awardee_contract_numbers") or last.get("contract_number") or last.get("folder") or "")
    elif rows:
        last = rows[-1] if isinstance(rows[-1], dict) else {}
        last_contract = str(last.get("awardee_contract_numbers") or last.get("contract_number") or last.get("folder") or "")
    return {
        "name": path.name,
        "path": str(path),
        "file_url": path.resolve().as_uri(),
        "modified": path.stat().st_mtime if path.exists() else 0,
        "modified_display": modified_display(path),
        "action_count": len(action_rows),
        "last_contract": last_contract,
    }


def list_packages() -> list[dict[str, Any]]:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    packages: list[dict[str, Any]] = []
    for child in OUTPUT_ROOT.iterdir():
        if child.is_dir() and not child.name.startswith((".", "_")) and package_manifest_path(child).exists():
            packages.append(package_summary(child))
    packages.sort(key=lambda item: item["modified"], reverse=True)
    return packages


def response_manifest(package_path: Path) -> list[dict[str, Any]]:
    payload = read_json(package_manifest_path(package_path), [])
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    return []


def parse_generated_package(stdout: str) -> Path | None:
    for line in stdout.splitlines():
        if " action folder(s): " in line:
            return Path(line.split(" action folder(s): ", 1)[1].strip())
    return None


def parse_tracker_path(stdout: str) -> Path | None:
    for line in stdout.splitlines():
        if line.startswith("Workload tracker:"):
            return Path(line.split(":", 1)[1].strip())
    return None


def parse_output_value(stdout: str, prefix: str) -> str:
    for line in stdout.splitlines():
        if line.startswith(prefix):
            return line[len(prefix):].strip()
    return ""


def cleaned_text(value: Any, limit: int = 500) -> str:
    text = str(value or "").strip()
    return text[:limit]


def cleaned_int(value: Any, default: int | None = None, minimum: int = 1, maximum: int = 9999) -> int | None:
    if value in (None, ""):
        return default
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, number))


def build_generate_command(payload: dict[str, Any]) -> list[str]:
    scenario = cleaned_text(payload.get("scenario"), 2000)
    if not scenario:
        raise ValueError("Scenario prompt is required.")

    cmd = [sys.executable, str(GENERATOR), "--scenario", scenario]

    count = cleaned_int(payload.get("count"), default=1, minimum=1, maximum=50) or 1
    if count != 1:
        cmd += ["--count", str(count)]

    scenario_type = cleaned_text(payload.get("type"), 40) or "auto"
    if scenario_type != "auto":
        cmd += ["--type", scenario_type]

    solicitation_style = cleaned_text(payload.get("solicitation_style"), 40) or "auto"
    if solicitation_style != "auto":
        cmd += ["--solicitation-style", solicitation_style]

    stage = cleaned_int(payload.get("stage"), default=8, minimum=1, maximum=8)
    max_stage = cleaned_int(payload.get("max_stage"), default=8, minimum=1, maximum=8)
    if stage:
        cmd += ["--stage", str(stage)]
    elif max_stage:
        cmd += ["--max-stage", str(max_stage)]

    quantity = cleaned_int(payload.get("quantity"), default=None, minimum=1, maximum=9999)
    if quantity:
        cmd += ["--quantity", str(quantity)]

    awardee_count = cleaned_int(payload.get("awardee_count"), default=None, minimum=1, maximum=8)
    if awardee_count and scenario_type in {"bpa", "idiq"}:
        cmd += ["--awardee-count", str(awardee_count)]

    seed = cleaned_int(payload.get("seed"), default=None, minimum=0, maximum=999999999)
    if seed is not None:
        cmd += ["--seed", str(seed)]

    if bool(payload.get("ai_assist")):
        cmd += ["--ai-plan", "--ai-qa", "--ai-provider", DEFAULT_AI_PROVIDER]

    parent_number = cleaned_text(payload.get("parent_number"), 40)
    if parent_number:
        cmd += ["--parent-number", parent_number]

    injects = payload.get("injects")
    if isinstance(injects, list):
        valid_keys = {key for key, _ in INJECT_OPTIONS}
        for inject in injects:
            inject_key = cleaned_text(inject, 40)
            if inject_key in valid_keys:
                cmd += ["--inject", inject_key]

    mode = cleaned_text(payload.get("mode"), 20) or "new"
    if mode == "append":
        append_package = cleaned_text(payload.get("append_package"), 240)
        if not append_package:
            raise ValueError("Append package is required.")
        cmd += ["--append-package", append_package]
    else:
        package_name = cleaned_text(payload.get("package_name"), 160)
        if package_name:
            cmd += ["--package-name", package_name]

    return cmd


def build_delete_command(payload: dict[str, Any]) -> list[str]:
    package = cleaned_text(payload.get("package"), 240)
    if not package:
        raise ValueError("Package name is required.")
    action = cleaned_text(payload.get("action"), 300)
    cmd = [sys.executable, str(GENERATOR)]
    if action:
        cmd += ["--delete-action", f"{package}/{action}"]
    else:
        cmd += ["--delete-package", package]
    return cmd


def run_office_command(extra_args: list[str]) -> dict[str, Any]:
    cmd = [sys.executable, str(GENERATOR)] + extra_args
    proc = subprocess.run(cmd, cwd=str(PACKAGE_ROOT), capture_output=True, text=True, timeout=300)
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""
    if proc.returncode not in (0, 2):
        raise RuntimeError((stderr or stdout or f"Command failed with exit code {proc.returncode}").strip())
    return {"ok": True, "command": " ".join(cmd), "stdout": stdout, "stderr": stderr, "exit_code": proc.returncode}


def run_qc_regression_command() -> dict[str, Any]:
    qc_root = OUTPUT_ROOT / "_qc"
    qc_root.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(GENERATOR), "--qc-regression", "--output-root", str(qc_root)]
    proc = subprocess.run(cmd, cwd=str(PACKAGE_ROOT), capture_output=True, text=True, timeout=1200)
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""
    if proc.returncode != 0:
        raise RuntimeError((stderr or stdout or f"QC failed with exit code {proc.returncode}").strip())
    return {
        "ok": True,
        "command": " ".join(cmd),
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": proc.returncode,
        "qc_root": parse_output_value(stdout, "QC_ROOT=") or str(qc_root),
    }


def run_delete(payload: dict[str, Any]) -> dict[str, Any]:
    cmd = build_delete_command(payload)
    proc = subprocess.run(cmd, cwd=str(PACKAGE_ROOT), capture_output=True, text=True, timeout=300)
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""
    if proc.returncode != 0:
        raise RuntimeError((stderr or stdout or f"Delete failed with exit code {proc.returncode}").strip())
    return {"ok": True, "command": " ".join(cmd), "stdout": stdout, "stderr": stderr}


def run_generation(payload: dict[str, Any]) -> dict[str, Any]:
    cmd = build_generate_command(payload)
    started = time.time()
    proc = subprocess.run(
        cmd,
        cwd=str(PACKAGE_ROOT),
        capture_output=True,
        text=True,
        timeout=900,
    )
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""
    if proc.returncode != 0:
        raise RuntimeError((stderr or stdout or f"Generator failed with exit code {proc.returncode}").strip())

    package_path = parse_generated_package(stdout)
    tracker_path = parse_tracker_path(stdout)
    manifest_rows: list[dict[str, Any]] = []
    if package_path and package_path.exists():
        manifest_rows = response_manifest(package_path)
    return {
        "ok": True,
        "command": " ".join(cmd),
        "stdout": stdout,
        "stderr": stderr,
        "duration_seconds": round(time.time() - started, 2),
        "package_path": str(package_path) if package_path else "",
        "tracker_path": str(tracker_path) if tracker_path else "",
        "manifest_rows": manifest_rows,
    }


def is_safe_open_path(path: Path) -> bool:
    try:
        resolved = path.resolve()
        roots = [OUTPUT_ROOT.resolve(), TOOL_DIR.resolve(), PACKAGE_ROOT.resolve()]
    except OSError:
        return False
    return any(resolved == root or root in resolved.parents for root in roots)


def open_local_path(path_value: str) -> None:
    path = Path(path_value)
    if not path.exists():
        raise ValueError("Path does not exist.")
    if not is_safe_open_path(path):
        raise ValueError("Path is outside the dashboard workspace.")
    if os.name == "nt":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


class DashboardHandler(BaseHTTPRequestHandler):
    server_version = "CCOTurnoverDashboard/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))
        sys.stdout.flush()

    def send_bytes(self, body: bytes, content_type: str, status: HTTPStatus = HTTPStatus.OK) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, payload: dict[str, Any], status: HTTPStatus = HTTPStatus.OK) -> None:
        self.send_bytes(json.dumps(payload, indent=2).encode("utf-8"), "application/json; charset=utf-8", status)

    def read_json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError("Invalid JSON body.") from exc
        if not isinstance(payload, dict):
            raise ValueError("JSON body must be an object.")
        return payload

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/favicon.ico":
            self.send_bytes(b"", "image/x-icon")
            return
        if parsed.path == "/":
            self.send_bytes(HTML.encode("utf-8"), "text/html; charset=utf-8")
            return
        if parsed.path == "/health":
            self.send_json({"ok": True})
            return
        if parsed.path == "/api/state":
            self.send_json(
                {
                    "ok": True,
                    "output_root": str(OUTPUT_ROOT),
                    "scenario_types": SCENARIO_TYPES,
                    "stages": STAGES,
                    "solicitation_styles": SOLICITATION_STYLES,
                    "inject_options": INJECT_OPTIONS,
                }
            )
            return
        if parsed.path == "/api/packages":
            self.send_json({"ok": True, "output_root": str(OUTPUT_ROOT), "packages": list_packages()})
            return
        if parsed.path == "/api/package":
            query = parse_qs(parsed.query)
            name = query.get("name", [""])[0]
            package_path = OUTPUT_ROOT / name
            if not package_path.exists() or not package_path.is_dir():
                self.send_json({"ok": False, "error": "Package not found."}, HTTPStatus.NOT_FOUND)
                return
            self.send_json({"ok": True, "package": package_summary(package_path), "manifest_rows": response_manifest(package_path)})
            return
        self.send_json({"ok": False, "error": "Not found."}, HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        try:
            payload = self.read_json_body()
            parsed = urlparse(self.path)
            if parsed.path == "/api/generate":
                self.send_json(run_generation(payload))
                return
            if parsed.path == "/api/delete":
                self.send_json(run_delete(payload))
                return
            if parsed.path == "/api/qc-regression":
                self.send_json(run_qc_regression_command())
                return
            if parsed.path == "/api/build-office":
                narrative = cleaned_text(payload.get("narrative"), 2000)
                if not narrative:
                    raise ValueError("Scenario narrative is required.")
                extra = ["--build-office", narrative]
                size = cleaned_int(payload.get("size"), default=18, minimum=6, maximum=50)
                extra += ["--office-size", str(size)]
                duration = cleaned_text(payload.get("duration"), 10) or "auto"
                if duration in ("short", "long"):
                    extra += ["--office-duration", duration]
                office = cleaned_text(payload.get("office"), 160)
                if office:
                    extra += ["--package-name", office]
                seed = cleaned_int(payload.get("seed"), default=None, minimum=0, maximum=999999999)
                if seed is not None:
                    extra += ["--seed", str(seed)]
                cmd = [sys.executable, str(GENERATOR)] + extra
                proc = subprocess.run(cmd, cwd=str(PACKAGE_ROOT), capture_output=True, text=True, timeout=3600)
                if proc.returncode != 0:
                    raise RuntimeError((proc.stderr or proc.stdout or "Office build failed").strip())
                self.send_json({"ok": True, "command": " ".join(cmd), "stdout": proc.stdout or "", "stderr": proc.stderr or ""})
                return
            if parsed.path == "/api/export":
                package = cleaned_text(payload.get("package"), 240)
                if not package:
                    raise ValueError("Package name is required.")
                self.send_json(run_office_command(["--export-trainee", package]))
                return
            if parsed.path == "/api/validate":
                package = cleaned_text(payload.get("package"), 240)
                if not package:
                    raise ValueError("Package name is required.")
                self.send_json(run_office_command(["--validate", package]))
                return
            if parsed.path == "/api/open-path":
                open_local_path(cleaned_text(payload.get("path"), 1000))
                self.send_json({"ok": True})
                return
            self.send_json({"ok": False, "error": "Not found."}, HTTPStatus.NOT_FOUND)
        except subprocess.TimeoutExpired:
            self.send_json({"ok": False, "error": "Generation timed out."}, HTTPStatus.REQUEST_TIMEOUT)
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, HTTPStatus.BAD_REQUEST)


def port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.2)
        return sock.connect_ex((host, port)) != 0


def choose_port(host: str, requested: int) -> int:
    if requested == 0:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, 0))
            return int(sock.getsockname()[1])
    for port in range(requested, requested + 50):
        if port_available(host, port):
            return port
    raise SystemExit(f"No available dashboard port from {requested} to {requested + 49}.")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the local CCO turnover dashboard.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if not GENERATOR.exists():
        raise SystemExit(f"Generator not found: {GENERATOR}")
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    port = choose_port(args.host, args.port)
    server = ThreadingHTTPServer((args.host, port), DashboardHandler)
    url = f"http://{args.host}:{port}/"
    print(f"CCO Turnover Dashboard: {url}", flush=True)
    print(f"Output root: {OUTPUT_ROOT}", flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Dashboard stopped.", flush=True)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
