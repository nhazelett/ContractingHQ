@echo off
setlocal
cd /d "%~dp0"

set "BUNDLED_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%BUNDLED_PY%" (
  set "PY=%BUNDLED_PY%"
) else (
  set "PY=python"
)

"%PY%" -m pip install --upgrade pip
if errorlevel 1 goto fail

"%PY%" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto fail

echo.
echo Requirements installed. You can run Start Dashboard.bat now.
pause
exit /b 0

:fail
echo.
echo Install failed. Confirm Python 3 is installed and available from the command line.
pause
exit /b 1
