# Inject Backlog

Candidate injects for the turnover tool, grouped by mechanism. Status: ideas only — nothing here is implemented unless marked. Feasibility reflects how much of the generator already supports it (Cheap = field/data mutation, Medium = conditional document content, Larger = new document type).

## Date-safety patterns

The kit must stay year-vague (20XX / FYXX). Three patterns survive yearly reuse:

1. **Relative year tokens** — `20XW` = last year, `20XV` = two years ago. Already implemented for `expired-vehicle` / `expired-parent`.
2. **Intra-year ordering** — all dates in a file share 20XX, so sequence violations never go stale: late quote, delivery before award, performance before funding certification.
3. **Month-anchored fiscal logic** — the generator controls months. September award + 12-month severable service + annual O&M = bona fide needs problem with no real dates. FYXX/FY-crossing language works the same way.
4. **Status words instead of dates** — "SAM registration inactive", "expired", "lapsed" in screening docs and trackers.

## Implemented

All injects carry a difficulty tier (obvious / moderate / subtle) in the answer key.

- `expired-parent` — call/order against a parent BPA/IDIQ that ended last FY. Evidence: tracker Vehicles sheet, registry.
- `near-ceiling-parent` — parent obligations leave less headroom than the order value. Evidence: tracker ceiling vs obligated.
- `expired-vehicle` — master file generated entirely as a prior-year (20XV/20XW) record.
- `call-limit-breach` — call exceeds the parent's per-call limit (Vehicles sheet Call Limit column).
- `out-of-scope-order` — parent scope plainly does not cover the order; MRR claims alignment anyway.
- `phantom-master` — registry/tracker lists an Active vehicle with no folder on the drive.
- `wrong-appropriation` — Form 9 cites the wrong appropriation for the requirement type.
- `funding-shortfall` — Form 9 certifies less than award; CLIN lines don't sum to its grand total.
- `missing-certification` — Form 9 certifying official block blank.
- `unjustified-award` — cheaper acceptable quote passed over with no documented discriminator.
- `late-quote` — awardee's quote received after the deadline (Quote Receipt log Received column).
- `missing-tech-eval` — awarded file with no tech eval; decision document cites unsourced findings.
- `entity-mismatch` — award face page vendor code transposed vs the MRR's UEI.
- `pop-clin-mismatch` — PWS 12-month period vs CLIN priced 6 MO.
- `unsigned-award` — CO signature block blank on the award face page.
- `tracker-mismatch` — tracker claims a stage the folder does not contain.
- `wrong-piid-letter` — PIID instrument letter doesn't match the action type.
- `sam-inactive` — responsibility screening (now present on every evaluated file) shows the awardee's registration lapsed; award proceeded anyway.
- `adverse-past-performance` — archived prior action documents the awardee's delivery failures + CO memo; this file's PP evaluation claims "no adverse information."

## Funding injects

| Idea | What the CCO should catch | Feasibility |
|---|---|---|
| Wrong appropriation | O&M (3400) cited for an investment-threshold supply buy, or 3080 cited for services. Form 9 LOA vs requirement type. | Cheap — funding profile swap |
| Award exceeds certified funding | Form 9 certifies less than award amount; no updated cert in file. | Cheap — amount delta |
| Missing certification signature | Certifying official block blank/unsigned on Form 9. | Cheap — blank a field |
| Funded BPA master | Master file contains a funded Form 9 for the full ceiling, contradicting its own terms page. | Medium |
| Duplicate PR number | Same Form 9 number cited on two actions in the package. | Medium — cross-action coordination |
| FY-crossing severable service | September award, 12-month severable service, annual O&M, no FY language. Month-anchored, date-safe. | Medium — pin timeline month |

## Competition / evaluation injects

| Idea | What the CCO should catch | Feasibility |
|---|---|---|
| Unjustified award selection | Abstract shows a cheaper technically-acceptable quote; decision doc gives no best-value rationale for passing it. | Cheap — reorder winner logic |
| CLIN math error | Unit price x quantity does not equal extended total on IGE/abstract/award. | Cheap — perturb one cell |
| Abstract vs award mismatch | Quote abstract total differs from awarded amount. | Cheap |
| Late quote accepted | Winning quote email timestamp after quotes-due deadline; no CO note. Intra-year, date-safe. | Cheap — timestamp shift |
| Factor bait-and-switch | Decision document evaluates factors the solicitation never announced (or drops an announced one). | Medium |
| Acceptable despite gap | Winner missing a required technical consideration but rated Acceptable; tech eval response contradicts quote content. | Medium — quote flaw machinery exists |
| Missing tech eval | Awarded file with no technical evaluation in folder 6. | Cheap — suppress doc |
| Single quote, no price analysis | One response, file claims adequate competition, no price-reasonableness documentation. | Medium |

## Vendor / responsibility injects

| Idea | What the CCO should catch | Feasibility |
|---|---|---|
| SAM inactive | Screening memo or award block shows registration inactive/lapsed (status words, no dates). | Medium — small screening doc |
| Exclusion hit ignored | Responsibility screening shows a potential exclusion-list match; no resolution documented before award. | Medium |
| Entity mismatch | Quote from one entity, award to near-identical name or different vendor code (CAGE/UEI confusion). | Cheap — vendor field swap |
| Adverse past performance trail | Prior action's delivery email shows discrepancies/complaints with same vendor; PP evaluation says "no adverse information." | Medium-Larger — cross-action evidence, highest training value |

## Scope / structure injects

| Idea | What the CCO should catch | Feasibility |
|---|---|---|
| Call exceeds call limit | BPA terms page states a per-call limit; the call exceeds it. | Cheap — terms vs amount |
| Out-of-scope order | Call/order requirement does not match parent vehicle scope (janitorial call on vehicle-lease IDIQ). | Cheap — scope mismatch |
| Misclassified construction | Real-property repair bought as supply: wrong PIID letter, no construction clauses/SOW. | Medium |
| Option without clause | Service file references option period; 52.217-9 absent from clause table. | Cheap — clause row suppression |
| PWS/CLIN mismatch | PWS says 12-month base period; CLIN priced for 6 MO. | Cheap |
| Delivery quantity mismatch | Receipt confirms different quantity than awarded; no mod in file. | Cheap |
| Performance before award | Email traffic shows customer directed vendor to start before award (unauthorized commitment setup); delivery precedes award date. Intra-year, date-safe. | Medium |

## Turnover-specific injects

| Idea | What the CCO should catch | Feasibility |
|---|---|---|
| Tracker/file disagreement | Tracker says Awarded; action folder stops at Evaluation (or vice versa). | Cheap — tracker row override |
| Phantom master | Registry/tracker lists an active BPA whose master folder is not on the drive. | Cheap — registry-only record |
| Stale open action | Open action whose quotes-due passed months ago; no award, no extension traffic. Month-based, date-safe. | Cheap — month pinning |
| Unsigned award | CO signature block missing //SIGNED// on the award. | Cheap |
| Wrong PIID letter | Instrument letter does not match action type (e.g., F on a standalone purchase). | Cheap |

## Design rules (carry into every new inject)

- Trainee-facing documents never announce the inject; evidence must be discoverable, not labeled.
- Every inject writes to the controller answer key (`_inject_key.json` / `.md`) with expected find, evidence locations, and planted values.
- One inject = one declarative key in `INJECT_DEFINITIONS`, mutation applied after the normal record builds.
- Injects must never collide with benign extras or look identical to intentional "noise" imperfections.
- Inject-mutated records stay package-level; never written to the global vehicle registry.
