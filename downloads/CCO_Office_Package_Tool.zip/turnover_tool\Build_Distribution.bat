@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build_Distribution.ps1"
echo.
pause
endlocal
