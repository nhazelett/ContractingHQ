param(
    [string]$Destination = ""
)

$ErrorActionPreference = "Stop"

$toolDir = $PSScriptRoot
$distDir = Join-Path $toolDir "dist"
if ([string]::IsNullOrWhiteSpace($Destination)) {
    $Destination = Join-Path $distDir "CCO_Office_Package_Tool.zip"
}

$excludeDirs = @("__pycache__", "dist", ".git", ".venv", "Outputs")
$excludeFilePatterns = @("settings.env", "*.pyc", "*.pyo", "*.log")

function Test-ExcludedFile {
    param([string]$Name)
    foreach ($pattern in $excludeFilePatterns) {
        if ($Name -like $pattern) {
            return $true
        }
    }
    return $false
}

function Copy-CleanTree {
    param(
        [string]$Source,
        [string]$Target
    )

    New-Item -ItemType Directory -Path $Target -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        if ($_.PSIsContainer) {
            if ($excludeDirs -contains $_.Name) {
                return
            }
            Copy-CleanTree -Source $_.FullName -Target (Join-Path $Target $_.Name)
            return
        }

        if (Test-ExcludedFile -Name $_.Name) {
            return
        }
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $Target $_.Name) -Force
    }
}

New-Item -ItemType Directory -Path $distDir -Force | Out-Null
if (Test-Path -LiteralPath $Destination) {
    Remove-Item -LiteralPath $Destination -Force
}

$stagingRoot = Join-Path ([IO.Path]::GetTempPath()) ("cco_office_package_tool_" + [Guid]::NewGuid().ToString("N"))
$packageRoot = Join-Path $stagingRoot "CCO Office Package Tool"
$toolTarget = Join-Path $packageRoot "turnover_tool"

try {
    Copy-CleanTree -Source $toolDir -Target $toolTarget

    Copy-Item -LiteralPath (Join-Path $toolDir "README_DISTRIBUTION.md") -Destination (Join-Path $packageRoot "README_FIRST.md") -Force

    $launcherLines = @(
        "@echo off",
        "call ""%~dp0turnover_tool\Start Dashboard.bat"""
    )
    Set-Content -LiteralPath (Join-Path $packageRoot "Start Dashboard.bat") -Value $launcherLines -Encoding ASCII

    Compress-Archive -Path (Join-Path $packageRoot "*") -DestinationPath $Destination -Force
}
finally {
    if (Test-Path -LiteralPath $stagingRoot) {
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force
    }
}

Write-Host "Distribution zip created:"
Write-Host $Destination
