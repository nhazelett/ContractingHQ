@echo off
setlocal
cd /d "%~dp0"
set "BUNDLED_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%BUNDLED_PY%" (
  "%BUNDLED_PY%" "%~dp0dashboard.py"
) else (
  python "%~dp0dashboard.py"
)
if errorlevel 1 (
  echo.
  echo The dashboard did not start. If this is a downloaded copy, run Install Requirements.bat once and try again.
  pause
)
endlocal
