# CCO Turnover Package Generator

This tool creates mock contract action folders for CCO turnover exercises. It writes outputs under `Outputs` and leaves the original `Generators` sample untouched.

## Quick Start

From this folder:

Browser dashboard:

```powershell
.\Start Dashboard.bat
```

Or run it directly:

```powershell
$py = "C:\Users\nickh\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
& $py .\dashboard.py
```

The dashboard runs at `http://127.0.0.1:8765/` by default, with automatic port fallback if that port is busy. It supports one-action generation, append-to-package generation, action type selection, lifecycle stage selection, BPA/IDIQ awardee-count selection, parent BPA/IDIQ entry, recent package folder opening, and an in-browser sequential queue so several requirements can be stacked while the generator works through them one at a time.

Downloadable setup:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Build_Distribution.ps1
```

This writes `dist\CCO_Office_Package_Tool.zip`. See `README_DISTRIBUTION.md` for the install flow, optional user-owned API-key setup, and the files intentionally excluded from the zip.

Command line:

```powershell
$py = "C:\Users\nickh\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
& $py .\generate_turnover.py --scenario "T-Wall barriers for an entry control point"
```

Useful options:

```powershell
& $py .\generate_turnover.py --scenario "Janitorial services for mission support facilities" --type service
& $py .\generate_turnover.py --scenario "48 T-Wall barriers for ECP traffic control" --quantity 48
& $py .\generate_turnover.py --scenario "Minor repair of the wash rack drainage pad" --type construction
& $py .\generate_turnover.py --scenario "Generator rental support for an annex facility" --solicitation-style rfq-email
& $py .\generate_turnover.py --scenario "Facility support blanket purchase agreement" --type bpa
& $py .\generate_turnover.py --scenario "Base support IDIQ" --type idiq
& $py .\generate_turnover.py --scenario "Multiple award construction IDIQ" --type idiq --awardee-count 5
& $py .\generate_turnover.py --scenario "Office supply BPA" --type bpa --awardee-count 3
& $py .\generate_turnover.py --scenario "Generator repair call against the facility support BPA" --type bpa-call
& $py .\generate_turnover.py --scenario "Janitorial services call against facility support BPA" --type bpa-call --parent-number FA4867XXA0004
& $py .\generate_turnover.py --scenario "HVAC repair order off base support IDIQ" --type idiq-order --parent-number FA4867XXD0002
& $py .\generate_turnover.py --scenario "Bulk sand and concrete mix for drainage repairs" --ai-plan --ai-qa
& $py .\generate_turnover.py --count 35 --package-name "CCO Turnover Noise Package"
& $py .\generate_turnover.py --append-package "CCO Turnover Noise Package" --scenario "Hesco barriers for an ECP expansion"
& $py .\generate_turnover.py --scenario "Generator repair call against the facility support BPA" --type bpa-call --inject expired-parent
& $py .\generate_turnover.py --scenario "HVAC repair order off base support IDIQ" --type idiq-order --inject near-ceiling-parent
& $py .\generate_turnover.py --scenario "Facility support blanket purchase agreement" --type bpa --inject expired-vehicle
& $py .\generate_turnover.py --scenario "Janitorial call against facility BPA" --type bpa-call --inject random
```

The normal workflow is one scenario in, one contract action package out. Use `--append-package` when you want to add one or more new action folders into an existing mock office package. Batch generation still exists for later stress testing or noise-package scaling.

The prompt matcher uses curated archetypes when there is a confident match, such as T-Walls, Hescos, janitorial service, generator maintenance, BPA, or IDIQ. If the prompt is more creative or generic, the tool falls back to a custom requirement instead of forcing the nearest template. Bulk material prompts such as sand, concrete mix, cement, asphalt, fill dirt, and aggregate are treated as custom supply buys with material, delivery, and offload CLINs.

The preferred expansion path is a hybrid model: keep full archetypes for high-value training scenarios, then add lighter item profiles for routine buys. A profile can define names, units, quantity ranges, price ranges, and evaluation focus without needing a separate document template for every possible purchase.

## Variability (Personas and Phrase Banks)

Every action assigns one author persona to the CO and one to the customer side (requester/approver share it). Personas control email greetings, closings (`V/r,`, `Thanks,`, `Respectfully,`, etc.), verbosity, and a low rate of benign typos and spacing quirks in email bodies. Stock sentences in requirement emails, the RFQ, the MRR, evaluation rationale, tracker notes, and delivery confirmation rotate through seeded phrase banks, so different action files read like they were worked by different people. All choices are seeded from the contract number, so output stays deterministic for a given run.

Action files also get occasional benign extras: a vendor question and CO answer in the Solicitation folder, a funding cert correction in Funding, or a customer status follow-up in Initial. These resolve themselves inside the document and are never injects.

## Injects

`--inject` (repeatable; also exposed as checkboxes in the dashboard) plants a deliberate, catchable problem in an otherwise normal record. Each inject has a difficulty tier (obvious / moderate / subtle) recorded in the answer key so controllers can dial a package to the trainee's level.

Vehicle/parent injects:

- `expired-parent` (BPA calls / IDIQ orders): the parent vehicle's ordering period ended last fiscal year. If the master exists in the office, its Award folder gains the renewal-decision closeout thread; if it never existed, a thin archived master folder (closeout email + one-page vehicle summary marked EXPIRED) is created in Contract Files so students have a real file to find. The tracker, registry, and continuity binder corroborate.
- `near-ceiling-parent` (BPA calls / IDIQ orders): the parent's obligated amount leaves less headroom than this action's value.
- `call-limit-breach` (BPA calls): the call exceeds the parent's per-call purchase limit (Vehicles sheet "Call Limit" column).
- `out-of-scope-order` (calls/orders): the parent vehicle's scope plainly does not cover the order, though the MRR claims alignment.
- `expired-vehicle` (BPA/IDIQ masters): the master file generates as a prior-year record, and - decisively - its Award folder contains `Renewal decision email traffic.pdf`: a CO/customer thread documenting that the vehicle was NOT renewed and no further calls/orders are authorized. Students identify expiration from the record's own narrative, not from date math, since exercise months vary.
- `phantom-master` (any action): the tracker/registry lists an Active vehicle that has no folder anywhere on the drive.

Funding injects:

- `wrong-appropriation`: the Form 9 cites the wrong appropriation (3400 vs 3080) for the requirement type.
- `funding-shortfall`: the Form 9 certifies less than the award; the CLIN lines on the form do not sum to its grand total.
- `missing-certification`: the Form 9 certifying official block is blank.

Competition/evaluation injects:

- `unjustified-award`: a cheaper technically-acceptable quote was passed over with no documented discriminator in the decision document.
- `late-quote`: the awardee's quote shows a received date after the quotes-due deadline (Quote Receipt log now carries a Received column).
- `missing-tech-eval`: awarded file with no Tech Eval Req/Tech Eval; the decision document cites findings with no source.

File integrity injects:

- `entity-mismatch`: the award face page vendor code is transposed relative to the UEI in the MRR vendor survey.
- `pop-clin-mismatch` (service): PWS describes a 12-month base period; the CLIN is priced for 6 MO.
- `unsigned-award`: the CO signature block on the award face page is blank.
- `tracker-mismatch`: the workload tracker claims a stage ahead of what the action folder actually contains.
- `wrong-piid-letter`: the PIID instrument letter does not match the action type.
- `sam-inactive`: every evaluated file now includes a `Vendor Responsibility Screening.pdf`; this inject flips the awardee's SAM status to inactive/lapsed while award proceeds unaddressed.
- `adverse-past-performance`: creates an archived prior action on the drive where the same vendor delivered late/short/damaged, including a CO memo flagging the record for future evaluations - which this file's clean Past Performance Evaluation ignores.
- `random`: picks one inject applicable to the action's category; skipped with a console note if none applies.

Every inject writes a controller-only answer key at the package root: `_inject_key.json` and a readable `_inject_key.md` listing difficulty, what the CCO should catch, where the evidence lives, and the planted values. The controller manifest gets an `injects` column. Do not copy `_inject_key.*` into the trainee's mock office drive. With `--count` above 1, the requested injects land on one randomly selected action in the batch; single-action generation is the most predictable way to place a specific inject. Inject-mutated parent records stay in the package-level registry only and never pollute the global `Outputs\_vehicle_registry.json`.

## Office Admin Artifacts

Every generation or delete refreshes the office's `00. Office Admin` folder: `Contract Workload Tracker.xlsx` (Workload, Vehicles, Parent Links, Dashboard sheets - the walk-in tracker covering every contract file in the office) and `Continuity Binder.pdf` (persona-voiced turnover notes listing hot actions, open pre-award work, awarded actions awaiting receipt, and vehicle status). A seeded `GPC Purchase Log.xlsx` is written there once as ambient office texture (never overwritten).

Awarded files gain extra realism documents: every awarded service action includes a `COR Designation Letter.pdf`, and roughly one in five awarded actions includes a benign no-cost `Modification P00001.pdf` (administrative SF 30-style change).

## Office Builder

Describe the deployment scenario in plain language and the tool builds an entire clean office (no injects) sized to your exercise. Available as the "Build Entire Office from Scenario" panel in the dashboard, or:

```powershell
& $py .\generate_turnover.py --build-office "The CCO team is deploying to a bare base. Force protection buildup and initial bed-down are underway." --office-size 30 --office-duration long
```

The narrative drives the *mix* of files only - it is never printed into any document, so location masking is preserved. Theme detection (buildup / sustainment / drawdown) picks what kinds of buys appear. Duration shapes the office's maturity: **short-term** offices get few or no master vehicles, more open in-progress actions, and a heavy GPC purchase log (the card carries early operations); **long-term** offices get established BPAs/IDIQs with calls and orders riding them and mostly completed files. `--office-duration auto` (default) reads the narrative; the dashboard has an explicit selector. File count is 6-50 via `--office-size`.

The derived plan is saved to `_controller\_office_build_plan.json` - an ordinary exercise script you can edit and re-run with `--script`. The builder plants **no injects**; add them afterward with the Generate form (or CLI) pointed at the same office.

## Exercise Scripts, Export, and Validation

Build a whole exercise from a JSON definition (see `sample_exercise.json`):

```powershell
& $py .\generate_turnover.py --script .\sample_exercise.json
```

Each entry supports `scenario`, `type`, `stage`, `count`, `quantity`, `parent_number`, `solicitation_style`, and `injects`. A top-level `seed` makes the whole exercise reproducible.

Export a trainee-ready copy (controller files excluded) and integrity-check an office (both also available as dashboard buttons):

```powershell
& $py .\generate_turnover.py --export-trainee "Mock Office Drive"
& $py .\generate_turnover.py --validate "Mock Office Drive"
```

Exports land in `Outputs\_exports`. Validation flags any inconsistency on the drive that is NOT explained by a recorded inject (missing stage folders, orphaned folders, registry entries pointing nowhere, tracker drift without a tracker-mismatch inject) and writes `_controller\_validation_report.md`. Exit code 2 means problems were found; a clean run means every anomaly on the drive is one you planted. Run it before every class.

If Windows reports a path-too-long error while copying an older office, use the dashboard's `Shorten` button for that office or run:

```powershell
& $py .\generate_turnover.py --shorten-names "Mock Office Drive"
```

This renames generated files and folders to compact common-sense names such as `SOR.docx`, `RFQ.pdf`, `Decision.pdf`, `Award.pdf`, `3. Market Research`, and `9. Admin`. If an action folder is renamed, the manifest, workload tracker, vehicle registry, parent links, and continuity binder are refreshed so the tool still knows what it has. Multiple-award packets still keep the PIID and contractor name so awardees remain distinct.

## QC Regression

Run the built-in mixed-office regression after changing routing, PIIDs, deletion, awardee-count, or validation behavior:

```powershell
& $py .\generate_turnover.py --qc-regression
```

The dashboard also has a `Run QC` button in the Offices panel. QC generates temporary test offices, validates them, checks MACC/BPA award packet counts, checks construction commercial-clause handling, checks protected supply routing, and verifies deleted PIID placeholders.

## Deleting Contract Files and Offices

Use the dashboard (Delete button per office; Manage Contract Files panel for individual action folders) or the CLI:

```powershell
& $py .\generate_turnover.py --delete-action "Mock Office Drive/FA4867XXP0003 - HVAC Repair"
& $py .\generate_turnover.py --delete-package "Mock Office Drive"
```

Deletes are permanent and scrub everything that referenced the action: controller manifest, office vehicle registry, tracker, continuity binder, inject answer key, and the global vehicle registry. PIID sequence state is intentionally not rewound, so regenerated actions get fresh numbers - just like a real office never reuses a PIID.

## Codex Assist

Codex assist is optional. Use `--ai-plan --ai-qa` to let the local Codex CLI shape a small scenario/variation JSON before the deterministic generator builds the file, then write a controller-only `_ai_qa_report.md` after generation. The dashboard exposes this as the `Codex QA + variation` checkbox.

The Codex pass is intentionally bounded: it may suggest title, category, CLIN shape, quantity ranges, price ranges, evaluation focus, market notes, delivery notes, and a subtle variation profile for email/document texture. The generator still controls PIIDs, Form 9 numbers, 20XX date rules, folder structure, funding math, vendor selection, award forms, and validation. The local Codex runner strips API-key environment variables before launch so it uses the logged-in Codex CLI path instead of surprise API billing.

Known archetypes keep their generator category unless you explicitly force an action type in the dashboard. For example, T-Wall, Hesco, gravel, sand, and concrete-mix delivery remain normal `P` supply actions even if Codex describes delivery, placement, offload, setup, or incidental installation support. Use `construction` only for actual real-property construction, alteration, or repair.

An API-backed mode still exists for portability: add `--ai-provider api` if you intentionally want to use `OPENAI_API_KEY`. The normal local workflow should use the default `codex-cli` provider.

## CLINs

Archetypes may define one CLIN or multiple `line_items`. When multiple CLINs are present, the generator prorates each vendor quote across the line items and uses the sum as the Form 9, IGE, quote, award, and accounting total. Prompt quantity overrides apply to the first CLIN, which is normally the primary item or service quantity.

For quantity-sensitive supply buys, the tool now randomizes the quantity when the prompt does not state one. For example, repeated T-Wall and Hesco prompts will no longer default to the same count every time. If the prompt says `200 T-Walls`, that explicit quantity still controls.

## Requirement Support

The initial document folder always includes an SOR. Service requirements also generate a PWS with a performance requirements summary, surveillance methods, deliverables, and acceptance language. Construction/site-work requirements generate a SOW with work elements, coordination, safety, submittals, and inspection/acceptance language. Supply buys do not generate a PWS or SOW unless the requirement type is forced to service or construction.

Service requirements are normalized to a 12-month base period and `12 MO` CLIN quantity. Service documents describe the period as a one-year/base-period service instead of creating accidental six-month ending dates that could look like exercise injects.

## Market Research

The Market Research Report uses a dedicated memo format. It samples 3-5 vendors from the contractor pool, ties the memo back to the PR/Form 9 number, records vendor capability notes, and carries the streamlined evaluation approach into a short acquisition strategy/recommendation.

## Solicitation

Solicitations support two formats: `rfq-email` and `combined`. Auto mode uses an emailed RFQ for simpler low-dollar supply buys and a combined synopsis/solicitation for larger, service, or more complex buys. The RFQ email sends to the CO and lists vendors in Bcc. The combined format includes tailored commercial instructions, a Price/Past Performance/Technical evaluation approach, a clause/provision table, and service option language with FAR 52.217-8 and FAR 52.217-9 when applicable.

## Quotes

Every vendor identified in the Market Research Report is carried into `All Quotes.pdf`. Vendors may submit a quote or provide a no-quote/non-response. Submitted quotes rotate through different formats such as emailed quotes, letterhead quotations, estimate-style sheets, technical/price responses, and simple vendor quote forms. Each vendor response also gets its own accent color/header palette so the quotes do not look like they were all produced by the same template. Each response attempts to address the technical considerations from the solicitation; some responses intentionally omit a consideration so the technical evaluation and decision document have something realistic to catch.

## Evaluation

The technical evaluation request is a blank technical-consideration worksheet for the mission partner; it does not pre-fill ratings or ask the evaluator to assess price, past performance, or award selection. The technical evaluation response records the mission partner's technical findings only. If the solicitation identifies Past Performance as an evaluation factor, the evaluation folder includes a separate `Past Performance Evaluation.pdf`. The award decision document then includes the CO's quote abstract, past performance evaluation summary, price analysis, awardee technical findings, and best-value rationale.

## Email Documents

Email-looking artifacts are rendered through one Outlook-style thread writer so headers, signatures, dividers, attachment bars, and exercise markings stay consistent. Each scenario picks a CO, customer requester, approving official, vendors, and awardee once, then reuses that cast across the file so follow-up traffic tells a coherent story.

Email text is currently template-driven with scenario variables, duty-title variation, and selected cast members. It does not call an AI model for fresh prose on each run, which keeps packages repeatable and easier to QA.

## Output Shape

Outputs use a single-office model. Each office under `Outputs` is one exercise drive:

```
Outputs/
└── Mock Office Drive/                  (or a custom office name)
    ├── 00. Office Admin/
    │   ├── Contract Workload Tracker.xlsx
    │   ├── Continuity Binder.pdf
    │   └── GPC Purchase Log.xlsx
    ├── 01. Contract Files/
    │   ├── FA4867XXA0001 - Facility Support BPA/
    │   ├── FA4867XXP0001 - Janitorial Services/
    │   └── ...                          (flat, PIID order)
    └── _controller/                     (exercise control only - never give to trainees)
        ├── _controller_manifest.json / .csv
        ├── _vehicle_registry.json
        ├── _inject_key.json / .md
        └── AI plan/QA reports
```

Generation defaults to the `Mock Office Drive` office, creating it if missing and appending to it otherwise, so repeated runs build one coherent office. Use `--package-name` (or the dashboard Office Name field) for a different office, e.g. one per class. Handing the drive to a trainee = copy the office folder and delete `_controller`.

Each generated action gets the same lifecycle folder pattern as the sample `Generators` folder:

1. Initial
2. Funding
3. Market Research
4. Solicitation
5. Quotes
6. Evaluation
7. Award
8. Delivery

Single-scenario actions default to a complete file through delivery confirmation. Batch actions can stop at different stages to create realistic turnover noise.

Action folder names use the generated PIID and purchase name, for example `FA4867XXP0001 - Generators`. Batch mode keeps the controller manifest index sequential, but the PIID sequence may skip a number to imply an older rotation closed out an unrelated action.

Package, action, stage, and document names are intentionally shortened on disk so the generated PDFs open reliably from OneDrive/Windows Explorer. Long scenario prompts still appear inside the documents. Generation and QC also check a path-length budget so future naming changes do not quietly creep back toward common Windows path-length trouble spots.

PIID letters are assigned by instrument type: `P` for normal supply/service purchases, `C` for construction awards, `A` for BPA masters, `D` for IDIQ masters, and `F` for BPA calls or IDIQ task/delivery orders.

Append mode reads the existing package manifest and folder names before generating. It continues the PIID sequence after the highest existing action, preserves prior manifest rows, refreshes the workload tracker, and refuses to overwrite an existing action folder.

For `bpa-call` and `idiq-order`, the tool creates a parent BPA/IDIQ reference and carries it through the SOR, requirement emails, Form 9, market research, solicitation, quotes, evaluation, decision document, award, delivery confirmation, and controller manifest. Use `--parent-number` when you want the call/order tied to a specific master file you already generated; otherwise the tool assigns a reusable `FA4867XXA####` or `FA4867XXD####` parent number. These call/order actions still keep an underlying requirement category, so a janitorial BPA call will generate a PWS and a 12-month service period, while a commodity call remains a supply-style package.

New packages scan the existing `Outputs` history before assigning the next PIID, so separate one-action packages do not all restart at `FA4867XXP0001`. The generator also writes `_sequence_state.json` at the output root while reserving numbers, which prevents duplicate PIIDs if two dashboard generations are started very close together.

## Award Documents

Supply and service awards generate an 11-page SF 1449-style packet using the local template layout: a black-and-white face page with blocks 1-31, a large continuation schedule, UCF table of contents, Sections B through J, continuation of Blocks 25/26, a clause matrix, full-text clause pages, attachment list, and the diagonal training watermark. Service awards carry the 12-month base period and service clauses from the solicitation logic.

Construction awards generate an 18-page SF 1442-style packet: solicitation/offer/award pages, UCF table of contents, construction Section B pricing, Sections C through J, construction WAWF instructions, construction clause matrix, full-text/reference clause pages, and the same training watermark. Generated construction awards are capped below $2M to keep the files in the intended CCO training lane.

BPA master awards generate a 3-page SF 1449-style BPA package plus a unit-priced price list attachment: the face page shows `N/A - BPA MASTER` funding, `SEE BPA CALLS` order language, authorized-call controls, BPA terms, and clause/reference pages. BPAs carry **no ceiling** - they state a per-call purchase limitation (seeded among $10K/$15K/$25K/$50K) and reference the attached price list for unit prices; quantities exist only on calls. Quote totals are framed in the decision document as a representative-basket evaluation, never as a cap. Organic calls against a generated BPA automatically respect the parent's call limit (only the `call-limit-breach` inject violates it). BPA master funding folders use a no-funding memo instead of a Form 9 so the file does not imply the master agreement has obligated funds.

IDIQ masters use the SF 1449-style packet with IDIQ ordering clauses and a `D` PIID. Section B shows unit-priced ordering CLINs with estimated quantities (marked as estimates, not delivery requirements), a round-number ceiling (e.g. $1,500,000) independent of the evaluated quotes, and a guaranteed minimum. The face page Total Award Amount block reads `SEE SECTION B - MIN/MAX`. The `near-ceiling-parent` inject now applies only to IDIQ orders, since BPAs have no ceiling to approach.

## Date Rules

The generator intentionally keeps exercise files reusable:

- Calendar years are `20XX`.
- Fiscal years are `FYXX`.
- PIIDs use `FA4867XX...`.
- Form 9 / PR numbers use the no-dash `F2D3JXXXXXXX` style from the Form 9 builder.
- Email headers avoid weekday names so the kit does not become calendar-wrong next year.

## Controller Files

All exercise-control files live in the office's `_controller` folder: `_controller_manifest.json` / `.csv`, `_vehicle_registry.json`, `_inject_key.json` / `.md`, and any AI plan/QA reports. Nothing controller-only sits next to trainee-facing content anymore - strip the single `_controller` folder and the office drive is trainee-ready. The `Contract Workload Tracker.xlsx` in `00. Office Admin` is trainee-facing turnover documentation by design.

The persistent registry at `Outputs\_vehicle_registry.json` lets later one-off BPA calls or IDIQ orders find previously generated master vehicles. The office-level `_controller\_vehicle_registry.json` is a snapshot of vehicles and parent links relevant to that office.
